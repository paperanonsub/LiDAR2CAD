from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation
from sklearn.linear_model import LinearRegression, RANSACRegressor

from .errors import DataQualityError
from .transforms import transform_points


@dataclass
class FloorModel:
    z_ax_by_c: np.ndarray
    normal: np.ndarray
    inlier_count: int
    rmse_m: float
    z_level: float


@dataclass
class LeveledCloud:
    points: np.ndarray
    floor: FloorModel
    transform_level_from_input: np.ndarray
    ceiling_height_m: float | None


def voxel_downsample(points: np.ndarray, voxel_m: float, max_points: int | None = None) -> np.ndarray:
    points = np.asarray(points, dtype=float)
    finite = points[np.all(np.isfinite(points), axis=1)]
    if not len(finite):
        return finite
    keys = np.floor(finite / voxel_m).astype(np.int64)
    _, indices = np.unique(keys, axis=0, return_index=True)
    result = finite[np.sort(indices)]
    if max_points and len(result) > max_points:
        rng = np.random.default_rng(23)
        result = result[rng.choice(len(result), max_points, replace=False)]
    return result


def _floor_candidate_z(points: np.ndarray, bin_m: float = 0.05) -> float:
    z = points[:, 2]
    low, high = np.percentile(z, [1, 55])
    if high - low < bin_m:
        return float(np.median(z))
    edges = np.arange(low, high + bin_m, bin_m)
    counts, edges = np.histogram(z, bins=edges)
    # Favor broad lower horizontal surfaces over the median-height wall population.
    weighted = counts / (1.0 + 0.15 * np.arange(len(counts)))
    index = int(np.argmax(weighted))
    return float((edges[index] + edges[index + 1]) / 2)


def fit_floor(points: np.ndarray, residual_m: float = 0.06, min_inliers: int = 300) -> FloorModel:
    sample = voxel_downsample(points, 0.08, 200_000)
    if len(sample) < min_inliers:
        raise DataQualityError("Point cloud has too few points for floor fitting")
    z0 = _floor_candidate_z(sample)
    candidates = sample[np.abs(sample[:, 2] - z0) <= 0.18]
    if len(candidates) < min_inliers:
        raise DataQualityError("No stable horizontal floor candidate")
    estimator = RANSACRegressor(
        estimator=LinearRegression(),
        min_samples=max(3, min(100, len(candidates) // 10)),
        residual_threshold=residual_m,
        max_trials=100,
        random_state=23,
    )
    estimator.fit(candidates[:, :2], candidates[:, 2])
    inliers = estimator.inlier_mask_
    assert inliers is not None
    count = int(np.count_nonzero(inliers))
    if count < min_inliers:
        raise DataQualityError(f"Floor fit has only {count} inliers")
    a, b = estimator.estimator_.coef_
    c = float(estimator.estimator_.intercept_)
    predicted = estimator.predict(candidates[inliers, :2])
    rmse = float(np.sqrt(np.mean((predicted - candidates[inliers, 2]) ** 2)))
    normal = np.asarray([-a, -b, 1.0], dtype=float)
    normal /= np.linalg.norm(normal)
    if normal[2] < 0:
        normal *= -1
    if normal[2] < np.cos(np.deg2rad(20)) or rmse > 0.10:
        raise DataQualityError(f"Floor is not stable/horizontal enough (normal={normal}, RMSE={rmse:.3f} m)")
    return FloorModel(np.asarray([a, b, c]), normal, count, rmse, float(z0))


def level_cloud(points: np.ndarray) -> LeveledCloud:
    floor = fit_floor(points)
    rotation, _ = Rotation.align_vectors(np.asarray([[0.0, 0.0, 1.0]]), np.asarray([floor.normal]))
    transform = np.eye(4)
    transform[:3, :3] = rotation.as_matrix()
    point_on_floor = np.asarray([0.0, 0.0, floor.z_ax_by_c[2]])
    transform[2, 3] = -(transform[:3, :3] @ point_on_floor)[2]
    leveled = transform_points(points, transform)
    ceiling = detect_ceiling(leveled)
    return LeveledCloud(leveled, floor, transform, ceiling)


def detect_ceiling(points: np.ndarray, minimum_height_m: float = 2.0) -> float | None:
    z = points[:, 2]
    z = z[(z >= minimum_height_m) & (z <= np.percentile(z, 99.5))]
    if len(z) < 300:
        return None
    bin_m = 0.05
    counts, edges = np.histogram(z, bins=max(1, int(np.ptp(z) / bin_m)))
    if not len(counts) or int(np.max(counts)) < 100:
        return None
    index = int(np.argmax(counts))
    return float((edges[index] + edges[index + 1]) / 2)


def read_trajectory(path: str | Path | None) -> tuple[np.ndarray, np.ndarray] | None:
    if not path or not Path(path).is_file():
        return None
    data = np.genfromtxt(path, delimiter=",", names=True, dtype=float, encoding="utf-8")
    if data.size == 0:
        return None
    names = {name.lower(): name for name in (data.dtype.names or [])}
    required = [names.get(key) for key in ("timestamp", "x", "y", "z")]
    if any(value is None for value in required):
        raise DataQualityError(f"Trajectory needs timestamp,x,y,z columns: {path}")
    timestamps = np.atleast_1d(data[required[0]])
    xyz = np.column_stack([np.atleast_1d(data[name]) for name in required[1:]])
    return timestamps, xyz


def read_trajectory_pose(path: str | Path | None) -> tuple[np.ndarray, np.ndarray, np.ndarray | None] | None:
    basic = read_trajectory(path)
    if basic is None:
        return None
    timestamps, xyz = basic
    data = np.genfromtxt(path, delimiter=",", names=True, dtype=float, encoding="utf-8")
    names = {name.lower(): name for name in (data.dtype.names or [])}
    quaternion_names = [names.get(key) for key in ("qx", "qy", "qz", "qw")]
    quaternions = None
    if all(name is not None for name in quaternion_names):
        quaternions = np.column_stack([np.atleast_1d(data[name]) for name in quaternion_names])
    return timestamps, xyz, quaternions


def trajectory_quality(
    timestamps: np.ndarray,
    xyz: np.ndarray,
    max_jump_m: float = 0.5,
    quaternions_xyzw: np.ndarray | None = None,
    max_jump_deg: float = 20.0,
) -> dict:
    dt = np.diff(timestamps)
    jumps = np.linalg.norm(np.diff(xyz, axis=0), axis=1)
    rollback_count = int(np.count_nonzero(dt <= 0))
    jump_count = int(np.count_nonzero(jumps > max_jump_m))
    rotation_jump_count = 0
    max_rotation_jump_deg = 0.0
    if quaternions_xyzw is not None and len(quaternions_xyzw) > 1:
        rotations = Rotation.from_quat(quaternions_xyzw)
        relative = rotations[:-1].inv() * rotations[1:]
        angles = np.degrees(relative.magnitude())
        rotation_jump_count = int(np.count_nonzero(angles > max_jump_deg))
        max_rotation_jump_deg = float(np.max(angles))
    return {
        "sample_count": int(len(xyz)),
        "timestamp_rollback_count": rollback_count,
        "jump_count": jump_count,
        "max_jump_m": float(np.max(jumps)) if len(jumps) else 0.0,
        "rotation_jump_count": rotation_jump_count,
        "max_rotation_jump_deg": max_rotation_jump_deg,
        "continuous": rollback_count == 0 and jump_count == 0 and rotation_jump_count == 0,
    }


def vertical_structural_cells(
    points: np.ndarray,
    grid_m: float,
    height_bin_m: float,
    min_height_m: float,
    max_height_m: float,
    min_span_m: float,
    min_bins: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return structural points and their unique XY cell indices."""
    points = np.asarray(points, dtype=float)
    band = points[(points[:, 2] >= min_height_m) & (points[:, 2] <= max_height_m)]
    if not len(band):
        return band, np.empty((0, 2), dtype=np.int64)
    xy = np.floor(band[:, :2] / grid_m).astype(np.int64)
    zb = np.floor((band[:, 2] - min_height_m) / height_bin_m).astype(np.int64)
    xyz_keys = np.column_stack([xy, zb])
    unique = np.unique(xyz_keys, axis=0)
    order = np.lexsort((unique[:, 2], unique[:, 1], unique[:, 0]))
    unique = unique[order]
    xy_unique, start, counts = np.unique(unique[:, :2], axis=0, return_index=True, return_counts=True)
    z_min = unique[start, 2]
    z_max = unique[start + counts - 1, 2]
    spans = (z_max - z_min + 1) * height_bin_m
    # A wall/column should be present close to the floor, not only on a tall
    # shelf or hanging object. One missing first bin is tolerated for occlusion.
    keep = (counts >= min_bins) & (spans >= min_span_m) & (z_min <= 1)
    structural_cells = xy_unique[keep]
    if not len(structural_cells):
        return np.empty((0, 3)), structural_cells
    cell_set = {tuple(v) for v in structural_cells.tolist()}
    mask = np.fromiter((tuple(v) in cell_set for v in xy), dtype=bool, count=len(xy))
    return band[mask], structural_cells
