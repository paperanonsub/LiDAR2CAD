from __future__ import annotations

import math
from dataclasses import dataclass

import cv2
import numpy as np
from scipy.spatial import cKDTree

from .transforms import se2_matrix, transform_points


@dataclass
class RegistrationResult:
    transform_ref_from_moving: np.ndarray
    rmse_m: float
    overlap: float
    wall_direction_residual_deg: float
    accepted: bool
    score: float


def _occupancy(xy: np.ndarray, grid_m: float, origin: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    ij = np.floor((xy - origin) / grid_m).astype(int)
    valid = (ij[:, 0] >= 0) & (ij[:, 1] >= 0) & (ij[:, 0] < shape[1]) & (ij[:, 1] < shape[0])
    image = np.zeros(shape, np.float32)
    image[ij[valid, 1], ij[valid, 0]] = 1.0
    return image


def wall_directions(xy: np.ndarray, grid_m: float, peak_count: int = 4) -> np.ndarray:
    if len(xy) < 20:
        return np.asarray([0.0])
    lo = np.min(xy, axis=0) - grid_m
    hi = np.max(xy, axis=0) + grid_m
    shape = tuple(np.ceil((hi - lo) / grid_m).astype(int)[::-1].clip(8, 6000))
    image = (_occupancy(xy, grid_m, lo, shape) * 255).astype(np.uint8)
    lines = cv2.HoughLinesP(image, 1, np.pi / 180, threshold=20, minLineLength=max(5, int(0.8 / grid_m)), maxLineGap=max(2, int(0.3 / grid_m)))
    if lines is None:
        centered = xy - np.mean(xy, axis=0)
        vec = np.linalg.eigh(centered.T @ centered)[1][:, -1]
        return np.asarray([math.atan2(vec[1], vec[0]) % math.pi])
    histogram = np.zeros(180, dtype=float)
    for x1, y1, x2, y2 in np.asarray(lines).reshape(-1, 4):
        angle = math.atan2(y2 - y1, x2 - x1) % math.pi
        length = math.hypot(x2 - x1, y2 - y1)
        histogram[int(round(math.degrees(angle))) % 180] += length
    smoothed = np.convolve(np.r_[histogram[-3:], histogram, histogram[:3]], np.ones(7), mode="same")[3:-3]
    peaks = []
    values = smoothed.copy()
    for _ in range(peak_count):
        index = int(np.argmax(values))
        if values[index] <= 0:
            break
        peaks.append(math.radians(index))
        for delta in range(-8, 9):
            values[(index + delta) % 180] = 0
    return np.asarray(peaks or [0.0])


def _angle_distance(a: float, b: float) -> float:
    return abs((a - b + math.pi / 2) % math.pi - math.pi / 2)


def _initial_translation(ref_xy: np.ndarray, mov_xy_rotated: np.ndarray, grid_m: float) -> np.ndarray:
    t0 = np.median(ref_xy, axis=0) - np.median(mov_xy_rotated, axis=0)
    moved = mov_xy_rotated + t0
    center = np.median(np.vstack([ref_xy, moved]), axis=0)
    radius = np.max(np.abs(np.vstack([ref_xy, moved]) - center), axis=0) + 2.0
    shape_xy = np.ceil(2 * radius / grid_m).astype(int) + 1
    if np.any(shape_xy > 6000):
        # Keep the phase correlation bounded; ICP still refines the median alignment.
        return t0
    origin = center - radius
    shape = (int(shape_xy[1]), int(shape_xy[0]))
    ref_image = _occupancy(ref_xy, grid_m, origin, shape)
    mov_image = _occupancy(moved, grid_m, origin, shape)
    shift, response = cv2.phaseCorrelate(mov_image, ref_image)
    residual = np.asarray(shift) * grid_m
    if response > 0.01 and np.linalg.norm(residual) <= max(radius):
        return t0 + residual
    return t0


def _normals_2d(xy: np.ndarray, neighbors: int = 12) -> np.ndarray:
    tree = cKDTree(xy)
    _, indices = tree.query(xy, k=min(neighbors, len(xy)))
    local = xy[np.atleast_2d(indices)]
    centered = local - np.mean(local, axis=1, keepdims=True)
    xx = np.mean(centered[:, :, 0] ** 2, axis=1)
    yy = np.mean(centered[:, :, 1] ** 2, axis=1)
    xy_cov = np.mean(centered[:, :, 0] * centered[:, :, 1], axis=1)
    tangent_angle = 0.5 * np.arctan2(2.0 * xy_cov, xx - yy)
    normal_angle = tangent_angle + np.pi / 2
    return np.column_stack([np.cos(normal_angle), np.sin(normal_angle)])


def refine_se2_point_to_plane(
    ref_xy: np.ndarray,
    mov_xy: np.ndarray,
    initial: np.ndarray,
    max_iterations: int = 20,
    max_distance_m: float = 0.5,
) -> np.ndarray:
    transform = initial.copy()
    tree = cKDTree(ref_xy)
    normals = _normals_2d(ref_xy)
    for _ in range(max_iterations):
        moved = transform_points(np.column_stack([mov_xy, np.zeros(len(mov_xy))]), transform)[:, :2]
        distances, indices = tree.query(moved, k=1)
        mask = distances <= max_distance_m
        if np.count_nonzero(mask) < 20:
            break
        q = moved[mask]
        target = ref_xy[indices[mask]]
        n = normals[indices[mask]]
        residual = np.sum(n * (q - target), axis=1)
        design = np.column_stack([n[:, 0], n[:, 1], -n[:, 0] * q[:, 1] + n[:, 1] * q[:, 0]])
        # Trim dynamic objects and outliers before a robust least-squares increment.
        trim = np.abs(residual) <= np.quantile(np.abs(residual), 0.85)
        if np.count_nonzero(trim) < 10:
            break
        delta, *_ = np.linalg.lstsq(design[trim], -residual[trim], rcond=None)
        transform = se2_matrix(float(delta[2]), float(delta[0]), float(delta[1])) @ transform
        if np.linalg.norm(delta) < 1e-5:
            break
    return transform


def registration_metrics(ref_xy: np.ndarray, mov_xy: np.ndarray, transform: np.ndarray, support_m: float = 0.15) -> tuple[float, float]:
    moved = transform_points(np.column_stack([mov_xy, np.zeros(len(mov_xy))]), transform)[:, :2]
    distances, _ = cKDTree(ref_xy).query(moved, k=1)
    overlap = float(np.mean(distances <= support_m))
    supported = distances[distances <= max(0.5, support_m)]
    rmse = float(np.sqrt(np.mean(supported**2))) if len(supported) else float("inf")
    return rmse, overlap


def register_se2(ref_xy: np.ndarray, mov_xy: np.ndarray, cfg: dict) -> RegistrationResult:
    max_points = int(cfg.get("max_points", 50000))
    rng = np.random.default_rng(23)
    if len(ref_xy) > max_points:
        ref_xy = ref_xy[rng.choice(len(ref_xy), max_points, replace=False)]
    if len(mov_xy) > max_points:
        mov_xy = mov_xy[rng.choice(len(mov_xy), max_points, replace=False)]
    grid_m = float(cfg.get("grid_m", 0.05))
    ref_dirs = wall_directions(ref_xy, grid_m, int(cfg.get("yaw_candidate_peaks", 4)))
    mov_dirs = wall_directions(mov_xy, grid_m, int(cfg.get("yaw_candidate_peaks", 4)))
    candidates = []
    for ref_angle in ref_dirs:
        for mov_angle in mov_dirs:
            base = ref_angle - mov_angle
            candidates.extend([base, base + math.pi])
    unique_candidates = []
    for candidate in candidates:
        normalized = (candidate + math.pi) % (2 * math.pi) - math.pi
        if all(abs((normalized - existing + math.pi) % (2 * math.pi) - math.pi) > math.radians(1) for existing in unique_candidates):
            unique_candidates.append(normalized)
    candidates = unique_candidates[:12]
    best = None
    for yaw in candidates:
        rotation = np.asarray([[math.cos(yaw), -math.sin(yaw)], [math.sin(yaw), math.cos(yaw)]])
        rotated = mov_xy @ rotation.T
        translation = _initial_translation(ref_xy, rotated, grid_m)
        initial = se2_matrix(yaw, translation[0], translation[1])
        refined = refine_se2_point_to_plane(ref_xy, mov_xy, initial)
        rmse, overlap = registration_metrics(ref_xy, mov_xy, refined)
        final_yaw = math.atan2(refined[1, 0], refined[0, 0])
        moved_dirs = np.asarray([(a + final_yaw) % math.pi for a in mov_dirs])
        direction_residual = min(_angle_distance(a, b) for a in ref_dirs for b in moved_dirs)
        direction_deg = math.degrees(direction_residual)
        score = overlap - min(rmse, 1.0) - direction_deg / 100.0
        current = (score, refined, rmse, overlap, direction_deg)
        if best is None or current[0] > best[0]:
            best = current
    assert best is not None
    score, transform, rmse, overlap, direction_deg = best
    accepted = (
        overlap >= float(cfg.get("overlap_min", 0.35))
        and rmse <= float(cfg.get("rmse_max_m", 0.15))
        and direction_deg <= float(cfg.get("wall_direction_max_deg", 5.0))
    )
    return RegistrationResult(transform, rmse, overlap, direction_deg, accepted, score)
