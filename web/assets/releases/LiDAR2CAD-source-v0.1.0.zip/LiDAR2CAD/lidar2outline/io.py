from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import open3d as o3d


def ensure_dirs(root: str | Path) -> dict[str, Path]:
    root = Path(root)
    dirs = {name: root / name for name in ("inspect", "calibration", "slam", "maps", "transforms", "cad", "qa", "logs")}
    root.mkdir(parents=True, exist_ok=True)
    for directory in dirs.values():
        directory.mkdir(parents=True, exist_ok=True)
    return dirs


def write_json(path: str | Path, value: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def fingerprint(paths: Iterable[str | Path], config_section: Any, version: str = "1") -> str:
    h = hashlib.sha256(version.encode())
    h.update(json.dumps(config_section, sort_keys=True, default=str).encode())
    for item in sorted((Path(p) for p in paths), key=lambda p: str(p)):
        h.update(str(item.resolve()).encode())
        if item.exists():
            stat = item.stat()
            h.update(f"{stat.st_size}:{stat.st_mtime_ns}".encode())
    return h.hexdigest()


def cache_valid(manifest: str | Path, digest: str, outputs: Iterable[str | Path]) -> bool:
    path = Path(manifest)
    if not path.is_file() or not all(Path(p).is_file() for p in outputs):
        return False
    try:
        return read_json(path).get("fingerprint") == digest
    except (OSError, ValueError):
        return False


def _read_pcd_xyz(path: Path) -> np.ndarray:
    header: dict[str, list[str]] = {}
    with path.open("rb") as stream:
        while True:
            line = stream.readline()
            if not line:
                raise ValueError(f"PCD header has no DATA line: {path}")
            decoded = line.decode("ascii").strip()
            if not decoded or decoded.startswith("#"):
                continue
            key, *values = decoded.split()
            header[key.upper()] = values
            if key.upper() == "DATA":
                data_pos = stream.tell()
                break
        fields = header.get("FIELDS") or header.get("FIELD")
        sizes = [int(value) for value in header.get("SIZE", [])]
        types = header.get("TYPE", [])
        counts = [int(value) for value in header.get("COUNT", ["1"] * len(fields or []))]
        point_count = int((header.get("POINTS") or header.get("WIDTH") or ["0"])[0])
        if not fields or not {"x", "y", "z"}.issubset(fields):
            raise ValueError(f"PCD has no x/y/z fields: {path}")
        if not (len(fields) == len(sizes) == len(types) == len(counts)):
            raise ValueError(f"Inconsistent PCD field metadata: {path}")
        data_kind = header["DATA"][0].lower()
        if data_kind == "ascii":
            stream.seek(data_pos)
            array = np.loadtxt(stream, dtype=float, ndmin=2)
            offsets = np.cumsum([0, *counts[:-1]])
            return array[:, [offsets[fields.index(axis)] for axis in ("x", "y", "z")]]
        if data_kind == "binary":
            type_map = {
                ("F", 4): "<f4",
                ("F", 8): "<f8",
                ("I", 1): "i1",
                ("I", 2): "<i2",
                ("I", 4): "<i4",
                ("I", 8): "<i8",
                ("U", 1): "u1",
                ("U", 2): "<u2",
                ("U", 4): "<u4",
                ("U", 8): "<u8",
            }
            dtype_fields = []
            for name, type_code, size, count in zip(fields, types, sizes, counts):
                base = type_map.get((type_code.upper(), size))
                if base is None:
                    raise ValueError(f"Unsupported PCD type {type_code}{size}: {path}")
                dtype_fields.append((name, base) if count == 1 else (name, base, (count,)))
            stream.seek(data_pos)
            records = np.frombuffer(stream.read(), dtype=np.dtype(dtype_fields), count=point_count)
            return np.column_stack([records[axis] for axis in ("x", "y", "z")]).astype(np.float64)
    raise ValueError(f"Compressed PCD requires Open3D fallback: {path}")


def read_point_cloud(path: str | Path) -> np.ndarray:
    path = Path(path)
    try:
        if path.suffix.lower() != ".pcd":
            raise ValueError("Use Open3D for non-PCD formats")
        points = _read_pcd_xyz(path)
    except (UnicodeDecodeError, ValueError) as direct_error:
        # Open3D supports PCD binary_compressed, but some Windows builds cannot
        # open Unicode paths. An ASCII-only temporary basename avoids that bug.
        temporary_path = None
        try:
            source = path
            if any(ord(character) > 127 for character in str(path)):
                temporary = tempfile.NamedTemporaryFile(suffix=path.suffix, delete=False)
                temporary_path = Path(temporary.name)
                temporary.close()
                shutil.copyfile(path, temporary_path)
                source = temporary_path
            cloud = o3d.io.read_point_cloud(str(source), remove_nan_points=True, remove_infinite_points=True)
            points = np.asarray(cloud.points, dtype=np.float64)
        finally:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
        if not len(points):
            raise direct_error
    if points.ndim != 2 or points.shape[1] != 3 or len(points) == 0:
        raise ValueError(f"Point cloud is empty or invalid: {path}")
    return points[np.all(np.isfinite(points), axis=1)]


def write_point_cloud(path: str | Path, points: np.ndarray) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cloud = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(np.asarray(points, dtype=np.float64)))
    if not o3d.io.write_point_cloud(str(path), cloud, write_ascii=False, compressed=True):
        raise OSError(f"Could not write point cloud: {path}")
