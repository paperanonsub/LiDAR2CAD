from __future__ import annotations

import hashlib
import json
import math
import os
import re
import tempfile
import threading
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

import cv2
import numpy as np
from shapely.geometry import Polygon

from .io import read_json, read_point_cloud
from .semantic_objects import extend_semantic_review_batch, prepare_semantic_label_manifest


LABELS = {"wall", "column", "non_building", "unknown"}
SAFE_ID = re.compile(r"^[A-Za-z0-9_-]+$")


def _normalise_roi(value: Any) -> list[float] | None:
    """Validate a human-drawn XY extent in reference-map metres."""
    if value is None:
        return None
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise ValueError("roi_ref must be [xmin, ymin, xmax, ymax] or null")
    roi = [float(item) for item in value]
    if not all(math.isfinite(item) for item in roi):
        raise ValueError("roi_ref contains a non-finite coordinate")
    if roi[2] - roi[0] < 0.05 or roi[3] - roi[1] < 0.05:
        raise ValueError("roi_ref must be at least 5 cm wide and high")
    if roi[2] - roi[0] > 30.0 or roi[3] - roi[1] > 30.0:
        raise ValueError("roi_ref is unexpectedly large")
    return roi


def _normalise_roi_polygon(value: Any) -> list[list[float]] | None:
    """Validate and explicitly close a human-drawn reference-frame polygon."""
    if value is None:
        return None
    if not isinstance(value, (list, tuple)) or len(value) < 3:
        raise ValueError("roi_polygon_ref must contain at least three vertices")
    vertices: list[list[float]] = []
    for point in value:
        if not isinstance(point, (list, tuple)) or len(point) != 2:
            raise ValueError("each roi_polygon_ref vertex must be [x, y]")
        vertex = [float(point[0]), float(point[1])]
        if not all(math.isfinite(item) for item in vertex):
            raise ValueError("roi_polygon_ref contains a non-finite coordinate")
        if not vertices or np.linalg.norm(np.asarray(vertex) - np.asarray(vertices[-1])) > 1e-6:
            vertices.append(vertex)
    if len(vertices) >= 2 and np.linalg.norm(np.asarray(vertices[0]) - np.asarray(vertices[-1])) <= 1e-6:
        vertices.pop()
    if len(vertices) < 3:
        raise ValueError("roi_polygon_ref must contain three distinct vertices")
    polygon = Polygon(vertices)
    if not polygon.is_valid:
        raise ValueError("roi_polygon_ref must not self-intersect")
    if polygon.area < 0.0025:
        raise ValueError("roi_polygon_ref area must be at least 0.0025 square metres")
    xmin, ymin, xmax, ymax = polygon.bounds
    if xmax - xmin > 30.0 or ymax - ymin > 30.0:
        raise ValueError("roi_polygon_ref is unexpectedly large")
    return [*vertices, vertices[0]]


def _polygon_bounds(value: list[list[float]]) -> list[float]:
    array = np.asarray(value, dtype=float)
    return [
        float(np.min(array[:, 0])),
        float(np.min(array[:, 1])),
        float(np.max(array[:, 0])),
        float(np.max(array[:, 1])),
    ]


def _atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False
    ) as stream:
        stream.write(payload)
        temporary = Path(stream.name)
    os.replace(temporary, path)


def _object_geometry(value: dict) -> np.ndarray:
    if "primitive" in value:
        return np.asarray(value["primitive"]["coordinates_ref"], dtype=float)
    return np.asarray(value.get("coordinates_ref", []), dtype=float)


def _draw_top_view(
    points: np.ndarray,
    geometry: np.ndarray,
    size: tuple[int, int],
    title: str,
    z_min: float | None = None,
    z_max: float | None = None,
) -> tuple[np.ndarray, dict | None]:
    width, height = size
    canvas = np.zeros((height, width, 3), np.uint8)
    selected = points
    if z_min is not None and z_max is not None:
        selected = points[(points[:, 2] >= z_min) & (points[:, 2] < z_max)]
    xy_source = selected[:, :2] if len(selected) else points[:, :2]
    if not len(xy_source):
        cv2.putText(canvas, "NO POINTS", (12, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (80, 80, 255), 2)
        return canvas, None
    combined = np.vstack([xy_source, geometry]) if len(geometry) else xy_source
    lower = np.min(combined, axis=0)
    upper = np.max(combined, axis=0)
    span = np.maximum(upper - lower, 0.5)
    margin = span * 0.10 + 0.10
    lower -= margin
    upper += margin
    scale = min((width - 24) / max(upper[0] - lower[0], 1e-6), (height - 54) / max(upper[1] - lower[1], 1e-6))

    def project(xy: np.ndarray) -> np.ndarray:
        pixel = np.empty_like(xy, dtype=float)
        pixel[:, 0] = 12 + (xy[:, 0] - lower[0]) * scale
        pixel[:, 1] = height - 12 - (xy[:, 1] - lower[1]) * scale
        return np.round(pixel).astype(np.int32)

    if len(selected):
        pixels = project(selected[:, :2])
        low_z = float(np.quantile(points[:, 2], 0.01))
        high_z = float(np.quantile(points[:, 2], 0.99))
        normalized = np.clip((selected[:, 2] - low_z) / max(high_z - low_z, 1e-6), 0, 1)
        colors = cv2.applyColorMap(
            np.round(normalized * 255).astype(np.uint8).reshape(-1, 1),
            cv2.COLORMAP_TURBO,
        )[:, 0, :]
        valid = (pixels[:, 0] >= 0) & (pixels[:, 0] < width) & (pixels[:, 1] >= 0) & (pixels[:, 1] < height)
        canvas[pixels[valid, 1], pixels[valid, 0]] = colors[valid]
    if len(geometry) >= 2:
        closed = len(geometry) > 3 and np.linalg.norm(geometry[0] - geometry[-1]) > 1e-6
        cv2.polylines(canvas, [project(geometry)], closed, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(canvas, title, (12, 27), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (245, 245, 245), 1, cv2.LINE_AA)
    return canvas, {
        "lower_ref": lower.tolist(),
        "upper_ref": upper.tolist(),
        "scale_px_per_m": float(scale),
        "width_px": width,
        "height_px": height,
        "plot_left_px": 12,
        "plot_bottom_px": 12,
    }


def _draw_isometric(points: np.ndarray, geometry: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    width, height = size
    canvas = np.zeros((height, width, 3), np.uint8)
    if not len(points):
        return canvas
    centered = points.copy()
    centered[:, :2] -= np.mean(points[:, :2], axis=0)
    centered[:, 2] -= np.min(points[:, 2])
    yaw = math.radians(-45.0)
    pitch = math.radians(32.0)
    rotation_z = np.asarray([[math.cos(yaw), -math.sin(yaw), 0], [math.sin(yaw), math.cos(yaw), 0], [0, 0, 1]])
    rotation_x = np.asarray([[1, 0, 0], [0, math.cos(pitch), -math.sin(pitch)], [0, math.sin(pitch), math.cos(pitch)]])
    projected = centered @ (rotation_x @ rotation_z).T
    uv = projected[:, :2]
    lower, upper = np.min(uv, axis=0), np.max(uv, axis=0)
    scale = min((width - 24) / max(upper[0] - lower[0], 1e-6), (height - 54) / max(upper[1] - lower[1], 1e-6))
    pixels = np.column_stack([12 + (uv[:, 0] - lower[0]) * scale, height - 12 - (uv[:, 1] - lower[1]) * scale]).astype(int)
    normalized = np.clip((points[:, 2] - np.min(points[:, 2])) / max(float(np.ptp(points[:, 2])), 1e-6), 0, 1)
    colors = cv2.applyColorMap(
        np.round(normalized * 255).astype(np.uint8).reshape(-1, 1),
        cv2.COLORMAP_TURBO,
    )[:, 0, :]
    valid = (pixels[:, 0] >= 0) & (pixels[:, 0] < width) & (pixels[:, 1] >= 0) & (pixels[:, 1] < height)
    canvas[pixels[valid, 1], pixels[valid, 0]] = colors[valid]
    cv2.putText(canvas, "3D LOCAL VIEW", (12, 27), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (245, 245, 245), 1, cv2.LINE_AA)
    return canvas


def _write_object_view(path: Path, value: dict, points: np.ndarray) -> dict | None:
    geometry = _object_geometry(value)
    if not len(geometry):
        return None
    lower = np.min(geometry, axis=0) - 1.2
    upper = np.max(geometry, axis=0) + 1.2
    local = points[
        (points[:, 0] >= lower[0])
        & (points[:, 0] <= upper[0])
        & (points[:, 1] >= lower[1])
        & (points[:, 1] <= upper[1])
    ]
    if len(local) > 40000:
        seed = int(hashlib.sha1(value["object_id"].encode()).hexdigest()[:8], 16)
        local = local[np.random.default_rng(seed).choice(len(local), 40000, replace=False)]
    if not len(local):
        local = points[:1]
    z_low, z_high = np.quantile(local[:, 2], [0.01, 0.99])
    edges = np.linspace(z_low, z_high + 1e-6, 4)
    all_view, top_mapping = _draw_top_view(local, geometry, (520, 660), "ALL HEIGHTS")
    bands = [
        _draw_top_view(local, geometry, (310, 220), f"Z {edges[index]:.2f}-{edges[index + 1]:.2f} m", edges[index], edges[index + 1])[0]
        for index in range(3)
    ]
    band_stack = np.vstack(bands)
    iso = _draw_isometric(local, geometry, (520, 660))
    canvas = np.hstack([all_view, band_stack, iso])
    header = np.zeros((70, canvas.shape[1], 3), np.uint8)
    primitive = value.get("primitive", {}).get("kind", value.get("shape", "unknown"))
    dimensions = value.get("dimensions_m")
    detail = f"candidate={value.get('class')}  confidence={value.get('confidence', 0):.2f}  model={primitive}"
    if dimensions:
        detail += f"  size={dimensions[0]:.2f} x {dimensions[1]:.2f} m"
    cv2.putText(header, value["object_id"], (15, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(header, detail, (15, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (190, 220, 255), 1, cv2.LINE_AA)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), np.vstack([header, canvas]))
    if top_mapping is None:
        return None
    return {
        "image_width_px": int(canvas.shape[1]),
        "image_height_px": int(canvas.shape[0] + header.shape[0]),
        "top_view": {
            **top_mapping,
            "image_left_px": 0,
            "image_top_px": int(header.shape[0]),
        },
    }


def prepare_label_views(source_dir: str | Path, labels_path: str | Path) -> dict:
    source_dir = Path(source_dir).resolve()
    labels_path = Path(labels_path).resolve()
    graph = read_json(source_dir / "building_object_graph.json")
    labels = read_json(labels_path)
    points = read_point_cloud(source_dir / "clean_interior.pcd")
    objects = {
        value["object_id"]: value
        for key in ("walls", "columns", "uncertain")
        for value in graph.get(key, [])
    }
    views_dir = source_dir / "semantic_label_views"
    generated = 0
    missing = []
    metadata: dict[str, dict] = {}
    for record in labels.get("records", []):
        if not record.get("suggested_for_review", False):
            continue
        object_id = str(record.get("object_id", ""))
        value = objects.get(object_id)
        if value is None or not SAFE_ID.fullmatch(object_id):
            missing.append(object_id)
            continue
        view_metadata = _write_object_view(views_dir / f"{object_id}.png", value, points)
        if view_metadata is None:
            missing.append(object_id)
            continue
        metadata[object_id] = view_metadata
        generated += 1
    metadata_path = views_dir / "metadata.json"
    _atomic_write_json(metadata_path, metadata)
    return {
        "generated": generated,
        "missing": missing,
        "views_dir": str(views_dir),
        "metadata_path": str(metadata_path),
    }


HTML = r"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>V13 建筑对象语义标注</title>
<style>
:root{color-scheme:dark;--bg:#101318;--panel:#191e26;--muted:#91a0b6;--line:#303949;--accent:#38bdf8}
*{box-sizing:border-box} body{margin:0;background:var(--bg);color:#eef3fa;font-family:Inter,"Microsoft YaHei",sans-serif}
header{height:68px;padding:12px 20px;background:#141922;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:18px;position:sticky;top:0;z-index:5}
h1{font-size:19px;margin:0}.meta{color:var(--muted);font-size:13px}.progress{margin-left:auto;min-width:260px}.bar{height:8px;background:#28303d;border-radius:5px;overflow:hidden}.bar i{display:block;height:100%;background:var(--accent)}
main{display:grid;grid-template-columns:minmax(620px,1fr) 360px;gap:16px;padding:16px;max-width:1900px;margin:auto}.viewer,.controls{background:var(--panel);border:1px solid var(--line);border-radius:12px;overflow:hidden}.viewer{display:flex;align-items:flex-start;justify-content:center;background:#000}.viewer canvas{display:block;max-width:100%;max-height:calc(100vh - 105px);width:auto;height:auto;background:#000;cursor:crosshair}.controls{padding:18px;height:calc(100vh - 105px);overflow:auto}
.object-title{font-size:22px;font-weight:700}.badges{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 18px}.badge{padding:4px 8px;background:#262f3d;border-radius:999px;color:#cbd5e1;font-size:12px}
.buttons{display:grid;grid-template-columns:1fr 1fr;gap:10px}.label{border:1px solid var(--line);border-radius:9px;padding:14px 8px;color:white;font-size:15px;cursor:pointer}.label:hover,.label.active{outline:2px solid white}.wall{background:#166534}.column{background:#0369a1}.non_building{background:#9f1239}.unknown{background:#6b4f0e}.clear{background:#374151}
.nav{display:flex;gap:8px;margin-top:14px}.nav button,.toolbar button,.toolbar select,.toolbar input{background:#293241;color:#eef3fa;border:1px solid #445067;border-radius:7px;padding:9px}.nav button,.toolbar button,.toolbar select{cursor:pointer}.toolbar input{width:145px}.nav button{flex:1}.toolbar{display:flex;gap:8px;margin:16px 0;flex-wrap:wrap}textarea{width:100%;min-height:90px;background:#10151d;color:white;border:1px solid var(--line);border-radius:8px;padding:10px}.help{color:var(--muted);font-size:13px;line-height:1.7;margin-top:18px}.status{min-height:24px;color:#7dd3fc;margin-top:8px}
@media(max-width:1000px){main{grid-template-columns:1fr}.viewer canvas{height:auto}.controls{height:auto}}
</style></head>
<body><header><div><h1>V13 建筑对象语义标注</h1><div class="meta" id="path"></div></div><div class="progress"><div id="progressText" class="meta"></div><div class="bar"><i id="progressBar"></i></div></div></header>
<main><section class="viewer"><canvas id="view" aria-label="对象多高度与三维视图"></canvas></section><aside class="controls">
<div class="object-title" id="objectId"></div><div class="badges"><span class="badge" id="candidate"></span><span class="badge" id="split"></span><span class="badge" id="position"></span></div>
<div class="buttons"><button class="label wall" data-label="wall">1　墙 wall</button><button class="label column" data-label="column">2　柱 column</button><button class="label non_building" data-label="non_building">3　非建筑</button><button class="label unknown" data-label="unknown">4　未知</button></div>
<div class="nav"><button id="prev">← 上一个</button><button id="clear" class="clear">0 清除</button><button id="next">下一个 →</button></div>
<div class="toolbar"><select id="filter"><option value="unlabelled">只看未标注</option><option value="all">全部推荐对象</option><option value="labelled">只看已标注</option></select><button id="jump">跳到首个未标注</button><input id="objectSearch" placeholder="例如 column-0112"><button id="findObject">定位对象</button><button id="editRoi">多点圈选</button><button id="undoPoint">撤销一点</button><button id="finishRoi">完成闭合</button><button id="clearRoi">清除圈选</button></div>
<label class="meta" for="notes">备注（失焦时自动保存）</label><textarea id="notes" placeholder="例如：车辆；两面可见但柱宽不确定；真实曲墙……"></textarea><div class="status" id="status"></div>
<div class="help"><b>判断原则</b><br>墙：固定建筑墙面，包括曲墙和核心筒边界。<br>柱：固定竖向柱体；不要仅凭“矩形”判断。<br>非建筑：车辆、桌椅、设备、杂物或噪声。<br>未知：证据不足，宁可未知，不要猜。<br><br><b>多点圈选修正</b><br>点击“多点圈选”，只在左侧 ALL HEIGHTS 面板依次点击轮廓点；点击“完成闭合”或按 Enter 生成闭合紫色多段线。Backspace 撤销一点，Esc 取消本次绘制。后续特征提取只使用多边形内部点云。<br><br>快捷键：1/2/3/4 标注，0 清除，←/→ 切换。每次点击立即写入 JSON。</div>
</aside></main>
<script>
let state={records:[],labelsPath:""}, index=0, loadedImage=null, polygonMode=false, polygonDraft=[];
const $=id=>document.getElementById(id);
function visible(){const f=$("filter").value;return state.records.filter(r=>f==="all"||(f==="unlabelled"?!r.label:!!r.label));}
function current(){const list=visible();if(!list.length)return null;index=Math.max(0,Math.min(index,list.length-1));return list[index];}
function canvasPoint(event){const c=$("view"),rect=c.getBoundingClientRect();return[(event.clientX-rect.left)*c.width/rect.width,(event.clientY-rect.top)*c.height/rect.height];}
function refFromPixel(point,r){const m=r.view_metadata&&r.view_metadata.top_view;if(!m)return null;const x=Math.max(m.image_left_px,Math.min(m.image_left_px+m.width_px,point[0]));const y=Math.max(m.image_top_px,Math.min(m.image_top_px+m.height_px,point[1]));return[m.lower_ref[0]+(x-m.image_left_px-m.plot_left_px)/m.scale_px_per_m,m.lower_ref[1]+(m.height_px-m.plot_bottom_px-(y-m.image_top_px))/m.scale_px_per_m];}
function pixelFromRef(point,r){const m=r.view_metadata&&r.view_metadata.top_view;if(!m)return null;return[m.image_left_px+m.plot_left_px+(point[0]-m.lower_ref[0])*m.scale_px_per_m,m.image_top_px+m.height_px-m.plot_bottom_px-(point[1]-m.lower_ref[1])*m.scale_px_per_m];}
function drawPolyline(ctx,points,closed,draft){if(!points||!points.length)return;ctx.save();ctx.strokeStyle="#ff4fd8";ctx.fillStyle="#ff4fd8";ctx.lineWidth=4;ctx.setLineDash(draft?[9,6]:[]);ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);for(let i=1;i<points.length;i++)ctx.lineTo(points[i][0],points[i][1]);if(closed)ctx.closePath();ctx.stroke();ctx.setLineDash([]);for(const p of points){ctx.beginPath();ctx.arc(p[0],p[1],6,0,Math.PI*2);ctx.fill();}ctx.restore();}
function drawCanvas(){const c=$("view"),ctx=c.getContext("2d"),r=current();if(!loadedImage||!r)return;ctx.clearRect(0,0,c.width,c.height);ctx.drawImage(loadedImage,0,0);if(r.roi_polygon_ref){const points=r.roi_polygon_ref.slice(0,-1).map(p=>pixelFromRef(p,r)).filter(Boolean);drawPolyline(ctx,points,true,false);}else if(r.roi_ref){const box=r.roi_ref,p0=pixelFromRef([box[0],box[1]],r),p1=pixelFromRef([box[2],box[3]],r);if(p0&&p1)drawPolyline(ctx,[[p0[0],p0[1]],[p1[0],p0[1]],[p1[0],p1[1]],[p0[0],p1[1]]],true,false);}if(polygonDraft.length){drawPolyline(ctx,polygonDraft,false,true);}}
function loadImage(r){const image=new Image();image.onload=()=>{loadedImage=image;const c=$("view");c.width=image.naturalWidth;c.height=image.naturalHeight;drawCanvas()};image.src=`/views/${encodeURIComponent(r.object_id)}.png?${Date.now()}`;}
function render(){const list=visible(),r=current(),done=state.records.filter(x=>x.label).length,total=state.records.length;$("progressText").textContent=`已完成 ${done} / ${total}`;$("progressBar").style.width=`${100*done/Math.max(total,1)}%`;$("path").textContent=state.labelsPath;if(!r){$("objectId").textContent="当前筛选条件下没有对象";return;}$("objectId").textContent=r.object_id;$("candidate").textContent=`算法候选：${r.candidate_class}${r.roi_polygon_ref?' · 已人工圈选':(r.roi_ref?' · 旧矩形范围':'')}`;$("split").textContent=`split：${r.split}`;$("position").textContent=`${index+1} / ${list.length}`;$("notes").value=r.notes||"";document.querySelectorAll(".label").forEach(b=>b.classList.toggle("active",b.dataset.label===r.label));$("editRoi").style.outline=polygonMode?"2px solid #ff4fd8":"";loadImage(r);}
async function save(label,advance=true){const r=current();if(!r)return;const payload={object_id:r.object_id,label:label,notes:$("notes").value,roi_ref:r.roi_ref||null,roi_polygon_ref:r.roi_polygon_ref||null};const response=await fetch("/api/label",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const value=await response.json();if(!response.ok){$("status").textContent=value.error||"保存失败";return;}Object.assign(r,value.record);$("status").textContent=`已保存 ${r.object_id} → ${r.label||"未标注"}${r.roi_polygon_ref?'（含闭合多段线）':(r.roi_ref?'（含旧矩形）':'')}`;if(label&&advance){const list=visible();if(index<list.length-1)index++;}render();}
function finishPolygon(){const r=current();if(!r||polygonDraft.length<3){$("status").textContent="至少需要三个轮廓点";return;}const vertices=polygonDraft.map(p=>refFromPixel(p,r)).filter(Boolean);if(vertices.length<3)return;r.roi_polygon_ref=[...vertices,vertices[0]];const xs=vertices.map(p=>p[0]),ys=vertices.map(p=>p[1]);r.roi_ref=[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)];polygonDraft=[];polygonMode=false;save(r.label,false);}
function findObject(id){const requested=(id||$("objectSearch").value).trim();if(!requested)return;$("filter").value="all";const list=visible(),found=list.findIndex(r=>r.object_id===requested);if(found<0){$("status").textContent=`未找到推荐对象 ${requested}`;return;}index=found;$("objectSearch").value=requested;render();}
async function load(){const response=await fetch("/api/state");state=await response.json();state.records=state.records.filter(r=>r.suggested_for_review);const requested=new URLSearchParams(location.search).get("object");if(requested)findObject(requested);else render();}
document.querySelectorAll(".label").forEach(b=>b.onclick=()=>save(b.dataset.label));$("clear").onclick=()=>save(null,false);$("prev").onclick=()=>{index--;polygonDraft=[];polygonMode=false;render()};$("next").onclick=()=>{index++;polygonDraft=[];polygonMode=false;render()};$("filter").onchange=()=>{index=0;polygonDraft=[];polygonMode=false;render()};$("jump").onclick=()=>{$("filter").value="unlabelled";index=0;render()};$("findObject").onclick=()=>findObject();$("objectSearch").onkeydown=e=>{if(e.key==="Enter")findObject()};$("notes").onblur=()=>{const r=current();if(r)save(r.label,false)};$("editRoi").onclick=()=>{polygonMode=!polygonMode;polygonDraft=[];$("status").textContent=polygonMode?"请在左侧 ALL HEIGHTS 图中逐点点击轮廓":"已取消圈选";drawCanvas()};$("undoPoint").onclick=()=>{polygonDraft.pop();drawCanvas()};$("finishRoi").onclick=finishPolygon;$("clearRoi").onclick=()=>{const r=current();if(r){r.roi_ref=null;r.roi_polygon_ref=null;polygonDraft=[];polygonMode=false;save(r.label,false)}};
$("view").onclick=e=>{const r=current(),m=r&&r.view_metadata&&r.view_metadata.top_view;if(!polygonMode||!m)return;const p=canvasPoint(e);if(p[0]<m.image_left_px||p[0]>m.image_left_px+m.width_px||p[1]<m.image_top_px||p[1]>m.image_top_px+m.height_px)return;polygonDraft.push(p);$("status").textContent=`已添加 ${polygonDraft.length} 个点`;drawCanvas()};
window.onkeydown=e=>{if(document.activeElement===$("notes")||document.activeElement===$("objectSearch"))return;if(polygonMode&&e.key==="Enter"){e.preventDefault();finishPolygon();return}if(polygonMode&&e.key==="Backspace"){e.preventDefault();polygonDraft.pop();drawCanvas();return}if(polygonMode&&e.key==="Escape"){polygonDraft=[];polygonMode=false;drawCanvas();return}const map={"1":"wall","2":"column","3":"non_building","4":"unknown","0":null};if(e.key in map)save(map[e.key]);else if(e.key==="ArrowLeft"){index--;render()}else if(e.key==="ArrowRight"){index++;render()}};load();
</script></body></html>"""


class LabelServer(ThreadingHTTPServer):
    def __init__(self, address, labels_path: Path, views_dir: Path, view_metadata: dict[str, dict]):
        super().__init__(address, LabelHandler)
        self.labels_path = labels_path
        self.views_dir = views_dir
        self.view_metadata = view_metadata
        self.write_lock = threading.Lock()


class LabelHandler(BaseHTTPRequestHandler):
    server: LabelServer

    def _json(self, value: Any, status: int = 200) -> None:
        payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path == "/":
            payload = HTML.encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if parsed.path == "/api/state":
            value = read_json(self.server.labels_path)
            records = []
            for source in value.get("records", []):
                record = dict(source)
                record["view_metadata"] = self.server.view_metadata.get(
                    str(record.get("object_id", ""))
                )
                records.append(record)
            self._json({"records": records, "labelsPath": str(self.server.labels_path)})
            return
        if parsed.path.startswith("/views/") and parsed.path.endswith(".png"):
            object_id = unquote(parsed.path[len("/views/") : -4])
            if not SAFE_ID.fullmatch(object_id):
                self.send_error(HTTPStatus.BAD_REQUEST)
                return
            path = self.server.views_dir / f"{object_id}.png"
            if not path.is_file():
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            payload = path.read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)
            return
        self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        if urlparse(self.path).path != "/api/label":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            request = json.loads(self.rfile.read(length).decode("utf-8"))
            object_id = str(request.get("object_id", ""))
            label = request.get("label")
            notes = str(request.get("notes", ""))[:2000]
            roi_polygon_ref = _normalise_roi_polygon(request.get("roi_polygon_ref"))
            roi_ref = (
                _polygon_bounds(roi_polygon_ref)
                if roi_polygon_ref is not None
                else _normalise_roi(request.get("roi_ref"))
            )
            if not SAFE_ID.fullmatch(object_id) or (label is not None and label not in LABELS):
                raise ValueError("invalid object id or label")
            with self.server.write_lock:
                value = read_json(self.server.labels_path)
                record = next((item for item in value.get("records", []) if item.get("object_id") == object_id), None)
                if record is None:
                    raise ValueError("unknown object id")
                previous_roi = (record.get("roi_ref"), record.get("roi_polygon_ref"))
                record["label"] = label
                record["notes"] = notes
                if roi_ref is None:
                    record.pop("roi_ref", None)
                    record.pop("roi_polygon_ref", None)
                    record.pop("roi_source", None)
                else:
                    record["roi_ref"] = roi_ref
                    if roi_polygon_ref is not None:
                        record["roi_polygon_ref"] = roi_polygon_ref
                        record["roi_source"] = "human_closed_polyline"
                    else:
                        record.pop("roi_polygon_ref", None)
                        record["roi_source"] = "human_box"
                current_roi = (record.get("roi_ref"), record.get("roi_polygon_ref"))
                if previous_roi != current_roi:
                    record.pop("sonata_embedding", None)
                    record.pop("sonata_point_count", None)
                    record.pop("sonata_embedding_scope", None)
                _atomic_write_json(self.server.labels_path, value)
            self._json({"ok": True, "record": record})
        except (ValueError, OSError, json.JSONDecodeError) as exc:
            self._json({"error": str(exc)}, 400)

    def log_message(self, format: str, *args: Any) -> None:
        return


def run_semantic_label_ui(
    source_dir: str | Path,
    labels_path: str | Path,
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = True,
    cfg: dict | None = None,
    extend_review_by: int = 0,
) -> None:
    source_dir = Path(source_dir).resolve()
    labels_path = Path(labels_path).resolve()
    cfg = cfg or {}
    prepare_semantic_label_manifest(
        source_dir,
        labels_path,
        dataset_id=cfg.get("semantic_dataset_id"),
        dataset_role=cfg.get("semantic_dataset_role"),
    )
    if extend_review_by > 0:
        extend_semantic_review_batch(labels_path, extend_review_by)
    report = prepare_label_views(source_dir, labels_path)
    view_metadata = read_json(report["metadata_path"])
    server = LabelServer(
        (host, int(port)), labels_path, Path(report["views_dir"]), view_metadata
    )
    url = f"http://{host}:{port}/"
    print(f"Semantic label UI: {url}")
    print(f"Labels: {labels_path}")
    print(f"Views generated: {report['generated']}; missing: {len(report['missing'])}")
    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
