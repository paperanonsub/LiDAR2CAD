from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString

from .io import read_json, read_point_cloud, write_json


LABELS = ("wall", "column", "non_building", "unknown")
TRAIN_LABELS = ("wall", "column", "non_building")


def merge_joint_wall_manifests(
    labels_paths: list[str | Path], output_path: str | Path
) -> dict:
    """Merge completed full-map ROI labels for a joint binary wall task."""
    if not labels_paths:
        raise ValueError("at least one semantic label manifest is required")
    manifests = [read_json(path) for path in labels_paths]
    feature_names = manifests[0].get("feature_names", [])
    records: list[dict] = []
    datasets: list[str] = []
    seen: set[str] = set()
    counts = {"wall": 0, "non_wall": 0}
    for path, manifest in zip(labels_paths, manifests):
        if manifest.get("feature_names", []) != feature_names:
            raise ValueError("semantic manifests use inconsistent feature vectors")
        dataset_id = str(
            next(
                (record.get("dataset_id") for record in manifest.get("records", []) if record.get("dataset_id")),
                Path(path).parent.name,
            )
        )
        datasets.append(dataset_id)
        for source in manifest.get("records", []):
            record = dict(source)
            sample_id = str(record.get("sample_id", f"{dataset_id}:{record.get('object_id')}"))
            if sample_id in seen:
                raise ValueError(f"duplicate joint semantic sample: {sample_id}")
            seen.add(sample_id)
            record["sample_id"] = sample_id
            record["dataset_id"] = dataset_id
            record["split"] = "joint"
            if record.get("label") == "column":
                record["source_semantic_label"] = "column"
                record["label"] = "non_wall"
                record["label_source"] = "manual_column_is_non_wall_for_binary_task"
            elif record.get("label") not in ("wall", "non_wall"):
                record["label"] = None
            records.append(record)
            if record.get("label") in counts:
                counts[record["label"]] += 1
    if min(counts.values()) == 0:
        raise ValueError(f"joint wall labels require both classes; found {counts}")
    result = {
        "schema_version": "semantic-joint-wall-v1",
        "training_task": "wall_binary_joint",
        "train_labels": ["wall", "non_wall"],
        "dataset_ids": sorted(set(datasets)),
        "source_manifests": [str(Path(path).resolve()) for path in labels_paths],
        "feature_names": feature_names,
        "record_count": len(records),
        "labelled_count": int(sum(record.get("label") in counts for record in records)),
        "class_counts": counts,
        "records": records,
        "evaluation_note": "all reviewed maps participate; no dataset is reserved as train/val/test",
    }
    write_json(output_path, result)
    return {key: value for key, value in result.items() if key != "records"}


def _train_joint_wall_head(
    labels_path: str | Path, output_dir: str | Path, cfg: dict
) -> dict:
    """Fit a binary wall head on every reviewed map, without a held-out split."""
    manifest = read_json(labels_path)
    train_labels = tuple(manifest.get("train_labels", ["wall", "non_wall"]))
    if train_labels != ("wall", "non_wall"):
        raise ValueError(f"unsupported joint labels: {train_labels}")
    all_records = manifest.get("records", [])
    labelled = [record for record in all_records if record.get("label") in train_labels]
    minimum = int(cfg.get("semantic_training_min_labelled_objects", 24))
    if len(labelled) < minimum:
        raise ValueError(f"Only {len(labelled)} joint wall labels are available; at least {minimum} are required")
    try:
        import torch
        from torch import nn
    except ImportError as exc:
        raise ValueError("PyTorch is required for train-semantics") from exc

    def record_array(record: dict) -> np.ndarray:
        return np.asarray(record.get("feature_vector", []), dtype=np.float32)

    arrays = [record_array(record) for record in all_records]
    widths = {len(value) for value in arrays}
    if len(widths) != 1 or not widths or next(iter(widths)) == 0:
        raise ValueError("Joint wall records have inconsistent or empty feature vectors")
    labelled_mask_np = np.asarray([record.get("label") in train_labels for record in all_records], dtype=bool)
    x_all_raw = torch.tensor(np.asarray(arrays), dtype=torch.float32)
    x_labelled_raw = x_all_raw[torch.tensor(labelled_mask_np)]
    mean = x_labelled_raw.mean(0)
    std = x_labelled_raw.std(0).clamp_min(1e-6)
    x_all = (x_all_raw - mean) / std
    x = x_all[torch.tensor(labelled_mask_np)]
    label_index = {label: index for index, label in enumerate(train_labels)}
    y = torch.tensor([label_index[record["label"]] for record in labelled], dtype=torch.long)
    class_count = torch.bincount(y, minlength=len(train_labels)).float()
    class_weight = class_count.sum() / class_count.clamp_min(1)
    hidden = int(cfg.get("semantic_head_hidden_channels", 64))
    seeds = [int(value) for value in cfg.get("semantic_training_seeds", [23, 47, 89])]
    maximum_epochs = int(cfg.get("semantic_head_max_epochs", 300))
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    run_reports: list[dict] = []
    selected: tuple[float, dict, dict] | None = None
    for seed in seeds:
        torch.manual_seed(seed)
        model = nn.Sequential(
            nn.Linear(x.shape[1], hidden),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden, len(train_labels)),
        )
        optimiser = torch.optim.AdamW(
            model.parameters(),
            lr=float(cfg.get("semantic_head_learning_rate", 1e-3)),
            weight_decay=float(cfg.get("semantic_head_weight_decay", 1e-4)),
        )
        criterion = nn.CrossEntropyLoss(weight=class_weight)
        best_loss = float("inf")
        best_state = None
        stale = 0
        for _ in range(maximum_epochs):
            model.train()
            optimiser.zero_grad()
            loss = criterion(model(x), y)
            loss.backward()
            optimiser.step()
            value = float(loss.detach())
            if value < best_loss - 1e-6:
                best_loss = value
                best_state = {key: item.detach().cpu().clone() for key, item in model.state_dict().items()}
                stale = 0
            else:
                stale += 1
            if stale >= int(cfg.get("semantic_head_patience", 35)):
                break
        model.load_state_dict(best_state)
        model.eval()
        with torch.inference_mode():
            predicted = model(x).argmax(1)
        metrics: dict[str, float] = {"fit_accuracy": float((predicted == y).float().mean())}
        for name, index in label_index.items():
            tp = int(torch.sum((predicted == index) & (y == index)))
            fp = int(torch.sum((predicted == index) & (y != index)))
            fn = int(torch.sum((predicted != index) & (y == index)))
            metrics[f"fit_{name}_precision"] = tp / max(tp + fp, 1)
            metrics[f"fit_{name}_recall"] = tp / max(tp + fn, 1)
        checkpoint = output_dir / f"joint_wall_head_seed_{seed}.pt"
        torch.save(
            {
                "state_dict": best_state,
                "input_mean": mean,
                "input_std": std,
                "labels": list(train_labels),
                "backend": "geometric_object_mlp",
                "input_channels": int(x.shape[1]),
                "hidden_channels": hidden,
                "training_scope": "all reviewed maps",
            },
            checkpoint,
        )
        row = {"seed": seed, "checkpoint": str(checkpoint), "fit_loss": best_loss, "metrics": metrics}
        run_reports.append(row)
        if selected is None or best_loss < selected[0]:
            selected = (best_loss, best_state, row)
    assert selected is not None
    selected_state = selected[1]
    selected_row = selected[2]
    model = nn.Sequential(
        nn.Linear(x_all.shape[1], hidden), nn.GELU(), nn.Dropout(0.15), nn.Linear(hidden, len(train_labels))
    )
    model.load_state_dict(selected_state)
    model.eval()
    with torch.inference_mode():
        probabilities = torch.softmax(model(x_all), dim=1).cpu().numpy()
    predictions = {}
    for record, values in zip(all_records, probabilities):
        index = int(np.argmax(values))
        key = record.get("sample_id", record.get("object_id"))
        predictions[key] = {
            "object_id": record.get("object_id"),
            "sample_id": key,
            "dataset_id": record.get("dataset_id"),
            "label": train_labels[index],
            "confidence": float(values[index]),
            "probabilities": {label: float(values[label_index[label]]) for label in train_labels},
        }
    result = {
        "training_task": "wall_binary_joint",
        "backend": "geometric_object_mlp",
        "train_labels": list(train_labels),
        "dataset_ids": manifest.get("dataset_ids", []),
        "labelled_count": len(labelled),
        "class_counts": {label: int(class_count[index]) for label, index in label_index.items()},
        "runs": run_reports,
        "selected_checkpoint": selected_row["checkpoint"],
        "fit_metrics": selected_row["metrics"],
        "object_predictions": predictions,
        "prediction_coverage": 1.0,
        "model_trained": True,
        "automatic_filtering_enabled": False,
        "evaluation_note": "No held-out split by user request; fit metrics are not generalisation metrics.",
        "sonata_status": "not used; this checkpoint is the geometric-feature MLP baseline",
    }
    write_json(output_dir / "semantic_training_report.json", result)
    return result


def _object_point_indices(value: dict, points: np.ndarray, radius_m: float) -> np.ndarray:
    if "primitive" in value:
        line = LineString(value["primitive"]["coordinates_ref"])
        count = max(2, int(np.ceil(line.length / 0.10)) + 1)
        samples = np.asarray(
            [line.interpolate(distance).coords[0] for distance in np.linspace(0, line.length, count)]
        )
        tree = cKDTree(points[:, :2])
        groups = tree.query_ball_point(samples, radius_m)
        return np.unique(np.fromiter((index for group in groups for index in group), dtype=np.int64))
    coordinates = np.asarray(value.get("coordinates_ref", []), dtype=float)
    if not len(coordinates):
        return np.empty(0, np.int64)
    center = np.mean(coordinates, axis=0)
    radius = float(np.max(np.linalg.norm(coordinates - center, axis=1))) + radius_m
    return np.flatnonzero(np.linalg.norm(points[:, :2] - center, axis=1) <= radius)


def _review_point_indices(record: dict, value: dict, points: np.ndarray, radius_m: float) -> np.ndarray:
    """Use a human-corrected extent instead of a faulty candidate geometry."""
    polygon_value = record.get("roi_polygon_ref")
    if isinstance(polygon_value, list) and len(polygon_value) >= 4:
        polygon = np.asarray(polygon_value, dtype=float)
        if np.all(np.isfinite(polygon)):
            if np.linalg.norm(polygon[0] - polygon[-1]) <= 1e-6:
                polygon = polygon[:-1]
            if len(polygon) >= 3:
                xmin, ymin = np.min(polygon, axis=0)
                xmax, ymax = np.max(polygon, axis=0)
                candidates = np.flatnonzero(
                    (points[:, 0] >= xmin)
                    & (points[:, 0] <= xmax)
                    & (points[:, 1] >= ymin)
                    & (points[:, 1] <= ymax)
                )
                xy = points[candidates, :2]
                inside = np.zeros(len(xy), dtype=bool)
                x, y = xy[:, 0], xy[:, 1]
                previous = polygon[-1]
                for current in polygon:
                    crossing = (current[1] > y) != (previous[1] > y)
                    x_crossing = (previous[0] - current[0]) * (y - current[1]) / (
                        previous[1] - current[1] + 1e-15
                    ) + current[0]
                    inside ^= crossing & (x < x_crossing)
                    previous = current
                return candidates[inside]
    roi = record.get("roi_ref")
    if isinstance(roi, list) and len(roi) == 4:
        xmin, ymin, xmax, ymax = (float(item) for item in roi)
        if xmax > xmin and ymax > ymin and np.all(np.isfinite([xmin, ymin, xmax, ymax])):
            padding = min(0.05, max(radius_m, 0.0))
            return np.flatnonzero(
                (points[:, 0] >= xmin - padding)
                & (points[:, 0] <= xmax + padding)
                & (points[:, 1] >= ymin - padding)
                & (points[:, 1] <= ymax + padding)
            )
    return _object_point_indices(value, points, radius_m)


def extract_sonata_object_embeddings(
    labels_path: str | Path,
    source_dir: str | Path,
    cfg: dict,
) -> dict:
    """Attach frozen Sonata/PTv3 embeddings to reviewed-candidate records."""
    try:
        import open3d as o3d
        import torch
        import sonata
    except ImportError as exc:
        raise ValueError(
            "Sonata feature extraction requires the official `sonata` package, "
            "its CUDA-compatible spconv build, Open3D and PyTorch"
        ) from exc
    labels_path = Path(labels_path)
    source_dir = Path(source_dir)
    manifest = read_json(labels_path)
    graph = read_json(source_dir / "building_object_graph.json")
    points = read_point_cloud(source_dir / "clean_interior.pcd")
    objects = {
        value["object_id"]: value
        for key in ("walls", "columns", "uncertain")
        for value in graph.get(key, [])
    }
    if not torch.cuda.is_available():
        raise ValueError("Sonata/PTv3 embedding extraction requires the CUDA GPU")
    try:
        import flash_attn  # noqa: F401
        model = sonata.load("sonata", repo_id="facebook/sonata").cuda()
    except ImportError:
        model = sonata.load(
            "sonata",
            repo_id="facebook/sonata",
            custom_config={"enc_patch_size": [256] * 5, "enable_flash": False},
        ).cuda()
    model.eval()
    transform = sonata.transform.default()
    maximum_points = int(cfg.get("semantic_sonata_max_object_points", 50000))
    radius_m = float(cfg.get("semantic_sonata_object_context_m", 0.35))
    rng = np.random.default_rng(int(cfg.get("semantic_sonata_seed", 23)))
    extracted = 0
    skipped = []
    for record in manifest.get("records", []):
        value = objects.get(record.get("object_id"))
        if value is None:
            skipped.append({"object_id": record.get("object_id"), "reason": "missing_object"})
            continue
        indices = _review_point_indices(record, value, points, radius_m)
        if len(indices) < int(cfg.get("semantic_sonata_min_object_points", 128)):
            skipped.append({"object_id": record["object_id"], "reason": "insufficient_points", "point_count": len(indices)})
            continue
        if len(indices) > maximum_points:
            indices = rng.choice(indices, maximum_points, replace=False)
        crop = np.asarray(points[indices], dtype=np.float32)
        cloud = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(crop.astype(np.float64)))
        cloud.estimate_normals(
            search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.20, max_nn=32)
        )
        normal = np.asarray(cloud.normals, dtype=np.float32)
        # B2 contains no RGB. A constant neutral colour preserves the expected
        # six-channel interface without pretending intensity is colour.
        data = {
            "coord": crop,
            "color": np.full((len(crop), 3), 127.5, dtype=np.float32),
            "normal": normal,
        }
        data = transform(data)
        with torch.inference_mode():
            for key, item in list(data.items()):
                if isinstance(item, torch.Tensor):
                    data[key] = item.cuda(non_blocking=True)
            encoded = model(data)
            while "pooling_parent" in encoded.keys():
                parent = encoded.pop("pooling_parent")
                inverse = encoded.pop("pooling_inverse")
                parent.feat = torch.cat([parent.feat, encoded.feat[inverse]], dim=-1)
                encoded = parent
            feature = encoded.feat.float()
            embedding = torch.cat([feature.mean(0), feature.amax(0)]).cpu().numpy()
        record["sonata_embedding"] = embedding.astype(float).tolist()
        record["sonata_point_count"] = int(len(crop))
        record["sonata_embedding_scope"] = (
            "human_roi" if record.get("roi_ref") is not None else "candidate_geometry"
        )
        extracted += 1
    manifest["sonata_features"] = {
        "backend": "facebook/sonata",
        "frozen": True,
        "object_embedding": "concatenated mean and max pooled PTv3 feature",
        "rgb_policy": "constant neutral because B2 PCD has no RGB",
        "intensity_policy": "unavailable in reused V12 cleaned XYZ cloud; not fabricated",
        "extracted_count": extracted,
        "skipped": skipped,
    }
    write_json(labels_path, manifest)
    return manifest["sonata_features"]


def validate_label_manifest(path: str | Path) -> dict:
    value = read_json(path)
    records = value.get("records", [])
    invalid = [
        record.get("object_id")
        for record in records
        if record.get("label") is not None and record.get("label") not in LABELS
    ]
    duplicate_ids = []
    seen = set()
    for record in records:
        object_id = record.get("object_id")
        if object_id in seen:
            duplicate_ids.append(object_id)
        seen.add(object_id)
    if invalid or duplicate_ids:
        raise ValueError(
            f"Invalid semantic labels={invalid}; duplicate object ids={duplicate_ids}"
        )
    labelled = [record for record in records if record.get("label") is not None]
    by_split = {
        split: sum(record.get("split") == split for record in labelled)
        for split in ("train", "val", "test")
    }
    by_class = {
        label: sum(record.get("label") == label for record in labelled)
        for label in LABELS
    }
    return {
        "record_count": len(records),
        "labelled_count": len(labelled),
        "by_split": by_split,
        "by_class": by_class,
        "records": records,
        "feature_names": value.get("feature_names", []),
    }


def train_semantic_head(
    labels_path: str | Path,
    output_dir: str | Path,
    cfg: dict,
) -> dict:
    """Train the auditable two-layer object head after human labels exist.

    Sonata embeddings are accepted in each record as ``sonata_embedding``.
    When the configured backend requires Sonata, their absence is a hard stop:
    geometric features must not be presented as pretrained semantic features.
    """
    manifest = read_json(labels_path)
    if manifest.get("training_task") == "wall_column_point_joint_v14":
        from .semantic_v14 import train_v14_point_head

        return train_v14_point_head(labels_path, output_dir, cfg)
    if manifest.get("training_task") == "wall_binary_joint":
        return _train_joint_wall_head(labels_path, output_dir, cfg)
    report = validate_label_manifest(labels_path)
    all_records = report["records"]
    records = [record for record in all_records if record.get("label") in TRAIN_LABELS]
    ignored_unknown_count = sum(record.get("label") == "unknown" for record in all_records)
    minimum = int(cfg.get("semantic_training_min_labelled_objects", 24))
    if len(records) < minimum:
        raise ValueError(
            f"Only {len(records)} reviewed objects are available; at least {minimum} are required"
        )
    for split in ("train", "val", "test"):
        if not any(record.get("split") == split for record in records):
            raise ValueError(f"Reviewed semantic labels contain no {split} objects")
    backend = str(cfg.get("semantic_feature_backend", "sonata_ptv3")).lower()
    require_sonata = backend == "sonata_ptv3"
    if require_sonata and any(not record.get("sonata_embedding") for record in records):
        raise ValueError(
            "Sonata/PTv3 embeddings are missing from one or more reviewed objects; "
            "semantic training stopped rather than substituting pseudo features"
        )
    try:
        import torch
        from torch import nn
    except ImportError as exc:
        raise ValueError("PyTorch is required for train-semantics") from exc

    label_index = {label: index for index, label in enumerate(TRAIN_LABELS)}
    def record_array(record: dict) -> np.ndarray:
        feature = np.asarray(record.get("feature_vector", []), dtype=np.float32)
        embedding = np.asarray(record.get("sonata_embedding", []), dtype=np.float32)
        return np.r_[embedding, feature]

    arrays = [record_array(record) for record in records]
    widths = {len(value) for value in arrays}
    if len(widths) != 1 or not widths or next(iter(widths)) == 0:
        raise ValueError("Semantic training records have inconsistent or empty feature vectors")
    x = torch.tensor(np.asarray(arrays), dtype=torch.float32)
    y = torch.tensor([label_index[record["label"]] for record in records], dtype=torch.long)
    split_masks = {
        split: torch.tensor([record.get("split") == split for record in records], dtype=torch.bool)
        for split in ("train", "val", "test")
    }
    mean = x[split_masks["train"]].mean(0)
    std = x[split_masks["train"]].std(0).clamp_min(1e-6)
    x = (x - mean) / std
    class_count = torch.bincount(
        y[split_masks["train"]], minlength=len(TRAIN_LABELS)
    ).float()
    class_weight = torch.where(class_count > 0, class_count.sum() / class_count.clamp_min(1), 0.0)
    hidden = int(cfg.get("semantic_head_hidden_channels", 64))
    seeds = [int(value) for value in cfg.get("semantic_training_seeds", [23, 47, 89])]
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    run_reports = []
    best_run = None
    best_model_state = None
    for seed in seeds:
        torch.manual_seed(seed)
        model = nn.Sequential(
            nn.Linear(x.shape[1], hidden),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden, len(TRAIN_LABELS)),
        )
        optimiser = torch.optim.AdamW(
            model.parameters(),
            lr=float(cfg.get("semantic_head_learning_rate", 1e-3)),
            weight_decay=float(cfg.get("semantic_head_weight_decay", 1e-4)),
        )
        criterion = nn.CrossEntropyLoss(weight=class_weight)
        best_state = None
        best_val = -1.0
        stale = 0
        for _ in range(int(cfg.get("semantic_head_max_epochs", 300))):
            model.train()
            optimiser.zero_grad()
            loss = criterion(model(x[split_masks["train"]]), y[split_masks["train"]])
            loss.backward()
            optimiser.step()
            model.eval()
            with torch.inference_mode():
                predicted = model(x[split_masks["val"]]).argmax(1)
                accuracy = float((predicted == y[split_masks["val"]]).float().mean())
            if accuracy > best_val + 1e-9:
                best_val = accuracy
                best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                stale = 0
            else:
                stale += 1
            if stale >= int(cfg.get("semantic_head_patience", 35)):
                break
        model.load_state_dict(best_state)
        model.eval()
        with torch.inference_mode():
            logits = model(x)
            predictions = logits.argmax(1)
        metrics = {}
        for split, mask in split_masks.items():
            target = y[mask]
            predicted = predictions[mask]
            metrics[f"{split}_accuracy"] = float((target == predicted).float().mean())
            for name, index in label_index.items():
                tp = int(torch.sum((predicted == index) & (target == index)))
                fp = int(torch.sum((predicted == index) & (target != index)))
                fn = int(torch.sum((predicted != index) & (target == index)))
                metrics[f"{split}_{name}_precision"] = tp / max(tp + fp, 1)
                metrics[f"{split}_{name}_recall"] = tp / max(tp + fn, 1)
        checkpoint = output_dir / f"semantic_head_seed_{seed}.pt"
        torch.save(
            {
                "state_dict": best_state,
                "input_mean": mean,
                "input_std": std,
                "labels": LABELS,
                "backend": backend,
                "input_channels": int(x.shape[1]),
                "hidden_channels": hidden,
            },
            checkpoint,
        )
        row = {"seed": seed, "checkpoint": str(checkpoint), "metrics": metrics}
        run_reports.append(row)
        if best_run is None or metrics["val_accuracy"] > best_run["metrics"]["val_accuracy"]:
            best_run = row
            best_model_state = best_state
    predictable = [
        record
        for record in all_records
        if (not require_sonata or bool(record.get("sonata_embedding")))
    ]
    prediction_arrays = [record_array(record) for record in predictable]
    object_predictions = {}
    if prediction_arrays and all(len(value) == int(x.shape[1]) for value in prediction_arrays):
        prediction_x = torch.tensor(np.asarray(prediction_arrays), dtype=torch.float32)
        prediction_x = (prediction_x - mean) / std
        selected_model = nn.Sequential(
            nn.Linear(x.shape[1], hidden),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden, len(TRAIN_LABELS)),
        )
        selected_model.load_state_dict(best_model_state)
        selected_model.eval()
        with torch.inference_mode():
            probability = torch.softmax(selected_model(prediction_x), dim=1).cpu().numpy()
        for record, values in zip(predictable, probability):
            index = int(np.argmax(values))
            prediction_key = record.get("sample_id", record["object_id"])
            object_predictions[prediction_key] = {
                "object_id": record["object_id"],
                "sample_id": prediction_key,
                "dataset_id": record.get("dataset_id"),
                "label": TRAIN_LABELS[index],
                "confidence": float(values[index]),
                "probabilities": {
                    label: float(values[label_index[label]]) for label in TRAIN_LABELS
                },
                "roi_ref": record.get("roi_ref"),
                "roi_polygon_ref": record.get("roi_polygon_ref"),
                "roi_source": record.get("roi_source"),
            }
    result = {
        "backend": backend,
        "train_labels": list(TRAIN_LABELS),
        "ignored_unknown_count": ignored_unknown_count,
        "label_report": {key: value for key, value in report.items() if key != "records"},
        "runs": run_reports,
        "selected_checkpoint": best_run["checkpoint"],
        "test_metrics": {
            key: value for key, value in best_run["metrics"].items() if key.startswith("test_")
        },
        "automatic_filtering_enabled": bool(
            best_run["metrics"].get("test_wall_precision", 0.0)
            >= float(cfg.get("semantic_accept_precision", 0.95))
            and best_run["metrics"].get("test_wall_recall", 0.0)
            >= float(cfg.get("semantic_accept_recall", 0.90))
            and best_run["metrics"].get("test_column_precision", 0.0)
            >= float(cfg.get("semantic_accept_precision", 0.95))
            and best_run["metrics"].get("test_column_recall", 0.0)
            >= float(cfg.get("semantic_accept_recall", 0.90))
        ),
        "object_predictions": object_predictions,
        "prediction_coverage": len(object_predictions) / max(len(all_records), 1),
    }
    write_json(output_dir / "semantic_training_report.json", result)
    return result
