from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import cv2
import ezdxf
import numpy as np
from scipy import ndimage
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.signal import find_peaks
from scipy.sparse import coo_matrix
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Point, Polygon, box, mapping

from .io import read_json, write_json
from .transforms import transform_points


@dataclass
class FrozenEvidence:
    xy: np.ndarray
    z_min_m: np.ndarray
    z_max_m: np.ndarray
    vertical_span_m: np.ndarray
    height_bin_count: np.ndarray
    point_count: np.ndarray
    session_count: np.ndarray
    local_direction_rad: np.ndarray
    structural_mask: np.ndarray
    low_mask: np.ndarray
    grid_m: float
    height_bin_m: float


@dataclass
class ArchitecturalResult:
    walls: list[dict]
    low_structures: list[dict]
    inferred: list[dict]
    uncertain: list[dict]
    evidence: FrozenEvidence
    metrics: dict
    audit: dict
    diagnostics: dict = field(default_factory=dict)


def _direction(line: LineString) -> np.ndarray:
    points = np.asarray(line.coords, dtype=float)[[0, -1]]
    value = points[1] - points[0]
    value /= max(float(np.linalg.norm(value)), 1e-12)
    if value[0] < 0 or (abs(value[0]) < 1e-12 and value[1] < 0):
        value *= -1
    return value


def _angle_difference(first: np.ndarray, second: np.ndarray) -> float:
    return math.acos(float(np.clip(abs(first @ second), -1.0, 1.0)))


def _canonical_angle(angle: float) -> float:
    return angle % math.pi


def _weighted_median(values: np.ndarray, weights: np.ndarray) -> float:
    order = np.argsort(values)
    values, weights = values[order], weights[order]
    return float(values[np.searchsorted(np.cumsum(weights), np.sum(weights) * 0.5)])


def build_frozen_evidence(
    clean_points: np.ndarray,
    session_points: list[tuple[str, np.ndarray]],
    floor_m: float,
    ceiling_m: float,
    cfg: dict,
) -> FrozenEvidence:
    """Build non-overlapping base-voxel evidence used by every later audit."""
    grid_m = float(cfg.get("architectural_xy_grid_m", cfg.get("grid_m", 0.05)))
    height_bin_m = float(cfg.get("architectural_height_bin_m", 0.10))
    finite = clean_points[np.all(np.isfinite(clean_points), axis=1)]
    finite = finite[(finite[:, 2] >= floor_m) & (finite[:, 2] <= ceiling_m)]
    ij = np.floor(finite[:, :2] / grid_m).astype(np.int64)
    kk = np.floor((finite[:, 2] - floor_m) / height_bin_m).astype(np.int64)
    xyz_keys = np.column_stack([ij, kk])
    unique_xyz, xyz_counts = np.unique(xyz_keys, axis=0, return_counts=True)
    xy_keys, inverse = np.unique(unique_xyz[:, :2], axis=0, return_inverse=True)
    cell_count = len(xy_keys)
    lower = np.min(xy_keys, axis=0)
    local = xy_keys - lower
    width, height = np.max(local, axis=0) + 1
    vertical_xy_tolerance = float(cfg.get("architectural_vertical_xy_tolerance_m", 0.10))
    vertical_radius = max(1, int(math.ceil(vertical_xy_tolerance / grid_m)))
    z_count = int(np.max(unique_xyz[:, 2])) + 1
    occupancy_3d = np.zeros((z_count, height, width), dtype=bool)
    xyz_local = unique_xyz[:, :2] - lower
    occupancy_3d[unique_xyz[:, 2], xyz_local[:, 1], xyz_local[:, 0]] = True
    neighbourhood_3d = ndimage.maximum_filter(
        occupancy_3d,
        size=(1, 2 * vertical_radius + 1, 2 * vertical_radius + 1),
        mode="constant",
    )
    z_min_bin = np.full(cell_count, np.iinfo(np.int32).max, dtype=np.int32)
    z_max_bin = np.full(cell_count, -1, dtype=np.int32)
    point_count = np.zeros(cell_count, dtype=np.int32)
    bin_count = np.zeros(cell_count, dtype=np.int16)
    np.add.at(point_count, inverse, xyz_counts.astype(np.int32))
    # Use the longest consecutive vertical run, not merely min/max height.
    # This prevents a floor/ceiling pair with empty space between it from being
    # mislabelled as a continuous wall column.
    for cell_index, (column, row) in enumerate(local):
        bins = np.flatnonzero(neighbourhood_3d[:, row, column])
        run_starts = np.r_[0, np.flatnonzero(np.diff(bins) > 1) + 1]
        run_ends = np.r_[run_starts[1:], len(bins)]
        lengths = run_ends - run_starts
        best = int(np.argmax(lengths))
        z_min_bin[cell_index] = int(bins[run_starts[best]])
        z_max_bin[cell_index] = int(bins[run_ends[best] - 1])
        bin_count[cell_index] = int(lengths[best])

    # Count each acquisition once per XY voxel.  Overlapping height windows do
    # not exist at this stage, so they cannot inflate session confidence.
    session_count_grid = np.zeros((height, width), dtype=np.int16)
    for _, points in session_points:
        points = points[np.all(np.isfinite(points), axis=1)]
        points = points[(points[:, 2] >= floor_m) & (points[:, 2] <= ceiling_m)]
        if not len(points):
            continue
        session_xy = np.unique(np.floor(points[:, :2] / grid_m).astype(np.int64), axis=0)
        session_local = session_xy - lower
        valid = (
            (session_local[:, 0] >= 0)
            & (session_local[:, 1] >= 0)
            & (session_local[:, 0] < width)
            & (session_local[:, 1] < height)
        )
        presence = np.zeros((height, width), dtype=bool)
        session_local = session_local[valid]
        presence[session_local[:, 1], session_local[:, 0]] = True
        presence = ndimage.maximum_filter(
            presence,
            size=2 * vertical_radius + 1,
            mode="constant",
        )
        session_count_grid += presence.astype(np.int16)
    session_count = session_count_grid[local[:, 1], local[:, 0]]

    xy = (xy_keys.astype(float) + 0.5) * grid_m
    z_min = floor_m + z_min_bin.astype(float) * height_bin_m
    z_max = floor_m + (z_max_bin.astype(float) + 1.0) * height_bin_m
    vertical_span = z_max - z_min

    # A dense raster structure tensor gives a traceable local ridge direction
    # without repeatedly fitting overlapping windows.
    occupancy = np.zeros((height, width), dtype=np.float32)
    occupancy[local[:, 1], local[:, 0]] = np.log1p(point_count)
    smooth = ndimage.gaussian_filter(occupancy, 1.2)
    gx = ndimage.sobel(smooth, axis=1)
    gy = ndimage.sobel(smooth, axis=0)
    tangent = np.arctan2(gx, -gy)
    local_direction = tangent[local[:, 1], local[:, 0]].astype(np.float32)

    minimum_span = float(cfg.get("architectural_min_vertical_span_m", 1.20))
    minimum_bins = int(cfg.get("architectural_min_height_bins", 4))
    minimum_sessions = int(cfg.get("architectural_min_sessions", 2))
    structural = (
        (vertical_span >= minimum_span)
        & (bin_count >= minimum_bins)
        & (session_count >= minimum_sessions)
    )
    low_min_span = float(cfg.get("architectural_low_min_span_m", 0.25))
    low_max_span = float(cfg.get("architectural_low_max_span_m", 1.20))
    low_start = float(cfg.get("architectural_low_start_above_floor_m", 0.35))
    low = (
        (z_min <= floor_m + low_start)
        & (vertical_span >= low_min_span)
        & (vertical_span < low_max_span)
        & (session_count >= minimum_sessions)
        & (bin_count >= 2)
    )
    return FrozenEvidence(
        xy=xy,
        z_min_m=z_min,
        z_max_m=z_max,
        vertical_span_m=vertical_span,
        height_bin_count=bin_count,
        point_count=point_count,
        session_count=session_count,
        local_direction_rad=local_direction,
        structural_mask=structural,
        low_mask=low,
        grid_m=grid_m,
        height_bin_m=height_bin_m,
    )


def save_frozen_evidence(path: Path, evidence: FrozenEvidence) -> None:
    np.savez_compressed(
        path,
        xy=evidence.xy,
        z_min_m=evidence.z_min_m,
        z_max_m=evidence.z_max_m,
        vertical_span_m=evidence.vertical_span_m,
        height_bin_count=evidence.height_bin_count,
        point_count=evidence.point_count,
        session_count=evidence.session_count,
        local_direction_rad=evidence.local_direction_rad,
        structural_mask=evidence.structural_mask,
        low_mask=evidence.low_mask,
        grid_m=np.asarray(evidence.grid_m),
        height_bin_m=np.asarray(evidence.height_bin_m),
    )


def _sample_line(line: LineString, step_m: float = 0.10) -> np.ndarray:
    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    return np.asarray(
        [line.interpolate(value, normalized=True).coords[0] for value in np.linspace(0, 1, count)],
        dtype=float,
    )


def _axis_record(line: LineString) -> tuple[np.ndarray, np.ndarray, float, tuple[float, float]]:
    direction = _direction(line)
    normal = np.asarray([-direction[1], direction[0]])
    coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
    offset = float(np.mean(coordinates @ normal))
    interval = tuple(sorted((coordinates @ direction).tolist()))
    return direction, normal, offset, interval


def _merge_source_runs(union: list[dict], cfg: dict) -> list[dict]:
    """Undo atomic height segmentation before graph-level reasoning."""
    angle_tol = math.radians(float(cfg.get("architectural_run_angle_deg", 1.0)))
    offset_tol = float(cfg.get("architectural_run_offset_m", 0.035))
    gap_tol = float(cfg.get("architectural_run_gap_m", 0.12))
    buckets: list[dict] = []
    for value in union:
        line = value["line_ref"]
        if line.length < 1e-6:
            continue
        direction, normal, offset, interval = _axis_record(line)
        chosen = None
        for bucket in buckets:
            if _angle_difference(direction, bucket["direction"]) > angle_tol:
                continue
            signed_offset = float(np.mean(np.asarray(line.coords) @ bucket["normal"]))
            if abs(signed_offset - bucket["offset"]) <= offset_tol:
                chosen = bucket
                break
        if chosen is None:
            chosen = {
                "direction": direction,
                "normal": normal,
                "offset": offset,
                "items": [],
            }
            buckets.append(chosen)
        chosen["items"].append((interval, value))

    result: list[dict] = []
    for bucket in buckets:
        direction, normal, offset = bucket["direction"], bucket["normal"], bucket["offset"]
        ordered = sorted(bucket["items"], key=lambda item: item[0][0])
        current: list[tuple[tuple[float, float], dict]] = []
        current_end = -float("inf")
        for interval, value in ordered:
            if current and interval[0] > current_end + gap_tol:
                result.append(_materialize_run(bucket, current, len(result)))
                current = []
            current.append((interval, value))
            current_end = max(current_end, interval[1])
        if current:
            result.append(_materialize_run(bucket, current, len(result)))
    return result


def _materialize_run(bucket: dict, items: list[tuple[tuple[float, float], dict]], index: int) -> dict:
    start = min(value[0][0] for value in items)
    end = max(value[0][1] for value in items)
    line = LineString(
        [
            bucket["direction"] * start + bucket["normal"] * bucket["offset"],
            bucket["direction"] * end + bucket["normal"] * bucket["offset"],
        ]
    )
    sources = [value for _, value in items]
    slices = sorted(set().union(*(set(value.get("slice_indices", [])) for value in sources)))
    z_ranges = [item for value in sources for item in value.get("observed_z_ranges_m", [])]
    return {
        "candidate_id": f"B{index:04d}",
        "line_ref": line,
        "slice_indices": slices,
        "source_segment_ids": sorted({value.get("segment_id", "") for value in sources}),
        "source_wall_ids": sorted(
            set().union(*(set(value.get("source_wall_ids", [value.get("wall_id", "")])) for value in sources))
        ),
        "observed_z_ranges_m": z_ranges,
        "z_min_m": min((value.get("z_min_m", 0.0) for value in sources), default=0.0),
        "z_max_m": max((value.get("z_max_m", 0.0) for value in sources), default=0.0),
        "baseline_atomic_count": len(sources),
        "source_observation_types": sorted(
            {value.get("source_observation_type", "calibrated_baseline") for value in sources}
        ),
    }


def _density_ridge_observations(
    evidence: FrozenEvidence, floor_m: float, ceiling_m: float, cfg: dict
) -> list[dict]:
    """Generate independent candidates from frozen LiDAR density ridges."""
    selected = evidence.xy[evidence.structural_mask]
    if not len(selected):
        return []
    grid_m = evidence.grid_m
    lower_key = np.floor(np.min(selected, axis=0) / grid_m).astype(int) - 2
    upper_key = np.floor(np.max(selected, axis=0) / grid_m).astype(int) + 3
    size = upper_key - lower_key
    raster = np.zeros((int(size[1]), int(size[0])), dtype=np.uint8)
    ij = np.floor(selected / grid_m).astype(int) - lower_key
    raster[ij[:, 1], ij[:, 0]] = 255
    raster = cv2.morphologyEx(
        raster,
        cv2.MORPH_CLOSE,
        np.ones((3, 3), np.uint8),
    )
    lines = cv2.HoughLinesP(
        raster,
        rho=1,
        theta=np.pi / 720.0,
        threshold=int(cfg.get("architectural_ridge_hough_votes", 20)),
        minLineLength=max(
            2,
            int(float(cfg.get("architectural_ridge_min_length_m", 0.60)) / grid_m),
        ),
        maxLineGap=max(
            1,
            int(float(cfg.get("architectural_ridge_max_gap_m", 0.20)) / grid_m),
        ),
    )
    if lines is None:
        return []
    observations = []
    for index, coordinates in enumerate(np.asarray(lines).reshape(-1, 4)):
        endpoints = (
            np.asarray(
                [[coordinates[0], coordinates[1]], [coordinates[2], coordinates[3]]],
                dtype=float,
            )
            + lower_key
            + 0.5
        ) * grid_m
        line = LineString(endpoints)
        if line.length < float(cfg.get("architectural_ridge_min_length_m", 0.60)):
            continue
        observations.append(
            {
                "line_ref": line,
                "segment_id": f"RIDGE_{index:04d}",
                "wall_id": f"RIDGE_{index:04d}",
                "slice_indices": [],
                "observed_z_ranges_m": [[floor_m, ceiling_m]],
                "z_min_m": floor_m,
                "z_max_m": ceiling_m,
                "source_observation_type": "lidar_density_ridge",
            }
        )
    observations.sort(key=lambda value: value["line_ref"].length, reverse=True)
    return observations[: int(cfg.get("architectural_ridge_max_candidates", 300))]


def _raw_slice_observations(raw_slices: list[Any] | None) -> list[dict]:
    observations = []
    for height_slice in raw_slices or []:
        for line_index, line in enumerate(height_slice.raw_lines_ref):
            observations.append(
                {
                    "line_ref": line,
                    "segment_id": f"RAW_{height_slice.index:02d}_{line_index:04d}",
                    "wall_id": f"RAW_{height_slice.index:02d}_{line_index:04d}",
                    "slice_indices": [height_slice.index],
                    "observed_z_ranges_m": [
                        [height_slice.z_min_m, height_slice.z_max_m]
                    ],
                    "z_min_m": height_slice.z_min_m,
                    "z_max_m": height_slice.z_max_m,
                    "source_observation_type": "raw_height_slice",
                }
            )
    return observations


def _calibrated_slice_runs(
    slices: list[Any] | None, indices: list[int], cfg: dict
) -> list[dict]:
    """Build complete per-slice runs without mixing axes between heights."""
    by_index = {int(value.index): value for value in slices or []}
    runs: list[dict] = []
    for slice_index in indices:
        height_slice = by_index.get(int(slice_index))
        if height_slice is None:
            continue
        observations = []
        for line_index, line in enumerate(height_slice.calibrated_lines_ref):
            observations.append(
                {
                    "line_ref": line,
                    "segment_id": f"CAL_{slice_index:02d}_{line_index:04d}",
                    "wall_id": f"CAL_{slice_index:02d}_{line_index:04d}",
                    "slice_indices": [int(slice_index)],
                    "observed_z_ranges_m": [
                        [float(height_slice.z_min_m), float(height_slice.z_max_m)]
                    ],
                    "z_min_m": float(height_slice.z_min_m),
                    "z_max_m": float(height_slice.z_max_m),
                    "source_observation_type": "calibrated_height_slice",
                }
            )
        for value in _merge_source_runs(observations, cfg):
            value["candidate_id"] = f"H{slice_index:02d}_{len(runs):04d}"
            value["backbone_source_slice"] = int(slice_index)
            runs.append(value)
    return runs


def _slice_point_trees(
    slices: list[Any] | None, clean_points: np.ndarray
) -> dict[int, cKDTree]:
    result: dict[int, cKDTree] = {}
    for height_slice in slices or []:
        selected = clean_points[
            (clean_points[:, 2] >= float(height_slice.z_min_m))
            & (clean_points[:, 2] < float(height_slice.z_max_m))
        ]
        if not len(selected):
            continue
        xy = np.unique(
            np.round(selected[:, :2] / 0.03).astype(np.int64), axis=0
        ).astype(float) * 0.03
        if len(xy):
            result[int(height_slice.index)] = cKDTree(xy)
    return result


def _base_height_bin_trees(
    clean_points: np.ndarray, floor_m: float, ceiling_m: float, cfg: dict
) -> dict[int, cKDTree]:
    bin_m = float(cfg.get("architectural_height_bin_m", 0.10))
    count = max(1, int(math.ceil((ceiling_m - floor_m) / bin_m)))
    trees: dict[int, cKDTree] = {}
    for index in range(count):
        lower = floor_m + index * bin_m
        upper = min(ceiling_m + 1e-9, lower + bin_m)
        points = clean_points[
            (clean_points[:, 2] >= lower) & (clean_points[:, 2] < upper)
        ]
        if len(points) < 3:
            continue
        xy = np.unique(
            np.round(points[:, :2] / 0.03).astype(np.int64), axis=0
        ).astype(float) * 0.03
        if len(xy):
            trees[index] = cKDTree(xy)
    return trees


def _revalidate_height_support(
    value: dict,
    slices: list[Any] | None,
    slice_trees: dict[int, cKDTree],
    base_trees: dict[int, cKDTree],
    floor_m: float,
    cfg: dict,
) -> None:
    """Derive height metadata again from points, never from copied union tags."""
    samples = _sample_line(
        value["line_ref"], float(cfg.get("architectural_sample_step_m", 0.10))
    )
    radius = float(cfg.get("architectural_backbone_support_distance_m", 0.12))
    slice_threshold = float(
        cfg.get("architectural_backbone_slice_support_fraction", 0.70)
    )
    bin_threshold = float(
        cfg.get("architectural_backbone_bin_support_fraction", 0.55)
    )
    slice_support = {
        int(height_slice.index): _tree_fraction(
            slice_trees.get(int(height_slice.index)), samples, radius
        )
        for height_slice in slices or []
    }
    bin_support = {
        int(index): _tree_fraction(tree, samples, radius)
        for index, tree in base_trees.items()
    }
    supported_slices = sorted(
        index for index, fraction in slice_support.items() if fraction >= slice_threshold
    )
    supported_bins = sorted(
        index for index, fraction in bin_support.items() if fraction >= bin_threshold
    )
    bin_m = float(cfg.get("architectural_height_bin_m", 0.10))
    ranges: list[list[float]] = []
    for index in supported_bins:
        lower, upper = floor_m + index * bin_m, floor_m + (index + 1) * bin_m
        if ranges and abs(ranges[-1][1] - lower) <= 1e-9:
            ranges[-1][1] = upper
        else:
            ranges.append([lower, upper])
    value["slice_support"] = {str(key): float(item) for key, item in slice_support.items()}
    value["slice_indices"] = supported_slices
    value["base_height_bin_support"] = {
        str(key): float(item) for key, item in bin_support.items()
    }
    value["observed_base_height_bins"] = supported_bins
    value["observed_z_ranges_m"] = ranges
    value["z_min_m"] = None if not ranges else float(ranges[0][0])
    value["z_max_m"] = None if not ranges else float(ranges[-1][1])
    value["slice_count"] = len(supported_slices)


def _axis_match(
    anchor: dict,
    candidate: dict,
    angle_m: float,
    offset_m: float,
    overlap_m: float,
) -> tuple[bool, float, float]:
    direction, normal, offset, interval = _axis_record(anchor["line_ref"])
    other_direction = _direction(candidate["line_ref"])
    angle = _angle_difference(direction, other_direction)
    coordinates = np.asarray(candidate["line_ref"].coords, dtype=float)[[0, -1]]
    other_offset = float(np.mean(coordinates @ normal))
    other_interval = tuple(sorted((coordinates @ direction).tolist()))
    overlap = min(interval[1], other_interval[1]) - max(interval[0], other_interval[0])
    return (
        angle <= angle_m and abs(offset - other_offset) <= offset_m and overlap >= overlap_m,
        abs(offset - other_offset),
        overlap,
    )


def _attach_support_without_moving(anchor: dict, observation: dict) -> None:
    """Attach provenance to a fixed axis; never recompute its direction/offset."""
    for key in (
        "source_candidate_ids",
        "source_segment_ids",
        "source_wall_ids",
        "source_observation_types",
    ):
        extra = (
            {str(observation.get("candidate_id"))}
            if key == "source_candidate_ids"
            else set()
        )
        anchor[key] = sorted(
            set(anchor.get(key, []))
            | set(observation.get(key, []))
            | extra
        )
    anchor["supporting_source_slices"] = sorted(
        set(anchor.get("supporting_source_slices", []))
        | set(observation.get("slice_indices", []))
        | {int(observation.get("backbone_source_slice", -1))}
        - {-1}
    )


def _candidate_strength(value: dict) -> tuple[float, float, float, float]:
    return (
        float(value.get("structural_coverage", 0.0)),
        float(value.get("point_coverage", 0.0)),
        float(value.get("session_count", 0)),
        float(value["line_ref"].length),
    )


def _build_high_slice_backbone(
    raw_slices: list[Any] | None,
    clean_points: np.ndarray,
    clean_session_points: list[tuple[str, np.ndarray]],
    evidence: FrozenEvidence,
    floor_m: float,
    ceiling_m: float,
    cfg: dict,
) -> tuple[list[dict], list[dict], dict]:
    """Select fixed high-slice axes, then admit lower candidates as supplements."""
    available = sorted(int(value.index) for value in raw_slices or [])
    configured = [int(value) for value in cfg.get("high_slice_backbone", [6, 7, 8])]
    high_indices = [value for value in configured if value in available]
    if not high_indices:
        high_indices = available[-min(3, len(available)) :]
    preferred = [int(value) for value in cfg.get("high_slice_priority", [7, 6, 8])]
    priority = [value for value in preferred if value in high_indices]
    priority += [value for value in high_indices if value not in priority]
    lower_indices = [value for value in available if value not in high_indices]

    structural_tree = (
        cKDTree(evidence.xy[evidence.structural_mask])
        if np.any(evidence.structural_mask)
        else None
    )
    low_tree = cKDTree(evidence.xy[evidence.low_mask]) if np.any(evidence.low_mask) else None
    all_tree = cKDTree(evidence.xy) if len(evidence.xy) else None
    session_trees = [
        (
            name,
            cKDTree(
                np.unique(
                    np.round(points[:, :2] / 0.04).astype(np.int64), axis=0
                ).astype(float)
                * 0.04
            ),
        )
        for name, points in clean_session_points
        if len(points)
    ]
    slice_trees = _slice_point_trees(raw_slices, clean_points)
    base_trees = _base_height_bin_trees(clean_points, floor_m, ceiling_m, cfg)
    cross_section_xy = np.unique(
        np.round(clean_points[:, :2] / 0.02).astype(np.int64), axis=0
    ).astype(float) * 0.02
    cross_section_tree = cKDTree(cross_section_xy) if len(cross_section_xy) else None

    high_runs = _calibrated_slice_runs(raw_slices, priority, cfg)
    lower_runs = _calibrated_slice_runs(raw_slices, lower_indices, cfg)
    for value in high_runs + lower_runs:
        _evaluate_candidate(
            value, evidence, structural_tree, low_tree, all_tree, session_trees, cfg
        )
        _revalidate_height_support(
            value, raw_slices, slice_trees, base_trees, floor_m, cfg
        )

    angle_limit = math.radians(
        float(cfg.get("architectural_backbone_match_angle_deg", 3.0))
    )
    offset_limit = float(cfg.get("architectural_backbone_match_offset_m", 0.08))
    overlap_limit = float(cfg.get("architectural_backbone_match_overlap_m", 0.50))
    minimum_length = float(cfg.get("architectural_backbone_min_length_m", 0.50))
    minimum_structural = float(
        cfg.get("architectural_backbone_min_structural_coverage", 0.58)
    )
    minimum_points = float(cfg.get("architectural_backbone_min_point_coverage", 0.90))
    minimum_sessions = int(cfg.get("architectural_min_sessions", 2))
    minimum_bins = int(cfg.get("architectural_backbone_min_base_bins", 4))

    def unresolved_near_conflict(candidate: dict, values: list[dict]) -> dict | None:
        broad_angle = math.radians(
            float(cfg.get("architectural_backbone_conflict_angle_deg", 5.0))
        )
        broad_offset = float(
            cfg.get("architectural_backbone_conflict_offset_m", 0.22)
        )
        broad_overlap = float(
            cfg.get("architectural_backbone_conflict_overlap_m", 0.30)
        )
        for anchor in values:
            near, _, _ = _axis_match(
                anchor, candidate, broad_angle, broad_offset, broad_overlap
            )
            if not near:
                continue
            if _cross_section_is_bimodal(
                anchor, candidate, cross_section_xy, cross_section_tree, cfg
            ):
                anchor["protected_double_face"] = True
                candidate["protected_double_face"] = True
                continue
            return anchor
        return None

    def novel_fraction(candidate: dict, values: list[dict]) -> float:
        if not values:
            return 1.0
        samples = np.vstack(
            [_sample_line(value["line_ref"], 0.08) for value in values]
        )
        distances = cKDTree(samples).query(
            _sample_line(candidate["line_ref"], 0.08), k=1
        )[0]
        return float(
            np.mean(
                distances
                > float(cfg.get("architectural_supplement_novel_distance_m", 0.25))
            )
        )

    anchors: list[dict] = []
    uncertain: list[dict] = []
    for slice_index in priority:
        candidates = [
            value
            for value in high_runs
            if int(value.get("backbone_source_slice", -1)) == slice_index
        ]
        candidates.sort(key=_candidate_strength, reverse=True)
        for candidate in candidates:
            qualifying = (
                candidate["line_ref"].length >= minimum_length
                and candidate.get("structural_coverage", 0.0) >= minimum_structural
                and candidate.get("point_coverage", 0.0) >= minimum_points
                and candidate.get("session_count", 0) >= minimum_sessions
                and len(candidate.get("observed_base_height_bins", [])) >= minimum_bins
            )
            matches = [
                anchor
                for anchor in anchors
                if _axis_match(
                    anchor, candidate, angle_limit, offset_limit, overlap_limit
                )[0]
            ]
            if matches:
                best = max(
                    matches,
                    key=lambda anchor: _axis_match(
                        anchor, candidate, angle_limit, offset_limit, overlap_limit
                    )[2],
                )
                _attach_support_without_moving(best, candidate)
                continue
            conflict = unresolved_near_conflict(candidate, anchors)
            if conflict is not None:
                rejected = dict(candidate)
                rejected["classification"] = "uncertain_detail"
                rejected["selection_reasons"] = [
                    "near_backbone_axis_without_resolvable_second_peak"
                ]
                rejected["conflicts_with"] = conflict.get("candidate_id")
                uncertain.append(rejected)
                continue
            if qualifying:
                candidate["protected"] = True
                candidate["backbone_role"] = "high_slice_fixed_axis"
                candidate["selection_reasons"] = [
                    "high_slice_backbone",
                    "point_revalidated_height_support",
                    "fixed_axis",
                ]
                candidate["supporting_source_slices"] = [slice_index]
                anchors.append(candidate)
            else:
                rejected = dict(candidate)
                rejected["classification"] = "uncertain_detail"
                rejected["selection_reasons"] = ["high_slice_candidate_failed_evidence"]
                uncertain.append(rejected)

    # Other heights can extend provenance on an existing axis or introduce a
    # genuinely missing, strongly supported structure.  They cannot move a
    # selected high-slice axis.
    lower_min_slices = int(cfg.get("architectural_supplement_min_slices", 3))
    lower_min_structural = float(
        cfg.get("architectural_supplement_min_structural_coverage", 0.72)
    )
    lower_min_length = float(cfg.get("architectural_supplement_min_length_m", 0.60))
    lower_runs.sort(key=_candidate_strength, reverse=True)
    supplements = 0
    attached = 0
    for candidate in lower_runs:
        matches = [
            anchor
            for anchor in anchors
            if _axis_match(anchor, candidate, angle_limit, offset_limit, overlap_limit)[0]
        ]
        if matches:
            best = max(
                matches,
                key=lambda anchor: _axis_match(
                    anchor, candidate, angle_limit, offset_limit, overlap_limit
                )[2],
            )
            _attach_support_without_moving(best, candidate)
            attached += 1
            continue
        conflict = unresolved_near_conflict(candidate, anchors)
        if conflict is not None:
            rejected = dict(candidate)
            rejected["classification"] = "uncertain_detail"
            rejected["selection_reasons"] = [
                "lower_height_near_backbone_without_resolvable_second_peak"
            ]
            uncertain.append(rejected)
            continue
        novelty = novel_fraction(candidate, anchors)
        qualifying = (
            candidate["line_ref"].length >= lower_min_length
            and candidate.get("structural_coverage", 0.0) >= lower_min_structural
            and candidate.get("point_coverage", 0.0) >= minimum_points
            and candidate.get("session_count", 0) >= minimum_sessions
            and candidate.get("slice_count", 0) >= lower_min_slices
            and candidate.get("vertical_span_m", 0.0)
            >= float(cfg.get("architectural_min_vertical_span_m", 1.20))
            and novelty
            >= float(cfg.get("architectural_supplement_min_novel_fraction", 0.70))
        )
        if qualifying:
            candidate["protected"] = False
            candidate["backbone_role"] = "lower_height_supplement"
            candidate["selection_reasons"] = [
                "missing_from_high_backbone",
                "strong_multi_height_point_support",
            ]
            candidate["novel_fraction_vs_high_backbone"] = novelty
            anchors.append(candidate)
            supplements += 1
        else:
            rejected = dict(candidate)
            rejected["classification"] = "uncertain_detail"
            rejected["selection_reasons"] = ["lower_height_candidate_not_reliable"]
            uncertain.append(rejected)

    # Density ridges are supplementary hypotheses only.  They never
    # participate in fitting a high-slice axis and must pass stricter current
    # point, height-bin, and three-session evidence before entering the plan.
    ridge_runs = (
        _merge_source_runs(
            _density_ridge_observations(evidence, floor_m, ceiling_m, cfg), cfg
        )
        if bool(cfg.get("architectural_ridge_supplement_enabled", False))
        else []
    )
    ridge_added = 0
    for candidate in ridge_runs:
        _evaluate_candidate(
            candidate, evidence, structural_tree, low_tree, all_tree, session_trees, cfg
        )
        _revalidate_height_support(
            candidate, raw_slices, slice_trees, base_trees, floor_m, cfg
        )
        matches = [
            anchor
            for anchor in anchors
            if _axis_match(anchor, candidate, angle_limit, offset_limit, overlap_limit)[0]
        ]
        if matches:
            _attach_support_without_moving(
                max(
                    matches,
                    key=lambda anchor: _axis_match(
                        anchor, candidate, angle_limit, offset_limit, overlap_limit
                    )[2],
                ),
                candidate,
            )
            continue
        if unresolved_near_conflict(candidate, anchors) is not None:
            rejected = dict(candidate)
            rejected["classification"] = "uncertain_detail"
            rejected["selection_reasons"] = [
                "density_ridge_near_backbone_without_resolvable_second_peak"
            ]
            uncertain.append(rejected)
            continue
        novelty = novel_fraction(candidate, anchors)
        qualifying = (
            candidate["line_ref"].length
            >= float(cfg.get("architectural_ridge_supplement_min_length_m", 1.0))
            and candidate.get("structural_coverage", 0.0)
            >= float(cfg.get("architectural_ridge_supplement_min_structural", 0.85))
            and candidate.get("point_coverage", 0.0) >= 0.95
            and candidate.get("session_count", 0) >= min(3, len(session_trees))
            and len(candidate.get("observed_base_height_bins", []))
            >= int(cfg.get("architectural_ridge_supplement_min_base_bins", 8))
            and candidate.get("slice_count", 0) >= 4
            and novelty
            >= float(cfg.get("architectural_supplement_min_novel_fraction", 0.70))
        )
        if qualifying:
            candidate["protected"] = False
            candidate["backbone_role"] = "density_ridge_supplement"
            candidate["selection_reasons"] = [
                "missing_from_slice_backbone",
                "strict_point_revalidated_density_supplement",
            ]
            anchors.append(candidate)
            ridge_added += 1
        else:
            rejected = dict(candidate)
            rejected["classification"] = "uncertain_detail"
            rejected["selection_reasons"] = ["density_ridge_is_comparison_candidate_only"]
            uncertain.append(rejected)

    for index, value in enumerate(anchors):
        value["candidate_id"] = f"V5W{index:04d}"
        value["classification"] = "building_wall"
        _revalidate_height_support(
            value, raw_slices, slice_trees, base_trees, floor_m, cfg
        )
    metrics = {
        "configured_high_slices": configured,
        "available_high_slices": high_indices,
        "high_slice_priority": priority,
        "high_run_count": len(high_runs),
        "lower_run_count": len(lower_runs),
        "fixed_backbone_count": int(
            sum(value.get("backbone_role") == "high_slice_fixed_axis" for value in anchors)
        ),
        "lower_supplement_count": supplements,
        "lower_observation_attachment_count": attached,
        "density_ridge_candidate_count": len(ridge_runs),
        "density_ridge_supplement_count": ridge_added,
        "rejected_candidate_count": len(uncertain),
    }
    return anchors, uncertain, metrics


def _tree_fraction(tree: cKDTree | None, points: np.ndarray, radius: float) -> float:
    if tree is None or not len(points):
        return 0.0
    distance = tree.query(points, k=1)[0]
    return float(np.mean(distance <= radius))


def _evaluate_candidate(
    candidate: dict,
    evidence: FrozenEvidence,
    structural_tree: cKDTree | None,
    low_tree: cKDTree | None,
    all_tree: cKDTree | None,
    session_trees: list[tuple[str, cKDTree]],
    cfg: dict,
) -> None:
    samples = _sample_line(candidate["line_ref"], float(cfg.get("architectural_sample_step_m", 0.10)))
    radius = float(cfg.get("architectural_support_distance_m", 0.15))
    candidate["structural_coverage"] = _tree_fraction(structural_tree, samples, radius)
    candidate["low_coverage"] = _tree_fraction(low_tree, samples, radius)
    candidate["point_coverage"] = _tree_fraction(all_tree, samples, radius)
    candidate["session_support"] = {
        name: _tree_fraction(tree, samples, radius) for name, tree in session_trees
    }
    candidate["session_count"] = int(
        sum(value >= float(cfg.get("architectural_session_coverage_fraction", 0.35)) for value in candidate["session_support"].values())
    )
    nearest_span: list[float] = []
    evidence_tree = cKDTree(evidence.xy) if len(evidence.xy) else None
    if evidence_tree is not None:
        neighbours = evidence_tree.query_ball_point(samples, radius)
        nearest_span = [
            float(np.max(evidence.vertical_span_m[value]))
            for value in neighbours
            if len(value)
        ]
    candidate["vertical_span_m"] = float(np.median(nearest_span)) if nearest_span else 0.0
    candidate["length_m"] = float(candidate["line_ref"].length)
    candidate["slice_count"] = int(len(candidate.get("slice_indices", [])))


def _refine_candidates_against_sessions(
    candidates: list[dict],
    all_tree: cKDTree | None,
    session_trees: list[tuple[str, cKDTree]],
    cfg: dict,
) -> dict:
    """Fit one shared axis without allowing a dense acquisition to dominate."""
    if all_tree is None or len(session_trees) < 2:
        return {"eligible": 0, "refined": 0, "mean_worst_p95_change_m": 0.0}
    angle_search = math.radians(float(cfg.get("architectural_session_angle_search_deg", 1.0)))
    angle_steps = int(cfg.get("architectural_session_angle_steps", 5))
    offset_search = float(cfg.get("architectural_session_offset_search_m", 0.10))
    offset_step = float(cfg.get("architectural_session_offset_step_m", 0.02))
    support_distance = float(cfg.get("architectural_support_distance_m", 0.15))
    minimum_fraction = float(cfg.get("architectural_session_coverage_fraction", 0.35))
    max_p95_regression = float(cfg.get("architectural_local_p95_regression_m", 0.02))
    max_support_regression = float(cfg.get("architectural_max_coverage_regression", 0.02))
    changes = []
    eligible = 0
    for value in candidates:
        original = value["line_ref"]
        original_samples = _sample_line(original, 0.10)
        active = []
        original_p95 = []
        for name, tree in session_trees:
            distances = tree.query(original_samples, k=1)[0]
            if float(np.mean(distances <= support_distance)) >= minimum_fraction:
                active.append((name, tree))
                original_p95.append(float(np.quantile(distances, 0.95)))
        if len(active) < 2:
            continue
        eligible += 1
        coordinates = np.asarray(original.coords, dtype=float)[[0, -1]]
        center = np.mean(coordinates, axis=0)
        original_direction = _direction(original)
        original_angle = math.atan2(original_direction[1], original_direction[0])
        length = float(original.length)
        all_original = all_tree.query(original_samples, k=1)[0]
        original_all_p95 = float(np.quantile(all_original, 0.95))
        original_all_support = float(np.mean(all_original <= support_distance))
        best = (max(original_p95) + 0.15 * float(np.mean(original_p95)), original)
        for delta in np.linspace(-angle_search, angle_search, angle_steps):
            angle = original_angle + float(delta)
            direction = np.asarray([math.cos(angle), math.sin(angle)])
            normal = np.asarray([-direction[1], direction[0]])
            center_offset = float(center @ normal)
            for shift in np.arange(-offset_search, offset_search + offset_step / 2, offset_step):
                offset = center_offset + float(shift)
                center_along = float(center @ direction)
                candidate = LineString(
                    [
                        direction * (center_along - length / 2.0) + normal * offset,
                        direction * (center_along + length / 2.0) + normal * offset,
                    ]
                )
                samples = _sample_line(candidate, 0.10)
                p95_values = [
                    float(np.quantile(tree.query(samples, k=1)[0], 0.95))
                    for _, tree in active
                ]
                score = max(p95_values) + 0.15 * float(np.mean(p95_values))
                score += abs(float(delta)) * 0.01
                if score >= best[0] - 1e-9:
                    continue
                all_distances = all_tree.query(samples, k=1)[0]
                if (
                    float(np.quantile(all_distances, 0.95))
                    > original_all_p95 + max_p95_regression
                    or float(np.mean(all_distances <= support_distance))
                    < original_all_support - max_support_regression
                ):
                    continue
                best = (score, candidate)
        if best[1] is not original:
            value["line_ref"] = best[1]
            changes.append(best[0] - (max(original_p95) + 0.15 * float(np.mean(original_p95))))
    return {
        "eligible": eligible,
        "refined": len(changes),
        "mean_worst_p95_change_m": 0.0 if not changes else float(np.mean(changes)),
    }


def _cross_section_is_bimodal(
    first: dict,
    second: dict,
    point_xy: np.ndarray,
    point_tree: cKDTree | None,
    cfg: dict,
) -> bool:
    if point_tree is None:
        return False
    direction, normal, first_offset, first_interval = _axis_record(first["line_ref"])
    second_coords = np.asarray(second["line_ref"].coords, dtype=float)[[0, -1]]
    second_interval = tuple(sorted((second_coords @ direction).tolist()))
    start, end = max(first_interval[0], second_interval[0]), min(first_interval[1], second_interval[1])
    if end - start < float(cfg.get("architectural_association_overlap_m", 0.50)):
        return False
    midpoint = direction * ((start + end) / 2.0) + normal * first_offset
    indices = point_tree.query_ball_point(midpoint, (end - start) / 2.0 + 0.45)
    if len(indices) < 40:
        return False
    values = point_xy[np.asarray(indices, dtype=int)]
    along = values @ direction
    cross = values @ normal
    values = cross[(along >= start) & (along <= end) & (np.abs(cross - first_offset) <= 0.40)]
    if len(values) < 40:
        return False
    bin_m = float(cfg.get("architectural_cross_section_bin_m", 0.025))
    boundaries = np.arange(float(np.min(values)) - bin_m, float(np.max(values)) + 2 * bin_m, bin_m)
    histogram, edges = np.histogram(values, boundaries)
    histogram = ndimage.gaussian_filter1d(histogram.astype(float), 1.0)
    peaks, properties = find_peaks(
        histogram,
        distance=max(1, int(float(cfg.get("architectural_double_min_separation_m", 0.08)) / bin_m)),
        prominence=max(3.0, float(np.max(histogram)) * 0.10),
    )
    if len(peaks) < 2:
        return False
    centers = (edges[:-1] + edges[1:]) / 2.0
    second_offset = float(np.mean(second_coords @ normal))
    near_first = [value for value in peaks if abs(centers[value] - first_offset) <= 0.06]
    near_second = [value for value in peaks if abs(centers[value] - second_offset) <= 0.06]
    return bool(
        near_first
        and near_second
        and abs(first_offset - second_offset)
        >= float(cfg.get("architectural_double_min_separation_m", 0.08))
    )


def _associate_and_fit(
    candidates: list[dict],
    evidence: FrozenEvidence,
    clean_points: np.ndarray,
    main_angle: float,
    cfg: dict,
) -> tuple[list[dict], list[dict]]:
    """Associate repeated height observations while preserving true double faces."""
    point_xy = np.unique(np.round(clean_points[:, :2] / 0.02).astype(np.int64), axis=0).astype(float) * 0.02
    point_tree = cKDTree(point_xy) if len(point_xy) else None
    angle_limit = math.radians(float(cfg.get("architectural_association_angle_deg", 5.0)))
    offset_limit = float(cfg.get("architectural_association_offset_m", 0.25))
    overlap_limit = float(cfg.get("architectural_association_overlap_m", 0.50))
    parent = np.arange(len(candidates))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = int(parent[index])
        return index

    protected_pairs: list[dict] = []
    protected_index_pairs: list[tuple[int, int]] = []
    merge_pairs: list[tuple[int, int]] = []
    axes = [_axis_record(value["line_ref"]) for value in candidates]
    for first in range(len(candidates)):
        d1, n1, o1, i1 = axes[first]
        for second in range(first + 1, len(candidates)):
            d2, _, _, _ = axes[second]
            if _angle_difference(d1, d2) > angle_limit:
                continue
            coordinates = np.asarray(candidates[second]["line_ref"].coords, dtype=float)[[0, -1]]
            o2 = float(np.mean(coordinates @ n1))
            if abs(o1 - o2) > offset_limit:
                continue
            i2 = tuple(sorted((coordinates @ d1).tolist()))
            overlap = min(i1[1], i2[1]) - max(i1[0], i2[0])
            if overlap < overlap_limit:
                continue
            if _cross_section_is_bimodal(candidates[first], candidates[second], point_xy, point_tree, cfg):
                protected_pairs.append(
                    {
                        "first": candidates[first]["candidate_id"],
                        "second": candidates[second]["candidate_id"],
                        "separation_m": abs(o1 - o2),
                        "overlap_m": overlap,
                        "reason": "two_resolvable_cross_section_peaks",
                    }
                )
                protected_index_pairs.append((first, second))
                continue
            merge_pairs.append((first, second))

    # A third, intermediate ridge must not bridge two faces that the
    # cross-section test explicitly protected as distinct.
    for first, second in merge_pairs:
        first_root, second_root = root(first), root(second)
        if first_root == second_root:
            continue
        conflict = any(
            (root(left) == first_root and root(right) == second_root)
            or (root(right) == first_root and root(left) == second_root)
            for left, right in protected_index_pairs
        )
        if not conflict:
            parent[second_root] = first_root

    components: dict[int, list[int]] = {}
    for index in range(len(candidates)):
        components.setdefault(root(index), []).append(index)
    fitted: list[dict] = []
    snap_limit = math.radians(float(cfg.get("architectural_soft_direction_deg", 2.0)))
    main_directions = [main_angle % math.pi, (main_angle + math.pi / 2.0) % math.pi]
    for indices in components.values():
        members = [candidates[index] for index in indices]
        lengths = np.asarray([max(value["line_ref"].length, 0.05) for value in members])
        angles = np.asarray([math.atan2(*_direction(value["line_ref"])[::-1]) for value in members])
        doubled = np.column_stack([np.cos(2 * angles), np.sin(2 * angles)])
        vector = np.sum(doubled * lengths[:, None], axis=0)
        angle = 0.5 * math.atan2(vector[1], vector[0])
        angle = _canonical_angle(angle)
        nearest = min(main_directions, key=lambda value: abs(math.sin(angle - value)))
        if abs(math.asin(np.clip(math.sin(angle - nearest), -1.0, 1.0))) <= snap_limit:
            angle = nearest
        direction = np.asarray([math.cos(angle), math.sin(angle)])
        normal = np.asarray([-direction[1], direction[0]])
        offsets = np.asarray(
            [float(np.mean(np.asarray(value["line_ref"].coords) @ normal)) for value in members]
        )
        # Huber reweighting keeps an occasional bad slice from moving a wall.
        weights = lengths.copy()
        offset = _weighted_median(offsets, weights)
        for _ in range(3):
            residual = np.abs(offsets - offset)
            huber = np.minimum(1.0, float(cfg.get("architectural_observation_scale_m", 0.05)) / np.maximum(residual, 1e-9))
            offset = float(np.sum(offsets * weights * huber) / np.sum(weights * huber))
        all_coordinates = np.vstack([np.asarray(value["line_ref"].coords)[[0, -1]] for value in members])
        along = all_coordinates @ direction
        line = LineString(
            [direction * float(np.min(along)) + normal * offset, direction * float(np.max(along)) + normal * offset]
        )
        slices = sorted(set().union(*(set(value.get("slice_indices", [])) for value in members)))
        fitted.append(
            {
                **members[0],
                "candidate_id": f"W{len(fitted):04d}",
                "line_ref": line,
                "slice_indices": slices,
                "source_candidate_ids": sorted(
                    set().union(
                        *(
                            set(value.get("source_candidate_ids", []))
                            | {value["candidate_id"]}
                            for value in members
                        )
                    )
                ),
                "source_segment_ids": sorted(set().union(*(set(value.get("source_segment_ids", [])) for value in members))),
                "source_wall_ids": sorted(set().union(*(set(value.get("source_wall_ids", [])) for value in members))),
                "source_observation_types": sorted(
                    set().union(
                        *(
                            set(value.get("source_observation_types", []))
                            for value in members
                        )
                    )
                ),
                "observed_z_ranges_m": [item for value in members for item in value.get("observed_z_ranges_m", [])],
                "z_min_m": min(value.get("z_min_m", 0.0) for value in members),
                "z_max_m": max(value.get("z_max_m", 0.0) for value in members),
                "association_count": len(members),
            }
        )
    return fitted, protected_pairs


def _deduplicate_final_walls(
    lines: list[dict], cfg: dict
) -> tuple[list[dict], dict]:
    """Remove exact repeated runs and density-ridge shadows after graph fitting."""
    values = list(lines)
    merged_count = 0
    shadow_count = 0
    changed = True
    while changed:
        changed = False
        for first in range(len(values)):
            d1, n1, o1, i1 = _axis_record(values[first]["line_ref"])
            for second in range(first + 1, len(values)):
                d2, _, _, _ = _axis_record(values[second]["line_ref"])
                if _angle_difference(d1, d2) > math.radians(0.5):
                    continue
                coordinates = np.asarray(values[second]["line_ref"].coords, dtype=float)[[0, -1]]
                o2 = float(np.mean(coordinates @ n1))
                if abs(o1 - o2) > 0.01:
                    continue
                i2 = tuple(sorted((coordinates @ d1).tolist()))
                overlap = min(i1[1], i2[1]) - max(i1[0], i2[0])
                if overlap < 0.50:
                    continue
                start, end = min(i1[0], i2[0]), max(i1[1], i2[1])
                first_value, second_value = values[first], values[second]
                first_value["line_ref"] = LineString(
                    [d1 * start + n1 * o1, d1 * end + n1 * o1]
                )
                for key in (
                    "source_candidate_ids",
                    "source_segment_ids",
                    "source_wall_ids",
                    "source_observation_types",
                    "slice_indices",
                ):
                    first_value[key] = sorted(
                        set(first_value.get(key, []))
                        | set(second_value.get(key, []))
                    )
                first_value["observed_z_ranges_m"] = (
                    first_value.get("observed_z_ranges_m", [])
                    + second_value.get("observed_z_ranges_m", [])
                )
                first_value["selection_reasons"] = sorted(
                    set(first_value.get("selection_reasons", []))
                    | set(second_value.get("selection_reasons", []))
                    | {"exact_coincident_run_deduplicated"}
                )
                values.pop(second)
                merged_count += 1
                changed = True
                break
            if changed:
                break

    keep = np.ones(len(values), dtype=bool)
    for first, value in enumerate(values):
        if set(value.get("source_observation_types", [])) != {
            "lidar_density_ridge"
        }:
            continue
        d1, n1, o1, i1 = _axis_record(value["line_ref"])
        for second, other in enumerate(values):
            if first == second:
                continue
            d2, _, _, _ = _axis_record(other["line_ref"])
            if _angle_difference(d1, d2) > math.radians(3.0):
                continue
            coordinates = np.asarray(other["line_ref"].coords, dtype=float)[[0, -1]]
            if abs(float(np.mean(coordinates @ n1)) - o1) > 0.10:
                continue
            interval = tuple(sorted((coordinates @ d1).tolist()))
            overlap = min(i1[1], interval[1]) - max(i1[0], interval[0])
            if overlap < max(0.50, 0.50 * value["line_ref"].length):
                continue
            if other.get("point_coverage", 0.0) + 0.05 < value.get(
                "point_coverage", 0.0
            ):
                continue
            keep[first] = False
            shadow_count += 1
            break
    return [value for index, value in enumerate(values) if keep[index]], {
        "exact_run_merge_count": merged_count,
        "density_ridge_shadow_count": shadow_count,
    }


def _supported_junction_updates(
    lines: list[dict],
    evidence: FrozenEvidence,
    all_tree: cKDTree | None,
    cfg: dict,
) -> tuple[list[dict], list[dict], dict]:
    """Correct tiny L/T endpoint errors and expose longer extensions as inference."""
    if len(lines) < 2 or all_tree is None or not np.any(evidence.structural_mask):
        return lines, [], {
            "candidate_count": 0,
            "snapped_count": 0,
            "inferred_count": 0,
            "rejected_count": 0,
        }
    evidence_tree = cKDTree(evidence.xy[evidence.structural_mask])
    maximum_extension = float(cfg.get("architectural_junction_extension_max_m", 0.30))
    direct_snap = float(cfg.get("architectural_junction_direct_snap_m", 0.05))
    support_distance = float(cfg.get("architectural_support_distance_m", 0.15))
    minimum_angle = math.radians(
        float(cfg.get("architectural_junction_min_angle_deg", 20.0))
    )
    proposals: dict[tuple[int, int], tuple[float, np.ndarray, int]] = {}
    candidate_count = 0
    rejected = 0
    axes = [_axis_record(value["line_ref"]) for value in lines]
    for first in range(len(lines)):
        d1, _, _, _ = axes[first]
        p1 = np.asarray(lines[first]["line_ref"].coords, dtype=float)[0]
        for second in range(first + 1, len(lines)):
            d2, _, _, _ = axes[second]
            angle = _angle_difference(d1, d2)
            if angle < minimum_angle or angle > math.pi - minimum_angle:
                continue
            p2 = np.asarray(lines[second]["line_ref"].coords, dtype=float)[0]
            matrix = np.column_stack([d1, -d2])
            if abs(float(np.linalg.det(matrix))) < 1e-6:
                continue
            parameters = np.linalg.solve(matrix, p2 - p1)
            intersection = p1 + d1 * parameters[0]
            endpoints1 = np.asarray(lines[first]["line_ref"].coords, dtype=float)[[0, -1]]
            endpoints2 = np.asarray(lines[second]["line_ref"].coords, dtype=float)[[0, -1]]
            distance1 = np.linalg.norm(endpoints1 - intersection, axis=1)
            distance2 = np.linalg.norm(endpoints2 - intersection, axis=1)
            near1, near2 = float(np.min(distance1)), float(np.min(distance2))
            inside1 = lines[first]["line_ref"].distance(
                LineString([intersection, intersection + d1 * 1e-6])
            ) <= 1e-5
            inside2 = lines[second]["line_ref"].distance(
                LineString([intersection, intersection + d2 * 1e-6])
            ) <= 1e-5
            if (near1 > maximum_extension and not inside1) or (
                near2 > maximum_extension and not inside2
            ):
                continue
            if near1 > maximum_extension and near2 > maximum_extension:
                continue
            # Valid graph junctions are either T connections (one intersection
            # lies on the other observed segment) or compact L gaps.  Two
            # arbitrary extended lines crossing in empty space are rejected.
            compact_l = (
                near1 <= min(maximum_extension, 0.20)
                and near2 <= min(maximum_extension, 0.20)
                and near1 + near2 <= maximum_extension
            )
            if not (inside1 or inside2 or compact_l):
                continue
            candidate_count += 1
            check_points = [intersection]
            for direction, endpoints in ((d1, endpoints1), (d2, endpoints2)):
                closest = endpoints[
                    int(np.argmin(np.linalg.norm(endpoints - intersection, axis=1)))
                ]
                inward = closest - intersection
                norm = float(np.linalg.norm(inward))
                check_points.append(
                    intersection + inward / norm * min(0.20, norm)
                    if norm > 1e-6
                    else intersection + direction * 0.15
                )
            if np.any(
                evidence_tree.query(np.asarray(check_points), k=1)[0]
                > support_distance
            ):
                rejected += 1
                continue
            angle_score = abs(math.sin(angle))
            for line_index, distances in ((first, distance1), (second, distance2)):
                endpoint_index = int(np.argmin(distances))
                distance = float(distances[endpoint_index])
                if distance > maximum_extension:
                    continue
                score = angle_score + 1.0 - distance / max(maximum_extension, 1e-6)
                key = (line_index, endpoint_index)
                if key not in proposals or score > proposals[key][0]:
                    proposals[key] = (
                        score,
                        intersection,
                        second if line_index == first else first,
                    )

    inferred: list[dict] = []
    snapped = 0
    for (line_index, endpoint_index), (_, intersection, other_index) in proposals.items():
        value = lines[line_index]
        coordinates = np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]]
        old_endpoint = coordinates[endpoint_index].copy()
        distance = float(np.linalg.norm(old_endpoint - intersection))
        if distance <= direct_snap:
            original = value["line_ref"]
            original_distances = all_tree.query(_sample_line(original, 0.08), k=1)[0]
            coordinates[endpoint_index] = intersection
            candidate = LineString(coordinates)
            candidate_distances = all_tree.query(_sample_line(candidate, 0.08), k=1)[0]
            if (
                float(np.mean(candidate_distances <= support_distance))
                >= float(np.mean(original_distances <= support_distance))
                - float(cfg.get("architectural_max_coverage_regression", 0.02))
                and float(np.quantile(candidate_distances, 0.95))
                <= float(np.quantile(original_distances, 0.95))
                + float(cfg.get("architectural_local_p95_regression_m", 0.02))
            ):
                value["line_ref"] = candidate
                value.setdefault("junction_node_ids", []).append(
                    f"J_{line_index:04d}_{other_index:04d}"
                )
                snapped += 1
            else:
                rejected += 1
        elif distance <= maximum_extension:
            connector = LineString([old_endpoint, intersection])
            connector_distances = all_tree.query(
                _sample_line(connector, 0.03), k=1
            )[0]
            if (
                float(np.mean(connector_distances <= 0.08))
                < float(cfg.get("architectural_junction_min_point_support", 0.85))
                or float(np.quantile(connector_distances, 0.95)) > 0.10
            ):
                rejected += 1
                continue
            inferred.append(
                {
                    "candidate_id": f"JT{len(inferred):04d}",
                    "line_ref": connector,
                    "classification": "inferred_connection",
                    "node_ids": [],
                    "selection_reasons": [
                        "supported_l_or_t_extension",
                        "frozen_structural_evidence",
                    ],
                    "source_candidate_ids": [
                        value.get("candidate_id", ""),
                        lines[other_index].get("candidate_id", ""),
                    ],
                    "observed": False,
                }
            )
    return lines, inferred, {
        "candidate_count": candidate_count,
        "snapped_count": snapped,
        "inferred_count": len(inferred),
        "rejected_count": rejected,
    }


def _classify_candidates(candidates: list[dict], cfg: dict) -> None:
    for value in candidates:
        reasons = []
        building = (
            value["length_m"] >= float(cfg.get("architectural_min_wall_length_m", 0.35))
            and value["session_count"] >= int(cfg.get("architectural_min_sessions", 2))
            and value["point_coverage"] >= float(cfg.get("architectural_min_point_coverage", 0.80))
            and (
                value["structural_coverage"] >= float(cfg.get("architectural_min_structural_coverage", 0.42))
                or value["slice_count"] >= int(cfg.get("architectural_min_slice_count", 4))
            )
            and value["vertical_span_m"] >= float(cfg.get("architectural_min_vertical_span_m", 1.20))
        )
        if building:
            reasons.extend(["vertical_support", "multi_session", "line_evidence"])
            value["classification"] = "building_wall"
        else:
            low = (
                value["length_m"] >= float(cfg.get("architectural_low_min_length_m", 0.40))
                and value["session_count"] >= int(cfg.get("architectural_min_sessions", 2))
                and value["low_coverage"] >= float(cfg.get("architectural_low_min_coverage", 0.55))
                and value["point_coverage"] >= float(cfg.get("architectural_min_point_coverage", 0.80))
                and value.get("z_min_m", 99.0)
                <= float(cfg.get("_architectural_floor_m", 0.0))
                + float(cfg.get("architectural_low_max_z_min_m", 0.45))
            )
            if low:
                reasons.extend(["near_floor_support", "multi_session", "stable_low_boundary"])
                value["classification"] = "low_structure"
            else:
                if value["session_count"] < int(cfg.get("architectural_min_sessions", 2)):
                    reasons.append("single_session_or_missing_session_support")
                if value["vertical_span_m"] < float(cfg.get("architectural_min_vertical_span_m", 1.20)):
                    reasons.append("insufficient_vertical_span")
                if value["structural_coverage"] < float(cfg.get("architectural_min_structural_coverage", 0.42)):
                    reasons.append("weak_structural_coverage")
                if value["length_m"] < float(cfg.get("architectural_min_wall_length_m", 0.35)):
                    reasons.append("short_fragment")
                value["classification"] = "uncertain_detail"
        value["selection_reasons"] = reasons
        value["protected"] = bool(
            value["classification"] == "building_wall"
            and value["structural_coverage"] >= 0.72
            and value["session_count"] >= 2
            and value["length_m"] >= 1.0
        )


def _evidence_coverage(lines: list[dict], points: np.ndarray, distance_m: float) -> float:
    if not len(points):
        return 1.0
    samples = np.vstack([_sample_line(value["line_ref"], 0.10) for value in lines]) if lines else np.empty((0, 2))
    if not len(samples):
        return 0.0
    return float(np.mean(cKDTree(samples).query(points, k=1)[0] <= distance_m))


def _milp_select(
    candidates: list[dict], evidence: FrozenEvidence, cfg: dict
) -> tuple[list[dict], dict]:
    pool = [value for value in candidates if value["classification"] == "building_wall"]
    if not pool:
        return [], {"status": "empty", "solver_success": False}
    structural_xy = evidence.xy[evidence.structural_mask]
    maximum = int(cfg.get("architectural_milp_max_evidence", 1800))
    if len(structural_xy) > maximum:
        indices = np.linspace(0, len(structural_xy) - 1, maximum).astype(int)
        structural_xy = structural_xy[indices]
    radius = float(cfg.get("architectural_support_distance_m", 0.15))
    candidate_samples = [_sample_line(value["line_ref"], 0.10) for value in pool]
    covering: list[list[int]] = [[] for _ in range(len(structural_xy))]
    evidence_tree = cKDTree(structural_xy) if len(structural_xy) else None
    if evidence_tree is not None:
        for index, samples in enumerate(candidate_samples):
            touched = set()
            for values in evidence_tree.query_ball_point(samples, radius):
                touched.update(values)
            for evidence_index in touched:
                covering[evidence_index].append(index)
    active_evidence = [index for index, values in enumerate(covering) if values]
    candidate_count, evidence_count = len(pool), len(active_evidence)
    objective = np.zeros(candidate_count + evidence_count, dtype=float)
    for index, value in enumerate(pool):
        objective[index] = (
            float(cfg.get("architectural_milp_line_penalty", 0.35))
            + float(cfg.get("architectural_milp_length_penalty", 0.015)) * value["length_m"]
            - 0.28 * value["structural_coverage"]
            - 0.08 * min(value["session_count"], 3)
        )
    objective[candidate_count:] = -float(cfg.get("architectural_milp_evidence_reward", 0.030))
    rows, columns, data, lower, upper = [], [], [], [], []
    for local_index, evidence_index in enumerate(active_evidence):
        row = len(lower)
        # y_e <= sum_i x_i
        rows.append(row)
        columns.append(candidate_count + local_index)
        data.append(1.0)
        for candidate_index in covering[evidence_index]:
            rows.append(row)
            columns.append(candidate_index)
            data.append(-1.0)
        lower.append(-np.inf)
        upper.append(0.0)
    matrix = coo_matrix((data, (rows, columns)), shape=(len(lower), len(objective))).tocsr()
    lb = np.zeros(len(objective))
    ub = np.ones(len(objective))
    for index, value in enumerate(pool):
        if value.get("protected"):
            lb[index] = 1.0
    try:
        result = milp(
            objective,
            integrality=np.ones(len(objective)),
            bounds=Bounds(lb, ub),
            constraints=LinearConstraint(matrix, np.asarray(lower), np.asarray(upper)),
            options={"time_limit": float(cfg.get("architectural_milp_time_limit_s", 120.0))},
        )
    except Exception as exc:  # pragma: no cover - solver failures are platform dependent
        result = None
        error = str(exc)
    else:
        error = None
    if result is None or result.x is None:
        selected = list(pool)
        status = "fallback_all_qualified"
    else:
        selected = [value for index, value in enumerate(pool) if result.x[index] >= 0.5]
        status = str(result.message)

    # Independent frozen-evidence rollback/add-back.  Selection cannot obtain a
    # prettier score by discarding more than two percentage points of evidence.
    baseline_coverage = _evidence_coverage(pool, structural_xy, radius)
    selected_coverage = _evidence_coverage(selected, structural_xy, radius)
    minimum = baseline_coverage - float(cfg.get("architectural_max_coverage_regression", 0.02))
    if selected_coverage < minimum:
        remaining = [value for value in pool if value not in selected]
        remaining.sort(key=lambda value: (value["structural_coverage"] * value["length_m"], value["session_count"]), reverse=True)
        for value in remaining:
            selected.append(value)
            selected_coverage = _evidence_coverage(selected, structural_xy, radius)
            if selected_coverage >= minimum:
                break
        status += "; evidence_addback"
    return selected, {
        "status": status,
        "solver_success": bool(result is not None and result.x is not None),
        "objective": None if result is None or result.fun is None else float(result.fun),
        "candidate_count": candidate_count,
        "evidence_variable_count": evidence_count,
        "baseline_frozen_coverage": baseline_coverage,
        "selected_frozen_coverage": selected_coverage,
        "coverage_change": selected_coverage - baseline_coverage,
        "error": error,
    }


def _node_degrees(lines: list[dict], tolerance_m: float) -> tuple[np.ndarray, list[int], list[str]]:
    if not lines:
        return np.empty((0, 2)), [], []
    endpoints = np.vstack([np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]] for value in lines])
    parent = np.arange(len(endpoints))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = int(parent[index])
        return index

    for first, second in cKDTree(endpoints).query_pairs(tolerance_m):
        a, b = root(first), root(second)
        if a != b:
            parent[b] = a
    roots = [root(index) for index in range(len(endpoints))]
    groups = {value: index for index, value in enumerate(sorted(set(roots)))}
    node_index = [groups[value] for value in roots]
    centers = np.zeros((len(groups), 2), dtype=float)
    counts = np.zeros(len(groups), dtype=int)
    for index, node in enumerate(node_index):
        centers[node] += endpoints[index]
        counts[node] += 1
    centers /= counts[:, None]
    ids = [f"N{index:04d}" for index in range(len(groups))]
    return centers, node_index, ids


def _assign_node_ids_without_moving(
    lines: list[dict], tolerance_m: float = 0.001
) -> None:
    """Assign shared IDs only; wall endpoints remain on their selected axes."""
    if not lines:
        return
    endpoints = np.vstack(
        [np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]] for value in lines]
    )
    parent = np.arange(len(endpoints))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = int(parent[index])
        return index

    for first, second in cKDTree(endpoints).query_pairs(tolerance_m):
        a, b = root(first), root(second)
        if a != b:
            parent[b] = a
    roots = [root(index) for index in range(len(endpoints))]
    groups = {value: index for index, value in enumerate(sorted(set(roots)))}
    for line_index, value in enumerate(lines):
        value["node_ids"] = [
            f"N{groups[roots[2 * line_index]]:04d}",
            f"N{groups[roots[2 * line_index + 1]]:04d}",
        ]


def _split_supported_t_junctions(lines: list[dict], cfg: dict) -> tuple[list[dict], int]:
    """Split the through wall at an already snapped T endpoint."""
    tolerance = float(cfg.get("architectural_shared_node_tolerance_m", 0.001))
    minimum_angle = math.radians(
        float(cfg.get("architectural_junction_min_angle_deg", 20.0))
    )
    split_positions: dict[int, list[float]] = {}
    for first, value in enumerate(lines):
        endpoints = np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]]
        direction = _direction(value["line_ref"])
        for second, other in enumerate(lines):
            if first == second:
                continue
            if _angle_difference(direction, _direction(other["line_ref"])) < minimum_angle:
                continue
            for endpoint in endpoints:
                projected = float(other["line_ref"].project(Point(endpoint)))
                point = np.asarray(other["line_ref"].interpolate(projected).coords[0])
                if float(np.linalg.norm(point - endpoint)) > tolerance:
                    continue
                if projected <= tolerance or projected >= other["line_ref"].length - tolerance:
                    continue
                split_positions.setdefault(second, []).append(projected)

    result: list[dict] = []
    split_count = 0
    for index, value in enumerate(lines):
        positions = sorted(
            {
                round(position, 6)
                for position in split_positions.get(index, [])
                if tolerance < position < value["line_ref"].length - tolerance
            }
        )
        if not positions:
            result.append(value)
            continue
        boundaries = [0.0, *positions, float(value["line_ref"].length)]
        for part_index, (start, end) in enumerate(zip(boundaries[:-1], boundaries[1:])):
            if end - start <= tolerance:
                continue
            child = dict(value)
            child["candidate_id"] = f"{value.get('candidate_id', 'W')}_T{part_index:02d}"
            child["line_ref"] = LineString(
                [
                    value["line_ref"].interpolate(start).coords[0],
                    value["line_ref"].interpolate(end).coords[0],
                ]
            )
            child["selection_reasons"] = sorted(
                set(child.get("selection_reasons", [])) | {"supported_t_junction_split"}
            )
            result.append(child)
        split_count += len(positions)
    _assign_node_ids_without_moving(result, tolerance)
    return result, split_count


def _remove_unsupported_spurs(
    selected: list[dict], cfg: dict
) -> tuple[list[dict], list[dict]]:
    if not selected:
        return [], []
    _, endpoint_nodes, _ = _node_degrees(
        selected, float(cfg.get("architectural_node_cluster_m", 0.10))
    )
    degrees = np.zeros(max(endpoint_nodes, default=-1) + 1, dtype=int)
    for node in endpoint_nodes:
        degrees[node] += 1
    kept, rejected = [], []
    for index, value in enumerate(selected):
        first, second = endpoint_nodes[2 * index : 2 * index + 2]
        is_spur = (
            value["line_ref"].length < float(cfg.get("architectural_spur_max_length_m", 0.75))
            and min(degrees[first], degrees[second]) <= 1
            and (
                value.get("slice_count", 0)
                < int(cfg.get("architectural_short_wall_min_slices", 2))
                or value["structural_coverage"]
                < float(cfg.get("architectural_spur_protect_coverage", 0.72))
            )
            and not value.get("protected")
        )
        if is_spur:
            value = dict(value)
            value["classification"] = "uncertain_detail"
            value["selection_reasons"] = [*value.get("selection_reasons", []), "unsupported_dangling_spur"]
            rejected.append(value)
        else:
            kept.append(value)
    # IDs reflect actual coincident endpoints.  Nearby endpoints are never
    # averaged because that bends fixed high-slice axes and creates kinks.
    _assign_node_ids_without_moving(
        kept, float(cfg.get("architectural_shared_node_tolerance_m", 0.001))
    )
    return kept, rejected


def _select_low_structures(
    candidates: list[dict], walls: list[dict], cfg: dict
) -> tuple[list[dict], list[dict]]:
    """Keep low boundaries only when connected to the building or a closed net."""
    if not candidates:
        return [], []
    wall_samples = (
        np.vstack([_sample_line(value["line_ref"], 0.10) for value in walls])
        if walls
        else np.empty((0, 2))
    )
    wall_tree = cKDTree(wall_samples) if len(wall_samples) else None
    _, endpoint_nodes, _ = _node_degrees(
        candidates, float(cfg.get("architectural_low_node_cluster_m", 0.14))
    )
    degrees = np.bincount(endpoint_nodes) if endpoint_nodes else np.empty(0, dtype=int)
    kept, rejected = [], []
    for index, value in enumerate(candidates):
        endpoints = np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]]
        connected_to_wall = 0
        if wall_tree is not None:
            connected_to_wall = int(
                np.count_nonzero(
                    wall_tree.query(endpoints, k=1)[0]
                    <= float(cfg.get("architectural_low_connection_m", 0.20))
                )
            )
        first, second = endpoint_nodes[2 * index : 2 * index + 2]
        closed_network = degrees[first] >= 2 and degrees[second] >= 2
        reliable = (
            value["low_coverage"]
            >= float(cfg.get("architectural_low_reliable_coverage", 0.72))
            and value["session_count"] >= int(cfg.get("architectural_min_sessions", 2))
            and (connected_to_wall >= 1 or closed_network)
        )
        value["low_connected_endpoint_count"] = connected_to_wall
        value["low_closed_network"] = bool(closed_network)
        if reliable:
            value["selection_reasons"] = [
                *value.get("selection_reasons", []),
                "connected_to_building" if connected_to_wall else "closed_low_network",
            ]
            kept.append(value)
        else:
            value = dict(value)
            value["classification"] = "uncertain_detail"
            value["selection_reasons"] = [
                *value.get("selection_reasons", []),
                "low_structure_not_connected_or_closed",
            ]
            rejected.append(value)
    return kept, rejected


def _evidence_constrained_connections(
    walls: list[dict], evidence: FrozenEvidence, cfg: dict
) -> list[dict]:
    """Add only point-supported collinear gaps; likely door gaps remain open."""
    maximum_gap = float(cfg.get("architectural_collinear_gap_max_m", 0.80))
    radius = float(cfg.get("architectural_support_distance_m", 0.15))
    tree = cKDTree(evidence.xy[evidence.structural_mask]) if np.any(evidence.structural_mask) else None
    inferred: list[dict] = []
    axes = [_axis_record(value["line_ref"]) for value in walls]
    for first in range(len(walls)):
        d1, n1, o1, i1 = axes[first]
        for second in range(first + 1, len(walls)):
            d2, _, _, _ = axes[second]
            if _angle_difference(d1, d2) > math.radians(2.0):
                continue
            coordinates = np.asarray(walls[second]["line_ref"].coords, dtype=float)[[0, -1]]
            if abs(float(np.mean(coordinates @ n1)) - o1) > 0.08:
                continue
            i2 = tuple(sorted((coordinates @ d1).tolist()))
            if i1[1] < i2[0]:
                start, end = i1[1], i2[0]
            elif i2[1] < i1[0]:
                start, end = i2[1], i1[0]
            else:
                continue
            gap = end - start
            if gap <= 0.02 or gap > maximum_gap:
                continue
            line = LineString([d1 * start + n1 * o1, d1 * end + n1 * o1])
            samples = _sample_line(line, 0.05)
            support = _tree_fraction(tree, samples, radius)
            if support < float(cfg.get("architectural_gap_min_evidence", 0.60)):
                continue
            inferred.append(
                {
                    "candidate_id": f"I{len(inferred):04d}",
                    "line_ref": line,
                    "classification": "inferred_connection",
                    "node_ids": [],
                    "selection_reasons": ["collinear_gap", "frozen_structural_evidence"],
                    "support_fraction": support,
                    "source_candidate_ids": [walls[first]["candidate_id"], walls[second]["candidate_id"]],
                    "observed": False,
                }
            )
    return inferred


def _line_point_metrics(lines: list[dict], clean_points: np.ndarray, threshold_m: float = 0.15) -> dict:
    if not lines:
        return {"p95_m": None, "support_fraction": 0.0}
    tree = cKDTree(clean_points[:, :2])
    distances = []
    for value in lines:
        distances.extend(tree.query(_sample_line(value["line_ref"], 0.05), k=1)[0].tolist())
    values = np.asarray(distances)
    return {
        "p95_m": float(np.quantile(values, 0.95)),
        "support_fraction": float(np.mean(values <= threshold_m)),
    }


def _is_protected_double_pair(first: dict, second: dict, protected_pairs: list[dict]) -> bool:
    first_sources = set(first.get("source_candidate_ids", [first.get("candidate_id")]))
    second_sources = set(second.get("source_candidate_ids", [second.get("candidate_id")]))
    return any(
        (
            value["first"] in first_sources
            and value["second"] in second_sources
        )
        or (
            value["second"] in first_sources
            and value["first"] in second_sources
        )
        for value in protected_pairs
    )


def _graph_clutter_metrics(
    lines: list[dict], cfg: dict, protected_pairs: list[dict] | None = None
) -> dict:
    if not lines:
        return {"line_count": 0, "dangling_branch_count": 0, "unsupported_short_spur_count": 0, "near_parallel_duplicate_length_m": 0.0}
    _, endpoint_nodes, _ = _node_degrees(lines, float(cfg.get("architectural_node_cluster_m", 0.10)))
    degrees = np.bincount(endpoint_nodes)
    dangling = 0
    short_spurs = 0
    for index, value in enumerate(lines):
        first, second = endpoint_nodes[2 * index : 2 * index + 2]
        if min(degrees[first], degrees[second]) <= 1:
            dangling += 1
            if value["line_ref"].length < float(cfg.get("architectural_spur_max_length_m", 0.75)):
                short_spurs += 1
    duplicate_length = 0.0
    protected_pairs = protected_pairs or []
    axes = [_axis_record(value["line_ref"]) for value in lines]
    for first in range(len(lines)):
        d1, n1, o1, i1 = axes[first]
        for second in range(first + 1, len(lines)):
            d2, _, _, _ = axes[second]
            if _angle_difference(d1, d2) > math.radians(3.0):
                continue
            coords = np.asarray(lines[second]["line_ref"].coords, dtype=float)[[0, -1]]
            separation = abs(float(np.mean(coords @ n1)) - o1)
            if separation > float(cfg.get("architectural_duplicate_offset_m", 0.20)):
                continue
            interval = tuple(sorted((coords @ d1).tolist()))
            overlap = min(i1[1], interval[1]) - max(i1[0], interval[0])
            if overlap >= 0.50 and not _is_protected_double_pair(
                lines[first], lines[second], protected_pairs
            ):
                duplicate_length += overlap
    return {
        "line_count": len(lines),
        "dangling_branch_count": int(dangling),
        "unsupported_short_spur_count": int(short_spurs),
        "near_parallel_duplicate_length_m": float(duplicate_length),
    }


def _heldout_session_residuals(
    lines: list[dict], session_points: list[tuple[str, np.ndarray]], cfg: dict
) -> dict:
    """Evaluate each fitted wall against each acquisition independently."""
    by_session = {}
    combined = []
    for name, points in session_points:
        if not len(points):
            continue
        xy = np.unique(
            np.round(points[:, :2] / 0.03).astype(np.int64), axis=0
        ).astype(float) * 0.03
        tree = cKDTree(xy)
        distances = []
        for value in lines:
            if value.get("session_support", {}).get(name, 0.0) < float(
                cfg.get("architectural_session_coverage_fraction", 0.35)
            ):
                continue
            samples = _sample_line(value["line_ref"], 0.10)
            # This audit is deliberately transverse: longitudinal endpoint
            # visibility differs between acquisitions and is assessed by the
            # coverage metric, not misreported as wall-axis displacement.
            if len(samples) > 4:
                samples = samples[1:-1]
            nearest = tree.query(samples, k=1)[1]
            direction, normal, offset, _ = _axis_record(value["line_ref"])
            del direction
            distances.extend(np.abs(xy[nearest] @ normal - offset).tolist())
        if distances:
            array = np.asarray(distances)
            p95 = float(np.quantile(array, 0.95))
            by_session[name] = {
                "sample_count": int(len(array)),
                "median_m": float(np.median(array)),
                "p95_m": p95,
            }
            combined.extend(array.tolist())
    return {
        "by_session": by_session,
        "p95_m": None if not combined else float(np.quantile(np.asarray(combined), 0.95)),
    }


def _leave_one_session_out_residuals(
    lines: list[dict], session_points: list[tuple[str, np.ndarray]], cfg: dict
) -> dict:
    """Refit from N-1 acquisitions and score the same wall face by height."""
    prepared = {}
    for name, points in session_points:
        if not len(points):
            continue
        keys = np.column_stack(
            [
                np.round(points[:, :2] / 0.03).astype(np.int64),
                np.floor(points[:, 2:3] / 0.10).astype(np.int64),
            ]
        )
        _, unique = np.unique(keys, axis=0, return_index=True)
        xyz = points[np.sort(unique)]
        prepared[name] = (xyz, cKDTree(xyz[:, :2]))
    by_session = {}
    combined: list[float] = []
    corridor = float(cfg.get("architectural_loo_fit_corridor_m", 0.18))
    minimum_coverage = float(cfg.get("architectural_session_coverage_fraction", 0.35))
    total_reference_length = float(sum(value["line_ref"].length for value in lines))
    for heldout_name, (heldout_xyz, heldout_tree) in prepared.items():
        residuals: list[float] = []
        fitted_count = 0
        matched_length = 0.0
        for value in lines:
            original_direction, original_normal, original_offset, interval = _axis_record(
                value["line_ref"]
            )
            samples = _sample_line(value["line_ref"], 0.10)
            z_ranges = value.get("observed_z_ranges_m") or []

            def height_mask(points: np.ndarray) -> np.ndarray:
                if not z_ranges:
                    return np.ones(len(points), dtype=bool)
                result = np.zeros(len(points), dtype=bool)
                for lower, upper in z_ranges:
                    result |= (points[:, 2] >= float(lower)) & (
                        points[:, 2] <= float(upper)
                    )
                return result

            training_parts = []
            for name, (xyz, tree) in prepared.items():
                if name == heldout_name:
                    continue
                indices = set()
                for neighbours in tree.query_ball_point(samples, corridor):
                    indices.update(neighbours)
                if indices:
                    local = xyz[np.fromiter(indices, dtype=int)]
                    local = local[height_mask(local)]
                    if len(local):
                        training_parts.append(local)
            if not training_parts:
                continue
            training = np.vstack(training_parts)
            along = training[:, :2] @ original_direction
            cross = training[:, :2] @ original_normal
            keep = (
                (along >= interval[0] - 0.10)
                & (along <= interval[1] + 0.10)
                & (np.abs(cross - original_offset) <= corridor)
            )
            training = training[keep]
            if len(training) < 8:
                continue
            # A wall often contributes two physical faces.  Refit the face
            # supported near the delivered axis instead of taking the median
            # between two peaks; the held-out acquisition remains untouched.
            training_cross = training[:, :2] @ original_normal
            bin_m = 0.02
            boundaries = np.arange(
                original_offset - corridor,
                original_offset + corridor + bin_m * 1.5,
                bin_m,
            )
            histogram, edges = np.histogram(training_cross, boundaries)
            centers = (edges[:-1] + edges[1:]) / 2.0
            scores = histogram.astype(float) - 0.75 * np.abs(
                centers - original_offset
            ) / max(bin_m, 1e-9)
            peak_offset = float(centers[int(np.argmax(scores))])
            face = np.abs(training_cross - peak_offset) <= 0.05
            if np.count_nonzero(face) >= 8:
                training = training[face]
            if len(np.unique(np.floor(training[:, 2] / 0.10))) < 2:
                continue
            center = np.median(training[:, :2], axis=0)
            covariance = np.cov(training[:, :2] - center, rowvar=False)
            eigenvalues, eigenvectors = np.linalg.eigh(covariance)
            direction = eigenvectors[:, int(np.argmax(eigenvalues))]
            if float(direction @ original_direction) < 0:
                direction *= -1
            if _angle_difference(direction, original_direction) > math.radians(5.0):
                direction = original_direction
            normal = np.asarray([-direction[1], direction[0]])
            offset = float(np.median(training[:, :2] @ normal))

            heldout_indices = set()
            for neighbours in heldout_tree.query_ball_point(samples, corridor):
                heldout_indices.update(neighbours)
            if not heldout_indices:
                continue
            heldout = heldout_xyz[np.fromiter(heldout_indices, dtype=int)]
            heldout = heldout[height_mask(heldout)]
            if not len(heldout):
                continue
            heldout_along = heldout[:, :2] @ direction
            heldout_cross = heldout[:, :2] @ normal
            heldout_keep = (
                (heldout_along >= interval[0] - 0.10)
                & (heldout_along <= interval[1] + 0.10)
                & (np.abs(heldout_cross - offset) <= corridor)
            )
            heldout = heldout[heldout_keep]
            if not len(heldout):
                continue
            heldout_cross = heldout[:, :2] @ normal
            boundaries = np.arange(
                offset - corridor, offset + corridor + 0.03, 0.02
            )
            histogram, edges = np.histogram(heldout_cross, boundaries)
            centers = (edges[:-1] + edges[1:]) * 0.5
            peak = float(centers[int(np.argmax(histogram - 0.75 * np.abs(centers - offset) / 0.02))])
            face = np.abs(heldout_cross - peak) <= 0.05
            heldout = heldout[face]
            if len(heldout) < 3:
                continue
            local_residuals = []
            for sample in samples:
                local_along = np.abs((heldout[:, :2] - sample) @ direction) <= 0.10
                local = heldout[local_along]
                if len(local) < 2 or len(np.unique(np.floor(local[:, 2] / 0.10))) < 2:
                    continue
                local_residuals.append(
                    float(abs(np.median(local[:, :2] @ normal) - offset))
                )
            coverage = len(local_residuals) / max(1, len(samples))
            if coverage < minimum_coverage:
                continue
            residuals.extend(local_residuals)
            fitted_count += 1
            matched_length += float(value["line_ref"].length) * coverage
        if residuals:
            values = np.asarray(residuals)
            p95 = float(np.quantile(values, 0.95))
            by_session[heldout_name] = {
                "fitted_wall_count": fitted_count,
                "sample_count": int(len(values)),
                "median_m": float(np.median(values)),
                "p95_m": p95,
                "reference_length_m": total_reference_length,
                "matched_length_m": matched_length,
                "matched_fraction": matched_length / max(total_reference_length, 1e-9),
                "unmatched_length_m": max(0.0, total_reference_length - matched_length),
            }
            combined.extend(values.tolist())
    return {
        "method": "leave_one_acquisition_out_refit",
        "session_count": int(len(prepared)),
        "applicable": bool(len(prepared) >= 2),
        "by_session": by_session,
        "p95_m": None
        if not combined
        else float(np.quantile(np.asarray(combined), 0.95)),
        "reference_length_m": total_reference_length,
        "matched_length_m": float(
            sum(value.get("matched_length_m", 0.0) for value in by_session.values())
        ),
        "unmatched_length_m": float(
            sum(value.get("unmatched_length_m", 0.0) for value in by_session.values())
        ),
    }


def refresh_architectural_result_metrics(
    result: ArchitecturalResult,
    clean_points: np.ndarray,
    session_points: list[tuple[str, np.ndarray]],
    cfg: dict,
) -> None:
    """Recompute architectural QA after the shared graph becomes authoritative."""
    point_metrics = _line_point_metrics(result.walls, clean_points)
    loo_metrics = _leave_one_session_out_residuals(result.walls, session_points, cfg)
    node_spread = _shared_node_spread(result.walls)
    result.metrics.update(
        {
            "algorithm_version": "structure-graph-v8-scored-wall-absorption",
            "architectural_wall_count": len(result.walls),
            "low_structure_count": len(result.low_structures),
            "architectural_line_to_point_p95_m": point_metrics["p95_m"],
            "architectural_line_support_fraction_0_15m": point_metrics[
                "support_fraction"
            ],
            "leave_one_session_out_residual": loo_metrics,
            "architectural_shared_node_max_spread_m": node_spread,
        }
    )
    result.audit.update(
        {
            "line_to_point_p95_pass": point_metrics["p95_m"] is not None
            and point_metrics["p95_m"]
            <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
            "line_support_pass": point_metrics["support_fraction"]
            >= float(cfg.get("accept_line_support_fraction", 0.95)),
            "leave_one_session_out_pass": not loo_metrics.get("applicable", False)
            or (
                loo_metrics["p95_m"] is not None
                and loo_metrics["p95_m"]
                <= float(cfg.get("architectural_independent_session_p95_m", 0.05))
            ),
            "shared_nodes_pass": node_spread is None or node_spread <= 0.001,
        }
    )


def _sampled_geometry_retention(
    reference: list[dict], delivered: list[dict], distance_m: float
) -> dict:
    if not reference:
        return {"reference_length_m": 0.0, "retained_length_m": 0.0, "fraction": 1.0}
    delivered_samples = (
        np.vstack([_sample_line(value["line_ref"], 0.04) for value in delivered])
        if delivered
        else np.empty((0, 2))
    )
    tree = cKDTree(delivered_samples) if len(delivered_samples) else None
    reference_length = 0.0
    retained_length = 0.0
    for value in reference:
        line = value["line_ref"]
        samples = _sample_line(line, 0.04)
        fraction = (
            0.0
            if tree is None
            else float(np.mean(tree.query(samples, k=1)[0] <= distance_m))
        )
        reference_length += float(line.length)
        retained_length += float(line.length) * fraction
    return {
        "reference_length_m": reference_length,
        "retained_length_m": retained_length,
        "fraction": retained_length / max(reference_length, 1e-9),
    }


def _optimize_high_backbone_plan(
    union: list[dict],
    clean_points: np.ndarray,
    clean_session_points: list[tuple[str, np.ndarray]],
    floor_m: float,
    ceiling_m: float,
    cfg: dict,
    raw_slices: list[Any] | None,
) -> ArchitecturalResult:
    evidence = build_frozen_evidence(
        clean_points, clean_session_points, floor_m, ceiling_m, cfg
    )
    selected, uncertain, backbone_metrics = _build_high_slice_backbone(
        raw_slices,
        clean_points,
        clean_session_points,
        evidence,
        floor_m,
        ceiling_m,
        cfg,
    )
    high_reference = [
        {**value, "line_ref": LineString(value["line_ref"].coords)}
        for value in selected
        if value.get("backbone_role") == "high_slice_fixed_axis"
    ]
    structural_xy = evidence.xy[evidence.structural_mask]
    support_distance = float(cfg.get("architectural_support_distance_m", 0.15))
    baseline_frozen_coverage = _evidence_coverage(
        selected, structural_xy, support_distance
    )

    selected, deduplication = _deduplicate_final_walls(selected, cfg)
    all_tree = cKDTree(evidence.xy) if len(evidence.xy) else None
    selected, junction_inferred, junction_metrics = _supported_junction_updates(
        selected, evidence, all_tree, cfg
    )
    selected, t_split_count = _split_supported_t_junctions(selected, cfg)

    structural_tree = (
        cKDTree(evidence.xy[evidence.structural_mask])
        if np.any(evidence.structural_mask)
        else None
    )
    low_tree = cKDTree(evidence.xy[evidence.low_mask]) if np.any(evidence.low_mask) else None
    session_trees = [
        (
            name,
            cKDTree(
                np.unique(
                    np.round(points[:, :2] / 0.04).astype(np.int64), axis=0
                ).astype(float)
                * 0.04
            ),
        )
        for name, points in clean_session_points
        if len(points)
    ]
    slice_trees = _slice_point_trees(raw_slices, clean_points)
    base_trees = _base_height_bin_trees(clean_points, floor_m, ceiling_m, cfg)
    for value in selected:
        _evaluate_candidate(
            value, evidence, structural_tree, low_tree, all_tree, session_trees, cfg
        )
        value["classification"] = "building_wall"
        _revalidate_height_support(
            value, raw_slices, slice_trees, base_trees, floor_m, cfg
        )
    selected, removed_spurs = _remove_unsupported_spurs(selected, cfg)
    uncertain.extend(removed_spurs)

    low_candidates = []
    remaining_uncertain = []
    for value in uncertain:
        if (
            value.get("low_coverage", 0.0)
            >= float(cfg.get("architectural_low_min_coverage", 0.55))
            and value["line_ref"].length
            >= float(cfg.get("architectural_low_min_length_m", 0.40))
            and value.get("z_min_m") is not None
            and float(value.get("z_min_m"))
            <= floor_m + float(cfg.get("architectural_low_max_z_min_m", 0.45))
            and value.get("vertical_span_m", float("inf"))
            < float(cfg.get("architectural_low_max_span_m", 1.20))
            and value.get("session_count", 0)
            >= int(cfg.get("architectural_min_sessions", 2))
        ):
            value["classification"] = "low_structure"
            low_candidates.append(value)
        else:
            remaining_uncertain.append(value)
    low, rejected_low = _select_low_structures(low_candidates, selected, cfg)
    uncertain = remaining_uncertain + rejected_low
    inferred = junction_inferred + _evidence_constrained_connections(
        selected, evidence, cfg
    )

    final_frozen_coverage = _evidence_coverage(
        selected, structural_xy, support_distance
    )
    retention = _sampled_geometry_retention(
        high_reference,
        selected,
        float(cfg.get("architectural_backbone_accept_distance_m", 0.15)),
    )
    baseline_runs = _merge_source_runs(
        [
            {**value, "source_observation_type": "calibrated_baseline"}
            for value in union
        ],
        cfg,
    )
    point_metrics = _line_point_metrics(selected, clean_points)
    loo_metrics = _leave_one_session_out_residuals(
        selected, clean_session_points, cfg
    )
    baseline_clutter = _graph_clutter_metrics(baseline_runs, cfg)
    optimized_clutter = _graph_clutter_metrics(selected, cfg)
    spur_reduction = 1.0 - optimized_clutter["unsupported_short_spur_count"] / max(
        1, baseline_clutter["unsupported_short_spur_count"]
    )
    duplicate_reduction = 1.0 - optimized_clutter[
        "near_parallel_duplicate_length_m"
    ] / max(1e-9, baseline_clutter["near_parallel_duplicate_length_m"])
    node_spread = _shared_node_spread(selected)
    audit = {
        "high_backbone_retention_pass": retention["fraction"]
        >= float(cfg.get("architectural_backbone_min_retention", 0.98)),
        "line_to_point_p95_pass": point_metrics["p95_m"] is not None
        and point_metrics["p95_m"]
        <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
        "line_support_pass": point_metrics["support_fraction"]
        >= float(cfg.get("accept_line_support_fraction", 0.95)),
        "frozen_coverage_pass": final_frozen_coverage
        >= baseline_frozen_coverage
        - float(cfg.get("architectural_max_coverage_regression", 0.02)),
        "leave_one_session_out_pass": not loo_metrics.get("applicable", False)
        or (
            loo_metrics["p95_m"] is not None
            and loo_metrics["p95_m"]
            <= float(cfg.get("architectural_independent_session_p95_m", 0.05))
        ),
        "shared_nodes_pass": node_spread is None or node_spread <= 0.001,
    }
    metrics = {
        "algorithm_version": "structure-graph-v8-scored-wall-absorption",
        "base_voxel_count": int(len(evidence.xy)),
        "frozen_structural_voxel_count": int(np.count_nonzero(evidence.structural_mask)),
        "frozen_low_voxel_count": int(np.count_nonzero(evidence.low_mask)),
        "backbone": backbone_metrics,
        "backbone_retention": retention,
        "backbone_deduplication": deduplication,
        "junction_optimization": junction_metrics,
        "supported_t_junction_split_count": t_split_count,
        "architectural_wall_count": len(selected),
        "low_structure_count": len(low),
        "uncertain_detail_count": len(uncertain),
        "inferred_connection_count": len(inferred),
        "architectural_line_to_point_p95_m": point_metrics["p95_m"],
        "architectural_line_support_fraction_0_15m": point_metrics[
            "support_fraction"
        ],
        "baseline_frozen_coverage": baseline_frozen_coverage,
        "final_frozen_coverage": final_frozen_coverage,
        "frozen_coverage_change": final_frozen_coverage - baseline_frozen_coverage,
        "leave_one_session_out_residual": loo_metrics,
        "architectural_shared_node_max_spread_m": node_spread,
        "baseline_graph": baseline_clutter,
        "optimized_graph": optimized_clutter,
        "unsupported_short_spur_reduction_fraction": spur_reduction,
        "near_parallel_duplicate_reduction_fraction": duplicate_reduction,
    }
    return ArchitecturalResult(
        selected,
        low,
        inferred,
        uncertain,
        evidence,
        metrics,
        audit,
        diagnostics={"high_backbone_reference": high_reference},
    )


def _shared_node_spread(lines: list[dict]) -> float | None:
    coordinates: dict[str, list[np.ndarray]] = {}
    for value in lines:
        endpoints = np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]]
        for node_id, point in zip(value.get("node_ids", []), endpoints):
            coordinates.setdefault(node_id, []).append(point)
    spreads = []
    for points in coordinates.values():
        if len(points) < 2:
            continue
        array = np.asarray(points)
        spreads.append(
            float(np.max(np.linalg.norm(array - np.mean(array, axis=0), axis=1)))
        )
    return None if not spreads else max(spreads)


def optimize_architectural_plan(
    union: list[dict],
    clean_points: np.ndarray,
    clean_session_points: list[tuple[str, np.ndarray]],
    floor_m: float,
    ceiling_m: float,
    main_angle: float,
    cfg: dict,
    raw_slices: list[Any] | None = None,
) -> ArchitecturalResult:
    cfg = {**cfg, "_architectural_floor_m": float(floor_m)}
    if bool(cfg.get("high_slice_backbone_enabled", False)):
        return _optimize_high_backbone_plan(
            union,
            clean_points,
            clean_session_points,
            floor_m,
            ceiling_m,
            cfg,
            raw_slices,
        )
    evidence = build_frozen_evidence(clean_points, clean_session_points, floor_m, ceiling_m, cfg)
    baseline_observations = [
        {**value, "source_observation_type": "calibrated_baseline"}
        for value in union
    ]
    raw_observations = _raw_slice_observations(raw_slices)
    ridge_observations = _density_ridge_observations(
        evidence, floor_m, ceiling_m, cfg
    )
    source_runs = _merge_source_runs(
        baseline_observations + raw_observations + ridge_observations, cfg
    )
    calibrated_baseline_runs = _merge_source_runs(baseline_observations, cfg)
    structural_tree = cKDTree(evidence.xy[evidence.structural_mask]) if np.any(evidence.structural_mask) else None
    low_tree = cKDTree(evidence.xy[evidence.low_mask]) if np.any(evidence.low_mask) else None
    all_tree = cKDTree(evidence.xy) if len(evidence.xy) else None
    session_trees = [
        (name, cKDTree(np.unique(np.round(points[:, :2] / 0.04).astype(np.int64), axis=0).astype(float) * 0.04))
        for name, points in clean_session_points
        if len(points)
    ]
    associated, double_pairs = _associate_and_fit(source_runs, evidence, clean_points, main_angle, cfg)
    session_refinement = _refine_candidates_against_sessions(
        associated, all_tree, session_trees, cfg
    )
    for value in associated:
        _evaluate_candidate(value, evidence, structural_tree, low_tree, all_tree, session_trees, cfg)
    _classify_candidates(associated, cfg)
    selected, solver_metrics = _milp_select(associated, evidence, cfg)
    # The equal-session refit can make two formerly separated observations
    # converge.  Re-associate once more (bounded by the three-round design)
    # and protect any cross-section that still has two resolvable peaks.
    selected, post_fit_double_pairs = _associate_and_fit(
        selected, evidence, clean_points, main_angle, cfg
    )
    post_fit_refinement = _refine_candidates_against_sessions(
        selected, all_tree, session_trees, cfg
    )
    selected, final_double_pairs = _associate_and_fit(
        selected, evidence, clean_points, main_angle, cfg
    )
    selected, final_deduplication = _deduplicate_final_walls(selected, cfg)
    selected, junction_inferred, junction_metrics = _supported_junction_updates(
        selected, evidence, all_tree, cfg
    )
    for value in selected:
        _evaluate_candidate(
            value,
            evidence,
            structural_tree,
            low_tree,
            all_tree,
            session_trees,
            cfg,
        )
        value["classification"] = "building_wall"
        value.setdefault("selection_reasons", []).append(
            "post_session_refit_consolidated"
        )
    selected, removed_spurs = _remove_unsupported_spurs(selected, cfg)
    selected, post_topology_deduplication = _deduplicate_final_walls(
        selected, cfg
    )
    selected, additional_removed_spurs = _remove_unsupported_spurs(
        selected, cfg
    )
    removed_spurs.extend(additional_removed_spurs)
    selected_ids = {value.get("candidate_id") for value in selected}
    junction_inferred = [
        value
        for value in junction_inferred
        if set(value.get("source_candidate_ids", [])) <= selected_ids
    ]
    low_candidates = [value for value in associated if value["classification"] == "low_structure"]
    low, rejected_low = _select_low_structures(low_candidates, selected, cfg)
    uncertain = (
        [value for value in associated if value["classification"] == "uncertain_detail"]
        + removed_spurs
        + rejected_low
    )
    inferred = junction_inferred + _evidence_constrained_connections(
        selected, evidence, cfg
    )
    baseline_metrics = _graph_clutter_metrics(calibrated_baseline_runs, cfg)
    all_protected_pairs = double_pairs + post_fit_double_pairs + final_double_pairs
    optimized_metrics = _graph_clutter_metrics(
        selected, cfg, all_protected_pairs
    )
    point_metrics = _line_point_metrics(selected, clean_points)
    heldout_metrics = _heldout_session_residuals(selected, clean_session_points, cfg)
    node_spread = _shared_node_spread(selected)
    spur_reduction = 1.0 - optimized_metrics["unsupported_short_spur_count"] / max(1, baseline_metrics["unsupported_short_spur_count"])
    duplicate_reduction = 1.0 - optimized_metrics["near_parallel_duplicate_length_m"] / max(1e-9, baseline_metrics["near_parallel_duplicate_length_m"])
    audit = {
        "line_to_point_p95_pass": point_metrics["p95_m"] is not None and point_metrics["p95_m"] <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
        "line_support_pass": point_metrics["support_fraction"] >= float(cfg.get("accept_line_support_fraction", 0.95)),
        "frozen_coverage_pass": solver_metrics["coverage_change"] >= -float(cfg.get("architectural_max_coverage_regression", 0.02)),
        "short_spur_reduction_pass": spur_reduction >= float(cfg.get("architectural_target_spur_reduction", 0.60)),
        "duplicate_reduction_pass": duplicate_reduction >= float(cfg.get("architectural_target_duplicate_reduction", 0.80)),
        "independent_session_residual_pass": heldout_metrics["p95_m"] is not None
        and heldout_metrics["p95_m"]
        <= float(cfg.get("architectural_independent_session_p95_m", 0.05)),
        "shared_nodes_pass": node_spread is not None and node_spread <= 0.001,
    }
    metrics = {
        "algorithm_version": "structure-graph-v4",
        "base_voxel_count": int(len(evidence.xy)),
        "frozen_structural_voxel_count": int(np.count_nonzero(evidence.structural_mask)),
        "frozen_low_voxel_count": int(np.count_nonzero(evidence.low_mask)),
        "source_complete_run_count": int(len(source_runs)),
        "calibrated_baseline_observation_count": int(len(baseline_observations)),
        "raw_slice_observation_count": int(len(raw_observations)),
        "density_ridge_observation_count": int(len(ridge_observations)),
        "associated_wall_candidate_count": int(len(associated)),
        "protected_double_face_pair_count": int(len(double_pairs)),
        "session_equal_axis_refinement": session_refinement,
        "post_fit_axis_refinement": post_fit_refinement,
        "post_fit_double_face_pair_count": int(len(post_fit_double_pairs)),
        "final_double_face_pair_count": int(len(final_double_pairs)),
        "junction_optimization": junction_metrics,
        "final_deduplication": final_deduplication,
        "post_topology_deduplication": post_topology_deduplication,
        "architectural_wall_count": int(len(selected)),
        "low_structure_count": int(len(low)),
        "uncertain_detail_count": int(len(uncertain)),
        "inferred_connection_count": int(len(inferred)),
        "architectural_line_to_point_p95_m": point_metrics["p95_m"],
        "architectural_line_support_fraction_0_15m": point_metrics["support_fraction"],
        "unsupported_short_spur_reduction_fraction": float(spur_reduction),
        "near_parallel_duplicate_reduction_fraction": float(duplicate_reduction),
        "architectural_independent_session_residual": heldout_metrics,
        "architectural_shared_node_max_spread_m": node_spread,
        "baseline_graph": baseline_metrics,
        "optimized_graph": optimized_metrics,
        "solver": solver_metrics,
        "protected_double_faces": all_protected_pairs,
    }
    return ArchitecturalResult(selected, low, inferred, uncertain, evidence, metrics, audit)


def _transform_line(line: LineString, transform: np.ndarray) -> LineString:
    xy = np.asarray(line.coords, dtype=float)
    points = transform_points(np.column_stack([xy, np.zeros(len(xy))]), transform)
    return LineString(points[:, :2])


def _new_dxf() -> ezdxf.document.Drawing:
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6
    if "LIDAR2OUTLINE" not in document.appids:
        document.appids.add("LIDAR2OUTLINE")
    return document


def _line_xdata(value: dict) -> list[tuple[int, str]]:
    fields = {
        "candidate_id": value.get("candidate_id", ""),
        "shared_wall_id": value.get("shared_wall_id", ""),
        "class": value.get("classification", ""),
        "node_ids": ",".join(value.get("node_ids", [])),
        "junction_node_ids": ",".join(value.get("junction_node_ids", [])),
        "source_observations": ",".join(value.get("source_segment_ids", [])),
        "selection_reasons": ",".join(value.get("selection_reasons", [])),
        "observed_slices": ",".join(map(str, value.get("slice_indices", []))),
        "z_min_m": value.get("z_min_m", "unknown"),
        "z_max_m": value.get("z_max_m", "unknown"),
        "structural_coverage": value.get("structural_coverage", ""),
        "session_count": value.get("session_count", ""),
        "backbone_role": value.get("backbone_role", ""),
        "support_interval_m": ",".join(
            map(str, value.get("support_interval_m", []))
        ),
        "observed_base_height_bins": ",".join(
            map(str, value.get("observed_base_height_bins", []))
        ),
    }
    return [(1000, f"{key}={item}") for key, item in fields.items()]


def _add_line(layout: Any, line: LineString, layer: str, value: dict) -> None:
    entity = layout.add_lwpolyline(
        [(float(x), float(y)) for x, y in line.coords],
        close=False,
        dxfattribs={"layer": layer},
    )
    entity.set_xdata("LIDAR2OUTLINE", _line_xdata(value))


def _add_semantic_polygons(
    document: ezdxf.document.Drawing, semantic_objects_cad: list[dict]
) -> None:
    layout = document.modelspace()
    for value in semantic_objects_cad:
        class_name = str(value.get("class", "")).upper()
        if class_name not in {"COLUMN", "CORE"}:
            continue
        geometry = value.get("coordinates")
        if not geometry or len(geometry) < 3:
            continue
        entity = layout.add_lwpolyline(
            [(float(x), float(y)) for x, y in geometry],
            close=True,
            dxfattribs={"layer": class_name},
        )
        entity.set_xdata("LIDAR2OUTLINE", [(1000, f"class={class_name}")])


def _validate_semantic_objects(
    semantic_objects_cad: list[dict],
    evidence: FrozenEvidence,
    transform_cad_from_ref: np.ndarray,
    cfg: dict,
) -> tuple[list[dict], list[dict]]:
    """Treat legacy column/core polygons as hypotheses, not trusted output."""
    if len(evidence.xy):
        evidence_cad = transform_points(
            np.column_stack([evidence.xy, np.zeros(len(evidence.xy))]),
            transform_cad_from_ref,
        )[:, :2]
        evidence_tree = cKDTree(evidence_cad)
    else:
        evidence_tree = None
    radius = float(cfg.get("architectural_semantic_support_distance_m", 0.15))
    minimum_support = float(
        cfg.get("architectural_semantic_min_structural_support", 0.82)
    )
    minimum_span = float(cfg.get("architectural_min_vertical_span_m", 1.20))
    minimum_sessions = int(cfg.get("architectural_min_sessions", 2))
    accepted: list[dict] = []
    rejected: list[dict] = []
    for source_index, source in enumerate(semantic_objects_cad):
        value = dict(source)
        value["semantic_source_index"] = source_index
        coordinates = np.asarray(value.get("coordinates", []), dtype=float)
        reasons = []
        try:
            polygon = Polygon(coordinates)
        except Exception:
            polygon = Polygon()
        if (
            len(coordinates) < 3
            or polygon.is_empty
            or not polygon.is_valid
            or polygon.area < float(cfg.get("architectural_semantic_min_area_m2", 0.04))
        ):
            reasons.append("invalid_or_too_small_polygon")
            support = 0.0
            vertical = 0.0
            sessions = 0
        elif evidence_tree is None:
            reasons.append("no_current_point_evidence")
            support = 0.0
            vertical = 0.0
            sessions = 0
        else:
            perimeter = LineString(coordinates)
            samples = _sample_line(perimeter, 0.05)
            distances, nearest = evidence_tree.query(samples, k=1)
            close = distances <= radius
            structural = close & evidence.structural_mask[nearest]
            support = float(np.mean(structural))
            vertical = (
                0.0
                if not np.any(structural)
                else float(np.median(evidence.vertical_span_m[nearest[structural]]))
            )
            sessions = (
                0
                if not np.any(structural)
                else int(np.median(evidence.session_count[nearest[structural]]))
            )
            if support < minimum_support:
                reasons.append("insufficient_current_perimeter_support")
            if vertical < minimum_span:
                reasons.append("insufficient_vertical_support")
            if sessions < minimum_sessions:
                reasons.append("insufficient_cross_session_support")
        value["semantic_validation"] = {
            "structural_support_fraction": support,
            "median_vertical_span_m": vertical,
            "median_session_count": sessions,
            "reasons": reasons,
        }
        if reasons:
            value["class"] = "UNCERTAIN_DETAIL"
            value["original_class"] = str(source.get("class", "")).upper()
            rejected.append(value)
        else:
            value["class"] = str(source.get("class", "")).upper()
            accepted.append(value)
    return accepted, rejected


def _regional_backbone_metrics(
    result: ArchitecturalResult,
    transform_cad_from_ref: np.ndarray,
    cfg: dict,
) -> dict:
    boxes = cfg.get(
        "architectural_detail_crops_cad",
        {
            "detail_oblique_wall.png": [10.0, 0.0, 25.0, 14.0],
            "detail_central_junctions.png": [6.0, 8.0, 29.0, 27.0],
            "detail_top_annex.png": [23.0, 19.0, 44.0, 40.0],
        },
    )

    def clipped(values: list[dict], bounds: list[float]) -> list[dict]:
        region = box(*map(float, bounds))
        output = []
        for value in values:
            geometry = _transform_line(value["line_ref"], transform_cad_from_ref).intersection(
                region
            )
            pieces = [geometry] if geometry.geom_type == "LineString" else list(
                getattr(geometry, "geoms", [])
            )
            for piece in pieces:
                if piece.geom_type == "LineString" and piece.length > 1e-6:
                    output.append({"line_ref": piece})
        return output

    reference = result.diagnostics.get("high_backbone_reference", [])
    metrics = {}
    for name, bounds in boxes.items():
        local_reference = clipped(reference, bounds)
        local_delivered = clipped(result.walls, bounds)
        retention = _sampled_geometry_retention(
            local_reference,
            local_delivered,
            float(cfg.get("architectural_backbone_accept_distance_m", 0.15)),
        )
        metrics[str(name)] = {
            **retention,
            "delivered_length_m": float(
                sum(value["line_ref"].length for value in local_delivered)
            ),
            "delivered_line_count": len(local_delivered),
        }
    return metrics


def audit_architectural_dxf(path: Path) -> dict:
    """Re-open the delivered DXF and validate layers and shared node geometry."""
    document = ezdxf.readfile(path)
    required_layers = {
        "ARCH_WALL",
        "LOW_STRUCTURE",
        "COLUMN",
        "CORE",
        "INFERRED_CONNECTION",
        "UNCERTAIN_DETAIL",
    }
    available = {layer.dxf.name for layer in document.layers}
    counts: dict[str, int] = {}
    node_coordinates: dict[str, list[np.ndarray]] = {}
    finite = True
    class_layer_mismatch = 0
    for entity in document.modelspace().query("LWPOLYLINE"):
        layer = entity.dxf.layer
        counts[layer] = counts.get(layer, 0) + 1
        coordinates = np.asarray(
            [(point[0], point[1]) for point in entity.get_points()], dtype=float
        )
        finite = finite and bool(np.all(np.isfinite(coordinates)))
        values = {}
        try:
            tags = entity.get_xdata("LIDAR2OUTLINE")
        except ezdxf.DXFValueError:
            tags = []
        for tag in tags:
            text = str(tag.value)
            if "=" in text:
                key, value = text.split("=", 1)
                values[key] = value
        expected_class = {
            "ARCH_WALL": "building_wall",
            "LOW_STRUCTURE": "low_structure",
            "INFERRED_CONNECTION": "inferred_connection",
            "UNCERTAIN_DETAIL": "uncertain_detail",
        }.get(layer)
        if expected_class and values.get("class") not in {None, expected_class}:
            class_layer_mismatch += 1
        if layer == "ARCH_WALL":
            node_ids = [
                value for value in values.get("node_ids", "").split(",") if value
            ]
            for node_id, point in zip(node_ids, coordinates[[0, -1]]):
                node_coordinates.setdefault(node_id, []).append(point)
    spreads = []
    for points in node_coordinates.values():
        if len(points) < 2:
            continue
        array = np.asarray(points)
        spreads.append(
            float(np.max(np.linalg.norm(array - np.mean(array, axis=0), axis=1)))
        )
    return {
        "readable": True,
        "required_layers_present": required_layers <= available,
        "uncertain_layer_off": document.layers.get("UNCERTAIN_DETAIL").is_off(),
        "inferred_layer_off": document.layers.get("INFERRED_CONNECTION").is_off(),
        "finite_geometry": finite,
        "class_layer_mismatch_count": class_layer_mismatch,
        "shared_node_max_spread_m": None if not spreads else float(max(spreads)),
        "entity_count_by_layer": counts,
    }


def export_architectural_outputs(
    output_dir: Path,
    result: ArchitecturalResult,
    transform_cad_from_ref: np.ndarray,
    clean_points_ref: np.ndarray,
    baseline_union: list[dict],
    cfg: dict,
    semantic_objects_cad: list[dict] | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    accepted_semantics, rejected_semantics = _validate_semantic_objects(
        semantic_objects_cad or [], result.evidence, transform_cad_from_ref, cfg
    )
    result.metrics["semantic_validation"] = {
        "input_count": len(semantic_objects_cad or []),
        "accepted_count": len(accepted_semantics),
        "rejected_to_uncertain_count": len(rejected_semantics),
    }
    regional_metrics = _regional_backbone_metrics(
        result, transform_cad_from_ref, cfg
    )
    result.metrics["regional_backbone_retention"] = regional_metrics
    result.audit["regional_backbone_retention_pass"] = all(
        value["reference_length_m"] < 0.50
        or value["fraction"]
        >= float(cfg.get("architectural_regional_min_retention", 0.95))
        for value in regional_metrics.values()
    )
    save_frozen_evidence(output_dir / "structure_evidence.npz", result.evidence)
    write_json(
        output_dir / "structure_evidence.json",
        {
            "algorithm_version": "structure-graph-v8-scored-wall-absorption",
            "grid_m": result.evidence.grid_m,
            "height_bin_m": result.evidence.height_bin_m,
            "voxel_count": len(result.evidence.xy),
            "structural_voxel_count": int(np.count_nonzero(result.evidence.structural_mask)),
            "low_voxel_count": int(np.count_nonzero(result.evidence.low_mask)),
            "frozen_before_optimization": True,
            "classification_rules": {
                "minimum_vertical_span_m": float(cfg.get("architectural_min_vertical_span_m", 1.20)),
                "minimum_sessions": int(cfg.get("architectural_min_sessions", 2)),
                "minimum_height_bins": int(cfg.get("architectural_min_height_bins", 4)),
            },
        },
    )
    document = _new_dxf()
    layer_settings = {
        "ARCH_WALL": (7, False, "CONTINUOUS"),
        "LOW_STRUCTURE": (4, False, "CONTINUOUS"),
        "COLUMN": (2, False, "CONTINUOUS"),
        "CORE": (1, False, "CONTINUOUS"),
        "INFERRED_CONNECTION": (2, True, "DASHED"),
        "UNCERTAIN_DETAIL": (8, True, "DASHDOT"),
    }
    for layer, (color, off, linetype) in layer_settings.items():
        document.layers.add(layer, color=color, linetype=linetype)
        if off:
            document.layers.get(layer).off()
    layout = document.modelspace()
    for values, layer in (
        (result.walls, "ARCH_WALL"),
        (result.low_structures, "LOW_STRUCTURE"),
        (result.inferred, "INFERRED_CONNECTION"),
        (result.uncertain, "UNCERTAIN_DETAIL"),
    ):
        for value in values:
            _add_line(layout, _transform_line(value["line_ref"], transform_cad_from_ref), layer, value)
    _add_semantic_polygons(document, accepted_semantics)
    for value in rejected_semantics:
        coordinates = value.get("coordinates", [])
        if len(coordinates) < 3:
            continue
        entity = layout.add_lwpolyline(
            [(float(x), float(y)) for x, y in coordinates],
            close=True,
            dxfattribs={"layer": "UNCERTAIN_DETAIL"},
        )
        entity.set_xdata(
            "LIDAR2OUTLINE",
            [
                (1000, "class=uncertain_detail"),
                (1000, f"original_class={value.get('original_class', '')}"),
                (1000, "reason=legacy_semantic_failed_current_evidence"),
            ],
        )
    architectural_dxf_path = output_dir / "architectural_plan.dxf"
    document.saveas(architectural_dxf_path)
    disk_audit = audit_architectural_dxf(architectural_dxf_path)
    result.metrics["architectural_disk_dxf_audit"] = disk_audit
    result.audit.update(
        {
            "disk_dxf_layers_pass": bool(disk_audit["required_layers_present"]),
            "disk_dxf_uncertain_layer_off_pass": bool(
                disk_audit["uncertain_layer_off"]
            ),
            "disk_dxf_inferred_layer_off_pass": bool(
                disk_audit["inferred_layer_off"]
            ),
            "disk_dxf_finite_pass": bool(disk_audit["finite_geometry"]),
            "disk_dxf_class_layers_pass": disk_audit[
                "class_layer_mismatch_count"
            ]
            == 0,
            "disk_dxf_shared_nodes_pass": disk_audit[
                "shared_node_max_spread_m"
            ]
            is not None
            and disk_audit["shared_node_max_spread_m"] <= 0.001,
        }
    )

    features = []
    for values, class_name, observed in (
        (result.walls, "BUILDING_WALL", True),
        (result.low_structures, "LOW_STRUCTURE", True),
        (result.inferred, "INFERRED_CONNECTION", False),
        (result.uncertain, "UNCERTAIN_DETAIL", True),
    ):
        for value in values:
            features.append(
                {
                    "type": "Feature",
                    "geometry": mapping(_transform_line(value["line_ref"], transform_cad_from_ref)),
                    "properties": {
                        "class": class_name,
                        "observed": observed,
                        "node_ids": value.get("node_ids", []),
                        "junction_node_ids": value.get("junction_node_ids", []),
                        "source_observations": value.get("source_segment_ids", []),
                        "source_wall_ids": value.get("source_wall_ids", []),
                        "selection_reasons": value.get("selection_reasons", []),
                        "support_intervals": value.get("observed_z_ranges_m", []),
                        "shared_wall_id": value.get("shared_wall_id"),
                        "shared_wall_support_segments": value.get(
                            "v7_support_segments", []
                        ),
                        "slice_indices": value.get("slice_indices", []),
                        "slice_support": value.get("slice_support", {}),
                        "observed_base_height_bins": value.get(
                            "observed_base_height_bins", []
                        ),
                        "base_height_bin_support": value.get(
                            "base_height_bin_support", {}
                        ),
                        "backbone_role": value.get("backbone_role"),
                        "supporting_source_slices": value.get(
                            "supporting_source_slices", []
                        ),
                        "conflicts_with": value.get("conflicts_with"),
                        "session_support": value.get("session_support", {}),
                        "structural_coverage": value.get("structural_coverage"),
                        "candidate_id": value.get("candidate_id"),
                    },
                }
            )
    for value in accepted_semantics + rejected_semantics:
        class_name = str(value.get("class", "")).upper()
        properties = {
            "class": class_name,
            "original_class": value.get("original_class", class_name),
            "observed": class_name != "UNCERTAIN_DETAIL",
            "source": "legacy_semantic_revalidated_against_v5_evidence",
            "semantic_validation": value.get("semantic_validation", {}),
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [value.get("coordinates", [])],
                },
                "properties": properties,
            }
        )
    write_json(
        output_dir / "architectural_plan.geojson",
        {
            "type": "FeatureCollection",
            "local_coordinate_system": {
                "units": "metre",
                "T_cad_reference_slam": np.asarray(transform_cad_from_ref).tolist(),
                "T_reference_slam_cad": np.linalg.inv(transform_cad_from_ref).tolist(),
            },
            "features": features,
        },
    )
    _render_architectural_outputs(
        output_dir,
        result,
        clean_points_ref,
        baseline_union,
        transform_cad_from_ref,
        cfg,
        accepted_semantics,
    )
    write_json(output_dir / "architectural_audit.json", {"metrics": result.metrics, "checks": result.audit, "passed": all(result.audit.values())})
    return {
        "architectural_plan_dxf": str(output_dir / "architectural_plan.dxf"),
        "architectural_geojson": str(output_dir / "architectural_plan.geojson"),
        "architectural_final_png": str(output_dir / "final_dxf.png"),
        "architectural_height_png": str(output_dir / "architectural_height.png"),
        "inferred_connections_diagnostic_png": str(
            output_dir / "inferred_connections_diagnostic.png"
        ),
        "full_observation_png": str(output_dir / "full_observation.png"),
        "architectural_comparison_png": str(output_dir / "architectural_comparison.png"),
        "high_backbone_reference_png": str(output_dir / "high_backbone_reference.png"),
        "backbone_v4_v5_comparison_png": str(
            output_dir / "backbone_v4_v5_comparison.png"
        ),
        "architectural_audit_json": str(output_dir / "architectural_audit.json"),
        "structure_evidence_npz": str(output_dir / "structure_evidence.npz"),
    }


def _raster_frame(points: np.ndarray, grid_m: float, padding_m: float) -> tuple[np.ndarray, tuple[int, int]]:
    minimum = np.floor((np.min(points[:, :2], axis=0) - padding_m) / grid_m) * grid_m
    maximum = np.ceil((np.max(points[:, :2], axis=0) + padding_m) / grid_m) * grid_m
    size = np.ceil((maximum - minimum) / grid_m).astype(int)
    return minimum, (int(size[1]), int(size[0]))


def _density(points: np.ndarray, origin: np.ndarray, shape: tuple[int, int], grid_m: float) -> np.ndarray:
    raster = np.zeros(shape, dtype=np.uint32)
    ij = np.floor((points[:, :2] - origin) / grid_m).astype(int)
    valid = (ij[:, 0] >= 0) & (ij[:, 1] >= 0) & (ij[:, 0] < shape[1]) & (ij[:, 1] < shape[0])
    np.add.at(raster, (ij[valid, 1], ij[valid, 0]), 1)
    value = np.log1p(raster.astype(np.float32))
    nonzero = value[value > 0]
    value /= max(float(np.quantile(nonzero, 0.995)) if len(nonzero) else 1.0, 1e-6)
    return np.clip(value * 220, 0, 220).astype(np.uint8)


def _draw(image: np.ndarray, line: LineString, origin: np.ndarray, grid_m: float, color: tuple[int, int, int], width: int = 2, dashed: bool = False) -> None:
    if dashed:
        position = 0.0
        while position < line.length:
            end = min(line.length, position + 0.14)
            _draw(image, LineString([line.interpolate(position).coords[0], line.interpolate(end).coords[0]]), origin, grid_m, color, width, False)
            position += 0.24
        return
    pixels = np.rint((np.asarray(line.coords) - origin) / grid_m - 0.5).astype(np.int32)
    pixels[:, 1] = image.shape[0] - 1 - pixels[:, 1]
    cv2.polylines(image, [pixels], False, color, width, cv2.LINE_AA)


def _draw_semantics(image: np.ndarray, objects: list[dict], origin: np.ndarray, grid_m: float) -> None:
    for value in objects:
        class_name = str(value.get("class", "")).upper()
        if class_name not in {"COLUMN", "CORE"}:
            continue
        coordinates = np.asarray(value.get("coordinates", []), dtype=float)
        if len(coordinates) < 3:
            continue
        pixels = np.rint((coordinates - origin) / grid_m - 0.5).astype(np.int32)
        pixels[:, 1] = image.shape[0] - 1 - pixels[:, 1]
        cv2.polylines(image, [pixels], True, (0, 210, 255) if class_name == "COLUMN" else (50, 80, 255), 2, cv2.LINE_AA)


def _add_scale_bar(image: np.ndarray, grid_m: float, length_m: float = 10.0) -> None:
    pixels = max(1, int(round(length_m / grid_m)))
    x0, y0 = 24, image.shape[0] - 28
    x1 = min(image.shape[1] - 24, x0 + pixels)
    cv2.line(image, (x0, y0), (x1, y0), (245, 245, 245), 3, cv2.LINE_AA)
    cv2.putText(
        image,
        f"{length_m:g} m",
        (x0, y0 - 8),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.48,
        (245, 245, 245),
        1,
        cv2.LINE_AA,
    )


def _render_architectural_outputs(
    output_dir: Path,
    result: ArchitecturalResult,
    clean_points_ref: np.ndarray,
    baseline_union: list[dict],
    transform: np.ndarray,
    cfg: dict,
    semantic_objects: list[dict],
) -> None:
    grid_m = float(cfg.get("grid_m", 0.05))
    cad_points = transform_points(clean_points_ref, transform)
    origin, shape = _raster_frame(cad_points, grid_m, float(cfg.get("raster_padding_m", 0.50)))
    density = np.flipud(_density(cad_points, origin, shape, grid_m))
    dark = cv2.cvtColor(np.clip(density * 0.32, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR)

    full = dark.copy()
    for value in baseline_union:
        _draw(full, _transform_line(value["line_ref"], transform), origin, grid_m, (180, 180, 180), 1)
    _add_scale_bar(full, grid_m)
    cv2.imwrite(str(output_dir / "full_observation.png"), full)

    high_reference = dark.copy()
    for value in result.diagnostics.get("high_backbone_reference", []):
        _draw(
            high_reference,
            _transform_line(value["line_ref"], transform),
            origin,
            grid_m,
            (255, 120, 40),
            2,
        )
    _add_scale_bar(high_reference, grid_m)
    cv2.imwrite(str(output_dir / "high_backbone_reference.png"), high_reference)

    final = np.zeros_like(dark)
    for value in result.walls:
        _draw(final, _transform_line(value["line_ref"], transform), origin, grid_m, (245, 245, 245), 2)
    for value in result.low_structures:
        _draw(final, _transform_line(value["line_ref"], transform), origin, grid_m, (255, 190, 50), 2)
    if bool(cfg.get("architectural_show_inferred_in_final_png", False)):
        for value in result.inferred:
            _draw(final, _transform_line(value["line_ref"], transform), origin, grid_m, (0, 210, 255), 2, True)
    _draw_semantics(final, semantic_objects, origin, grid_m)
    cv2.putText(final, "white=building  cyan=verified low  yellow=verified column/core  inference/uncertain=off", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.54, (230, 230, 230), 2, cv2.LINE_AA)
    _add_scale_bar(final, grid_m)
    cv2.imwrite(str(output_dir / "final_dxf.png"), final)

    inferred_diagnostic = dark.copy()
    for value in result.walls:
        _draw(
            inferred_diagnostic,
            _transform_line(value["line_ref"], transform),
            origin,
            grid_m,
            (190, 190, 190),
            1,
        )
    for value in result.inferred:
        _draw(
            inferred_diagnostic,
            _transform_line(value["line_ref"], transform),
            origin,
            grid_m,
            (0, 210, 255),
            2,
            True,
        )
    _add_scale_bar(inferred_diagnostic, grid_m)
    cv2.imwrite(
        str(output_dir / "inferred_connections_diagnostic.png"),
        inferred_diagnostic,
    )

    height = dark.copy()
    palette = [(50, 70, 255), (60, 200, 255), (80, 230, 100), (255, 180, 50), (220, 80, 220)]
    for value in result.walls + result.low_structures:
        zmax = float(value.get("z_max_m") or 0.0)
        index = min(len(palette) - 1, int(zmax / max(0.5, float(cfg.get("slice_height_m", 0.5)))))
        _draw(height, _transform_line(value["line_ref"], transform), origin, grid_m, palette[index], 2)
    cv2.imwrite(str(output_dir / "architectural_height.png"), height)

    target_width = 720
    panels = [cv2.cvtColor(density, cv2.COLOR_GRAY2BGR), high_reference, final]
    panels = [cv2.resize(value, (target_width, max(1, int(value.shape[0] * target_width / value.shape[1])))) for value in panels]
    labels = ["CLEAN LIDAR", "HIGH-SLICE BACKBONE", "V5 ARCHITECTURAL PLAN"]
    for panel, label in zip(panels, labels):
        cv2.putText(panel, label, (12, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.68, (255, 255, 255), 2, cv2.LINE_AA)
    comparison = np.hstack(panels)
    cv2.imwrite(str(output_dir / "architectural_comparison.png"), comparison)

    v4 = np.zeros_like(dark)
    v4_geojson = output_dir.parent / "height_slices_v4" / "architectural_plan.geojson"
    if v4_geojson.is_file():
        for feature in read_json(v4_geojson).get("features", []):
            if feature.get("properties", {}).get("class") != "BUILDING_WALL":
                continue
            coordinates = feature.get("geometry", {}).get("coordinates", [])
            if len(coordinates) >= 2:
                _draw(v4, LineString(coordinates), origin, grid_m, (245, 245, 245), 2)
    comparison_panels = [high_reference.copy(), v4, final.copy()]
    for panel, label in zip(
        comparison_panels, ["HIGH REFERENCE", "V4", "V5"]
    ):
        cv2.putText(
            panel,
            label,
            (12, 28),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.68,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
    cv2.imwrite(
        str(output_dir / "backbone_v4_v5_comparison.png"),
        np.hstack(comparison_panels),
    )

    # Fixed CAD-coordinate crops remain comparable between reruns.
    default_boxes = {
        "detail_oblique_wall.png": [10.0, 0.0, 25.0, 14.0],
        "detail_central_junctions.png": [6.0, 8.0, 29.0, 27.0],
        "detail_top_annex.png": [23.0, 19.0, 44.0, 40.0],
    }
    boxes = cfg.get("architectural_detail_crops_cad", default_boxes)
    for filename, box in boxes.items():
        x0, y0, x1, y1 = map(float, box)
        c0 = max(0, int(math.floor((x0 - origin[0]) / grid_m)))
        c1 = min(shape[1], int(math.ceil((x1 - origin[0]) / grid_m)))
        r0 = max(0, shape[0] - int(math.ceil((y1 - origin[1]) / grid_m)))
        r1 = min(shape[0], shape[0] - int(math.floor((y0 - origin[1]) / grid_m)))
        if c1 <= c0 or r1 <= r0:
            continue
        crop_panels = [value[r0:r1, c0:c1] for value in (high_reference, v4, final)]
        cv2.imwrite(str(output_dir / filename), np.hstack(crop_panels))
