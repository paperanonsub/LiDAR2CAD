from __future__ import annotations

import math
from dataclasses import dataclass

import cv2
import numpy as np
import shapely
from scipy.spatial import cKDTree
from shapely.geometry import LineString, MultiLineString, MultiPoint, Point, Polygon
from shapely.ops import transform as shapely_transform

from .cloud import vertical_structural_cells
from .errors import DataQualityError
from .transforms import invert_transform, se2_matrix, transform_points


@dataclass
class OutlineResult:
    shell_ref: Polygon
    internals_ref: list[tuple[str, Polygon, float]]
    wall_polygons_ref: list[Polygon]
    wall_centerlines_ref: list[LineString]
    doors_ref: list[LineString]
    windows_ref: list[LineString]
    scan_detail_lines_ref: list[LineString]
    spaces_ref: list[tuple[Polygon, float]]
    shell_cad: Polygon
    internals_cad: list[tuple[str, Polygon, float]]
    wall_polygons_cad: list[Polygon]
    wall_centerlines_cad: list[LineString]
    doors_cad: list[LineString]
    windows_cad: list[LineString]
    scan_detail_lines_cad: list[LineString]
    spaces_cad: list[tuple[Polygon, float]]
    structural_points_ref: np.ndarray
    detail_points_ref: np.ndarray
    transform_cad_from_ref: np.ndarray
    transform_ref_from_cad: np.ndarray
    metrics: dict
    raster: np.ndarray
    raster_origin: np.ndarray
    grid_m: float
    structural_raster: np.ndarray
    structural_raster_origin: np.ndarray
    structural_grid_m: float


def _dense_detail_raster(
    points: np.ndarray,
    grid_m: float,
    height_bin_m: float,
    min_height_m: float,
    max_height_m: float,
    min_points: int,
    min_height_bins: int,
    min_component_cells: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict]:
    """Build wall evidence from the dense fused cloud, not the sparse shell cloud.

    A cell is retained when it has repeated returns at more than one height.  This
    keeps weakly observed room partitions while rejecting most floor, ceiling and
    single-height furniture returns.
    """
    finite = points[np.all(np.isfinite(points), axis=1)]
    if not len(finite):
        raise DataQualityError("Dense fused point cloud is empty")
    lower = np.percentile(finite[:, :2], 0.05, axis=0)
    upper = np.percentile(finite[:, :2], 99.95, axis=0)
    origin = np.floor((lower - 0.5) / grid_m) * grid_m
    end = np.ceil((upper + 0.5) / grid_m) * grid_m
    width, height = np.ceil((end - origin) / grid_m).astype(int) + 1
    if width > 10000 or height > 10000:
        raise DataQualityError(f"Detailed raster is too large ({width} x {height}); check map scale")

    comparison_max_height = max_height_m + 0.35
    detail_points = finite[
        (finite[:, 0] >= origin[0])
        & (finite[:, 0] <= end[0])
        & (finite[:, 1] >= origin[1])
        & (finite[:, 1] <= end[1])
        & (finite[:, 2] >= -0.20)
        & (finite[:, 2] <= comparison_max_height)
    ]
    band = finite[(finite[:, 2] >= min_height_m) & (finite[:, 2] <= max_height_m)]
    ij = np.floor((band[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < width)
        & (ij[:, 1] < height)
    )
    ij = ij[valid]
    band = band[valid]
    density = np.zeros((height, width), np.uint16)
    np.add.at(density, (ij[:, 1], ij[:, 0]), 1)

    z_bin = np.floor((band[:, 2] - min_height_m) / height_bin_m).astype(np.int64)
    unique_xyz = np.unique(np.column_stack([ij, z_bin]), axis=0)
    cells, bin_counts = np.unique(unique_xyz[:, :2], axis=0, return_counts=True)
    vertical_bins = np.zeros((height, width), np.uint8)
    vertical_bins[cells[:, 1], cells[:, 0]] = np.minimum(bin_counts, 255).astype(np.uint8)
    wall = np.where((density >= min_points) & (vertical_bins >= min_height_bins), 255, 0).astype(np.uint8)
    wall = cv2.morphologyEx(wall, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(wall, 8)
    cleaned = np.zeros_like(wall)
    for component in range(1, count):
        if stats[component, cv2.CC_STAT_AREA] >= min_component_cells:
            cleaned[labels == component] = 255
    metrics = {
        "detail_source_point_count": int(len(detail_points)),
        "height_band_point_count": int(len(band)),
        "wall_evidence_cell_count": int(np.count_nonzero(cleaned)),
        "detail_grid_m": float(grid_m),
        "detail_min_points_per_cell": int(min_points),
        "detail_min_height_bins": int(min_height_bins),
    }
    return cleaned, origin, detail_points, metrics


def _mask_polygons(
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    simplify_m: float,
    min_area_m2: float,
    min_perimeter_m: float,
) -> list[Polygon]:
    contours, hierarchy = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is None:
        return []
    hierarchy = hierarchy[0]

    def ring(index: int) -> list[tuple[float, float]]:
        xy = contours[index][:, 0, :].astype(float)
        xy[:, 0] = origin[0] + (xy[:, 0] + 0.5) * grid_m
        xy[:, 1] = origin[1] + (xy[:, 1] + 0.5) * grid_m
        return [(float(x), float(y)) for x, y in xy]

    polygons: list[Polygon] = []
    for index, relation in enumerate(hierarchy):
        if relation[3] != -1 or len(contours[index]) < 3:
            continue
        holes = []
        child = relation[2]
        while child != -1:
            if len(contours[child]) >= 3:
                holes.append(ring(child))
            child = hierarchy[child][0]
        candidate = Polygon(ring(index), holes).buffer(0)
        parts = list(candidate.geoms) if candidate.geom_type == "MultiPolygon" else [candidate]
        for part in parts:
            if not isinstance(part, Polygon):
                continue
            simplified = part.simplify(simplify_m, preserve_topology=True)
            if (
                isinstance(simplified, Polygon)
                and simplified.is_valid
                and simplified.area >= min_area_m2
                and simplified.length >= min_perimeter_m
            ):
                polygons.append(simplified)
    return polygons


def _valid_polygon_parts(
    geometry,
    min_area_m2: float = 0.0,
    min_perimeter_m: float = 0.0,
) -> list[Polygon]:
    """Return valid polygonal parts after Boolean/raster operations.

    GEOS overlay can occasionally leave a tiny self-intersection where a
    pixel-derived wall footprint touches the clipping boundary. Repair only
    invalid inputs so normal surveyed coordinates remain unchanged.
    """
    if geometry is None or geometry.is_empty:
        return []
    repaired = geometry
    if not geometry.is_valid:
        make_valid = getattr(shapely, "make_valid", None)
        repaired = make_valid(geometry) if make_valid is not None else geometry.buffer(0)

    pending = [repaired]
    polygons: list[Polygon] = []
    while pending:
        candidate = pending.pop()
        if isinstance(candidate, Polygon):
            if (
                candidate.is_valid
                and not candidate.is_empty
                and candidate.area >= min_area_m2
                and candidate.length >= min_perimeter_m
            ):
                polygons.append(candidate)
        elif hasattr(candidate, "geoms"):
            pending.extend(candidate.geoms)
    return polygons


def _projected_detail_mask(
    points: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    shape: tuple[int, int],
    min_points: int,
    min_component_cells: int,
) -> np.ndarray:
    height, width = shape
    ij = np.floor((points[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (ij[:, 0] >= 0) & (ij[:, 1] >= 0) & (ij[:, 0] < width) & (ij[:, 1] < height)
    ij = ij[valid]
    density = np.zeros((height, width), np.uint16)
    np.add.at(density, (ij[:, 1], ij[:, 0]), 1)
    mask = np.where(density >= min_points, 255, 0).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    cleaned = np.zeros_like(mask)
    for component in range(1, count):
        if stats[component, cv2.CC_STAT_AREA] >= min_component_cells:
            cleaned[labels == component] = 255
    return cleaned


def _angle_difference(a: float, b: float) -> float:
    return abs((a - b + math.pi / 2) % math.pi - math.pi / 2)


def _wall_centerlines(
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float | None,
    snap_deg: float,
) -> list[LineString]:
    lines = cv2.HoughLinesP(
        mask,
        1,
        np.pi / 360,
        threshold=max(10, int(round(0.50 / grid_m))),
        minLineLength=max(6, int(round(0.60 / grid_m))),
        maxLineGap=max(2, int(round(0.18 / grid_m))),
    )
    if lines is None:
        return []
    groups: list[dict] = []
    for x1, y1, x2, y2 in np.asarray(lines).reshape(-1, 4):
        a = origin + (np.asarray([x1, y1], dtype=float) + 0.5) * grid_m
        b = origin + (np.asarray([x2, y2], dtype=float) + 0.5) * grid_m
        raw = math.atan2(b[1] - a[1], b[0] - a[0]) % math.pi
        angle = raw
        if main_angle is not None:
            directions = [main_angle % math.pi, (main_angle + math.pi / 2) % math.pi]
            nearest = min(directions, key=lambda value: _angle_difference(raw, value))
            if _angle_difference(raw, nearest) <= math.radians(snap_deg):
                angle = nearest
        # Store the angle and normal with one consistent orientation.  Keeping
        # an angle modulo pi while flipping only its direction mirrors all
        # near-vertical lines across the raster origin.
        angle = (angle + math.pi / 2) % math.pi - math.pi / 2
        direction = np.asarray([math.cos(angle), math.sin(angle)])
        normal = np.asarray([-direction[1], direction[0]])
        middle = (a + b) / 2
        offset = float(normal @ middle)
        length = float(np.linalg.norm(b - a))
        match = None
        for group in groups:
            if _angle_difference(angle, group["angle"]) <= math.radians(2.0) and abs(offset - group["offset"]) <= 0.12:
                match = group
                break
        if match is None:
            match = {"angle": angle, "offset": offset, "weight": 0.0, "segments": []}
            groups.append(match)
        # Keep the representative on an observed wall face. Averaging the two
        # LiDAR-visible faces of a thick wall can place the result in an empty
        # wall core and later fail the point-support check.
        match["weight"] += length
        group_direction = np.asarray([math.cos(match["angle"]), math.sin(match["angle"])])
        match["segments"].append(sorted([float(group_direction @ a), float(group_direction @ b)]))

    output: list[LineString] = []
    for group in groups:
        direction = np.asarray([math.cos(group["angle"]), math.sin(group["angle"])])
        normal = np.asarray([-direction[1], direction[0]])
        intervals = sorted(group["segments"])
        start, end = intervals[0]
        merged = []
        for next_start, next_end in intervals[1:]:
            if next_start <= end + 0.20:
                end = max(end, next_end)
            else:
                merged.append((start, end))
                start, end = next_start, next_end
        merged.append((start, end))
        for start, end in merged:
            if end - start < 0.50:
                continue
            a = direction * start + normal * group["offset"]
            b = direction * end + normal * group["offset"]
            output.append(LineString([a, b]))
    return output


def _mask_distance_at(
    xy: np.ndarray,
    distance_pixels: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
) -> np.ndarray:
    ij = np.round((xy - origin) / grid_m - 0.5).astype(np.int64)
    result = np.full(len(xy), np.inf, dtype=float)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < distance_pixels.shape[1])
        & (ij[:, 1] < distance_pixels.shape[0])
    )
    result[valid] = distance_pixels[ij[valid, 1], ij[valid, 0]] * grid_m
    return result


def _clip_lines_to_wall_support(
    lines: list[LineString],
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    support_distance_m: float,
    bridge_gap_m: float,
    min_length_m: float,
) -> list[LineString]:
    """Keep only continuously point-supported portions of fitted straight lines."""
    distance_pixels = cv2.distanceTransform(np.where(mask > 0, 0, 255).astype(np.uint8), cv2.DIST_L2, 5)
    result: list[LineString] = []
    sample_step = min(grid_m, 0.05)
    for line in lines:
        count = max(2, int(math.ceil(line.length / sample_step)) + 1)
        samples = np.asarray(
            [[line.interpolate(i / (count - 1), normalized=True).x, line.interpolate(i / (count - 1), normalized=True).y] for i in range(count)]
        )
        supported = _mask_distance_at(samples, distance_pixels, origin, grid_m) <= support_distance_m
        max_gap = max(0, int(round(bridge_gap_m / sample_step)))
        if max_gap:
            false_indices = np.flatnonzero(~supported)
            start = 0
            while start < len(false_indices):
                end = start
                while end + 1 < len(false_indices) and false_indices[end + 1] == false_indices[end] + 1:
                    end += 1
                first, last = false_indices[start], false_indices[end]
                if first > 0 and last < len(supported) - 1 and last - first + 1 <= max_gap:
                    supported[first : last + 1] = True
                start = end + 1
        indices = np.flatnonzero(supported)
        if not len(indices):
            continue
        run_start = indices[0]
        previous = indices[0]
        for index in [*indices[1:], None]:
            if index is not None and index == previous + 1:
                previous = index
                continue
            a = samples[run_start]
            b = samples[previous]
            if np.linalg.norm(b - a) >= min_length_m:
                result.append(LineString([a, b]))
            if index is not None:
                run_start = index
                previous = index
    return result


def _cross2d(a: np.ndarray, b: np.ndarray) -> float:
    return float(a[0] * b[1] - a[1] * b[0])


def _snap_line_junctions(lines: list[LineString], tolerance_m: float) -> list[LineString]:
    """Extend/trim nearby segment endpoints to their exact line intersection."""
    if len(lines) < 2:
        return lines
    endpoints = [np.asarray(line.coords, dtype=float).copy() for line in lines]
    candidates: dict[tuple[int, int], list[tuple[float, np.ndarray]]] = {}
    for i in range(len(endpoints)):
        p, p2 = endpoints[i]
        d = p2 - p
        length_i = float(np.linalg.norm(d))
        if length_i <= 1e-9:
            continue
        for j in range(i + 1, len(endpoints)):
            q, q2 = endpoints[j]
            e = q2 - q
            length_j = float(np.linalg.norm(e))
            if length_j <= 1e-9:
                continue
            denominator = _cross2d(d, e)
            if abs(denominator) <= math.sin(math.radians(5.0)) * length_i * length_j:
                continue
            delta = q - p
            t = _cross2d(delta, e) / denominator
            u = _cross2d(delta, d) / denominator
            intersection = p + t * d
            if t < -tolerance_m / length_i or t > 1 + tolerance_m / length_i:
                continue
            if u < -tolerance_m / length_j or u > 1 + tolerance_m / length_j:
                continue
            for line_index, values in ((i, endpoints[i]), (j, endpoints[j])):
                distances = np.linalg.norm(values - intersection, axis=1)
                endpoint_index = int(np.argmin(distances))
                if distances[endpoint_index] <= tolerance_m:
                    candidates.setdefault((line_index, endpoint_index), []).append(
                        (float(distances[endpoint_index]), intersection)
                    )
    for (line_index, endpoint_index), values in candidates.items():
        endpoints[line_index][endpoint_index] = min(values, key=lambda item: item[0])[1]
    return [LineString(values) for values in endpoints if np.linalg.norm(values[1] - values[0]) >= 0.40]


def _cluster_line_endpoints(lines: list[LineString], tolerance_m: float) -> list[LineString]:
    """Give raster-derived paths one shared coordinate at the same graph node."""
    if len(lines) < 2 or tolerance_m <= 0:
        return lines
    values = [np.asarray(line.coords, dtype=float)[[0, -1]].copy() for line in lines]
    endpoints = np.vstack(values)
    parent = np.arange(len(endpoints))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = int(parent[index])
        return index

    for first, second in cKDTree(endpoints).query_pairs(tolerance_m):
        # Never collapse both ends of the same short segment.
        if first // 2 == second // 2:
            continue
        first_root, second_root = root(first), root(second)
        if first_root != second_root:
            parent[second_root] = first_root
    clusters: dict[int, list[int]] = {}
    for index in range(len(endpoints)):
        clusters.setdefault(root(index), []).append(index)
    snapped = endpoints.copy()
    for indices in clusters.values():
        if len(indices) < 2:
            continue
        center = np.mean(endpoints[indices], axis=0)
        snapped[indices] = center
    result = []
    for index in range(len(lines)):
        coordinates = snapped[2 * index : 2 * index + 2]
        if np.linalg.norm(coordinates[1] - coordinates[0]) >= 0.40:
            result.append(LineString(coordinates))
    return result


def _filter_and_merge_straight_lines(
    lines: list[LineString],
    main_angle: float | None,
    snap_deg: float,
    min_length_m: float,
    oblique_min_length_m: float,
    angle_tolerance_deg: float,
    offset_tolerance_m: float,
    merge_gap_m: float,
) -> list[LineString]:
    groups: list[dict] = []
    for line in lines:
        values = np.asarray(line.coords, dtype=float)
        delta = values[-1] - values[0]
        length = float(np.linalg.norm(delta))
        if length <= 1e-9:
            continue
        angle = math.atan2(delta[1], delta[0]) % math.pi
        frame_aligned = False
        if main_angle is not None:
            frame_angles = [main_angle % math.pi, (main_angle + math.pi / 2) % math.pi]
            nearest = min(frame_angles, key=lambda value: _angle_difference(angle, value))
            frame_aligned = _angle_difference(angle, nearest) <= math.radians(snap_deg)
            if frame_aligned:
                angle = nearest
        required_length = min_length_m if frame_aligned else oblique_min_length_m
        if length < required_length:
            continue
        angle = (angle + math.pi / 2) % math.pi - math.pi / 2
        direction = np.asarray([math.cos(angle), math.sin(angle)])
        normal = np.asarray([-direction[1], direction[0]])
        offset = float(normal @ np.mean(values, axis=0))
        group = None
        for candidate in groups:
            if (
                _angle_difference(angle, candidate["angle"]) <= math.radians(angle_tolerance_deg)
                and abs(offset - candidate["offset"]) <= offset_tolerance_m
            ):
                group = candidate
                break
        if group is None:
            group = {"angle": angle, "offset": offset, "weight": 0.0, "intervals": []}
            groups.append(group)
        # Preserve an actually observed offset instead of averaging parallel
        # wall faces into the unobserved middle of a thick wall.
        group["weight"] += length
        group_direction = np.asarray([math.cos(group["angle"]), math.sin(group["angle"])])
        interval = sorted([float(group_direction @ values[0]), float(group_direction @ values[-1])])
        group["intervals"].append(interval)

    result: list[LineString] = []
    for group in groups:
        direction = np.asarray([math.cos(group["angle"]), math.sin(group["angle"])])
        normal = np.asarray([-direction[1], direction[0]])
        intervals = sorted(group["intervals"])
        start, end = intervals[0]
        merged: list[tuple[float, float]] = []
        for next_start, next_end in intervals[1:]:
            if next_start <= end + merge_gap_m:
                end = max(end, next_end)
            else:
                merged.append((start, end))
                start, end = next_start, next_end
        merged.append((start, end))
        for start, end in merged:
            if end - start < min_length_m:
                continue
            a = direction * start + normal * group["offset"]
            b = direction * end + normal * group["offset"]
            result.append(LineString([a, b]))
    return result


def _deduplicate_evidence_lines(
    lines: list[LineString],
    angle_tolerance_deg: float,
    offset_tolerance_m: float,
    gap_m: float,
) -> list[LineString]:
    """Fuse repeated wall observations without collapsing parallel wall faces."""
    groups: list[dict] = []
    for line in sorted(lines, key=lambda value: value.length, reverse=True):
        values = np.asarray(line.coords, dtype=float)
        delta = values[-1] - values[0]
        length = float(np.linalg.norm(delta))
        if length <= 1e-9:
            continue
        angle = (math.atan2(delta[1], delta[0]) + math.pi / 2) % math.pi - math.pi / 2
        direction = np.asarray([math.cos(angle), math.sin(angle)])
        normal = np.asarray([-direction[1], direction[0]])
        offset = float(normal @ np.mean(values, axis=0))
        interval = sorted([float(direction @ values[0]), float(direction @ values[-1])])
        target = None
        for group in groups:
            overlaps = interval[0] <= group["max"] + gap_m and interval[1] >= group["min"] - gap_m
            if (
                overlaps
                and _angle_difference(angle, group["angle"]) <= math.radians(angle_tolerance_deg)
                and abs(offset - group["offset"]) <= offset_tolerance_m
            ):
                target = group
                break
        if target is None:
            groups.append(
                {
                    "angle": angle,
                    "offset": offset,
                    "weight": length,
                    "min": interval[0],
                    "max": interval[1],
                }
            )
        else:
            total = target["weight"] + length
            target["offset"] = (target["offset"] * target["weight"] + offset * length) / total
            target["weight"] = total
            target["min"] = min(target["min"], interval[0])
            target["max"] = max(target["max"], interval[1])
    output: list[LineString] = []
    for group in groups:
        direction = np.asarray([math.cos(group["angle"]), math.sin(group["angle"])])
        normal = np.asarray([-direction[1], direction[0]])
        output.append(
            LineString(
                [
                    direction * group["min"] + normal * group["offset"],
                    direction * group["max"] + normal * group["offset"],
                ]
            )
        )
    return output


def _ceiling_assisted_wall_lines(
    points: np.ndarray,
    ceiling_height_m: float | None,
    mask_shape: tuple[int, int],
    origin: np.ndarray,
    grid_m: float,
    main_angle: float | None,
    cfg: dict,
) -> tuple[list[LineString], int]:
    """Recover walls from the dense near-ceiling return band.

    Indoor scans often observe the ceiling-to-wall junction more continuously
    than the wall body.  A count threshold rejects the lower-density ceiling
    surface while retaining those junctions; every resulting line is still
    checked by the ordinary LiDAR accuracy gates after fusion.
    """
    if not bool(cfg.get("ceiling_assist_enabled", True)) or ceiling_height_m is None:
        return [], 0
    lower = ceiling_height_m - float(cfg.get("ceiling_assist_below_m", 0.26))
    upper = ceiling_height_m + float(cfg.get("ceiling_assist_above_m", 0.18))
    band = points[(points[:, 2] >= lower) & (points[:, 2] <= upper)]
    if not len(band):
        return [], 0
    ij = np.floor((band[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < mask_shape[1])
        & (ij[:, 1] < mask_shape[0])
    )
    density = np.zeros(mask_shape, dtype=np.int32)
    np.add.at(density, (ij[valid, 1], ij[valid, 0]), 1)
    ceiling_mask = np.where(
        density >= int(cfg.get("ceiling_assist_min_points_per_cell", 4)), 255, 0
    ).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(ceiling_mask, 8)
    cleaned = np.zeros_like(ceiling_mask)
    min_cells = int(cfg.get("ceiling_assist_min_component_cells", 4))
    for component in range(1, count):
        if stats[component, cv2.CC_STAT_AREA] >= min_cells:
            cleaned[labels == component] = 255
    ceiling_mask = cv2.morphologyEx(cleaned, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    lines = _wall_centerlines(
        ceiling_mask,
        origin,
        grid_m,
        main_angle,
        float(cfg["snap_angle_deg"]),
    )
    lines = _clip_lines_to_wall_support(
        lines,
        ceiling_mask,
        origin,
        grid_m,
        float(cfg.get("ceiling_assist_support_distance_m", 0.10)),
        float(cfg.get("ceiling_assist_bridge_gap_m", 0.20)),
        float(cfg.get("ceiling_assist_min_length_m", 0.50)),
    )
    lines = _filter_and_merge_straight_lines(
        lines,
        main_angle,
        float(cfg["snap_angle_deg"]),
        float(cfg.get("straight_wall_min_length_m", 0.75)),
        float(cfg.get("straight_wall_oblique_min_length_m", 1.50)),
        float(cfg.get("straight_wall_merge_angle_deg", 1.0)),
        float(cfg.get("straight_wall_merge_offset_m", 0.25)),
        float(cfg.get("ceiling_assist_merge_gap_m", 0.80)),
    )
    return lines, int(np.count_nonzero(ceiling_mask))


def _straight_line_metrics(
    lines: list[LineString],
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
) -> dict:
    wall_yx = np.column_stack(np.nonzero(mask))
    if not lines or not len(wall_yx):
        return {
            "straight_wall_sample_count": 0,
            "straight_wall_total_length_m": 0.0,
            "straight_wall_distance_median_m": None,
            "straight_wall_distance_p95_m": None,
            "straight_wall_support_fraction": 0.0,
            "straight_wall_evidence_coverage_fraction": 0.0,
            "straight_wall_connected_endpoint_fraction": 0.0,
        }
    wall_xy = origin + (wall_yx[:, ::-1] + 0.5) * grid_m
    tree = cKDTree(wall_xy)
    samples = []
    for line in lines:
        count = max(2, int(math.ceil(line.length / 0.05)) + 1)
        samples.extend(
            [line.interpolate(i / (count - 1), normalized=True).coords[0] for i in range(count)]
        )
    distances, _ = tree.query(np.asarray(samples))
    sample_array = np.asarray(samples)
    evidence_distances, _ = cKDTree(sample_array).query(wall_xy)
    # A T junction is connected when one endpoint lands on the interior of
    # another segment; endpoint-to-endpoint KD distance incorrectly marks all
    # such valid CAD junctions as disconnected.
    connected = []
    for index, line in enumerate(lines):
        values = np.asarray(line.coords, dtype=float)[[0, -1]]
        others = [candidate for other_index, candidate in enumerate(lines) if other_index != index]
        for value in values:
            point = Point(value)
            connected.append(bool(others) and min(point.distance(candidate) for candidate in others) <= 0.25)
    connected_fraction = float(np.mean(connected)) if connected else 0.0
    return {
        "straight_wall_sample_count": int(len(distances)),
        "straight_wall_total_length_m": float(sum(line.length for line in lines)),
        "straight_wall_distance_median_m": float(np.median(distances)),
        "straight_wall_distance_p95_m": float(np.percentile(distances, 95)),
        "straight_wall_support_fraction": float(np.mean(distances <= 0.15)),
        "straight_wall_evidence_coverage_fraction": float(np.mean(evidence_distances <= 0.15)),
        "straight_wall_connected_endpoint_fraction": connected_fraction,
    }


def _line_point_fit_metrics(lines: list[LineString], points_xy: np.ndarray) -> dict:
    """Measure exported geometry against the dense cropped LiDAR points."""
    if not lines or not len(points_xy):
        return {
            "straight_wall_sample_count": 0,
            "straight_wall_total_length_m": 0.0,
            "straight_wall_distance_median_m": None,
            "straight_wall_distance_p95_m": None,
            "straight_wall_support_fraction": 0.0,
        }
    samples = []
    for line in lines:
        count = max(2, int(math.ceil(line.length / 0.05)) + 1)
        samples.extend(
            [line.interpolate(index / (count - 1), normalized=True).coords[0] for index in range(count)]
        )
    distances, _ = cKDTree(points_xy).query(np.asarray(samples))
    return {
        "straight_wall_sample_count": int(len(distances)),
        "straight_wall_total_length_m": float(sum(line.length for line in lines)),
        "straight_wall_distance_median_m": float(np.median(distances)),
        "straight_wall_distance_p95_m": float(np.percentile(distances, 95)),
        "straight_wall_support_fraction": float(np.mean(distances <= 0.15)),
    }


def _line_kernel(length: int, angle_rad: float) -> np.ndarray:
    length = max(3, length | 1)
    kernel = np.zeros((length, length), np.uint8)
    center = (length - 1) / 2
    radius = center
    dx, dy = math.cos(angle_rad) * radius, math.sin(angle_rad) * radius
    cv2.line(
        kernel,
        (int(round(center - dx)), int(round(center - dy))),
        (int(round(center + dx)), int(round(center + dy))),
        1,
        1,
    )
    return kernel


def _inferred_spaces(
    wall_mask: np.ndarray,
    shell: Polygon,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float | None,
    close_gap_m: float,
    min_area_m2: float,
    simplify_m: float,
) -> list[tuple[Polygon, float]]:
    angle = main_angle or 0.0
    kernel_length = max(3, int(round(close_gap_m / grid_m)) + 1)
    along = cv2.morphologyEx(wall_mask, cv2.MORPH_CLOSE, _line_kernel(kernel_length, angle))
    across = cv2.morphologyEx(wall_mask, cv2.MORPH_CLOSE, _line_kernel(kernel_length, angle + math.pi / 2))
    barrier = cv2.max(wall_mask, cv2.max(along, across))
    barrier = cv2.dilate(barrier, np.ones((3, 3), np.uint8), iterations=1)
    shell_mask = np.zeros_like(wall_mask)
    shell_xy = np.asarray(shell.exterior.coords)
    shell_ij = np.round((shell_xy - origin) / grid_m).astype(np.int32)
    cv2.fillPoly(shell_mask, [shell_ij], 255)
    free = np.where((shell_mask > 0) & (barrier == 0), 255, 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(free, 8)
    wall_yx = np.column_stack(np.nonzero(wall_mask))
    if not len(wall_yx):
        return []
    wall_xy = origin + (wall_yx[:, ::-1] + 0.5) * grid_m
    tree = cKDTree(wall_xy)
    spaces: list[tuple[Polygon, float]] = []
    for component in range(1, count):
        area = stats[component, cv2.CC_STAT_AREA] * grid_m * grid_m
        if area < min_area_m2 or area > 0.85 * shell.area:
            continue
        component_mask = np.where(labels == component, 255, 0).astype(np.uint8)
        contours, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            continue
        polygon = _contour_polygon(max(contours, key=cv2.contourArea), origin, grid_m, simplify_m)
        if polygon is None:
            continue
        samples = _sample_boundary(polygon, max(0.10, grid_m * 2))
        distances, _ = tree.query(samples)
        support = float(np.mean(distances <= max(0.20, grid_m * 3)))
        if support >= 0.45:
            spaces.append((polygon, min(0.85, 0.45 + 0.50 * support)))
    return spaces


def _topological_wall_network(
    spaces: list[tuple[Polygon, float]],
    shell: Polygon,
    wall_points_xy: np.ndarray,
    main_angle: float | None,
    cfg: dict,
) -> list[LineString]:
    """Build the editable wall layer from closed free-space boundaries.

    Hough segments are useful evidence, but exporting every supported fragment
    creates a disconnected drawing. Room boundaries provide the missing
    topology: simplify and orthogonalize them, then retain only edges supported
    by the dense wall raster and contained by the surveyed shell.
    """
    simplify_m = float(cfg.get("topology_simplify_m", 0.50))
    closing_m = float(cfg.get("topology_space_closing_m", 0.40))
    min_edge_m = float(cfg.get("topology_min_edge_m", 0.55))
    edges: list[LineString] = []
    for polygon, _ in spaces:
        regularized = polygon
        if closing_m > 0:
            regularized = regularized.buffer(closing_m, join_style=2).buffer(-closing_m, join_style=2)
            if regularized.geom_type == "MultiPolygon":
                regularized = max(regularized.geoms, key=lambda value: value.area)
        if not isinstance(regularized, Polygon) or regularized.is_empty:
            continue
        regularized = regularized.simplify(simplify_m, preserve_topology=True)
        regularized = _snap_polygon(regularized, float(cfg["snap_angle_deg"]), main_angle)
        coordinates = np.asarray(regularized.exterior.coords, dtype=float)
        edges.extend(
            LineString([start, end])
            for start, end in zip(coordinates[:-1], coordinates[1:])
            if float(np.linalg.norm(end - start)) >= min_edge_m
        )
    if not edges:
        return []

    lines = _filter_and_merge_straight_lines(
        edges,
        main_angle,
        float(cfg["snap_angle_deg"]),
        float(cfg.get("topology_min_line_m", 0.60)),
        float(cfg.get("topology_oblique_min_line_m", 1.20)),
        float(cfg.get("topology_merge_angle_deg", 1.0)),
        float(cfg.get("topology_merge_offset_m", 0.08)),
        float(cfg.get("topology_merge_gap_m", 0.25)),
    )
    lines = _snap_line_junctions(lines, float(cfg.get("topology_junction_tolerance_m", 0.25)))

    wall_tree = cKDTree(wall_points_xy)
    scope = shell.buffer(float(cfg.get("topology_shell_margin_m", 0.25)))
    minimum_support = float(cfg.get("topology_min_dense_support_fraction", 0.70))
    maximum_p95 = float(cfg.get("topology_max_dense_p95_m", 0.30))
    minimum_length = float(cfg.get("topology_min_line_m", 0.60))
    sample_step = 0.10
    verified: list[LineString] = []
    for line in lines:
        clipped = line.intersection(scope)
        parts = list(clipped.geoms) if clipped.geom_type == "MultiLineString" else [clipped]
        for part in parts:
            if not isinstance(part, LineString) or part.length < minimum_length:
                continue
            count = max(2, int(math.ceil(part.length / sample_step)) + 1)
            samples = np.asarray(
                [
                    [
                        part.interpolate(index / (count - 1), normalized=True).x,
                        part.interpolate(index / (count - 1), normalized=True).y,
                    ]
                    for index in range(count)
                ]
            )
            distances, _ = wall_tree.query(samples)
            if float(np.mean(distances <= 0.15)) < minimum_support:
                continue
            if float(np.quantile(distances, 0.95)) > maximum_p95:
                continue
            verified.append(part)
    return _snap_line_junctions(
        verified,
        float(cfg.get("topology_junction_tolerance_m", 0.25)),
    )


def _wall_network_metrics(
    lines: list[LineString],
    shell: Polygon,
    tolerance_m: float,
    shell_margin_m: float,
) -> dict:
    if not lines:
        return {
            "topology_component_count": 0,
            "topology_outside_shell_fraction": 1.0,
        }
    adjacency = [set() for _ in lines]
    for first in range(len(lines)):
        for second in range(first + 1, len(lines)):
            if lines[first].distance(lines[second]) <= tolerance_m:
                adjacency[first].add(second)
                adjacency[second].add(first)
    seen: set[int] = set()
    component_count = 0
    for index in range(len(lines)):
        if index in seen:
            continue
        component_count += 1
        pending = [index]
        seen.add(index)
        while pending:
            current = pending.pop()
            for neighbor in adjacency[current]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    pending.append(neighbor)
    scope = shell.buffer(shell_margin_m)
    total_length = float(sum(line.length for line in lines))
    inside_length = float(sum(line.intersection(scope).length for line in lines))
    return {
        "topology_component_count": component_count,
        "topology_outside_shell_fraction": max(0.0, 1.0 - inside_length / max(total_length, 1e-9)),
    }


def _geometry_transform(geometry, matrix: np.ndarray):
    def apply(x, y, z=None):
        xy = np.column_stack([np.asarray(x), np.asarray(y)])
        xyz = np.column_stack([xy, np.zeros(len(xy))])
        out = transform_points(xyz, matrix)
        return out[:, 0], out[:, 1]

    return shapely_transform(apply, geometry)


def _points_to_mask(points: np.ndarray, grid_m: float, padding_m: float = 1.0) -> tuple[np.ndarray, np.ndarray]:
    lo = np.floor((np.min(points[:, :2], axis=0) - padding_m) / grid_m) * grid_m
    hi = np.ceil((np.max(points[:, :2], axis=0) + padding_m) / grid_m) * grid_m
    width, height = np.ceil((hi - lo) / grid_m).astype(int) + 1
    if width > 10000 or height > 10000:
        raise DataQualityError(f"Structural raster is too large ({width} x {height}); check map scale")
    ij = np.floor((points[:, :2] - lo) / grid_m).astype(int)
    mask = np.zeros((height, width), np.uint8)
    mask[ij[:, 1], ij[:, 0]] = 255
    return mask, lo


def _contour_polygon(contour: np.ndarray, origin: np.ndarray, grid_m: float, simplify_m: float) -> Polygon | None:
    if len(contour) < 4:
        return None
    xy = contour[:, 0, :].astype(float)
    xy[:, 0] = origin[0] + (xy[:, 0] + 0.5) * grid_m
    xy[:, 1] = origin[1] + (xy[:, 1] + 0.5) * grid_m
    polygon = Polygon(xy).buffer(0)
    if polygon.geom_type == "MultiPolygon":
        polygon = max(polygon.geoms, key=lambda g: g.area)
    if not isinstance(polygon, Polygon) or polygon.area <= 0:
        return None
    simplified = polygon.simplify(simplify_m, preserve_topology=True)
    return simplified if isinstance(simplified, Polygon) and simplified.is_valid else polygon


def _trajectory_containment(polygon: Polygon, trajectory_xy: np.ndarray | None) -> float:
    if trajectory_xy is None or not len(trajectory_xy):
        return 0.0
    if len(trajectory_xy) > 2000:
        trajectory_xy = trajectory_xy[np.linspace(0, len(trajectory_xy) - 1, 2000).astype(int)]
    return float(np.mean([polygon.buffer(0.15).contains(Point(v)) for v in trajectory_xy]))


def _structural_evidence_containment(
    polygon: Polygon,
    evidence_xy: np.ndarray,
    margin_m: float,
    maximum_samples: int = 20_000,
) -> float:
    """Measure how much global wall evidence a shell candidate explains.

    Boundary support alone strongly favours tiny, perfectly traced room loops when
    no trajectory is available.  A usable building shell must also enclose most
    of the structural evidence.  Sampling is deterministic so that candidate
    ranking and cache audits remain reproducible.
    """
    values = np.asarray(evidence_xy, dtype=float)
    values = values[np.all(np.isfinite(values), axis=1)]
    if not len(values):
        return 0.0
    if len(values) > maximum_samples:
        indices = np.linspace(0, len(values) - 1, maximum_samples).astype(int)
        values = values[indices]
    scope = polygon.buffer(max(0.0, float(margin_m)))
    try:
        contained = shapely.contains_xy(scope, values[:, 0], values[:, 1])
        return float(np.mean(contained))
    except AttributeError:  # pragma: no cover - compatibility with Shapely 1.x
        return float(np.mean([scope.contains(Point(value)) for value in values]))


def _trajectory_free_space_polygon(
    wall_mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    simplify_m: float,
    trajectory_xy: np.ndarray | None,
) -> Polygon | None:
    """Return the enclosed free-space face traversed by most trajectory poses.

    Wall contours are thin obstacle rings, so selecting their largest contour
    tends to pick a wall band or an outlier hull.  Labelling the inverse raster
    instead exposes the actual closed planar faces.  The border-touching label
    is the unbounded exterior and is deliberately excluded.
    """
    if trajectory_xy is None or not len(trajectory_xy):
        return None
    dilation_pixels = max(1, int(round(0.10 / grid_m)))
    barriers = cv2.dilate(wall_mask, np.ones((3, 3), np.uint8), iterations=dilation_pixels)
    free = np.where(barriers == 0, 255, 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(free, 8)
    if count <= 1:
        return None
    ij = np.floor((trajectory_xy - origin) / grid_m).astype(int)
    valid = (ij[:, 0] >= 0) & (ij[:, 1] >= 0) & (ij[:, 0] < labels.shape[1]) & (ij[:, 1] < labels.shape[0])
    votes = np.bincount(labels[ij[valid, 1], ij[valid, 0]], minlength=count)
    candidates = []
    height, width = labels.shape
    for component in range(1, count):
        x, y, w, h, area = stats[component]
        touches_border = x == 0 or y == 0 or x + w >= width or y + h >= height
        if touches_border or area < 16 or votes[component] == 0:
            continue
        candidates.append((int(votes[component]), int(area), component))
    if not candidates:
        return None
    _, _, component = max(candidates)
    component_mask = np.where(labels == component, 255, 0).astype(np.uint8)
    contours, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    polygons = [
        polygon
        for contour in contours
        if (polygon := _contour_polygon(contour, origin, grid_m, simplify_m)) is not None
    ]
    return max(polygons, key=lambda polygon: polygon.area) if polygons else None


def _ceiling_trajectory_shell(
    points: np.ndarray,
    ceiling_height_m: float | None,
    trajectory_xy: np.ndarray | None,
    mask_shape: tuple[int, int],
    origin: np.ndarray,
    grid_m: float,
    main_angle: float | None,
    cfg: dict,
) -> tuple[Polygon | None, int]:
    """Trace the building envelope from dense ceiling returns near the path.

    The ceiling plane is usually observed continuously even where a wall body
    is occluded. Limiting occupied cells by distance to the surveyed path keeps
    neighbouring roofs and facade clutter out of the envelope.
    """
    if (
        not bool(cfg.get("ceiling_shell_enabled", True))
        or ceiling_height_m is None
        or trajectory_xy is None
        or not len(trajectory_xy)
    ):
        return None, 0
    lower = ceiling_height_m - float(cfg.get("ceiling_assist_below_m", 0.26))
    upper = ceiling_height_m + float(cfg.get("ceiling_assist_above_m", 0.18))
    band = points[(points[:, 2] >= lower) & (points[:, 2] <= upper)]
    if not len(band):
        return None, 0
    ij = np.floor((band[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < mask_shape[1])
        & (ij[:, 1] < mask_shape[0])
    )
    density = np.zeros(mask_shape, dtype=np.int32)
    np.add.at(density, (ij[valid, 1], ij[valid, 0]), 1)
    occupied_yx = np.column_stack(
        np.nonzero(density >= int(cfg.get("ceiling_shell_min_points_per_cell", 1)))
    )
    if not len(occupied_yx):
        return None, 0
    occupied_xy = origin + (occupied_yx[:, ::-1] + 0.5) * grid_m
    path_distance, _ = cKDTree(trajectory_xy).query(occupied_xy)
    retained = occupied_yx[
        path_distance <= float(cfg.get("ceiling_shell_max_path_distance_m", 5.0))
    ]
    if not len(retained):
        return None, 0
    ceiling_mask = np.zeros(mask_shape, dtype=np.uint8)
    ceiling_mask[retained[:, 0], retained[:, 1]] = 255
    close_pixels = max(3, int(round(float(cfg.get("ceiling_shell_close_gap_m", 0.80)) / grid_m)) | 1)
    ceiling_mask = cv2.morphologyEx(
        ceiling_mask,
        cv2.MORPH_CLOSE,
        np.ones((close_pixels, close_pixels), np.uint8),
    )
    ceiling_mask = cv2.morphologyEx(ceiling_mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(ceiling_mask, 8)
    candidates: list[tuple[float, float, Polygon]] = []
    for component in range(1, count):
        if stats[component, cv2.CC_STAT_AREA] * grid_m * grid_m < 10.0:
            continue
        component_mask = np.where(labels == component, 255, 0).astype(np.uint8)
        contours, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            continue
        polygon = _contour_polygon(
            max(contours, key=cv2.contourArea),
            origin,
            grid_m,
            float(cfg.get("ceiling_shell_simplify_m", 0.20)),
        )
        if polygon is None:
            continue
        opening = float(cfg.get("ceiling_shell_opening_m", 0.0))
        if opening > 0:
            opened = polygon.buffer(-opening, join_style=2).buffer(opening, join_style=2)
            if opened.geom_type == "MultiPolygon":
                opened = max(opened.geoms, key=lambda value: value.area)
            if (
                isinstance(opened, Polygon)
                and opened.is_valid
                and opened.area >= 0.90 * polygon.area
            ):
                polygon = opened.simplify(
                    float(cfg.get("ceiling_shell_post_simplify_m", 0.20)),
                    preserve_topology=True,
                )
        polygon = _snap_polygon(polygon, float(cfg["snap_angle_deg"]), main_angle)
        candidates.append((_trajectory_containment(polygon, trajectory_xy), polygon.area, polygon))
    if not candidates:
        return None, int(len(retained))
    containment, _, shell = max(candidates, key=lambda row: (row[0], row[1]))
    if containment < float(cfg.get("ceiling_shell_min_trajectory_containment", 0.95)):
        return None, int(len(retained))
    return shell, int(len(retained))


def _line_from_edge(a: np.ndarray, b: np.ndarray, snap_deg: float) -> tuple[float, float, float]:
    d = b - a
    angle = math.atan2(d[1], d[0])
    horizontal = abs(math.sin(angle)) <= math.sin(math.radians(snap_deg))
    vertical = abs(math.cos(angle)) <= math.sin(math.radians(snap_deg))
    middle = (a + b) / 2
    if horizontal:
        return 0.0, 1.0, float(middle[1])
    if vertical:
        return 1.0, 0.0, float(middle[0])
    normal = np.asarray([-d[1], d[0]], dtype=float)
    normal /= np.linalg.norm(normal)
    return float(normal[0]), float(normal[1]), float(normal @ middle)


def _snap_polygon(polygon: Polygon, snap_deg: float, main_angle: float | None = None) -> Polygon:
    coords = np.asarray(polygon.exterior.coords[:-1], dtype=float)
    if len(coords) < 4:
        return polygon
    edges = np.roll(coords, -1, axis=0) - coords
    lengths = np.linalg.norm(edges, axis=1)
    if main_angle is None:
        main_angle = math.atan2(edges[np.argmax(lengths), 1], edges[np.argmax(lengths), 0])
    c, s = math.cos(-main_angle), math.sin(-main_angle)
    rotation = np.asarray([[c, -s], [s, c]])
    local = coords @ rotation.T
    lines = [_line_from_edge(local[i], local[(i + 1) % len(local)], snap_deg) for i in range(len(local))]
    vertices = []
    for i in range(len(local)):
        previous = lines[i - 1]
        current = lines[i]
        matrix = np.asarray([[previous[0], previous[1]], [current[0], current[1]]])
        if abs(np.linalg.det(matrix)) < 1e-6:
            vertices.append(local[i])
        else:
            vertices.append(np.linalg.solve(matrix, np.asarray([previous[2], current[2]])))
    snapped_local = np.asarray(vertices)
    snapped = snapped_local @ rotation
    candidate = Polygon(snapped).buffer(0)
    if isinstance(candidate, Polygon) and candidate.is_valid and candidate.area > 0.5 * polygon.area:
        return candidate
    return polygon


def _merge_collinear_hough(lines: np.ndarray, angle_tolerance_deg: float = 2.0, offset_tolerance_px: float = 3.0) -> int:
    """Count robust line supports after grouping collinear Hough fragments."""
    groups: list[dict] = []
    for x1, y1, x2, y2 in np.asarray(lines).reshape(-1, 4):
        direction = np.asarray([x2 - x1, y2 - y1], dtype=float)
        length = float(np.linalg.norm(direction))
        if length <= 0:
            continue
        direction /= length
        if direction[0] < 0 or (abs(direction[0]) < 1e-12 and direction[1] < 0):
            direction *= -1
        angle = math.atan2(direction[1], direction[0]) % math.pi
        normal = np.asarray([-direction[1], direction[0]])
        offset = float(normal @ np.asarray([(x1 + x2) / 2, (y1 + y2) / 2]))
        match = None
        for group in groups:
            difference = abs((angle - group["angle"] + math.pi / 2) % math.pi - math.pi / 2)
            if difference <= math.radians(angle_tolerance_deg) and abs(offset - group["offset"]) <= offset_tolerance_px:
                match = group
                break
        if match is None:
            groups.append({"angle": angle, "offset": offset, "weight": length})
        else:
            total = match["weight"] + length
            match["angle"] = (match["angle"] * match["weight"] + angle * length) / total
            match["offset"] = (match["offset"] * match["weight"] + offset * length) / total
            match["weight"] = total
    return len(groups)


def _hough_line_summary(mask: np.ndarray, grid_m: float) -> tuple[float | None, int, int]:
    lines = cv2.HoughLinesP(
        mask,
        1,
        np.pi / 360,
        threshold=max(15, int(0.5 / grid_m)),
        minLineLength=max(5, int(0.8 / grid_m)),
        maxLineGap=max(2, int(0.8 / grid_m)),
    )
    if lines is None:
        return None, 0, 0
    histogram = np.zeros(180, dtype=float)
    for x1, y1, x2, y2 in np.asarray(lines).reshape(-1, 4):
        angle = math.atan2(y2 - y1, x2 - x1) % math.pi
        histogram[int(round(math.degrees(angle))) % 180] += math.hypot(x2 - x1, y2 - y1)
    # Orthogonal walls vote into a shared Manhattan-frame orientation.
    folded = histogram[:90] + histogram[90:]
    index = int(np.argmax(folded))
    raw_count = len(np.asarray(lines).reshape(-1, 4))
    return math.radians(index), raw_count, _merge_collinear_hough(lines)


def _longest_edge_angle(polygon: Polygon) -> float:
    coords = np.asarray(polygon.exterior.coords, dtype=float)
    edges = np.diff(coords, axis=0)
    index = int(np.argmax(np.linalg.norm(edges, axis=1)))
    return math.atan2(edges[index, 1], edges[index, 0])


def _sample_boundary(polygon: Polygon, interval_m: float) -> np.ndarray:
    line = LineString(polygon.exterior.coords)
    count = max(2, int(math.ceil(line.length / interval_m)))
    return np.asarray([[line.interpolate(i / count, normalized=True).x, line.interpolate(i / count, normalized=True).y] for i in range(count)])


def _outline_metrics(shell: Polygon, structural_xy: np.ndarray, support_distance_m: float) -> dict:
    samples = _sample_boundary(shell, min(0.05, support_distance_m / 2))
    distances, _ = cKDTree(structural_xy).query(samples)
    return {
        "closed": bool(shell.exterior.is_ring),
        "valid": bool(shell.is_valid),
        "self_intersects": not bool(shell.is_simple),
        "area_m2": float(shell.area),
        "perimeter_m": float(shell.length),
        "outline_distance_median_m": float(np.median(distances)),
        "outline_distance_p95_m": float(np.percentile(distances, 95)),
        "shell_support_fraction": float(np.mean(distances <= support_distance_m)),
        "shell_sample_count": int(len(samples)),
    }


def vectorize_sessions(
    session_points_ref: list[np.ndarray],
    cfg: dict,
    trajectory_ref: np.ndarray | None = None,
    ceiling_height_m: float | None = None,
    vision_cfg: dict | None = None,
    vision_output_dir: str | None = None,
    vision_force: bool = False,
) -> OutlineResult:
    if not session_points_ref:
        raise DataQualityError("No accepted point cloud sessions to vectorize")
    grid_m = float(cfg["grid_m"])
    max_height = float(cfg["max_height_m"])
    if ceiling_height_m is not None:
        max_height = min(max_height, ceiling_height_m - float(cfg["ceiling_margin_m"]))
    dense_points = np.vstack([np.asarray(points, dtype=float) for points in session_points_ref])
    detail_grid_m = float(cfg.get("detail_grid_m", grid_m))
    detail_mask, detail_origin, detail_points, detail_metrics = _dense_detail_raster(
        dense_points,
        detail_grid_m,
        float(cfg["height_bin_m"]),
        float(cfg["min_height_m"]),
        max_height,
        int(cfg.get("detail_min_points_per_cell", 4)),
        int(cfg.get("detail_min_height_bins", 2)),
        int(cfg.get("detail_min_component_cells", 4)),
    )
    structural_by_session: list[np.ndarray] = []
    cells_by_session: list[np.ndarray] = []
    for points in session_points_ref:
        structural, cells = vertical_structural_cells(
            points,
            grid_m,
            float(cfg["height_bin_m"]),
            float(cfg["min_height_m"]),
            max_height,
            float(cfg["vertical_span_m"]),
            int(cfg["min_height_bins"]),
        )
        structural_by_session.append(structural)
        cells_by_session.append(cells)
    if not any(len(points) for points in structural_by_session):
        raise DataQualityError("No vertically continuous structural points were detected")

    support: dict[tuple[int, int], int] = {}
    for cells in cells_by_session:
        for key in map(tuple, cells.tolist()):
            support[key] = support.get(key, 0) + 1
    desired_support = min(int(cfg.get("min_session_support", 2)), len(session_points_ref))
    stable = {key for key, count in support.items() if count >= desired_support}
    all_cells = set(support)
    used_support = 1
    if len(stable) < max(100, int(0.2 * len(all_cells))):
        stable = all_cells
    stable_selected = []
    for points in structural_by_session:
        if not len(points):
            continue
        keys = np.floor(points[:, :2] / grid_m).astype(np.int64)
        keep = np.fromiter((tuple(v) in stable for v in keys), dtype=bool, count=len(keys))
        stable_selected.append(points[keep])
    stable_structural = np.vstack(stable_selected)
    # Single-session walls remain useful for closing the outer shell.  Keep
    # them in the shell raster and confidence metrics, while the support table
    # below still enforces cross-session stability for columns/core objects.
    structural = np.vstack([points for points in structural_by_session if len(points)])
    mask, origin = _points_to_mask(structural, grid_m)
    component_count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    denoised = np.zeros_like(mask)
    for component in range(1, component_count):
        if stats[component, cv2.CC_STAT_AREA] >= 4:
            denoised[labels == component] = 255
    mask = denoised
    gap_pixels = max(1, int(round(float(cfg["max_gap_m"]) / grid_m)))
    closed = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=max(1, gap_pixels // 2))
    hough_main_angle, hough_line_count, merged_line_count = _hough_line_summary(closed, grid_m)
    contours, _ = cv2.findContours(closed, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    raster_polygons = [
        polygon
        for contour in contours
        if (polygon := _contour_polygon(contour, origin, grid_m, float(cfg["shell_simplify_m"]))) is not None
    ]
    polygon_sources: list[tuple[Polygon, str]] = [(polygon, "raster_line_graph") for polygon in raster_polygons]
    trajectory_xy = trajectory_ref[:, :2] if trajectory_ref is not None else None
    free_space_polygon = _trajectory_free_space_polygon(
        closed,
        origin,
        grid_m,
        float(cfg["shell_simplify_m"]),
        trajectory_xy,
    )
    if free_space_polygon is not None:
        polygon_sources.append((free_space_polygon, "trajectory_free_space"))
    ceiling_shell, ceiling_shell_evidence_cells = _ceiling_trajectory_shell(
        dense_points,
        ceiling_height_m,
        trajectory_xy,
        detail_mask.shape,
        detail_origin,
        detail_grid_m,
        hough_main_angle,
        cfg,
    )
    if ceiling_shell is not None:
        polygon_sources.append((ceiling_shell, "ceiling_trajectory_envelope"))
    hull_xy = (np.asarray(list(all_cells), dtype=float) + 0.5) * grid_m
    max_shell_distance = float(cfg.get("max_shell_distance_to_trajectory_m", 0.0))
    if trajectory_xy is not None and len(trajectory_xy) and max_shell_distance > 0:
        distances_to_path, _ = cKDTree(trajectory_xy).query(hull_xy)
        nearby = hull_xy[distances_to_path <= max_shell_distance]
        if len(nearby) >= 4:
            hull_xy = nearby
    if len(hull_xy) > 50_000:
        rng = np.random.default_rng(23)
        hull_xy = hull_xy[rng.choice(len(hull_xy), 50_000, replace=False)]
    if len(hull_xy) >= 4:
        base_ratio = float(cfg.get("concave_hull_ratio", 0.12))
        # A single alpha/concavity value is brittle when portions of the outer
        # wall were only observed in one session.  Generate a small deterministic
        # family and let path containment plus wall support choose the fallback.
        hull_ratios = sorted({base_ratio, 0.03, 0.05, 0.08, 0.12, 0.20, 0.30, 0.40})
        for ratio in hull_ratios:
            hull = shapely.concave_hull(
                MultiPoint(hull_xy),
                ratio=ratio,
                allow_holes=False,
            ).simplify(float(cfg["shell_simplify_m"]), preserve_topology=True)
            if isinstance(hull, Polygon) and hull.is_valid and hull.area > 0:
                polygon_sources.append((hull, f"concave_hull_{ratio:g}"))
    fallback = False
    if not polygon_sources:
        fallback = True
        polygon = MultiPoint(structural[:, :2]).convex_hull
        if not isinstance(polygon, Polygon):
            raise DataQualityError("Could not construct a closed shell")
        polygon_sources = [(polygon, "convex_hull")]
    scored = []
    support_tree = cKDTree(detail_points[:, :2])
    support_distance = float(cfg.get("shell_support_distance_m", 0.15))
    for polygon, source in polygon_sources:
        containment = _trajectory_containment(polygon, trajectory_xy)
        evidence_containment = _structural_evidence_containment(
            polygon,
            structural[:, :2],
            support_distance,
        )
        boundary_samples = _sample_boundary(polygon, max(grid_m, 0.10))
        boundary_distances, _ = support_tree.query(boundary_samples)
        boundary_support = float(np.mean(boundary_distances <= support_distance))
        # Containing the surveyed path is the primary requirement; structural
        # boundary support prevents a broad outlier-driven hull from winning.
        containment_score = min(containment / 0.80, 1.0)
        if trajectory_xy is None or not len(trajectory_xy):
            # Without a surveyed path the global structural coverage replaces
            # trajectory containment as the primary signal.  This prevents a
            # sub-metre room loop with perfect local support from beating the
            # whole-building concave hull.
            score = (
                10.0 * evidence_containment
                + 4.0 * boundary_support
                + 0.35 * math.log1p(polygon.area)
                - 0.005 * polygon.length
            )
        else:
            score = (
                8.0 * containment_score
                + 6.0 * boundary_support
                + 1.5 * evidence_containment
                + 0.25 * math.log1p(polygon.area)
                - 0.01 * polygon.length
            )
        scored.append(
            (
                score,
                polygon,
                containment,
                source,
                boundary_support,
                evidence_containment,
            )
        )
    (
        _,
        shell,
        trajectory_containment,
        shell_source,
        shell_boundary_support,
        shell_evidence_containment,
    ) = max(scored, key=lambda row: row[0])
    fallback = fallback or shell_source not in {
        "raster_line_graph",
        "trajectory_free_space",
        "ceiling_trajectory_envelope",
    }
    shell = _snap_polygon(shell, float(cfg["snap_angle_deg"]), hough_main_angle)
    if not shell.is_valid or not shell.exterior.is_ring:
        shell = shell.buffer(0)
    if not isinstance(shell, Polygon) or not shell.is_valid:
        raise DataQualityError("Extracted shell is invalid")

    internals: list[tuple[str, Polygon, float]] = []
    clearance = float(cfg["shell_clearance_m"])
    min_area = float(cfg["min_internal_area_m2"])
    max_column = float(cfg["column_max_area_m2"])
    for _, polygon, _, source, _, _ in scored:
        if source != "raster_line_graph":
            continue
        if polygon.equals(shell) or polygon.area < min_area:
            continue
        center = polygon.representative_point()
        if not shell.contains(center) or polygon.distance(shell.boundary) < clearance:
            continue
        min_x, min_y, max_x, max_y = polygon.bounds
        candidate_support = []
        for key, count in support.items():
            x, y = (np.asarray(key, dtype=float) + 0.5) * grid_m
            if min_x - grid_m <= x <= max_x + grid_m and min_y - grid_m <= y <= max_y + grid_m:
                if polygon.buffer(grid_m).contains(Point(x, y)):
                    candidate_support.append(count)
        object_support = max(candidate_support, default=0)
        if len(session_points_ref) >= 2 and object_support < desired_support:
            continue
        session_confidence = min(1.0, object_support / max(1, desired_support))
        klass = "COLUMN" if polygon.area <= max_column else "CORE"
        rectangle = polygon.minimum_rotated_rectangle
        rectangle_edges = np.linalg.norm(np.diff(np.asarray(rectangle.exterior.coords), axis=0), axis=1)
        nonzero_edges = rectangle_edges[rectangle_edges > 1e-6]
        aspect_ratio = float(np.max(nonzero_edges) / np.min(nonzero_edges)) if len(nonzero_edges) else float("inf")
        compactness = float(4.0 * math.pi * polygon.area / max(polygon.length**2, 1e-12))
        if klass == "COLUMN" and (aspect_ratio > 4.0 or compactness < 0.18):
            continue
        if klass == "CORE" and compactness < 0.08:
            continue
        internals.append((klass, _snap_polygon(polygon, float(cfg["snap_angle_deg"])), session_confidence))

    detail_main_angle, detail_hough_count, detail_merged_count = _hough_line_summary(detail_mask, detail_grid_m)
    layout_mask = detail_mask
    vision_metrics: dict = {
        "vision_layout_backend": None,
        "vision_layout_accepted": False,
    }
    vision_vector_heatmap: np.ndarray | None = None
    if vision_cfg and vision_cfg.get("enabled", False):
        try:
            from .vision_layout import run_vision_layout

            vision_result = run_vision_layout(
                session_points_ref,
                detail_mask,
                detail_origin,
                detail_grid_m,
                float(cfg["height_bin_m"]),
                float(cfg["min_height_m"]),
                max_height,
                detail_main_angle,
                shell,
                vision_cfg,
                vision_output_dir or "vision_layout",
                force=vision_force,
            )
            layout_mask = vision_result.mask
            vision_vector_heatmap = vision_result.vector_heatmap
            vision_metrics = vision_result.metrics
        except Exception as exc:
            vision_metrics = {
                "vision_layout_backend": "Lane2StructureNet",
                "vision_layout_accepted": False,
                "vision_layout_error": f"{type(exc).__name__}: {exc}",
            }
    wall_polygons = _mask_polygons(
        layout_mask,
        detail_origin,
        detail_grid_m,
        float(cfg.get("detail_simplify_m", 0.05)),
        float(cfg.get("detail_min_wall_area_m2", 0.015)),
        float(cfg.get("detail_min_wall_perimeter_m", 0.40)),
    )
    vision_wall_centerlines: list[LineString] = []
    if vision_metrics.get("vision_layout_accepted", False):
        vision_wall_centerlines = _wall_centerlines(
            layout_mask,
            detail_origin,
            detail_grid_m,
            detail_main_angle,
            float(cfg["snap_angle_deg"]),
        )
        # The network selects plausible structure. The original LiDAR mask
        # still verifies every metric segment before it can enter the CAD.
        vision_wall_centerlines = _clip_lines_to_wall_support(
            vision_wall_centerlines,
            detail_mask,
            detail_origin,
            detail_grid_m,
            float(cfg.get("straight_wall_support_distance_m", 0.10)),
            float(cfg.get("straight_wall_bridge_gap_m", 0.15)),
            float(cfg.get("vision_open_wall_min_length_m", 1.00)),
        )
        vision_wall_centerlines = _filter_and_merge_straight_lines(
            vision_wall_centerlines,
            detail_main_angle,
            float(cfg["snap_angle_deg"]),
            float(cfg.get("vision_open_wall_min_length_m", 1.00)),
            float(cfg.get("straight_wall_oblique_min_length_m", 1.20)),
            float(cfg.get("straight_wall_merge_angle_deg", 1.0)),
            float(cfg.get("straight_wall_merge_offset_m", 0.18)),
            float(cfg.get("vision_open_wall_merge_gap_m", 0.30)),
        )
        vision_wall_centerlines = _snap_line_junctions(
            vision_wall_centerlines,
            float(cfg.get("straight_wall_junction_tolerance_m", 0.20)),
        )
    wall_centerlines = _wall_centerlines(
        detail_mask,
        detail_origin,
        detail_grid_m,
        detail_main_angle,
        float(cfg["snap_angle_deg"]),
    )
    wall_centerlines = _clip_lines_to_wall_support(
        wall_centerlines,
        detail_mask,
        detail_origin,
        detail_grid_m,
        float(cfg.get("straight_wall_support_distance_m", 0.10)),
        float(cfg.get("straight_wall_bridge_gap_m", 0.15)),
        float(cfg.get("straight_wall_min_length_m", 0.50)),
    )
    wall_centerlines = _filter_and_merge_straight_lines(
        wall_centerlines,
        detail_main_angle,
        float(cfg["snap_angle_deg"]),
        float(cfg.get("straight_wall_min_length_m", 0.75)),
        float(cfg.get("straight_wall_oblique_min_length_m", 1.20)),
        float(cfg.get("straight_wall_merge_angle_deg", 1.0)),
        float(cfg.get("straight_wall_merge_offset_m", 0.18)),
        float(cfg.get("straight_wall_merge_gap_m", 0.12)),
    )
    wall_centerlines = _clip_lines_to_wall_support(
        wall_centerlines,
        detail_mask,
        detail_origin,
        detail_grid_m,
        float(cfg.get("straight_wall_support_distance_m", 0.10)),
        float(cfg.get("straight_wall_bridge_gap_m", 0.15)),
        float(cfg.get("straight_wall_min_length_m", 0.75)),
    )
    wall_centerlines = _snap_line_junctions(
        wall_centerlines,
        float(cfg.get("straight_wall_junction_tolerance_m", 0.20)),
    )
    ceiling_lines, ceiling_evidence_cells = _ceiling_assisted_wall_lines(
        dense_points,
        ceiling_height_m,
        detail_mask.shape,
        detail_origin,
        detail_grid_m,
        detail_main_angle,
        cfg,
    )
    if ceiling_lines:
        wall_centerlines = _deduplicate_evidence_lines(
            wall_centerlines + ceiling_lines,
            float(cfg.get("ceiling_assist_dedup_angle_deg", 2.0)),
            float(cfg.get("ceiling_assist_dedup_offset_m", 0.16)),
            float(cfg.get("ceiling_assist_merge_gap_m", 0.80)),
        )
        wall_centerlines = _snap_line_junctions(
            wall_centerlines,
            float(cfg.get("straight_wall_junction_tolerance_m", 0.20)),
        )
    projected_mask = _projected_detail_mask(
        detail_points,
        detail_origin,
        detail_grid_m,
        detail_mask.shape,
        int(cfg.get("projected_detail_min_points_per_cell", 8)),
        int(cfg.get("detail_min_component_cells", 4)),
    )
    projected_lines = _wall_centerlines(
        projected_mask,
        detail_origin,
        detail_grid_m,
        detail_main_angle,
        float(cfg["snap_angle_deg"]),
    )
    projected_lines = _clip_lines_to_wall_support(
        projected_lines,
        projected_mask,
        detail_origin,
        detail_grid_m,
        float(cfg.get("straight_wall_support_distance_m", 0.10)),
        float(cfg.get("straight_wall_bridge_gap_m", 0.15)),
        float(cfg.get("straight_wall_min_length_m", 0.50)),
    )
    projected_lines = _filter_and_merge_straight_lines(
        projected_lines,
        detail_main_angle,
        float(cfg["snap_angle_deg"]),
        float(cfg.get("straight_wall_min_length_m", 0.75)),
        float(cfg.get("straight_wall_oblique_min_length_m", 1.20)),
        float(cfg.get("straight_wall_merge_angle_deg", 1.0)),
        float(cfg.get("straight_wall_merge_offset_m", 0.18)),
        float(cfg.get("straight_wall_merge_gap_m", 0.12)),
    )
    primary_buffer = shapely.union_all(wall_centerlines).buffer(0.12) if wall_centerlines else None
    scan_detail_lines: list[LineString] = []
    for line in projected_lines:
        uncovered = line if primary_buffer is None else line.difference(primary_buffer)
        parts = list(uncovered.geoms) if uncovered.geom_type == "MultiLineString" else [uncovered]
        scan_detail_lines.extend(part for part in parts if isinstance(part, LineString) and part.length >= 0.80)
    scope_margin = float(cfg.get("detail_scope_margin_m", 0.0))
    if scope_margin > 0:
        detail_scope = shell.buffer(scope_margin)
        scoped_wall_polygons: list[Polygon] = []
        for polygon in wall_polygons:
            clipped = polygon.intersection(detail_scope)
            scoped_wall_polygons.extend(
                _valid_polygon_parts(
                    clipped,
                    float(cfg.get("detail_min_wall_area_m2", 0.015)),
                    float(cfg.get("detail_min_wall_perimeter_m", 0.40)),
                )
            )
        wall_polygons = scoped_wall_polygons
        scoped_centerlines: list[LineString] = []
        for line in wall_centerlines:
            clipped = line.intersection(detail_scope)
            parts = list(clipped.geoms) if clipped.geom_type == "MultiLineString" else [clipped]
            scoped_centerlines.extend(part for part in parts if isinstance(part, LineString) and part.length >= 0.80)
        wall_centerlines = scoped_centerlines
    spaces = _inferred_spaces(
        layout_mask,
        shell,
        detail_origin,
        detail_grid_m,
        detail_main_angle,
        float(cfg.get("room_gap_close_m", 0.90)),
        float(cfg.get("min_space_area_m2", 1.0)),
        float(cfg.get("detail_simplify_m", 0.05)),
    )

    raw_wall_centerlines = wall_centerlines
    direct_vector_metrics: dict = {}
    direct_vector_lines: list[LineString] = []
    if (
        vision_metrics.get("vision_layout_accepted", False)
        and vision_cfg
        and bool(vision_cfg.get("direct_vectorization_enabled", False))
    ):
        from pathlib import Path

        from .raster_vectorize import (
            soft_consolidate_junctions,
            soft_regularize_oblique_lines,
            vectorize_structure_mask,
        )

        direct = vectorize_structure_mask(
            layout_mask,
            detail_origin,
            detail_grid_m,
            detail_main_angle,
            vision_cfg,
            heatmap=vision_vector_heatmap,
        )
        direct_vector_lines = _cluster_line_endpoints(
            direct.lines,
            float(vision_cfg.get("vector_endpoint_cluster_m", 0.22)),
        )
        direct_vector_lines = _snap_line_junctions(
            direct_vector_lines,
            float(vision_cfg.get("vector_junction_tolerance_m", 0.35)),
        )
        direct_vector_lines = _cluster_line_endpoints(
            direct_vector_lines,
            float(vision_cfg.get("vector_endpoint_cluster_m", 0.22)),
        )
        oblique = soft_regularize_oblique_lines(
            direct_vector_lines,
            direct.cleaned_mask,
            direct.skeleton,
            vision_vector_heatmap,
            detail_origin,
            detail_grid_m,
            detail_main_angle,
            vision_cfg,
        )
        direct_vector_lines = _cluster_line_endpoints(
            oblique.lines,
            float(vision_cfg.get("vector_endpoint_cluster_m", 0.22)),
        )
        direct_vector_lines = _snap_line_junctions(
            direct_vector_lines,
            float(vision_cfg.get("vector_junction_tolerance_m", 0.35)),
        )
        direct_vector_lines = _cluster_line_endpoints(
            direct_vector_lines,
            float(vision_cfg.get("vector_endpoint_cluster_m", 0.22)),
        )
        junctions = soft_consolidate_junctions(
            direct_vector_lines,
            direct.cleaned_mask,
            vision_vector_heatmap,
            detail_origin,
            detail_grid_m,
            detail_main_angle,
            vision_cfg,
        )
        direct_vector_lines = junctions.lines
        direct_vector_metrics = direct.metrics
        direct_vector_metrics.update(oblique.metrics)
        direct_vector_metrics.update(junctions.metrics)
        direct_vector_metrics["direct_vector_final_line_count"] = len(direct_vector_lines)
        if vision_output_dir:
            output_dir = Path(vision_output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(output_dir / "direct_cleaned_mask.png"), direct.cleaned_mask)
            cv2.imwrite(str(output_dir / "direct_skeleton.png"), direct.skeleton)
            heat_preview = np.clip(
                (vision_vector_heatmap if vision_vector_heatmap is not None else direct.cleaned_mask / 255.0)
                * 180,
                0,
                255,
            ).astype(np.uint8)
            heat_preview = cv2.cvtColor(heat_preview, cv2.COLOR_GRAY2BGR)
            for line in direct_vector_lines:
                pixels = np.rint(
                    (np.asarray(line.coords) - detail_origin) / detail_grid_m - 0.5
                ).astype(np.int32)
                cv2.polylines(heat_preview, [pixels], False, (235, 235, 235), 1, cv2.LINE_AA)
            for line in oblique.accepted_candidates:
                pixels = np.rint(
                    (np.asarray(line.coords) - detail_origin) / detail_grid_m - 0.5
                ).astype(np.int32)
                cv2.polylines(heat_preview, [pixels], False, (40, 240, 80), 2, cv2.LINE_AA)
            cv2.imwrite(str(output_dir / "oblique_regularization.png"), heat_preview)
            junction_preview = heat_preview.copy()
            for junction in junctions.accepted_junctions:
                pixel = np.rint(
                    (np.asarray(junction["point"]) - detail_origin) / detail_grid_m - 0.5
                ).astype(int)
                radius = 5 + int(round(3 * float(junction["reward"])))
                cv2.circle(junction_preview, tuple(pixel), radius, (40, 220, 255), 2, cv2.LINE_AA)
                cv2.circle(junction_preview, tuple(pixel), 2, (40, 80, 255), -1, cv2.LINE_AA)
            cv2.imwrite(str(output_dir / "junction_consolidation.png"), junction_preview)

    if len(direct_vector_lines) >= int((vision_cfg or {}).get("vector_min_output_lines", 20)):
        wall_centerlines = direct_vector_lines
        topology_source = "vision_prediction_skeleton_graph"
        vision_open_added = 0
        topological_wall_centerlines: list[LineString] = []
        # Keep all geometric alternatives on the hidden audit layer. The
        # visible WALL layer is now a direct vectorization of prediction.png.
        scan_detail_lines = raw_wall_centerlines + scan_detail_lines
    else:
        topological_wall_centerlines = _topological_wall_network(
            spaces,
            shell,
            detail_points[:, :2],
            detail_main_angle,
            cfg,
        )
        if len(topological_wall_centerlines) >= int(cfg.get("topology_min_line_count", 10)):
            wall_centerlines = topological_wall_centerlines
            vision_open_added = 0
            if (
                vision_metrics.get("vision_layout_accepted", False)
                and bool(cfg.get("vision_open_wall_fusion_enabled", True))
                and vision_wall_centerlines
            ):
                redundancy = shapely.union_all(topological_wall_centerlines).buffer(
                    float(cfg.get("vision_open_wall_redundancy_buffer_m", 0.18))
                )
                minimum_open_length = float(cfg.get("vision_open_wall_min_length_m", 1.00))
                open_parts: list[LineString] = []
                for line in vision_wall_centerlines:
                    uncovered = line.difference(redundancy)
                    parts = list(uncovered.geoms) if uncovered.geom_type == "MultiLineString" else [uncovered]
                    open_parts.extend(
                        part
                        for part in parts
                        if isinstance(part, LineString) and part.length >= minimum_open_length
                    )
                anchor_tolerance = float(cfg.get("vision_open_wall_anchor_tolerance_m", 0.35))
                one_anchor_minimum = float(cfg.get("vision_open_wall_one_anchor_min_length_m", 1.40))
                unanchored_minimum = float(cfg.get("vision_open_wall_unanchored_min_length_m", 4.50))
                anchored_parts: list[LineString] = []
                pending = sorted(open_parts, key=lambda value: value.length, reverse=True)
                anchor_geometry = shapely.union_all(topological_wall_centerlines)
                for _ in range(3):
                    admitted: list[LineString] = []
                    retained: list[LineString] = []
                    for part in pending:
                        endpoints = np.asarray(part.coords, dtype=float)[[0, -1]]
                        anchor_count = sum(
                            Point(endpoint).distance(anchor_geometry) <= anchor_tolerance
                            for endpoint in endpoints
                        )
                        if (
                            anchor_count >= 2
                            or (anchor_count == 1 and part.length >= one_anchor_minimum)
                            or (anchor_count == 0 and part.length >= unanchored_minimum)
                        ):
                            admitted.append(part)
                        else:
                            retained.append(part)
                    if not admitted:
                        break
                    anchored_parts.extend(admitted)
                    anchor_geometry = shapely.union_all([anchor_geometry, *admitted])
                    pending = retained
                wall_centerlines = _deduplicate_evidence_lines(
                    topological_wall_centerlines + anchored_parts,
                    float(cfg.get("straight_wall_merge_angle_deg", 1.0)),
                    float(cfg.get("straight_wall_merge_offset_m", 0.18)),
                    float(cfg.get("vision_open_wall_merge_gap_m", 0.30)),
                )
                wall_centerlines = _snap_line_junctions(
                    wall_centerlines,
                    float(cfg.get("topology_junction_tolerance_m", 0.25)),
                )
                vision_open_added = max(0, len(wall_centerlines) - len(topological_wall_centerlines))
                topology_source = "vision_space_graph_plus_open_walls"
            else:
                topology_source = (
                    "vision_regularized_space_boundary_graph"
                    if vision_metrics.get("vision_layout_accepted", False)
                    else "regularized_space_boundary_graph"
                )
            scan_detail_lines = raw_wall_centerlines + scan_detail_lines
        else:
            topology_source = "hough_fallback"
            vision_open_added = 0

    angle = _longest_edge_angle(shell)
    transform_cad_from_ref = se2_matrix(-angle, 0, 0)
    rotated_shell = _geometry_transform(shell, transform_cad_from_ref)
    min_x, min_y, _, _ = rotated_shell.bounds
    translation = se2_matrix(0, -min_x, -min_y)
    transform_cad_from_ref = translation @ transform_cad_from_ref
    shell_cad = _geometry_transform(shell, transform_cad_from_ref)
    internals_cad = [(klass, _geometry_transform(poly, transform_cad_from_ref), confidence) for klass, poly, confidence in internals]
    # Affine transforms preserve topology mathematically, but repairing again
    # protects serialized CAD/GIS output from floating-point ring crossings.
    wall_polygons = [part for poly in wall_polygons for part in _valid_polygon_parts(poly)]
    wall_polygons_cad = [
        part
        for poly in wall_polygons
        for part in _valid_polygon_parts(_geometry_transform(poly, transform_cad_from_ref))
    ]
    wall_centerlines_cad = [_geometry_transform(line, transform_cad_from_ref) for line in wall_centerlines]
    scan_detail_lines_cad = [_geometry_transform(line, transform_cad_from_ref) for line in scan_detail_lines]
    spaces_cad = [(_geometry_transform(poly, transform_cad_from_ref), confidence) for poly, confidence in spaces]
    shell_support_distance = float(cfg.get("shell_support_distance_m", 0.15))
    # The deliverable is traced against the dense, height-filtered LiDAR wall
    # evidence.  Keep the stricter vertically-continuous result as a separate
    # diagnostic instead of letting its intentionally sparse sampling make a
    # geometrically supported boundary look inaccurate.
    metrics = _outline_metrics(shell, detail_points[:, :2], shell_support_distance)
    strict_shell_metrics = _outline_metrics(shell, structural[:, :2], shell_support_distance)
    metrics.update(
        {
            "outline_structural_distance_median_m": strict_shell_metrics["outline_distance_median_m"],
            "outline_structural_distance_p95_m": strict_shell_metrics["outline_distance_p95_m"],
            "shell_structural_support_fraction": strict_shell_metrics["shell_support_fraction"],
        }
    )
    straight_metrics = _straight_line_metrics(wall_centerlines, detail_mask, detail_origin, detail_grid_m)
    straight_metrics.update(_line_point_fit_metrics(wall_centerlines, detail_points[:, :2]))
    structural_straight_metrics = _straight_line_metrics(wall_centerlines, mask, origin, grid_m)
    straight_metrics["straight_wall_structural_evidence_coverage_fraction"] = structural_straight_metrics[
        "straight_wall_evidence_coverage_fraction"
    ]
    raw_straight_metrics = _straight_line_metrics(
        raw_wall_centerlines, detail_mask, detail_origin, detail_grid_m
    )
    raw_structural_metrics = _straight_line_metrics(raw_wall_centerlines, mask, origin, grid_m)
    network_metrics = _wall_network_metrics(
        wall_centerlines,
        shell,
        float(cfg.get("topology_junction_tolerance_m", 0.25)),
        float(cfg.get("topology_shell_margin_m", 0.25)),
    )
    metrics.update(
        {
            "trajectory_containment": trajectory_containment,
            "shell_boundary_support_fraction": shell_boundary_support,
            "shell_structural_containment_fraction": shell_evidence_containment,
            "shell_candidate_count": len(scored),
            "ceiling_shell_evidence_cell_count": ceiling_shell_evidence_cells,
            "session_support_required": used_support,
            "cross_session_stable_point_count": int(len(stable_structural)),
            "session_count": len(session_points_ref),
            "structural_point_count": int(len(structural)),
            "internal_object_count": len(internals),
            "fallback_shell": fallback,
            "shell_method": shell_source,
            "hough_line_count": hough_line_count,
            "merged_line_count": merged_line_count,
            "hough_main_direction_deg": None if hough_main_angle is None else math.degrees(hough_main_angle),
            "wall_polygon_count": len(wall_polygons),
            "wall_centerline_count": len(wall_centerlines),
            "raw_wall_evidence_line_count": len(raw_wall_centerlines),
            "scan_detail_line_count": len(scan_detail_lines),
            "wall_polygon_area_m2": float(sum(poly.area for poly in wall_polygons)),
            "inferred_space_count": len(spaces),
            "detail_hough_line_count": detail_hough_count,
            "detail_merged_line_count": detail_merged_count,
            "detail_main_direction_deg": None if detail_main_angle is None else math.degrees(detail_main_angle),
            "ceiling_assist_evidence_cell_count": ceiling_evidence_cells,
            "ceiling_assist_line_count": len(ceiling_lines),
            "vision_open_wall_candidate_count": len(vision_wall_centerlines),
            "vision_open_wall_added_count": vision_open_added,
            "wall_topology_source": topology_source,
            "raw_wall_evidence_coverage_fraction": raw_straight_metrics.get(
                "straight_wall_evidence_coverage_fraction", 0.0
            ),
            "raw_wall_structural_evidence_coverage_fraction": raw_structural_metrics.get(
                "straight_wall_evidence_coverage_fraction", 0.0
            ),
            **network_metrics,
            **detail_metrics,
            **vision_metrics,
            **direct_vector_metrics,
            **straight_metrics,
        }
    )
    return OutlineResult(
        shell_ref=shell,
        internals_ref=internals,
        wall_polygons_ref=wall_polygons,
        wall_centerlines_ref=wall_centerlines,
        doors_ref=[],
        windows_ref=[],
        scan_detail_lines_ref=scan_detail_lines,
        spaces_ref=spaces,
        shell_cad=shell_cad,
        internals_cad=internals_cad,
        wall_polygons_cad=wall_polygons_cad,
        wall_centerlines_cad=wall_centerlines_cad,
        doors_cad=[],
        windows_cad=[],
        scan_detail_lines_cad=scan_detail_lines_cad,
        spaces_cad=spaces_cad,
        structural_points_ref=structural,
        detail_points_ref=detail_points,
        transform_cad_from_ref=transform_cad_from_ref,
        transform_ref_from_cad=invert_transform(transform_cad_from_ref),
        metrics=metrics,
        raster=layout_mask,
        raster_origin=detail_origin,
        grid_m=detail_grid_m,
        structural_raster=mask,
        structural_raster_origin=origin,
        structural_grid_m=grid_m,
    )
