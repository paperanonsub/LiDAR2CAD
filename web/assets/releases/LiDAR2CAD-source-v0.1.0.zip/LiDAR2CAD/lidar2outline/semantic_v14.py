from __future__ import annotations

import json
import math
import subprocess
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import open3d as o3d
from scipy.spatial import cKDTree
from shapely.geometry import Point, Polygon

from .io import read_json, read_point_cloud, write_json


V14_SCHEMA = "semantic-point-joint-v14"
UNKNOWN_LABEL = -1
WALL_LABEL = 0
COLUMN_LABEL = 1
TRAIN_LABELS = ("wall", "column")


def _accepted_polygon(value: Any) -> Polygon | None:
    try:
        polygon = Polygon(np.asarray(value, dtype=float))
    except (TypeError, ValueError):
        return None
    if polygon.is_empty or not polygon.is_valid or polygon.area <= 0:
        return None
    return polygon


def _points_in_polygon(points_xy: np.ndarray, polygon: Polygon) -> np.ndarray:
    """Vectorised even/odd test; boundary points are included by a tiny buffer."""
    coordinates = np.asarray(polygon.exterior.coords, dtype=float)
    x, y = points_xy[:, 0], points_xy[:, 1]
    inside = np.zeros(len(points_xy), dtype=bool)
    previous = coordinates[-1]
    for current in coordinates:
        crossing = (current[1] > y) != (previous[1] > y)
        x_crossing = (previous[0] - current[0]) * (y - current[1]) / (
            previous[1] - current[1] + 1e-15
        ) + current[0]
        inside ^= crossing & (x <= x_crossing)
        previous = current
    return inside


def _voxelise(points: np.ndarray, voxel_m: float) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    origin = np.floor(np.min(points, axis=0) / voxel_m) * voxel_m
    keys = np.floor((points - origin) / voxel_m + 1e-8).astype(np.int32)
    unique, inverse, counts = np.unique(keys, axis=0, return_inverse=True, return_counts=True)
    sums = np.zeros((len(unique), 3), dtype=np.float64)
    np.add.at(sums, inverse, points)
    centers = sums / counts[:, None]
    return origin, unique, inverse.astype(np.int32), centers.astype(np.float32)


def _normals_and_geometry(points: np.ndarray, radius_m: float = 0.20) -> tuple[np.ndarray, np.ndarray]:
    cloud = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(points.astype(np.float64)))
    cloud.estimate_normals(
        search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=radius_m, max_nn=32)
    )
    normals = np.asarray(cloud.normals, dtype=np.float32)
    invalid = ~np.all(np.isfinite(normals), axis=1)
    normals[invalid] = np.asarray([0.0, 0.0, 1.0], np.float32)
    normals /= np.maximum(np.linalg.norm(normals, axis=1, keepdims=True), 1e-8)
    # Sign-free normals plus height provide a deliberately small geometry baseline.
    extent = np.ptp(points, axis=0)
    z_norm = (points[:, 2] - np.min(points[:, 2])) / max(float(extent[2]), 1e-6)
    geometry = np.column_stack(
        [np.abs(normals), z_norm, np.linalg.norm(normals[:, :2], axis=1)]
    ).astype(np.float32)
    return normals, geometry


def _xy_vertical_statistics(
    centers: np.ndarray, floor_m: float, xy_grid_m: float, z_bin_m: float
) -> tuple[np.ndarray, np.ndarray]:
    origin_xy = np.floor(np.min(centers[:, :2], axis=0) / xy_grid_m) * xy_grid_m
    xy = np.floor((centers[:, :2] - origin_xy) / xy_grid_m + 1e-8).astype(np.int32)
    z = np.floor((centers[:, 2] - floor_m) / z_bin_m + 1e-8).astype(np.int32)
    packed = np.column_stack([xy, z])
    unique_pairs = np.unique(packed, axis=0)
    unique_xy, pair_inverse = np.unique(unique_pairs[:, :2], axis=0, return_inverse=True)
    counts = np.bincount(pair_inverse, minlength=len(unique_xy)).astype(np.int16)
    z_min = np.full(len(unique_xy), np.iinfo(np.int32).max, np.int32)
    z_max = np.full(len(unique_xy), np.iinfo(np.int32).min, np.int32)
    np.minimum.at(z_min, pair_inverse, unique_pairs[:, 2])
    np.maximum.at(z_max, pair_inverse, unique_pairs[:, 2])
    lookup = {tuple(key): index for index, key in enumerate(unique_xy)}
    cell_index = np.asarray([lookup[tuple(value)] for value in xy], dtype=np.int32)
    span = (z_max - z_min + 1).astype(np.float32) * z_bin_m
    return counts[cell_index], span[cell_index]


def _column_polygons(labels: dict, graph: dict) -> list[tuple[str, Polygon]]:
    objects = {
        value.get("object_id"): value
        for key in ("columns", "uncertain")
        for value in graph.get(key, [])
    }
    result: list[tuple[str, Polygon]] = []
    for record in labels.get("records", []):
        if record.get("label") != "column":
            continue
        geometry = record.get("roi_polygon_ref")
        if not geometry:
            value = objects.get(record.get("object_id"), {})
            geometry = value.get("manual_roi_polygon_ref") or value.get("coordinates_ref")
        polygon = _accepted_polygon(geometry)
        if polygon is None:
            roi = record.get("roi_ref")
            if isinstance(roi, list) and len(roi) == 4:
                xmin, ymin, xmax, ymax = map(float, roi)
                polygon = Polygon([(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)])
        if polygon is not None:
            result.append((str(record.get("object_id")), polygon))
    return result


def _migrate_object_labels(source: dict, dataset_id: str) -> tuple[dict, dict]:
    migrated = json.loads(json.dumps(source))
    actions: list[dict] = []
    counts = {"wall": 0, "column": 0, "unknown": 0}
    for record in migrated.get("records", []):
        before = record.get("label")
        source_label = record.get("source_semantic_label")
        label_source = str(record.get("label_source") or "")
        if source_label == "column" or before == "column":
            after = "column"
            record["label_source"] = record.get("label_source") or "human_column_review"
            record["supervision_kind"] = "human_confirmed"
        elif before == "wall":
            after = "wall"
            record["supervision_kind"] = (
                "roi_derived" if "wall_roi" in label_source else "human_confirmed"
            )
        else:
            # ROI exterior is explicitly unknown: the user may have omitted walls.
            after = None
            record["supervision_kind"] = "unlabelled"
        if before != after:
            actions.append(
                {
                    "sample_id": record.get("sample_id", f"{dataset_id}:{record.get('object_id')}"),
                    "before": before,
                    "after": after,
                    "reason": "roi_exterior_is_unknown" if after is None else "restore_column_class",
                }
            )
        record["label"] = after
        record["dataset_id"] = dataset_id
        record["sample_id"] = f"{dataset_id}:{record.get('object_id')}"
        record["split"] = "joint"
        counts[after if after in ("wall", "column") else "unknown"] += 1
    migrated.update(
        {
            "schema_version": "semantic-object-labels-v14",
            "training_task": "wall_column_point_joint_v14",
            "train_labels": list(TRAIN_LABELS),
            "roi_outside_policy": "ignore",
            "dataset_id": dataset_id,
        }
    )
    return migrated, {"dataset_id": dataset_id, "counts": counts, "actions": actions}


def _render_supervision(
    path: Path, centers: np.ndarray, labels: np.ndarray, voxel_m: float
) -> None:
    padding = 12
    origin = np.min(centers[:, :2], axis=0) - padding * voxel_m
    shape_xy = np.ceil((np.max(centers[:, :2], axis=0) - origin) / voxel_m).astype(int) + padding
    maximum = 2400
    scale = min(1.0, maximum / max(int(shape_xy[0]), int(shape_xy[1]), 1))
    width, height = np.maximum(1, np.ceil(shape_xy * scale).astype(int))
    image = np.zeros((height, width, 3), np.uint8)
    pixels = np.floor((centers[:, :2] - origin) / voxel_m * scale).astype(int)
    valid = (
        (pixels[:, 0] >= 0) & (pixels[:, 0] < width)
        & (pixels[:, 1] >= 0) & (pixels[:, 1] < height)
    )
    colours = {
        UNKNOWN_LABEL: np.asarray([55, 55, 55], np.uint8),
        WALL_LABEL: np.asarray([245, 245, 245], np.uint8),
        COLUMN_LABEL: np.asarray([40, 210, 255], np.uint8),
    }
    for label in (UNKNOWN_LABEL, WALL_LABEL, COLUMN_LABEL):
        selected = valid & (labels == label)
        image[pixels[selected, 1], pixels[selected, 0]] = colours[label]
    cv2.imwrite(str(path), np.flipud(image))


def prepare_joint_supervision(cfg: dict, output_dir: str | Path) -> dict:
    """Create auditable point/voxel supervision without using old wall masks."""
    settings = cfg.get("semantic_v14", {})
    scenes = settings.get("scenes", [])
    if not scenes:
        raise ValueError("semantic_v14.scenes is empty")
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    voxel_m = float(settings.get("voxel_m", 0.05))
    z_bin_m = float(settings.get("height_bin_m", 0.10))
    manifest_scenes: list[dict] = []
    migration_rows: list[dict] = []
    total_counts = {"wall": 0, "column": 0, "unknown": 0}

    for scene in scenes:
        dataset_id = str(scene["dataset_id"])
        scene_dir = output_dir / dataset_id
        scene_dir.mkdir(parents=True, exist_ok=True)
        points = read_point_cloud(scene["point_cloud"])
        origin, voxel_keys, point_to_voxel, centers = _voxelise(points, voxel_m)
        normals, geometry_features = _normals_and_geometry(centers)
        summary = read_json(scene["height_summary"])
        metrics = summary.get("metrics", summary)
        floor_m = float(metrics.get("height_floor_m", np.min(centers[:, 2])))
        bin_count, vertical_span = _xy_vertical_statistics(
            centers, floor_m, float(settings.get("supervision_xy_grid_m", 0.10)), z_bin_m
        )
        vertical_normal = np.abs(normals[:, 2]) <= math.sin(
            math.radians(float(settings.get("wall_normal_vertical_tolerance_deg", 25.0)))
        )
        vertical = (
            vertical_normal
            & (bin_count >= int(settings.get("wall_min_height_bins", 4)))
            & (vertical_span >= float(settings.get("wall_min_vertical_span_m", 0.80)))
        )
        labels = np.full(len(centers), UNKNOWN_LABEL, np.int8)
        region_ids = np.full(len(centers), -1, np.int32)
        source_codes = np.zeros(len(centers), np.uint8)
        regions = read_json(scene["wall_regions"])
        for region_index, region in enumerate(regions.get("regions", [])):
            if region.get("status", "accepted") != "accepted":
                continue
            polygon = _accepted_polygon(region.get("polygon_ref"))
            if polygon is None:
                continue
            inside = _points_in_polygon(centers[:, :2], polygon)
            selected = inside & vertical
            free = labels == UNKNOWN_LABEL
            labels[selected & free] = WALL_LABEL
            region_ids[selected & free] = region_index
            source_codes[selected & free] = 1

        object_labels_source = read_json(scene["object_labels"])
        migrated, migration = _migrate_object_labels(object_labels_source, dataset_id)
        write_json(scene_dir / "object_labels_v14.json", migrated)
        graph = read_json(scene["building_object_graph"])
        for column_index, (_, polygon) in enumerate(_column_polygons(migrated, graph)):
            inside = _points_in_polygon(centers[:, :2], polygon.buffer(0.03)) & vertical
            conflict = inside & (labels == WALL_LABEL)
            labels[conflict] = UNKNOWN_LABEL
            region_ids[conflict] = -1
            source_codes[conflict] = 4
            selected = inside & ~conflict
            labels[selected] = COLUMN_LABEL
            region_ids[selected] = 100000 + column_index
            source_codes[selected] = 2

        raw_counts = np.bincount(point_to_voxel, minlength=len(centers)).astype(np.int32)
        weights = np.zeros(len(centers), np.float32)
        labelled = labels >= 0
        weights[labelled] = 1.0
        supervision_path = scene_dir / "point_supervision.npz"
        np.savez_compressed(
            supervision_path,
            dataset_id=np.asarray(dataset_id),
            origin=origin.astype(np.float64),
            voxel_m=np.asarray(voxel_m),
            voxel_keys=voxel_keys,
            coordinates=centers,
            normals=normals,
            geometry_features=geometry_features,
            labels=labels,
            weights=weights,
            region_ids=region_ids,
            source_codes=source_codes,
            raw_point_count=raw_counts,
            raw_point_to_voxel=point_to_voxel,
        )
        overlay_path = scene_dir / "supervision_overlay.png"
        _render_supervision(overlay_path, centers, labels, voxel_m)
        counts = {
            "wall": int(np.sum(labels == WALL_LABEL)),
            "column": int(np.sum(labels == COLUMN_LABEL)),
            "unknown": int(np.sum(labels == UNKNOWN_LABEL)),
        }
        for key in total_counts:
            total_counts[key] += counts[key]
        migration["supervision_counts"] = counts
        migration["conflict_count"] = int(np.sum(source_codes == 4))
        migration_rows.append(migration)
        manifest_scenes.append(
            {
                "dataset_id": dataset_id,
                "point_cloud": str(Path(scene["point_cloud"]).resolve()),
                "supervision": str(supervision_path.resolve()),
                "object_labels": str((scene_dir / "object_labels_v14.json").resolve()),
                "supervision_overlay": str(overlay_path.resolve()),
                "voxel_count": int(len(centers)),
                "counts": counts,
            }
        )

    migration_report = {
        "schema_version": "semantic-label-migration-v14",
        "roi_outside_policy": "ignore",
        "scenes": migration_rows,
        "total_counts": total_counts,
        "removed_roi_exterior_negative_count": int(
            sum(
                action.get("before") == "non_wall" and action.get("after") is None
                for scene in migration_rows
                for action in scene.get("actions", [])
            )
        ),
        "confirmed_column_object_count": int(
            sum(scene["counts"]["column"] for scene in migration_rows)
        ),
        "evaluation_note": "All maps participate jointly; these are supervision counts, not test metrics.",
    }
    write_json(output_dir / "label_migration_audit.json", migration_report)
    manifest = {
        "schema_version": V14_SCHEMA,
        "training_task": "wall_column_point_joint_v14",
        "train_labels": list(TRAIN_LABELS),
        "feature_backend": "pending",
        "roi_outside_policy": "ignore",
        "scenes": manifest_scenes,
        "migration_audit": str((output_dir / "label_migration_audit.json").resolve()),
        "evaluation_note": "No held-out split by user request; fit metrics are not generalisation metrics.",
    }
    write_json(output_dir / "semantic_point_manifest.json", manifest)
    return manifest


def _wsl_path(path: Path, distribution: str) -> str:
    resolved = path.resolve()
    drive = resolved.drive
    if len(drive) == 2 and drive[1] == ":":
        relative = resolved.as_posix()[3:]
        return f"/mnt/{drive[0].lower()}/{relative}"
    result = subprocess.run(
        ["wsl", "-d", distribution, "--", "wslpath", "-a", str(resolved)],
        check=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )
    return result.stdout.strip()


def extract_joint_features(
    manifest_path: str | Path,
    output_dir: str | Path,
    cfg: dict,
    geometry_only: bool = False,
) -> dict:
    """Run the frozen point encoder per scene; missing Sonata is a hard failure."""
    manifest_path = Path(manifest_path)
    manifest = read_json(manifest_path)
    if manifest.get("schema_version") != V14_SCHEMA:
        raise ValueError(f"Unsupported V14 manifest: {manifest.get('schema_version')}")
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    settings = cfg.get("semantic_v14", {})
    backend = "geometry" if geometry_only else str(settings.get("feature_backend", "sonata_ptv3"))
    feature_rows = []
    if backend != "geometry":
        distribution = str(settings.get("wsl_distribution", cfg.get("runtime", {}).get("wsl_distribution", "Ubuntu-20.04")))
        python_value = str(settings.get("sonata_python", "~/.venvs/lidar2outline-sonata/bin/python"))
        hf_endpoint = str(settings.get("huggingface_endpoint", "https://huggingface.co"))
        script = Path(__file__).resolve().parent.parent / "scripts" / "extract_sonata_point_features.py"
        if not script.is_file():
            raise ValueError(f"Sonata extraction script is missing: {script}")
        usage = output_dir.drive and Path(output_dir.drive + "\\")
        if usage:
            free = __import__("shutil").disk_usage(usage).free
            budget = int(float(settings.get("feature_cache_budget_gib", 12.0)) * (1024**3))
            if free < budget:
                raise ValueError(
                    f"Only {free / 1024**3:.1f} GiB is free; {budget / 1024**3:.1f} GiB is required for the feature cache"
                )
        for scene in manifest.get("scenes", []):
            dataset_id = scene["dataset_id"]
            destination = output_dir / f"{dataset_id}_sonata_features.npy"
            command = (
                f"HF_ENDPOINT={hf_endpoint} {python_value} {_wsl_path(script, distribution)} "
                f"--input {_wsl_path(Path(scene['supervision']), distribution)} "
                f"--output {_wsl_path(destination, distribution)} "
                f"--tile-size {float(settings.get('tile_size_m', 8.0))} "
                f"--halo {float(settings.get('tile_halo_m', 1.0))} "
                f"--max-voxels {int(settings.get('tile_max_voxels', 30000))}"
            )
            completed = subprocess.run(
                ["wsl", "-d", distribution, "--", "bash", "-lc", command],
                capture_output=True,
                encoding="utf-8",
                errors="replace",
            )
            if completed.returncode != 0:
                raise ValueError(
                    "Sonata feature extraction failed; no geometry fallback was used. "
                    + (completed.stderr.strip() or completed.stdout.strip())
                )
            array = np.load(destination, mmap_mode="r")
            with np.load(scene["supervision"], allow_pickle=False) as supervision:
                expected = len(supervision["coordinates"])
            if array.ndim != 2 or len(array) != expected or not np.all(np.isfinite(array)):
                raise ValueError(f"Invalid Sonata feature array for {dataset_id}: {array.shape}, expected {expected} rows")
            scene["sonata_features"] = str(destination.resolve())
            feature_rows.append({"dataset_id": dataset_id, "shape": list(array.shape), "path": str(destination.resolve())})
    manifest["feature_backend"] = backend
    manifest["sonata_features"] = feature_rows
    write_json(manifest_path, manifest)
    write_json(output_dir / "feature_extraction_report.json", {
        "backend": backend,
        "frozen": backend != "geometry",
        "scenes": feature_rows,
        "geometry_features_embedded_in_supervision": True,
    })
    return manifest


def _balanced_weights(labels: np.ndarray, datasets: np.ndarray, regions: np.ndarray) -> np.ndarray:
    result = np.zeros(len(labels), np.float32)
    valid = labels >= 0
    for label in np.unique(labels[valid]):
        label_mask = valid & (labels == label)
        dataset_values = np.unique(datasets[label_mask])
        for dataset in dataset_values:
            dataset_mask = label_mask & (datasets == dataset)
            region_values = np.unique(regions[dataset_mask])
            for region in region_values:
                mask = dataset_mask & (regions == region)
                result[mask] = 1.0 / max(len(dataset_values), 1) / max(len(region_values), 1) / max(int(np.sum(mask)), 1)
    if np.any(valid):
        result[valid] *= float(np.sum(valid)) / max(float(np.sum(result[valid])), 1e-12)
    return result


def train_v14_point_head(labels_path: str | Path, output_dir: str | Path, cfg: dict) -> dict:
    manifest = read_json(labels_path)
    if manifest.get("schema_version") != V14_SCHEMA:
        raise ValueError("V14 point training requires semantic-point-joint-v14")
    try:
        import torch
        from torch import nn
    except ImportError as exc:
        raise ValueError("PyTorch is required for V14 semantic training") from exc
    settings = cfg.get("semantic_v14", cfg)
    backend = str(manifest.get("feature_backend", "pending"))
    head_type = str(settings.get("head_type", "mlp"))
    if backend == "pending":
        raise ValueError("Run semantic-features before V14 semantic training")
    if backend not in ("geometry", "sonata_ptv3"):
        raise ValueError(f"Unsupported V14 feature backend: {backend}")
    cap = int(settings.get("max_supervised_voxels_per_region", 2048))
    arrays, labels, datasets, regions = [], [], [], []
    full_class_counts = np.zeros(2, np.int64)
    total_voxels = 0
    scene_sizes: list[tuple[dict, int]] = []
    for dataset_index, scene in enumerate(manifest.get("scenes", [])):
        with np.load(scene["supervision"], allow_pickle=False) as values:
            geometry = values["geometry_features"].astype(np.float32)
            y_scene = values["labels"].astype(np.int64)
            region_scene = values["region_ids"].astype(np.int64)
        total_voxels += int(np.sum(y_scene >= 0))
        for class_index in range(2):
            full_class_counts[class_index] += int(np.sum(y_scene == class_index))
        selected_groups = []
        for class_index in range(2):
            for region_id in np.unique(region_scene[y_scene == class_index]):
                group = np.flatnonzero((y_scene == class_index) & (region_scene == region_id))
                if len(group) > cap:
                    positions = np.linspace(0, len(group) - 1, cap, dtype=np.int64)
                    group = group[positions]
                selected_groups.append(group)
        selected = np.unique(np.concatenate(selected_groups)) if selected_groups else np.empty(0, np.int64)
        if backend == "sonata_ptv3":
            path = scene.get("sonata_features")
            if not path or not Path(path).is_file():
                raise ValueError(f"Missing Sonata features for {scene['dataset_id']}; no fallback was used")
            semantic = np.load(path, mmap_mode="r")
            if len(semantic) != len(geometry):
                raise ValueError(f"Feature/supervision coordinate mismatch for {scene['dataset_id']}")
            feature = np.column_stack(
                [np.asarray(semantic[selected], dtype=np.float32), geometry[selected]]
            )
        else:
            feature = geometry[selected]
        arrays.append(feature)
        labels.append(y_scene[selected])
        datasets.append(np.full(len(selected), dataset_index, np.int16))
        regions.append(region_scene[selected])
        scene_sizes.append((scene, len(y_scene)))
    x_raw = np.vstack(arrays).astype(np.float32)
    y_all = np.concatenate(labels)
    dataset_all = np.concatenate(datasets)
    region_all = np.concatenate(regions)
    if not np.any(y_all == WALL_LABEL) or not np.any(y_all == COLUMN_LABEL):
        raise ValueError("V14 training requires both wall and column supervision")
    mean = x_raw.mean(0)
    std = x_raw.std(0).clip(1e-6)
    x_all = (x_raw - mean) / std
    sample_weight = _balanced_weights(y_all, dataset_all, region_all)
    x = torch.from_numpy(x_all)
    y = torch.from_numpy(y_all)
    w = torch.from_numpy(sample_weight)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    x = x.to(device)
    y = y.to(device)
    w = w.to(device)
    hidden = int(settings.get("head_hidden_channels", 64))
    seeds = [int(value) for value in settings.get("training_seeds", [23, 47, 89])]
    maximum_epochs = int(settings.get("head_max_epochs", 300))
    patience = int(settings.get("head_patience", 35))
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    states, runs = [], []

    def make_model() -> Any:
        if head_type == "linear":
            return nn.Linear(x.shape[1], 2).to(device)
        if head_type != "mlp":
            raise ValueError(f"Unsupported V14 head type: {head_type}")
        return nn.Sequential(
            nn.Linear(x.shape[1], hidden),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden, 2),
        ).to(device)

    for seed in seeds:
        torch.manual_seed(seed)
        model = make_model()
        optimiser = torch.optim.AdamW(
            model.parameters(),
            lr=float(settings.get("head_learning_rate", 1e-3)),
            weight_decay=float(settings.get("head_weight_decay", 1e-4)),
        )
        criterion = nn.CrossEntropyLoss(reduction="none")
        best_loss, best_state, stale = float("inf"), None, 0
        epochs = 0
        for epoch in range(maximum_epochs):
            epochs = epoch + 1
            model.train()
            optimiser.zero_grad()
            loss = torch.sum(criterion(model(x), y) * w) / torch.sum(w)
            loss.backward()
            optimiser.step()
            model.eval()
            with torch.inference_mode():
                deterministic = float(torch.sum(criterion(model(x), y) * w) / torch.sum(w))
            if deterministic < best_loss - 1e-7:
                best_loss = deterministic
                best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                stale = 0
            else:
                stale += 1
            if stale >= patience:
                break
        assert best_state is not None
        states.append(best_state)
        checkpoint = output_dir / f"semantic_point_head_{head_type}_seed_{seed}.pt"
        torch.save(
            {
                "state_dict": best_state,
                "input_mean": torch.from_numpy(mean),
                "input_std": torch.from_numpy(std),
                "labels": list(TRAIN_LABELS),
                "backend": backend,
                "head_type": head_type,
                "hidden_channels": hidden,
            },
            checkpoint,
        )
        runs.append({"seed": seed, "epochs": epochs, "fit_loss": best_loss, "checkpoint": str(checkpoint.resolve())})

    batch = int(settings.get("inference_batch_size", 65536))
    fit_probability_sum = np.zeros((len(x_all), 2), np.float64)
    fit_votes = np.zeros((len(x_all), 2), np.uint8)
    trained_models = []
    for state in states:
        model = make_model()
        model.load_state_dict(state)
        model.eval()
        trained_models.append(model)
        chunks = []
        with torch.inference_mode():
            for begin in range(0, len(x_all), batch):
                value = torch.from_numpy(x_all[begin : begin + batch]).to(device)
                chunks.append(torch.softmax(model(value), dim=1).cpu().numpy())
        fit_probability = np.vstack(chunks)
        fit_probability_sum += fit_probability
        fit_votes[np.arange(len(fit_votes)), np.argmax(fit_probability, axis=1)] += 1
    fit_probability = (fit_probability_sum / len(states)).astype(np.float32)
    predicted = np.argmax(fit_probability, axis=1)
    truth = y_all
    fit_metrics = {"fit_accuracy": float(np.mean(predicted == truth))}
    for index, label in enumerate(TRAIN_LABELS):
        tp = int(np.sum((predicted == index) & (truth == index)))
        fp = int(np.sum((predicted == index) & (truth != index)))
        fn = int(np.sum((predicted != index) & (truth == index)))
        fit_metrics[f"fit_{label}_precision"] = tp / max(tp + fp, 1)
        fit_metrics[f"fit_{label}_recall"] = tp / max(tp + fn, 1)

    prediction_files = {}
    for scene, scene_size in scene_sizes:
        with np.load(scene["supervision"], allow_pickle=False) as values:
            geometry = values["geometry_features"].astype(np.float32)
            destination = output_dir / f"{scene['dataset_id']}_semantic_probabilities.npz"
            local_probability = np.zeros((scene_size, 2), np.float32)
            local_votes = np.zeros((scene_size, 2), np.uint8)
            semantic = (
                np.load(scene["sonata_features"], mmap_mode="r")
                if backend == "sonata_ptv3"
                else None
            )
            with torch.inference_mode():
                for begin in range(0, scene_size, batch):
                    end = min(scene_size, begin + batch)
                    raw = (
                        np.column_stack(
                            [np.asarray(semantic[begin:end], dtype=np.float32), geometry[begin:end]]
                        )
                        if semantic is not None
                        else geometry[begin:end]
                    )
                    value = torch.from_numpy((raw - mean) / std).to(device)
                    probability_sum = np.zeros((end - begin, 2), np.float64)
                    for model in trained_models:
                        seed_probability = torch.softmax(model(value), dim=1).cpu().numpy()
                        probability_sum += seed_probability
                        local_votes[
                            begin + np.arange(end - begin), np.argmax(seed_probability, axis=1)
                        ] += 1
                    local_probability[begin:end] = (
                        probability_sum / len(trained_models)
                    ).astype(np.float32)
            confidence = np.max(local_probability, axis=1)
            margin = np.abs(local_probability[:, 0] - local_probability[:, 1])
            accepted = (confidence >= float(settings.get("prediction_min_confidence", 0.80))) & (
                margin >= float(settings.get("prediction_min_margin", 0.20))
            ) & (np.max(local_votes, axis=1) >= int(settings.get("prediction_min_seed_votes", 2)))
            np.savez_compressed(
                destination,
                dataset_id=np.asarray(scene["dataset_id"]),
                origin=values["origin"],
                voxel_m=values["voxel_m"],
                voxel_keys=values["voxel_keys"],
                coordinates=values["coordinates"],
                probabilities=local_probability,
                votes=local_votes,
                accepted=accepted,
                labels=values["labels"],
            )
        prediction_files[scene["dataset_id"]] = str(destination.resolve())
    report = {
        "schema_version": "semantic-point-model-v14",
        "training_task": "wall_column_point_joint_v14",
        "backend": backend,
        "head_type": head_type,
        "train_labels": list(TRAIN_LABELS),
        "training_scope": "all reviewed maps jointly; no held-out split",
        "labelled_voxel_count": int(total_voxels),
        "fit_voxel_count": int(len(y_all)),
        "max_supervised_voxels_per_region": cap,
        "class_counts": {
            label: int(full_class_counts[index]) for index, label in enumerate(TRAIN_LABELS)
        },
        "runs": runs,
        "fit_metrics": fit_metrics,
        "point_prediction_files": prediction_files,
        "model_trained": True,
        "automatic_filtering_enabled": False,
        "candidate_augmentation_enabled": True,
        "training_device": str(device),
        "evaluation_note": "Fit metrics are not test or generalisation metrics.",
    }
    write_json(output_dir / "semantic_training_report.json", report)
    return report
