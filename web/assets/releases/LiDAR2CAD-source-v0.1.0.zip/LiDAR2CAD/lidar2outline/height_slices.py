from __future__ import annotations

import colorsys
import copy
import math
import shutil
from dataclasses import dataclass
from pathlib import Path

import cv2
import ezdxf
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Polygon, mapping
from shapely.ops import linemerge, unary_union

from .io import read_json, read_point_cloud, write_json, write_point_cloud
from .closed_layout import ClosedLayoutResult, optimize_closed_layout
from .post_fusion import (
    MorphologyRevectorResult,
    PostFusionResult,
    morphology_revectorize_wall_network,
    regularize_merged_wall_network,
)
from .raster_vectorize import (
    soft_consolidate_junctions,
    soft_regularize_oblique_lines,
    vectorize_structure_mask,
)
from .shared_wall import (
    SharedWallRecovery,
    materialize_architectural_graph,
    recover_shared_wall_model,
)
from .semantic_objects import run_semantic_object_stage
from .structure_graph import (
    export_architectural_outputs,
    optimize_architectural_plan,
    refresh_architectural_result_metrics,
)
from .transforms import transform_points


@dataclass
class HeightSlice:
    index: int
    z_min_m: float
    z_max_m: float
    point_count: int
    mask: np.ndarray
    heatmap: np.ndarray
    raw_lines_ref: list[LineString]
    calibrated_lines_ref: list[LineString]
    overlap_weight: float = 1.0
    scale_id: str = "thin_0.50m"
    window_id: str = ""


def _select_closure_backbone(
    slices: list[HeightSlice],
    cfg: dict,
    ceiling_m: float | None,
) -> tuple[list[LineString] | None, dict]:
    """Select the cleanest high wall slice instead of trusting a fixed index.

    The score rewards long, well-supported geometry and penalises fragmented
    slices.  A ceiling guard keeps residual roof returns from winning merely
    because they are dense.  ``closure_backbone_slice_priority`` is retained
    only as a deterministic tie breaker and compatibility fallback.
    """
    geometry_name = str(cfg.get("closure_backbone_geometry", "raw")).strip().lower()
    priority = [int(value) for value in cfg.get("closure_backbone_slice_priority", [])]
    priority_rank = {value: rank for rank, value in enumerate(priority)}
    long_threshold = float(cfg.get("closure_backbone_long_line_m", 1.0))
    min_z = float(cfg.get("closure_backbone_min_z_m", 1.20))
    ceiling_margin = float(cfg.get("closure_backbone_ceiling_margin_m", 0.20))

    candidates = []
    for value in slices:
        lines = (
            value.calibrated_lines_ref
            if geometry_name == "calibrated"
            else value.raw_lines_ref
        )
        lengths = np.asarray(
            [float(line.length) for line in lines if float(line.length) > 1e-6],
            dtype=float,
        )
        if not len(lengths):
            continue
        total_length = float(np.sum(lengths))
        long_fraction = float(np.sum(lengths[lengths >= long_threshold]) / total_length)
        fragmentation = float(len(lengths) / max(total_length, 1e-9))
        ceiling_safe = ceiling_m is None or value.z_max_m <= ceiling_m - ceiling_margin + 1e-9
        height_safe = value.z_min_m >= min_z - 1e-9
        candidates.append(
            {
                "slice": value,
                "lines": list(lines),
                "total_length_m": total_length,
                "long_line_fraction": long_fraction,
                "fragmentation_per_m": fragmentation,
                "point_count": int(value.point_count),
                "height_safe": bool(height_safe),
                "ceiling_safe": bool(ceiling_safe),
                "eligible": bool(height_safe and ceiling_safe),
            }
        )
    if not candidates:
        return None, {
            "selection": "none",
            "geometry": geometry_name,
            "candidates": [],
        }

    eligible = [item for item in candidates if item["eligible"]]
    if not eligible:
        eligible = candidates
    max_length = max(item["total_length_m"] for item in eligible)
    max_points = max(item["point_count"] for item in eligible)
    min_fragmentation = min(item["fragmentation_per_m"] for item in eligible)
    eligible_ids = {id(item) for item in eligible}
    weights = cfg.get("closure_backbone_score_weights", {})
    length_weight = float(weights.get("length", 0.30))
    point_weight = float(weights.get("points", 0.30))
    long_weight = float(weights.get("long_fraction", 0.25))
    continuity_weight = float(weights.get("continuity", 0.15))
    for item in candidates:
        if id(item) not in eligible_ids:
            item["score"] = -1.0
            continue
        length_score = item["total_length_m"] / max(max_length, 1e-9)
        point_score = item["point_count"] / max(max_points, 1)
        continuity_score = min_fragmentation / max(item["fragmentation_per_m"], 1e-9)
        tie_bonus = 1e-4 * max(
            0,
            len(priority) - priority_rank.get(item["slice"].index, len(priority)),
        )
        item["score"] = float(
            length_weight * length_score
            + point_weight * point_score
            + long_weight * item["long_line_fraction"]
            + continuity_weight * continuity_score
            + tie_bonus
        )

    selection_mode = str(cfg.get("closure_backbone_selection", "auto")).strip().lower()
    if selection_mode == "priority":
        selected = next(
            (
                item
                for index in priority
                for item in candidates
                if item["slice"].index == index
            ),
            max(eligible, key=lambda item: item["score"]),
        )
    else:
        selected = max(eligible, key=lambda item: item["score"])
    diagnostics = []
    for item in sorted(candidates, key=lambda row: row["slice"].index):
        diagnostics.append(
            {
                "slice_index": int(item["slice"].index),
                "z_min_m": float(item["slice"].z_min_m),
                "z_max_m": float(item["slice"].z_max_m),
                "point_count": int(item["point_count"]),
                "total_length_m": float(item["total_length_m"]),
                "long_line_fraction": float(item["long_line_fraction"]),
                "fragmentation_per_m": float(item["fragmentation_per_m"]),
                "height_safe": bool(item["height_safe"]),
                "ceiling_safe": bool(item["ceiling_safe"]),
                "eligible": bool(item["eligible"]),
                "score": float(item["score"]),
            }
        )
    selected_slice = selected["slice"]
    return selected["lines"], {
        "selection": selection_mode,
        "geometry": geometry_name,
        "selected_slice_index": int(selected_slice.index),
        "selected_window_id": str(selected_slice.window_id),
        "selected_score": float(selected["score"]),
        "candidates": diagnostics,
    }


def _angle_difference(first: np.ndarray, second: np.ndarray) -> float:
    return math.acos(float(np.clip(abs(first @ second), -1.0, 1.0)))


def _line_direction(line: LineString, reference: np.ndarray | None = None) -> np.ndarray:
    values = np.asarray(line.coords, dtype=float)[[0, -1]]
    direction = values[1] - values[0]
    direction /= max(float(np.linalg.norm(direction)), 1e-12)
    if reference is not None:
        if float(direction @ reference) < 0:
            direction *= -1
    elif direction[0] < 0 or (abs(direction[0]) < 1e-9 and direction[1] < 0):
        direction *= -1
    return direction


def _transform_line(line: LineString, transform: np.ndarray) -> LineString:
    xy = np.asarray(line.coords, dtype=float)
    xyz = np.column_stack([xy, np.zeros(len(xy))])
    return LineString(transform_points(xyz, transform)[:, :2])


def _fit_gravity_aligned_plane(
    points: np.ndarray, approximate_height_m: float, cfg: dict, seed: int
) -> dict | None:
    """Robustly fit z=ax+by+c while rejecting non-horizontal surfaces."""
    half_width = float(cfg.get("horizontal_plane_candidate_half_width_m", 0.14))
    candidates = points[
        np.all(np.isfinite(points), axis=1)
        & (np.abs(points[:, 2] - approximate_height_m) <= half_width)
    ]
    if len(candidates) < int(cfg.get("horizontal_plane_min_points", 500)):
        return None
    maximum = int(cfg.get("horizontal_plane_ransac_max_points", 30000))
    rng = np.random.default_rng(seed)
    sample = (
        candidates
        if len(candidates) <= maximum
        else candidates[rng.choice(len(candidates), maximum, replace=False)]
    )
    design = np.column_stack([sample[:, :2], np.ones(len(sample))])
    threshold = float(cfg.get("horizontal_plane_residual_m", 0.04))
    maximum_slope = math.tan(
        math.radians(float(cfg.get("horizontal_plane_max_tilt_deg", 5.0)))
    )
    best_mask: np.ndarray | None = None
    best_coefficients: np.ndarray | None = None
    for _ in range(int(cfg.get("horizontal_plane_ransac_iterations", 96))):
        indices = rng.choice(len(sample), 3, replace=False)
        local = design[indices]
        if abs(float(np.linalg.det(local))) < 1e-8:
            continue
        coefficients = np.linalg.solve(local, sample[indices, 2])
        if float(np.linalg.norm(coefficients[:2])) > maximum_slope:
            continue
        residuals = np.abs(sample[:, 2] - design @ coefficients)
        mask = residuals <= threshold
        if best_mask is None or int(np.count_nonzero(mask)) > int(np.count_nonzero(best_mask)):
            best_mask, best_coefficients = mask, coefficients
    if best_mask is None or best_coefficients is None:
        return None
    minimum = int(cfg.get("horizontal_plane_min_points", 500))
    if int(np.count_nonzero(best_mask)) < minimum:
        return None
    coefficients = np.linalg.lstsq(
        design[best_mask], sample[best_mask, 2], rcond=None
    )[0]
    if float(np.linalg.norm(coefficients[:2])) > maximum_slope:
        return None
    residuals = np.abs(sample[:, 2] - design @ coefficients)
    inliers = residuals <= threshold
    coverage_grid = float(cfg.get("horizontal_plane_coverage_grid_m", 0.25))
    coverage = len(
        np.unique(np.floor(sample[inliers, :2] / coverage_grid).astype(np.int64), axis=0)
    )
    if coverage < int(cfg.get("horizontal_plane_min_coverage_cells", 100)):
        return None
    normal = np.asarray([-coefficients[0], -coefficients[1], 1.0], dtype=float)
    normal /= float(np.linalg.norm(normal))
    return {
        "coefficients": coefficients.tolist(),
        "normal": normal.tolist(),
        "tilt_deg": float(math.degrees(math.acos(np.clip(normal[2], -1.0, 1.0)))),
        "rmse_m": float(np.sqrt(np.mean((sample[inliers, 2] - design[inliers] @ coefficients) ** 2))),
        "inlier_count": int(np.count_nonzero(inliers)),
        "candidate_count": int(len(candidates)),
        "coverage_cells": int(coverage),
        "residual_threshold_m": threshold,
    }


def _detect_floor_ceiling(
    points: np.ndarray,
    ceiling_hint_m: float | None,
    cfg: dict,
) -> tuple[float, float, dict]:
    finite = points[np.all(np.isfinite(points), axis=1)]
    z = finite[:, 2]
    bin_m = float(cfg.get("vertical_histogram_bin_m", 0.05))

    floor_values = z[(z >= -0.30) & (z <= 0.30)]
    if len(floor_values) >= 100:
        edges = np.arange(-0.30, 0.30 + bin_m, bin_m)
        counts, edges = np.histogram(floor_values, bins=edges)
        floor_m = float((edges[int(np.argmax(counts))] + edges[int(np.argmax(counts)) + 1]) / 2)
    else:
        floor_m = 0.0
    # The maps have already been levelled; remove a tiny histogram quantisation
    # offset rather than shifting every advertised height interval by 2.5 cm.
    if abs(floor_m) <= 0.08:
        floor_m = 0.0

    minimum_ceiling = floor_m + float(cfg.get("minimum_ceiling_height_m", 2.0))
    high = z[(z >= minimum_ceiling) & (z <= np.percentile(z, 99.7))]
    if not len(high):
        ceiling_m = ceiling_hint_m or float(cfg.get("fallback_ceiling_height_m", 3.0))
        return floor_m, float(ceiling_m), {"ceiling_detection": "fallback"}

    low_edge = math.floor(float(np.min(high)) / bin_m) * bin_m
    high_edge = math.ceil(float(np.max(high)) / bin_m) * bin_m
    edges = np.arange(low_edge, high_edge + bin_m * 1.5, bin_m)
    z_indices = np.clip(np.digitize(high, edges) - 1, 0, len(edges) - 2)
    high_points = finite[(z >= minimum_ceiling) & (z <= np.percentile(z, 99.7))]
    xy_grid_m = float(cfg.get("volume_xy_grid_m", 0.10))
    xy = np.floor(high_points[:, :2] / xy_grid_m).astype(np.int64)
    occupied = np.unique(np.column_stack([z_indices, xy]), axis=0)
    coverage = np.bincount(occupied[:, 0], minlength=len(edges) - 1)
    point_counts = np.bincount(z_indices, minlength=len(edges) - 1)
    score = coverage.astype(float) * np.sqrt(np.maximum(point_counts, 1))
    if ceiling_hint_m is not None:
        centers = (edges[:-1] + edges[1:]) / 2
        allowed = np.abs(centers - ceiling_hint_m) <= float(
            cfg.get("ceiling_hint_search_m", 0.45)
        )
        score[~allowed] = 0
    peak = int(np.argmax(score))
    detected = float((edges[peak] + edges[peak + 1]) / 2)
    ceiling_m = detected if score[peak] > 0 else float(ceiling_hint_m or detected)
    floor_plane = _fit_gravity_aligned_plane(points, floor_m, cfg, 2301)
    ceiling_plane = _fit_gravity_aligned_plane(points, ceiling_m, cfg, 2302)
    metrics = {
        "ceiling_detection": "xy_volume_coverage_peak",
        "ceiling_peak_xy_cells": int(coverage[peak]),
        "ceiling_peak_points": int(point_counts[peak]),
    }
    if floor_plane is not None:
        metrics["floor_plane"] = floor_plane
    if ceiling_plane is not None:
        metrics["ceiling_plane"] = ceiling_plane
    return floor_m, ceiling_m, metrics


def _filter_interior_volume_detailed(
    points: np.ndarray,
    floor_m: float,
    ceiling_m: float,
    cfg: dict,
) -> tuple[np.ndarray, dict, np.ndarray]:
    floor_margin = float(cfg.get("floor_margin_m", 0.12))
    ceiling_margin = float(cfg.get("ceiling_margin_m", 0.12))
    finite = np.all(np.isfinite(points), axis=1)
    floor_coefficients = cfg.get("_floor_plane_coefficients")
    ceiling_coefficients = cfg.get("_ceiling_plane_coefficients")
    floor_surface = (
        points[:, :2] @ np.asarray(floor_coefficients[:2]) + floor_coefficients[2]
        if floor_coefficients is not None
        else np.full(len(points), floor_m)
    )
    ceiling_surface = (
        points[:, :2] @ np.asarray(ceiling_coefficients[:2]) + ceiling_coefficients[2]
        if ceiling_coefficients is not None
        else np.full(len(points), ceiling_m)
    )
    floor_boundary = finite & (points[:, 2] < floor_surface + floor_margin)
    ceiling_boundary = finite & (points[:, 2] > ceiling_surface - ceiling_margin)
    inside_mask = finite & ~floor_boundary & ~ceiling_boundary
    inside = points[inside_mask]
    boundary_removed = int(len(points) - len(inside))
    reasons = np.full(len(points), 5, dtype=np.uint8)
    reasons[finite] = 0
    reasons[floor_boundary] = 1
    reasons[ceiling_boundary] = 2
    if not len(inside):
        return inside, {
            "boundary_removed_points": boundary_removed,
            "floor_boundary_removed_points": int(np.count_nonzero(floor_boundary)),
            "ceiling_boundary_removed_points": int(np.count_nonzero(ceiling_boundary)),
            "residual_slab_removed_points": 0,
            "sparse_volume_removed_points": 0,
        }, reasons

    xy_grid_m = float(cfg.get("volume_xy_grid_m", 0.10))
    z_grid_m = float(cfg.get("volume_z_grid_m", 0.10))
    xy = np.floor(inside[:, :2] / xy_grid_m).astype(np.int64)
    zb = np.floor((inside[:, 2] - floor_m) / z_grid_m).astype(np.int64)
    unique_xyz = np.unique(np.column_stack([xy, zb]), axis=0)
    xy_cells, vertical_counts = np.unique(unique_xyz[:, :2], axis=0, return_counts=True)
    vertical_support = {
        (int(cell[0]), int(cell[1])): int(count)
        for cell, count in zip(xy_cells, vertical_counts)
    }
    support = np.asarray(
        [vertical_support[(int(cell[0]), int(cell[1]))] for cell in xy], dtype=int
    )
    unique_xy, xy_point_counts = np.unique(xy, axis=0, return_counts=True)
    point_count_by_xy = {
        (int(cell[0]), int(cell[1])): int(count)
        for cell, count in zip(unique_xy, xy_point_counts)
    }
    point_support = np.asarray(
        [point_count_by_xy[(int(cell[0]), int(cell[1]))] for cell in xy], dtype=int
    )

    guard_m = float(cfg.get("horizontal_residual_guard_m", 0.35))
    minimum_vertical_bins = int(cfg.get("horizontal_residual_min_vertical_bins", 3))
    inside_floor_surface = floor_surface[inside_mask]
    inside_ceiling_surface = ceiling_surface[inside_mask]
    near_ceiling = inside[:, 2] >= inside_ceiling_surface - guard_m
    near_floor = inside[:, 2] <= inside_floor_surface + guard_m

    # A roof/floor remnant occupies many XY voxels in only one or two Z voxels.
    # Real walls and columns retain a vertical stack, so the volume integral
    # (number of occupied Z voxels per XY cell) cleanly separates the two.
    slab_residual = (near_ceiling | near_floor) & (support < minimum_vertical_bins)
    sparse_volume = (
        (support < int(cfg.get("volume_min_vertical_bins", 2)))
        | (point_support < int(cfg.get("volume_min_points_per_xy_cell", 3)))
    )

    minimum_z_bin = int(np.min(unique_xyz[:, 2]))
    maximum_z_bin = int(np.max(unique_xyz[:, 2]))
    z_occupancy = np.bincount(
        unique_xyz[:, 2] - minimum_z_bin,
        minlength=maximum_z_bin - minimum_z_bin + 1,
    )
    interior_bins = np.arange(minimum_z_bin, maximum_z_bin + 1)
    interior_centers = floor_m + (interior_bins + 0.5) * z_grid_m
    reference = z_occupancy[
        (interior_centers >= floor_m + guard_m)
        & (interior_centers <= ceiling_m - guard_m)
        & (z_occupancy > 0)
    ]
    reference_level = float(np.median(reference)) if len(reference) else 0.0
    broad_threshold = max(
        float(cfg.get("horizontal_residual_min_xy_cells", 120)),
        reference_level * float(cfg.get("horizontal_residual_density_ratio", 2.5)),
    )
    broad_bins = set(
        (
            np.flatnonzero(
            (z_occupancy >= broad_threshold)
            & ((interior_centers >= ceiling_m - guard_m) | (interior_centers <= floor_m + guard_m))
            )
            + minimum_z_bin
        ).tolist()
    )
    if broad_bins:
        broad_residual = np.asarray([int(value) in broad_bins for value in zb]) & (
            support < minimum_vertical_bins + 1
        )
        slab_residual |= broad_residual
    rejected = slab_residual | sparse_volume
    clean = inside[~rejected]
    inside_indices = np.flatnonzero(inside_mask)
    reasons[inside_indices[slab_residual]] = 3
    reasons[inside_indices[sparse_volume & ~slab_residual]] = 4
    return clean, {
        "boundary_removed_points": boundary_removed,
        "floor_boundary_removed_points": int(np.count_nonzero(floor_boundary)),
        "ceiling_boundary_removed_points": int(np.count_nonzero(ceiling_boundary)),
        "residual_slab_removed_points": int(np.count_nonzero(slab_residual)),
        "sparse_volume_removed_points": int(np.count_nonzero(sparse_volume & ~slab_residual)),
        "clean_interior_point_count": int(len(clean)),
        "volume_xy_grid_m": xy_grid_m,
        "volume_z_grid_m": z_grid_m,
        "horizontal_spike_bin_count": int(len(broad_bins)),
    }, reasons


def _filter_interior_volume(
    points: np.ndarray,
    floor_m: float,
    ceiling_m: float,
    cfg: dict,
) -> tuple[np.ndarray, dict]:
    clean, metrics, _ = _filter_interior_volume_detailed(
        points, floor_m, ceiling_m, cfg
    )
    return clean, metrics


def _height_density_profile(
    points: np.ndarray,
    floor_m: float,
    ceiling_m: float,
    cfg: dict,
) -> dict:
    bin_m = float(cfg.get("vertical_histogram_bin_m", 0.05))
    xy_grid_m = float(cfg.get("volume_xy_grid_m", 0.10))
    edges = np.arange(floor_m, ceiling_m + bin_m * 1.5, bin_m)
    finite = points[
        np.all(np.isfinite(points), axis=1)
        & (points[:, 2] >= floor_m)
        & (points[:, 2] <= ceiling_m)
    ]
    counts, edges = np.histogram(finite[:, 2], bins=edges)
    z_indices = np.clip(np.digitize(finite[:, 2], edges) - 1, 0, len(edges) - 2)
    xy = np.floor(finite[:, :2] / xy_grid_m).astype(np.int64)
    occupied = np.unique(np.column_stack([z_indices, xy]), axis=0)
    coverage = np.bincount(occupied[:, 0], minlength=len(edges) - 1)
    return {
        "bin_m": bin_m,
        "xy_grid_m": xy_grid_m,
        "bins": [
            {
                "z_min_m": float(edges[index]),
                "z_max_m": float(edges[index + 1]),
                "point_count": int(counts[index]),
                "occupied_xy_cells": int(coverage[index]),
            }
            for index in range(len(counts))
        ],
    }


def _common_raster(points: np.ndarray, grid_m: float, padding_m: float) -> tuple[np.ndarray, tuple[int, int]]:
    lower = np.percentile(points[:, :2], 0.05, axis=0)
    upper = np.percentile(points[:, :2], 99.95, axis=0)
    origin = np.floor((lower - padding_m) / grid_m) * grid_m
    end = np.ceil((upper + padding_m) / grid_m) * grid_m
    width, height = np.ceil((end - origin) / grid_m).astype(int) + 1
    return origin, (int(height), int(width))


def _slice_projection(
    points: np.ndarray,
    z_min_m: float,
    z_max_m: float,
    origin: np.ndarray,
    shape: tuple[int, int],
    grid_m: float,
    cfg: dict,
) -> tuple[np.ndarray, np.ndarray, int]:
    band = points[(points[:, 2] >= z_min_m) & (points[:, 2] < z_max_m)]
    density = np.zeros(shape, np.uint16)
    vertical = np.zeros(shape, np.uint8)
    if not len(band):
        return density.astype(np.uint8), density.astype(np.float32), 0
    ij = np.floor((band[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < shape[1])
        & (ij[:, 1] < shape[0])
    )
    ij, band = ij[valid], band[valid]
    np.add.at(density, (ij[:, 1], ij[:, 0]), 1)
    height_bin_m = float(cfg.get("slice_height_bin_m", 0.10))
    zb = np.floor((band[:, 2] - z_min_m) / height_bin_m).astype(np.int64)
    unique = np.unique(np.column_stack([ij, zb]), axis=0)
    cells, counts = np.unique(unique[:, :2], axis=0, return_counts=True)
    vertical[cells[:, 1], cells[:, 0]] = np.minimum(counts, 255).astype(np.uint8)
    minimum_points = int(cfg.get("slice_min_points_per_cell", 2))
    minimum_bins = int(cfg.get("slice_min_height_bins", 2))
    strong_points = int(cfg.get("slice_strong_points_per_cell", 7))
    mask = np.where(
        ((density >= minimum_points) & (vertical >= minimum_bins)) | (density >= strong_points),
        255,
        0,
    ).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    clean = np.zeros_like(mask)
    minimum_cells = int(cfg.get("slice_min_component_cells", 6))
    for component in range(1, count):
        if int(stats[component, cv2.CC_STAT_AREA]) >= minimum_cells:
            clean[labels == component] = 255
    nonzero = density[density > 0]
    scale = float(np.quantile(nonzero, 0.95)) if len(nonzero) else 1.0
    density_heat = np.log1p(density.astype(np.float32)) / max(math.log1p(scale), 1e-6)
    vertical_heat = vertical.astype(np.float32) / max(1.0, (z_max_m - z_min_m) / height_bin_m)
    heat = np.clip(0.65 * density_heat + 0.35 * vertical_heat, 0.0, 1.0)
    return clean, heat, int(len(band))


def _vectorize_slice_untiled(
    mask: np.ndarray,
    heatmap: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float,
    cfg: dict,
) -> list[LineString]:
    from .vectorize import _cluster_line_endpoints, _snap_line_junctions

    result = vectorize_structure_mask(mask, origin, grid_m, main_angle, cfg, heatmap)
    lines = _cluster_line_endpoints(
        result.lines, float(cfg.get("vector_endpoint_cluster_m", 0.25))
    )
    lines = _snap_line_junctions(
        lines, float(cfg.get("vector_junction_tolerance_m", 0.30))
    )
    lines = _cluster_line_endpoints(
        lines, float(cfg.get("vector_endpoint_cluster_m", 0.25))
    )
    oblique = soft_regularize_oblique_lines(
        lines,
        result.cleaned_mask,
        result.skeleton,
        heatmap,
        origin,
        grid_m,
        main_angle,
        cfg,
    )
    lines = _cluster_line_endpoints(
        oblique.lines, float(cfg.get("vector_endpoint_cluster_m", 0.25))
    )
    lines = _snap_line_junctions(
        lines, float(cfg.get("vector_junction_tolerance_m", 0.30))
    )
    lines = _cluster_line_endpoints(
        lines, float(cfg.get("vector_endpoint_cluster_m", 0.25))
    )
    junctions = soft_consolidate_junctions(
        lines, result.cleaned_mask, heatmap, origin, grid_m, main_angle, cfg
    )
    return junctions.lines


def _raster_tile_bounds(
    shape: tuple[int, int], tile_cells: int, overlap_cells: int
) -> list[tuple[int, int, int, int, int, int, int, int]]:
    """Return expanded and non-overlapping core bounds for raster tiles."""

    height, width = int(shape[0]), int(shape[1])
    tile_cells = max(32, int(tile_cells))
    overlap_cells = max(0, min(int(overlap_cells), tile_cells // 2))
    result = []
    for core_y0 in range(0, height, tile_cells):
        core_y1 = min(height, core_y0 + tile_cells)
        for core_x0 in range(0, width, tile_cells):
            core_x1 = min(width, core_x0 + tile_cells)
            result.append(
                (
                    max(0, core_y0 - overlap_cells),
                    min(height, core_y1 + overlap_cells),
                    max(0, core_x0 - overlap_cells),
                    min(width, core_x1 + overlap_cells),
                    core_y0,
                    core_y1,
                    core_x0,
                    core_x1,
                )
            )
    return result


def _vectorize_slice(
    mask: np.ndarray,
    heatmap: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float,
    cfg: dict,
) -> list[LineString]:
    """Vectorize one height raster, optionally in overlapping spatial tiles.

    Full-floor Hough/skeleton candidate searches become prohibitively slow on
    200+ metre maps.  Expanded tiles preserve local context, while disjoint
    core ownership prevents overlap from duplicating geometry.  Coordinates
    stay in the original metric reference frame and are reconciled once after
    all tiles have been processed.
    """

    tile_size_m = float(cfg.get("vector_tile_size_m", 0.0))
    if tile_size_m <= 0.0:
        return _vectorize_slice_untiled(
            mask, heatmap, origin, grid_m, main_angle, cfg
        )
    tile_cells = max(32, int(round(tile_size_m / grid_m)))
    if mask.shape[0] <= tile_cells and mask.shape[1] <= tile_cells:
        return _vectorize_slice_untiled(
            mask, heatmap, origin, grid_m, main_angle, cfg
        )
    overlap_cells = int(
        round(float(cfg.get("vector_tile_overlap_m", 3.0)) / grid_m)
    )
    minimum_pixels = max(2, int(cfg.get("vector_tile_min_pixels", 8)))
    local_cfg = dict(cfg)
    local_cfg["vector_tile_size_m"] = 0.0
    collected: list[LineString] = []
    for (
        y0,
        y1,
        x0,
        x1,
        core_y0,
        core_y1,
        core_x0,
        core_x1,
    ) in _raster_tile_bounds(mask.shape, tile_cells, overlap_cells):
        local_mask = mask[y0:y1, x0:x1]
        if int(np.count_nonzero(local_mask)) < minimum_pixels:
            continue
        local_heatmap = heatmap[y0:y1, x0:x1]
        local_origin = np.asarray(origin, dtype=float) + np.asarray(
            [x0 * grid_m, y0 * grid_m], dtype=float
        )
        lines = _vectorize_slice_untiled(
            local_mask,
            local_heatmap,
            local_origin,
            grid_m,
            main_angle,
            local_cfg,
        )
        for line in lines:
            midpoint = np.asarray(line.interpolate(0.5, normalized=True).coords[0])
            cell = (midpoint - np.asarray(origin, dtype=float)) / grid_m
            owns_x = core_x0 <= cell[0] < core_x1 or (
                core_x1 == mask.shape[1] and cell[0] <= core_x1
            )
            owns_y = core_y0 <= cell[1] < core_y1 or (
                core_y1 == mask.shape[0] and cell[1] <= core_y1
            )
            if owns_x and owns_y:
                collected.append(line)
    if not collected:
        return []
    from .vectorize import _cluster_line_endpoints, _snap_line_junctions

    lines = _cluster_line_endpoints(
        collected, float(cfg.get("vector_endpoint_cluster_m", 0.25))
    )
    lines = _snap_line_junctions(
        lines, float(cfg.get("vector_junction_tolerance_m", 0.30))
    )
    return _cluster_line_endpoints(
        lines, float(cfg.get("vector_endpoint_cluster_m", 0.25))
    )


def _height_window_starts(
    floor_m: float, ceiling_m: float, width_m: float, step_m: float
) -> list[float]:
    starts: list[float] = []
    value = float(floor_m)
    while value + width_m <= ceiling_m + 1e-6:
        starts.append(value)
        value += step_m
    tail_start = max(float(floor_m), float(ceiling_m) - width_m)
    if not starts or tail_start - starts[-1] > 1e-6:
        starts.append(tail_start)
    return starts


def _build_height_windows(
    points: np.ndarray,
    floor_m: float,
    ceiling_m: float,
    width_m: float,
    step_m: float,
    scale_id: str,
    origin: np.ndarray,
    shape: tuple[int, int],
    grid_m: float,
    main_angle: float,
    projection_cfg: dict,
    vector_cfg: dict,
) -> list[HeightSlice]:
    starts = _height_window_starts(floor_m, ceiling_m, width_m, step_m)
    base_bin_m = float(projection_cfg.get("slice_height_bin_m", 0.10))
    base_centers = np.arange(floor_m + base_bin_m / 2, ceiling_m, base_bin_m)
    base_coverage = np.asarray(
        [
            sum(start <= center < start + width_m for start in starts)
            for center in base_centers
        ],
        dtype=float,
    )
    result: list[HeightSlice] = []
    for index, start in enumerate(starts):
        end = start + width_m
        mask, heatmap, point_count = _slice_projection(
            points, start, end, origin, shape, grid_m, projection_cfg
        )
        lines = _vectorize_slice(
            mask, heatmap, origin, grid_m, main_angle, vector_cfg
        )
        covered_bins = (base_centers >= start) & (base_centers < end)
        overlap_weight = (
            float(np.mean(1.0 / np.maximum(base_coverage[covered_bins], 1.0)))
            if np.any(covered_bins)
            else 1.0
        )
        result.append(
            HeightSlice(
                index=index,
                z_min_m=float(start),
                z_max_m=float(end),
                point_count=point_count,
                mask=mask,
                heatmap=heatmap,
                raw_lines_ref=lines,
                calibrated_lines_ref=[],
                overlap_weight=overlap_weight,
                scale_id=scale_id,
                window_id=f"{scale_id}:{start:.3f}:{end:.3f}",
            )
        )
    return result


def _weighted_median(values: np.ndarray, weights: np.ndarray) -> float:
    order = np.argsort(values)
    values, weights = values[order], weights[order]
    cumulative = np.cumsum(weights)
    return float(values[int(np.searchsorted(cumulative, cumulative[-1] / 2.0))])


def _update_group(group: dict, cfg: dict) -> None:
    reference = group.get("direction")
    if reference is None:
        reference = _line_direction(group["entries"][0]["line"])
    base_weights = np.asarray(
        [
            max(0.2, entry["line"].length)
            * max(0.25, entry["evidence"])
            * float(entry.get("overlap_weight", 1.0))
            for entry in group["entries"]
        ]
    )
    weights = base_weights.copy()
    direction = np.asarray(reference, dtype=float)
    offset = 0.0
    for _ in range(int(cfg.get("calibration_iterations", 4))):
        directions = np.asarray(
            [_line_direction(entry["line"], direction) for entry in group["entries"]]
        )
        direction = np.sum(directions * weights[:, None], axis=0)
        direction /= max(float(np.linalg.norm(direction)), 1e-12)
        normal = np.asarray([-direction[1], direction[0]])
        offsets = np.asarray(
            [float(np.mean(np.asarray(entry["line"].coords), axis=0) @ normal) for entry in group["entries"]]
        )
        offset = _weighted_median(offsets, weights)
        angular = np.asarray([_angle_difference(value, direction) for value in directions])
        residual = np.abs(offsets - offset)
        offset_scale = float(cfg.get("calibration_offset_tolerance_m", 0.25))
        angle_scale = math.radians(float(cfg.get("calibration_angle_tolerance_deg", 5.0)))
        weights = base_weights / (
            1.0 + (residual / offset_scale) ** 2 + (angular / max(angle_scale, 1e-6)) ** 2
        )
    group["direction"] = direction
    group["normal"] = np.asarray([-direction[1], direction[0]])
    group["offset"] = offset
    # Cache axis projections used by assignment and agglomeration.  Previously
    # these arrays were rebuilt inside every entry/group comparison, making the
    # calibration stage effectively super-quadratic on large floor plates.
    intervals = []
    slice_profiles: dict[int, list[tuple[tuple[float, float], float]]] = {}
    midpoint_offsets = []
    for entry in group["entries"]:
        coordinates = entry.get("_coordinates")
        if coordinates is None:
            coordinates = np.asarray(entry["line"].coords, dtype=float)[[0, -1]]
        midpoint = entry.get("_midpoint")
        if midpoint is None:
            midpoint = np.mean(coordinates, axis=0)
        interval = tuple(sorted((coordinates @ direction).tolist()))
        local_offset = float(midpoint @ group["normal"])
        intervals.append(interval)
        midpoint_offsets.append(local_offset)
        slice_profiles.setdefault(int(entry["slice"]), []).append(
            (interval, local_offset)
        )
    group["_entry_intervals"] = intervals
    group["_interval"] = (
        float(min(value[0] for value in intervals)),
        float(max(value[1] for value in intervals)),
    )
    group["_slice_profiles"] = slice_profiles
    group["_midpoint_offsets"] = np.asarray(midpoint_offsets, dtype=float)


def _interval_gap(first: tuple[float, float], second: tuple[float, float]) -> float:
    return max(0.0, max(first[0], second[0]) - min(first[1], second[1]))


def _group_interval(group: dict, direction: np.ndarray | None = None) -> tuple[float, float]:
    if "_interval" in group and (
        direction is None
        or np.allclose(np.asarray(direction), np.asarray(group["direction"]), atol=1e-12)
    ):
        return group["_interval"]
    direction = group["direction"] if direction is None else direction
    values = []
    for entry in group["entries"]:
        values.extend(
            (np.asarray(entry["line"].coords, dtype=float)[[0, -1]] @ direction).tolist()
        )
    return float(min(values)), float(max(values))


def _same_slice_parallel_conflict(entry: dict, group: dict, cfg: dict) -> bool:
    direction = group["direction"]
    normal = np.asarray([-direction[1], direction[0]])
    coordinates = np.asarray(entry["line"].coords, dtype=float)[[0, -1]]
    interval = tuple(sorted((coordinates @ direction).tolist()))
    offset = float(np.mean(coordinates, axis=0) @ normal)
    separation_guard = float(cfg.get("calibration_same_slice_parallel_guard_m", 0.08))
    overlap_guard = float(cfg.get("calibration_same_slice_overlap_guard_m", 0.60))
    profiles = group.get("_slice_profiles", {}).get(int(entry["slice"]))
    if profiles is not None:
        for existing_interval, existing_offset in profiles:
            overlap = min(interval[1], existing_interval[1]) - max(
                interval[0], existing_interval[0]
            )
            if overlap >= overlap_guard and abs(offset - existing_offset) > separation_guard:
                return True
        return False
    for existing in group["entries"]:
        if existing["slice"] != entry["slice"]:
            continue
        existing_coordinates = np.asarray(existing["line"].coords, dtype=float)[[0, -1]]
        existing_interval = tuple(sorted((existing_coordinates @ direction).tolist()))
        overlap = min(interval[1], existing_interval[1]) - max(
            interval[0], existing_interval[0]
        )
        existing_offset = float(np.mean(existing_coordinates, axis=0) @ normal)
        if overlap >= overlap_guard and abs(offset - existing_offset) > separation_guard:
            return True
    return False


def _entry_group_cost(entry: dict, group: dict, cfg: dict) -> float | None:
    if _same_slice_parallel_conflict(entry, group, cfg):
        return None
    direction = group["direction"]
    raw_direction = entry.get("_direction")
    if raw_direction is None:
        raw_direction = _line_direction(entry["line"], direction)
    angle = _angle_difference(raw_direction, direction)
    angle_tolerance = math.radians(float(cfg.get("calibration_angle_tolerance_deg", 5.0)))
    if angle > angle_tolerance:
        return None
    coordinates = entry.get("_coordinates")
    if coordinates is None:
        coordinates = np.asarray(entry["line"].coords, dtype=float)[[0, -1]]
    midpoint = entry.get("_midpoint")
    if midpoint is None:
        midpoint = np.mean(coordinates, axis=0)
    offset_error = abs(float(midpoint @ group["normal"]) - float(group["offset"]))
    offset_tolerance = float(cfg.get("calibration_offset_tolerance_m", 0.25))
    if offset_error > offset_tolerance:
        return None
    interval = tuple(sorted((coordinates @ direction).tolist()))
    gap = _interval_gap(interval, _group_interval(group, direction))
    gap_tolerance = float(cfg.get("calibration_interval_gap_m", 0.60))
    if gap > gap_tolerance:
        return None
    return (
        angle / max(angle_tolerance, 1e-9)
        + offset_error / max(offset_tolerance, 1e-9)
        + gap / max(gap_tolerance, 1e-9)
    )


def _merge_wall_groups(groups: list[dict], cfg: dict) -> tuple[list[dict], int]:
    """Agglomerate fragmented wall hypotheses with complete-link safeguards."""
    initial_count = len(groups)
    angle_tolerance = math.radians(float(cfg.get("calibration_merge_angle_deg", 3.0)))
    offset_tolerance = float(cfg.get("calibration_merge_offset_m", 0.18))
    gap_tolerance = float(cfg.get("calibration_merge_gap_m", 1.00))
    same_slice_guard = float(cfg.get("calibration_same_slice_parallel_guard_m", 0.08))
    maximum_rounds = int(cfg.get("calibration_merge_rounds", 5))
    for _ in range(maximum_rounds):
        candidates: list[tuple[float, int, int]] = []
        for first in range(len(groups)):
            first_group = groups[first]
            direction = first_group["direction"]
            normal = np.asarray([-direction[1], direction[0]])
            first_interval = _group_interval(first_group, direction)
            first_offsets = first_group.get("_midpoint_offsets")
            if first_offsets is None:
                first_offsets = np.asarray(
                    [
                        float(np.mean(np.asarray(value["line"].coords), axis=0) @ normal)
                        for value in first_group["entries"]
                    ]
                )
            first_offset = float(np.median(first_offsets))
            for second in range(first + 1, len(groups)):
                second_group = groups[second]
                angle = _angle_difference(direction, second_group["direction"])
                if angle > angle_tolerance:
                    continue
                if np.allclose(direction, second_group["direction"], atol=1e-12):
                    second_offset = float(np.median(second_group["_midpoint_offsets"]))
                else:
                    second_midpoints = np.asarray(
                        [np.mean(np.asarray(value["line"].coords), axis=0) for value in second_group["entries"]]
                    )
                    second_offset = float(np.median(second_midpoints @ normal))
                offset_error = abs(second_offset - first_offset)
                if offset_error > offset_tolerance:
                    continue
                second_interval = _group_interval(second_group, direction)
                gap = _interval_gap(first_interval, second_interval)
                if gap > gap_tolerance:
                    continue
                shared_slices = {
                    value["slice"] for value in first_group["entries"]
                } & {value["slice"] for value in second_group["entries"]}
                # Parallel faces that coexist and overlap within one slice are
                # different physical edges, even if their offsets are close.
                conflict = False
                if shared_slices and offset_error > same_slice_guard:
                    for slice_index in shared_slices:
                        first_entries = [
                            value for value in first_group["entries"] if value["slice"] == slice_index
                        ]
                        second_entries = [
                            value for value in second_group["entries"] if value["slice"] == slice_index
                        ]
                        for first_entry in first_entries:
                            first_values = tuple(
                                sorted(
                                    (
                                        np.asarray(first_entry["line"].coords)[[0, -1]] @ direction
                                    ).tolist()
                                )
                            )
                            for second_entry in second_entries:
                                second_values = tuple(
                                    sorted(
                                        (
                                            np.asarray(second_entry["line"].coords)[[0, -1]]
                                            @ direction
                                        ).tolist()
                                    )
                                )
                                overlap = min(first_values[1], second_values[1]) - max(
                                    first_values[0], second_values[0]
                                )
                                if overlap >= float(
                                    cfg.get("calibration_same_slice_overlap_guard_m", 0.60)
                                ):
                                    conflict = True
                                    break
                            if conflict:
                                break
                        if conflict:
                            break
                if conflict:
                    continue
                cost = (
                    angle / max(angle_tolerance, 1e-9)
                    + offset_error / max(offset_tolerance, 1e-9)
                    + gap / max(gap_tolerance, 1e-9)
                )
                candidates.append((cost, first, second))
        if not candidates:
            break
        used: set[int] = set()
        merged: list[dict] = []
        for _, first, second in sorted(candidates):
            if first in used or second in used:
                continue
            trial = {"entries": groups[first]["entries"] + groups[second]["entries"]}
            _update_group(trial, cfg)
            direction, normal, offset = trial["direction"], trial["normal"], trial["offset"]
            angular = np.asarray(
                [_angle_difference(_line_direction(value["line"]), direction) for value in trial["entries"]]
            )
            residual = np.asarray(
                [
                    abs(
                        float(np.mean(np.asarray(value["line"].coords), axis=0) @ normal)
                        - offset
                    )
                    for value in trial["entries"]
                ]
            )
            if (
                float(np.quantile(angular, 0.90)) > angle_tolerance * 1.20
                or float(np.quantile(residual, 0.90)) > offset_tolerance * 1.15
            ):
                continue
            used.update((first, second))
            merged.append(trial)
        if not merged:
            break
        groups = [value for index, value in enumerate(groups) if index not in used] + merged
        for group in groups:
            _update_group(group, cfg)
    return groups, initial_count - len(groups)


def _em_reassign_entries(groups: list[dict], cfg: dict) -> list[dict]:
    """Alternate soft wall assignment and robust prototype re-estimation."""
    entries = [entry for group in groups for entry in group["entries"]]
    for _ in range(int(cfg.get("calibration_em_iterations", 3))):
        assigned = [[] for _ in groups]
        for entry in entries:
            costs = [
                (_entry_group_cost(entry, group, cfg), index) for index, group in enumerate(groups)
            ]
            valid = [(cost, index) for cost, index in costs if cost is not None]
            if not valid:
                group = {"entries": [entry]}
                _update_group(group, cfg)
                groups.append(group)
                assigned.append([entry])
                continue
            _, index = min(valid)
            assigned[index].append(entry)
        groups = [{"entries": values} for values in assigned if values]
        for group in groups:
            _update_group(group, cfg)
    return groups


def _point_raster_distance(
    point: np.ndarray,
    slice_index: int,
    distance_images: dict[int, np.ndarray],
    origin: np.ndarray,
    grid_m: float,
) -> float:
    pixel = np.rint((np.asarray(point, dtype=float) - origin) / grid_m - 0.5).astype(int)
    image = distance_images[slice_index]
    if pixel[0] < 0 or pixel[1] < 0 or pixel[0] >= image.shape[1] or pixel[1] >= image.shape[0]:
        return float("inf")
    return float(image[pixel[1], pixel[0]] * grid_m)


def _axis_raster_score(
    group: dict,
    direction: np.ndarray,
    offset: float,
    distance_images: dict[int, np.ndarray],
    heatmaps: dict[int, np.ndarray],
    origin: np.ndarray,
    grid_m: float,
    cfg: dict,
) -> float:
    normal = np.asarray([-direction[1], direction[0]])
    local_scores: list[float] = []
    local_weights: list[float] = []
    distance_clip = float(cfg.get("calibration_axis_distance_clip_m", 0.25))
    heat_reward = float(cfg.get("calibration_axis_heat_reward_m", 0.015))
    sample_step = float(cfg.get("calibration_axis_sample_step_m", 0.12))
    for entry in group["entries"]:
        coordinates = np.asarray(entry["line"].coords, dtype=float)[[0, -1]]
        interval = coordinates @ direction
        length = abs(float(interval[1] - interval[0]))
        count = max(3, min(96, int(math.ceil(length / sample_step)) + 1))
        samples_t = np.linspace(float(interval[0]), float(interval[1]), count)
        samples = samples_t[:, None] * direction + offset * normal
        pixels = np.rint((samples - origin) / grid_m - 0.5).astype(int)
        image = distance_images[int(entry["slice"])]
        valid = (
            (pixels[:, 0] >= 0)
            & (pixels[:, 1] >= 0)
            & (pixels[:, 0] < image.shape[1])
            & (pixels[:, 1] < image.shape[0])
        )
        if not np.any(valid):
            continue
        pixels = pixels[valid]
        distances = np.minimum(
            image[pixels[:, 1], pixels[:, 0]].astype(float) * grid_m,
            distance_clip,
        )
        heat = heatmaps[int(entry["slice"])][pixels[:, 1], pixels[:, 0]].astype(float)
        local_scores.append(
            0.60 * float(np.quantile(distances, 0.90))
            + 0.40 * float(np.mean(distances))
            - heat_reward * float(np.mean(heat))
        )
        local_weights.append(
            math.sqrt(max(entry["line"].length, 0.10))
            * (0.50 + float(entry.get("evidence", 0.50)))
        )
    if not local_scores:
        return float("inf")
    values = np.asarray(local_scores)
    weights = np.asarray(local_weights)
    # The upper-quantile term stops a dense layer from dragging the shared
    # wall away from a less dense but geometrically valid height layer.
    return 0.55 * float(np.average(values, weights=weights)) + 0.45 * float(
        np.quantile(values, 0.80)
    )


def _refine_group_axes_against_rasters(
    groups: list[dict],
    cfg: dict,
    distance_images: dict[int, np.ndarray],
    heatmaps: dict[int, np.ndarray],
    origin: np.ndarray,
    grid_m: float,
) -> dict:
    angle_range = float(cfg.get("calibration_axis_angle_search_deg", 0.75))
    angle_step = float(cfg.get("calibration_axis_angle_step_deg", 0.375))
    offset_range = float(cfg.get("calibration_axis_offset_search_m", 0.10))
    offset_step = float(cfg.get("calibration_axis_offset_step_m", 0.025))
    improvements: list[float] = []
    direction_changes: list[float] = []
    offset_changes: list[float] = []
    eligible = 0
    for group in groups:
        if len({value["slice"] for value in group["entries"]}) < 2:
            continue
        eligible += 1
        original_direction = group["direction"].copy()
        original_offset = float(group["offset"])
        best_direction = original_direction
        best_offset = original_offset
        best_score = _axis_raster_score(
            group,
            best_direction,
            best_offset,
            distance_images,
            heatmaps,
            origin,
            grid_m,
            cfg,
        )
        if angle_step > 0 and angle_range > 0:
            for delta_deg in np.arange(-angle_range, angle_range + angle_step * 0.5, angle_step):
                angle = math.atan2(original_direction[1], original_direction[0]) + math.radians(
                    float(delta_deg)
                )
                direction = np.asarray([math.cos(angle), math.sin(angle)])
                normal = np.asarray([-direction[1], direction[0]])
                midpoints = np.asarray(
                    [np.mean(np.asarray(value["line"].coords), axis=0) for value in group["entries"]]
                )
                weights = np.asarray(
                    [max(0.2, value["line"].length) for value in group["entries"]]
                )
                offset = _weighted_median(midpoints @ normal, weights)
                score = _axis_raster_score(
                    group,
                    direction,
                    offset,
                    distance_images,
                    heatmaps,
                    origin,
                    grid_m,
                    cfg,
                )
                if (score, abs(float(delta_deg))) < (
                    best_score - 1e-9,
                    math.degrees(_angle_difference(best_direction, original_direction)),
                ):
                    best_direction, best_offset, best_score = direction, offset, score
        normal = np.asarray([-best_direction[1], best_direction[0]])
        raw_offsets = np.asarray(
            [
                float(np.mean(np.asarray(value["line"].coords), axis=0) @ normal)
                for value in group["entries"]
            ]
        )
        candidates = np.concatenate(
            [
                np.arange(
                    best_offset - offset_range,
                    best_offset + offset_range + offset_step * 0.5,
                    offset_step,
                ),
                raw_offsets,
                np.asarray([best_offset]),
            ]
        )
        direction_offset = best_offset
        for offset in np.unique(np.round(candidates, 6)):
            score = _axis_raster_score(
                group,
                best_direction,
                float(offset),
                distance_images,
                heatmaps,
                origin,
                grid_m,
                cfg,
            )
            if (score, abs(float(offset) - direction_offset)) < (
                best_score - 1e-9,
                abs(best_offset - direction_offset),
            ):
                best_offset, best_score = float(offset), score
        original_score = _axis_raster_score(
            group,
            original_direction,
            original_offset,
            distance_images,
            heatmaps,
            origin,
            grid_m,
            cfg,
        )
        if best_score + 1e-6 < original_score:
            group["direction"] = best_direction
            group["normal"] = np.asarray([-best_direction[1], best_direction[0]])
            group["offset"] = best_offset
            improvements.append(original_score - best_score)
            direction_changes.append(
                math.degrees(_angle_difference(original_direction, best_direction))
            )
            anchor = np.mean(
                np.vstack(
                    [np.asarray(value["line"].coords, dtype=float) for value in group["entries"]]
                ),
                axis=0,
            )
            original_normal = np.asarray([-original_direction[1], original_direction[0]])
            original_axis_point = (
                original_direction * float(anchor @ original_direction)
                + original_normal * original_offset
            )
            offset_changes.append(
                abs(float(original_axis_point @ group["normal"] - best_offset))
            )
    return {
        "height_axis_raster_eligible_group_count": int(eligible),
        "height_axis_raster_refined_group_count": int(len(improvements)),
        "height_axis_raster_mean_objective_improvement_m": (
            None if not improvements else float(np.mean(improvements))
        ),
        "height_axis_raster_mean_direction_change_deg": (
            None if not direction_changes else float(np.mean(direction_changes))
        ),
        "height_axis_raster_mean_offset_change_m": (
            None if not offset_changes else float(np.mean(offset_changes))
        ),
    }


def _regularize_group_endpoints(
    groups: list[dict],
    cfg: dict,
    distance_images: dict[int, np.ndarray],
    origin: np.ndarray,
    grid_m: float,
) -> dict:
    cluster_m = float(cfg.get("calibration_endpoint_cluster_m", 0.40))
    minimum_slices = int(cfg.get("calibration_endpoint_min_slices", 2))
    evidence_m = float(cfg.get("calibration_endpoint_evidence_m", 0.10))
    deviations_before: list[float] = []
    deviations_after: list[float] = []
    cluster_count = 0
    snapped_count = 0
    evidence_rejected_count = 0
    for group in groups:
        direction, normal, offset = group["direction"], group["normal"], group["offset"]
        endpoint_records: dict[int, list[dict]] = {0: [], 1: []}
        for entry in group["entries"]:
            values = np.asarray(entry["calibrated"].coords, dtype=float)[[0, -1]].copy()
            projections = values @ direction
            low_index, high_index = int(np.argmin(projections)), int(np.argmax(projections))
            endpoint_records[0].append(
                {"entry": entry, "coordinate_index": low_index, "t": float(projections[low_index])}
            )
            endpoint_records[1].append(
                {"entry": entry, "coordinate_index": high_index, "t": float(projections[high_index])}
            )
        for side_records in endpoint_records.values():
            ordered = sorted(side_records, key=lambda value: value["t"])
            clusters: list[list[dict]] = []
            for record in ordered:
                if not clusters or record["t"] - clusters[-1][-1]["t"] > cluster_m:
                    clusters.append([record])
                else:
                    clusters[-1].append(record)
            for records in clusters:
                if len({value["entry"]["slice"] for value in records}) < minimum_slices:
                    continue
                weights = np.asarray(
                    [max(0.2, value["entry"]["line"].length) for value in records]
                )
                target = _weighted_median(
                    np.asarray([value["t"] for value in records]), weights
                )
                cluster_count += 1
                for record in records:
                    entry = record["entry"]
                    values = np.asarray(entry["calibrated"].coords, dtype=float)[[0, -1]].copy()
                    target_point = direction * target + normal * offset
                    if (
                        _point_raster_distance(
                            target_point,
                            int(entry["slice"]),
                            distance_images,
                            origin,
                            grid_m,
                        )
                        > evidence_m
                    ):
                        evidence_rejected_count += 1
                        continue
                    deviations_before.append(abs(record["t"] - target))
                    values[record["coordinate_index"]] = target_point
                    if float(np.linalg.norm(values[1] - values[0])) >= 0.15:
                        entry["calibrated"] = LineString(values)
                        snapped_count += 1
                        deviations_after.append(0.0)
    return {
        "height_endpoint_consensus_cluster_count": int(cluster_count),
        "height_endpoint_snapped_count": int(snapped_count),
        "height_endpoint_evidence_rejected_count": int(evidence_rejected_count),
        "height_endpoint_mean_dispersion_before_m": (
            None if not deviations_before else float(np.mean(deviations_before))
        ),
        "height_endpoint_mean_dispersion_after_m": (
            None if not deviations_after else float(np.mean(deviations_after))
        ),
    }


def _solve_global_junctions(
    groups: list[dict],
    cfg: dict,
    distance_images: dict[int, np.ndarray],
    origin: np.ndarray,
    grid_m: float,
) -> dict:
    extension_m = float(cfg.get("calibration_junction_extension_m", 0.50))
    cluster_m = float(cfg.get("calibration_junction_cluster_m", 0.28))
    snap_m = float(cfg.get("calibration_junction_snap_m", 0.42))
    minimum_angle = math.radians(float(cfg.get("calibration_junction_min_angle_deg", 15.0)))
    minimum_shared = int(cfg.get("calibration_junction_min_shared_slices", 2))
    evidence_m = float(cfg.get("calibration_junction_evidence_m", 0.12))
    candidates: list[dict] = []
    for first in range(len(groups)):
        first_group = groups[first]
        for second in range(first + 1, len(groups)):
            second_group = groups[second]
            angle = _angle_difference(first_group["direction"], second_group["direction"])
            if angle < minimum_angle:
                continue
            shared = {value["slice"] for value in first_group["entries"]} & {
                value["slice"] for value in second_group["entries"]
            }
            if len(shared) < minimum_shared:
                continue
            matrix = np.vstack([first_group["normal"], second_group["normal"]])
            if abs(float(np.linalg.det(matrix))) < 1e-6:
                continue
            point = np.linalg.solve(
                matrix, np.asarray([first_group["offset"], second_group["offset"]])
            )
            first_interval = _group_interval(first_group, first_group["direction"])
            second_interval = _group_interval(second_group, second_group["direction"])
            first_t = float(point @ first_group["direction"])
            second_t = float(point @ second_group["direction"])
            first_extension = max(0.0, first_interval[0] - first_t, first_t - first_interval[1])
            second_extension = max(0.0, second_interval[0] - second_t, second_t - second_interval[1])
            if max(first_extension, second_extension) > extension_m:
                continue
            # A geometric crossing is not automatically a CAD junction.  It
            # must be observed as an endpoint/T-junction in several height
            # slices; this rejects unrelated walls whose infinite axes cross.
            observed_slices = 0
            for slice_index in shared:
                relevant_entries = [
                    value
                    for value in first_group["entries"] + second_group["entries"]
                    if value["slice"] == slice_index
                ]
                endpoint_distance = min(
                    float(
                        np.min(
                            np.linalg.norm(
                                np.asarray(value["calibrated"].coords, dtype=float)[[0, -1]]
                                - point,
                                axis=1,
                            )
                        )
                    )
                    for value in relevant_entries
                )
                if endpoint_distance <= snap_m:
                    observed_slices += 1
            if observed_slices < minimum_shared:
                continue
            candidates.append(
                {
                    "point": point,
                    "groups": {first, second},
                    "weight": observed_slices * math.sin(angle),
                }
            )
    if not candidates:
        return {
            "height_global_junction_count": 0,
            "height_junction_snapped_endpoint_count": 0,
            "height_junction_evidence_rejected_count": 0,
            "height_junction_mean_gap_before_m": None,
            "height_junction_mean_gap_after_m": None,
        }
    parent = np.arange(len(candidates))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = int(parent[index])
        return index

    for first in range(len(candidates)):
        for second in range(first + 1, len(candidates)):
            if float(np.linalg.norm(candidates[first]["point"] - candidates[second]["point"])) <= cluster_m:
                first_root, second_root = root(first), root(second)
                if first_root != second_root:
                    parent[second_root] = first_root
    components: dict[int, list[int]] = {}
    for index in range(len(candidates)):
        components.setdefault(root(index), []).append(index)
    junctions: list[dict] = []
    for indices in components.values():
        group_indices = sorted(
            set().union(*(candidates[index]["groups"] for index in indices))
        )
        if len(group_indices) < 2:
            continue
        matrix = np.zeros((2, 2), dtype=float)
        vector = np.zeros(2, dtype=float)
        for group_index in group_indices:
            group = groups[group_index]
            weight = max(1.0, len({value["slice"] for value in group["entries"]}))
            projector = np.outer(group["normal"], group["normal"])
            matrix += weight * projector
            vector += weight * group["offset"] * group["normal"]
        if abs(float(np.linalg.det(matrix))) < 1e-8:
            continue
        point = np.linalg.solve(matrix, vector)
        residuals = [
            abs(float(point @ groups[group_index]["normal"] - groups[group_index]["offset"]))
            for group_index in group_indices
        ]
        if max(residuals) > float(cfg.get("calibration_junction_max_residual_m", 0.12)):
            continue
        junctions.append({"point": point, "groups": set(group_indices)})

    for junction_index, junction in enumerate(junctions):
        junction["id"] = f"J{junction_index:04d}"
        for group_index in junction["groups"]:
            groups[group_index].setdefault("junctions", []).append(
                {"id": junction["id"], "point": junction["point"].copy()}
            )

    gaps_before: list[float] = []
    gaps_after: list[float] = []
    snapped = 0
    evidence_rejected_count = 0
    for group_index, group in enumerate(groups):
        relevant = [value for value in junctions if group_index in value["groups"]]
        if not relevant:
            continue
        for entry in group["entries"]:
            values = np.asarray(entry["calibrated"].coords, dtype=float)[[0, -1]].copy()
            for endpoint_index in range(2):
                distances = [
                    float(np.linalg.norm(values[endpoint_index] - value["point"]))
                    for value in relevant
                ]
                if not distances:
                    continue
                selected = int(np.argmin(distances))
                if distances[selected] > snap_m:
                    continue
                target_point = relevant[selected]["point"]
                if (
                    _point_raster_distance(
                        target_point,
                        int(entry["slice"]),
                        distance_images,
                        origin,
                        grid_m,
                    )
                    > evidence_m
                ):
                    evidence_rejected_count += 1
                    continue
                candidate = values.copy()
                candidate[endpoint_index] = target_point
                if float(np.linalg.norm(candidate[1] - candidate[0])) < 0.15:
                    continue
                gaps_before.append(distances[selected])
                values = candidate
                gaps_after.append(0.0)
                snapped += 1
            entry["calibrated"] = LineString(values)
    return {
        "height_global_junction_count": int(len(junctions)),
        "height_junction_snapped_endpoint_count": int(snapped),
        "height_junction_evidence_rejected_count": int(evidence_rejected_count),
        "height_junction_mean_gap_before_m": (
            None if not gaps_before else float(np.mean(gaps_before))
        ),
        "height_junction_mean_gap_after_m": (
            None if not gaps_after else float(np.mean(gaps_after))
        ),
    }


def _slice_evidence_metrics(
    slices: list[HeightSlice], origin: np.ndarray, grid_m: float, calibrated: bool
) -> dict:
    distances: list[float] = []
    for height_slice in slices:
        distance_image = cv2.distanceTransform(
            np.where(height_slice.mask > 0, 0, 255).astype(np.uint8), cv2.DIST_L2, 5
        )
        lines = (
            height_slice.calibrated_lines_ref if calibrated else height_slice.raw_lines_ref
        )
        for line in lines:
            count = max(2, int(math.ceil(line.length / max(grid_m, 0.05))) + 1)
            samples = np.asarray(
                [line.interpolate(index / (count - 1), normalized=True).coords[0] for index in range(count)]
            )
            pixels = np.rint((samples - origin) / grid_m - 0.5).astype(int)
            valid = (
                (pixels[:, 0] >= 0)
                & (pixels[:, 1] >= 0)
                & (pixels[:, 0] < distance_image.shape[1])
                & (pixels[:, 1] < distance_image.shape[0])
            )
            if np.any(valid):
                distances.extend(
                    (distance_image[pixels[valid, 1], pixels[valid, 0]] * grid_m).tolist()
                )
    prefix = "height_calibrated_evidence" if calibrated else "height_raw_evidence"
    return {
        f"{prefix}_median_m": None if not distances else float(np.median(distances)),
        f"{prefix}_p95_m": None if not distances else float(np.quantile(distances, 0.95)),
        f"{prefix}_support_fraction": (
            0.0 if not distances else float(np.mean(np.asarray(distances) <= 0.15))
        ),
    }


def _slice_reverse_coverage_metrics(
    slices: list[HeightSlice], origin: np.ndarray, grid_m: float, calibrated: bool
) -> dict:
    supported = 0
    total = 0
    threshold_pixels = float(0.15 / grid_m)
    for height_slice in slices:
        line_image = np.zeros_like(height_slice.mask, dtype=np.uint8)
        lines = (
            height_slice.calibrated_lines_ref if calibrated else height_slice.raw_lines_ref
        )
        for line in lines:
            pixels = np.rint((np.asarray(line.coords) - origin) / grid_m - 0.5).astype(
                np.int32
            )
            cv2.polylines(line_image, [pixels], False, 255, 1, cv2.LINE_8)
        evidence = height_slice.mask > 0
        count = int(np.count_nonzero(evidence))
        if not count:
            continue
        distance = cv2.distanceTransform(
            np.where(line_image > 0, 0, 255).astype(np.uint8), cv2.DIST_L2, 5
        )
        supported += int(np.count_nonzero(evidence & (distance <= threshold_pixels)))
        total += count
    prefix = "height_calibrated" if calibrated else "height_raw"
    return {
        f"{prefix}_evidence_to_line_coverage_fraction": (
            0.0 if not total else float(supported / total)
        ),
        f"{prefix}_evidence_cell_count": int(total),
    }


def _slice_point_distance_metrics(
    slices: list[HeightSlice], clean_points: np.ndarray, sample_step_m: float = 0.05
) -> dict:
    """Measure exported line samples against the actual points in each Z window.

    Raster distances remain useful for optimisation, but this independent
    check prevents morphology in the binary mask from making a line appear
    better supported than the source LiDAR observations.
    """
    distances: dict[str, list[float]] = {"raw": [], "calibrated": []}
    per_slice: list[dict] = []
    for height_slice in slices:
        band_xy = clean_points[
            (clean_points[:, 2] >= height_slice.z_min_m)
            & (clean_points[:, 2] < height_slice.z_max_m),
            :2,
        ]
        row = {"slice_index": int(height_slice.index), "point_count": int(len(band_xy))}
        if not len(band_xy):
            per_slice.append(row)
            continue
        tree = cKDTree(band_xy)
        for name, lines in (
            ("raw", height_slice.raw_lines_ref),
            ("calibrated", height_slice.calibrated_lines_ref),
        ):
            local: list[float] = []
            for line in lines:
                count = max(2, int(math.ceil(line.length / sample_step_m)) + 1)
                samples = np.asarray(
                    [
                        line.interpolate(index / (count - 1), normalized=True).coords[0]
                        for index in range(count)
                    ],
                    dtype=float,
                )
                local.extend(tree.query(samples, k=1)[0].tolist())
            distances[name].extend(local)
            row[f"{name}_sample_count"] = int(len(local))
            row[f"{name}_p95_m"] = (
                None if not local else float(np.quantile(np.asarray(local), 0.95))
            )
            row[f"{name}_support_fraction"] = (
                0.0 if not local else float(np.mean(np.asarray(local) <= 0.15))
            )
        per_slice.append(row)

    metrics: dict = {"height_point_distance_by_slice": per_slice}
    for name, values in distances.items():
        array = np.asarray(values, dtype=float)
        metrics[f"height_{name}_point_distance_median_m"] = (
            None if not len(array) else float(np.median(array))
        )
        metrics[f"height_{name}_point_distance_p95_m"] = (
            None if not len(array) else float(np.quantile(array, 0.95))
        )
        metrics[f"height_{name}_point_support_fraction"] = (
            0.0 if not len(array) else float(np.mean(array <= 0.15))
        )
    return metrics


def _calibrate_slices(slices: list[HeightSlice], cfg: dict) -> tuple[list[dict], dict]:
    """Jointly calibrate height-slice vectors against shared wall topology.

    The raw per-slice line work first creates deliberately conservative wall
    hypotheses.  Calibration then optimises four coupled terms: shared wall
    direction/offset, stable line assignment, endpoint consensus, and global
    junction closure.  Raster evidence is evaluated independently before and
    after calibration so a zero internal axis residual cannot masquerade as an
    accuracy improvement.
    """
    entries = []
    for height_slice in slices:
        for line in height_slice.raw_lines_ref:
            coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
            midpoint = np.mean(coordinates, axis=0)
            pixel = np.rint(
                (midpoint - cfg["_origin"]) / float(cfg["grid_m"]) - 0.5
            ).astype(int)
            evidence = 0.5
            if (
                0 <= pixel[0] < height_slice.heatmap.shape[1]
                and 0 <= pixel[1] < height_slice.heatmap.shape[0]
            ):
                evidence = float(height_slice.heatmap[pixel[1], pixel[0]])
            entries.append(
                {
                    "slice": height_slice.index,
                    "line": line,
                    "evidence": evidence,
                    "overlap_weight": height_slice.overlap_weight,
                    "_coordinates": coordinates,
                    "_midpoint": midpoint,
                    "_direction": _line_direction(line),
                }
            )
    groups: list[dict] = []
    angle_tolerance = math.radians(float(cfg.get("calibration_angle_tolerance_deg", 5.0)))
    offset_tolerance = float(cfg.get("calibration_offset_tolerance_m", 0.25))
    gap_tolerance = float(cfg.get("calibration_interval_gap_m", 0.60))
    for entry in sorted(entries, key=lambda value: value["line"].length, reverse=True):
        best: tuple[float, dict] | None = None
        coordinates = entry["_coordinates"]
        midpoint = entry["_midpoint"]
        raw_direction = entry["_direction"]
        for group in groups:
            if _same_slice_parallel_conflict(entry, group, cfg):
                continue
            direction = group["direction"]
            angle = _angle_difference(raw_direction, direction)
            if angle > angle_tolerance:
                continue
            normal = group["normal"]
            offset_error = abs(float(midpoint @ normal) - float(group["offset"]))
            if offset_error > offset_tolerance:
                continue
            interval = tuple(sorted((coordinates @ direction).tolist()))
            group_intervals = group.get("_entry_intervals")
            if group_intervals is None:
                group_intervals = [
                    tuple(
                        sorted(
                            (
                                np.asarray(value["line"].coords, dtype=float)[[0, -1]]
                                @ direction
                            ).tolist()
                        )
                    )
                    for value in group["entries"]
                ]
            gap = min(_interval_gap(interval, value) for value in group_intervals)
            if gap > gap_tolerance:
                continue
            cost = angle / angle_tolerance + offset_error / offset_tolerance + gap / gap_tolerance
            if best is None or cost < best[0]:
                best = (cost, group)
        if best is None:
            group = {"entries": [entry], "direction": raw_direction}
            _update_group(group, cfg)
            groups.append(group)
        else:
            best[1]["entries"].append(entry)
            _update_group(best[1], cfg)

    initial_group_count = len(groups)
    groups, first_merge_count = _merge_wall_groups(groups, cfg)
    groups = _em_reassign_entries(groups, cfg)
    groups, second_merge_count = _merge_wall_groups(groups, cfg)

    origin = np.asarray(cfg["_origin"], dtype=float)
    grid_m = float(cfg["grid_m"])
    distance_images = {
        value.index: cv2.distanceTransform(
            np.where(value.mask > 0, 0, 255).astype(np.uint8), cv2.DIST_L2, 5
        )
        for value in slices
    }
    heatmaps = {value.index: value.heatmap for value in slices}
    raster_axis_metrics = _refine_group_axes_against_rasters(
        groups, cfg, distance_images, heatmaps, origin, grid_m
    )

    before_residuals = []
    after_residuals = []
    for group in groups:
        # The raster optimiser owns the final shared axis. Re-estimating it
        # from raw lines here silently discards that optimisation.
        direction, normal, offset = group["direction"], group["normal"], group["offset"]
        for entry in group["entries"]:
            coordinates = np.asarray(entry["line"].coords, dtype=float)[[0, -1]]
            before_residuals.append(abs(float(np.mean(coordinates, axis=0) @ normal) - offset))
            interval = coordinates @ direction
            calibrated = LineString(
                [direction * float(interval[0]) + normal * offset, direction * float(interval[1]) + normal * offset]
            )
            entry["calibrated"] = calibrated
            after_residuals.append(
                abs(float(np.mean(np.asarray(calibrated.coords), axis=0) @ normal) - offset)
            )

    def sync_calibrated_lines() -> None:
        for height_slice in slices:
            height_slice.calibrated_lines_ref = [
                entry["calibrated"]
                for entry in entries
                if entry["slice"] == height_slice.index
            ]

    sync_calibrated_lines()
    axis_evidence = _slice_evidence_metrics(slices, origin, grid_m, True)
    endpoint_metrics = _regularize_group_endpoints(
        groups, cfg, distance_images, origin, grid_m
    )
    sync_calibrated_lines()
    endpoint_evidence = _slice_evidence_metrics(slices, origin, grid_m, True)
    junction_metrics = _solve_global_junctions(
        groups, cfg, distance_images, origin, grid_m
    )
    sync_calibrated_lines()

    raw_evidence = _slice_evidence_metrics(
        slices, origin, grid_m, False
    )
    calibrated_evidence = _slice_evidence_metrics(
        slices, origin, grid_m, True
    )
    raw_reverse = _slice_reverse_coverage_metrics(slices, origin, grid_m, False)
    calibrated_reverse = _slice_reverse_coverage_metrics(slices, origin, grid_m, True)
    raw_p95 = raw_evidence["height_raw_evidence_p95_m"]
    calibrated_p95 = calibrated_evidence["height_calibrated_evidence_p95_m"]
    raw_support = raw_evidence["height_raw_evidence_support_fraction"]
    calibrated_support = calibrated_evidence[
        "height_calibrated_evidence_support_fraction"
    ]
    metrics = {
        "height_calibration_initial_group_count": int(initial_group_count),
        "height_calibration_group_count": int(len(groups)),
        "height_calibration_merged_group_count": int(
            first_merge_count + second_merge_count
        ),
        "height_calibration_em_iterations": int(cfg.get("calibration_em_iterations", 3)),
        "height_calibration_input_line_count": int(len(entries)),
        "height_calibration_mean_offset_before_m": (
            None if not before_residuals else float(np.mean(before_residuals))
        ),
        "height_calibration_mean_offset_after_m": (
            None if not after_residuals else float(np.mean(after_residuals))
        ),
        "height_calibration_independent_p95_change_m": (
            None
            if raw_p95 is None or calibrated_p95 is None
            else float(calibrated_p95 - raw_p95)
        ),
        "height_calibration_independent_support_change": float(
            calibrated_support - raw_support
        ),
        "height_calibration_reverse_coverage_change": float(
            calibrated_reverse["height_calibrated_evidence_to_line_coverage_fraction"]
            - raw_reverse["height_raw_evidence_to_line_coverage_fraction"]
        ),
        "height_axis_evidence_p95_m": axis_evidence[
            "height_calibrated_evidence_p95_m"
        ],
        "height_axis_evidence_support_fraction": axis_evidence[
            "height_calibrated_evidence_support_fraction"
        ],
        "height_endpoint_evidence_p95_m": endpoint_evidence[
            "height_calibrated_evidence_p95_m"
        ],
        "height_endpoint_evidence_support_fraction": endpoint_evidence[
            "height_calibrated_evidence_support_fraction"
        ],
    }
    metrics.update(endpoint_metrics)
    metrics.update(junction_metrics)
    metrics.update(raster_axis_metrics)
    metrics.update(raw_evidence)
    metrics.update(calibrated_evidence)
    metrics.update(raw_reverse)
    metrics.update(calibrated_reverse)
    raw_axis_residuals = []
    for group_index, group in enumerate(groups):
        group["id"] = f"W{group_index:04d}"
        if len({entry["slice"] for entry in group["entries"]}) < 2:
            continue
        for entry in group["entries"]:
            coordinates = np.asarray(entry["line"].coords, dtype=float)[[0, -1]]
            raw_axis_residuals.extend(
                np.abs(coordinates @ group["normal"] - group["offset"]).tolist()
            )
    metrics["height_shared_wall_raw_residual_p95_m"] = (
        None
        if not raw_axis_residuals
        else float(np.quantile(np.asarray(raw_axis_residuals), 0.95))
    )
    return groups, metrics


def _merge_intervals(intervals: list[tuple[float, float]], gap_m: float) -> list[tuple[float, float]]:
    if not intervals:
        return []
    ordered = sorted((min(value), max(value)) for value in intervals)
    merged = [ordered[0]]
    for start, end in ordered[1:]:
        if start <= merged[-1][1] + gap_m:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged


def _merge_height_ranges(ranges: list[tuple[float, float]]) -> list[list[float]]:
    return [list(value) for value in _merge_intervals(ranges, 1e-6)]


def _group_axis_point(group: dict, value: float, tolerance_m: float) -> np.ndarray:
    candidates = []
    for junction in group.get("junctions", []):
        point = np.asarray(junction["point"], dtype=float)
        error = abs(float(point @ group["direction"]) - value)
        if error <= tolerance_m:
            candidates.append((error, point))
    if candidates:
        return min(candidates, key=lambda item: item[0])[1]
    return group["direction"] * value + group["normal"] * group["offset"]


def _deduplicate_consensus_segments(
    values: list[dict], slices: list[HeightSlice], cfg: dict
) -> list[dict]:
    """Merge only coincident cross-group atomic segments and their evidence.

    This is intentionally much tighter than wall association.  It removes
    duplicated output caused by two IDs converging to the same final axis,
    while preserving resolvable parallel faces such as walls 15 cm apart.
    """
    if not values:
        return []
    angle_tolerance = math.radians(
        float(cfg.get("consensus_duplicate_angle_tolerance_deg", 0.02))
    )
    offset_tolerance = float(cfg.get("consensus_duplicate_offset_tolerance_m", 0.001))
    axis_groups: list[dict] = []
    for value in values:
        line = value["line_ref"]
        direction = _line_direction(line)
        normal = np.asarray([-direction[1], direction[0]])
        offset = float(np.mean(np.asarray(line.coords), axis=0) @ normal)
        selected = None
        for axis_group in axis_groups:
            candidate_direction = axis_group["direction"]
            if _angle_difference(direction, candidate_direction) > angle_tolerance:
                continue
            candidate_normal = axis_group["normal"]
            candidate_offset = float(
                np.mean(np.asarray(line.coords), axis=0) @ candidate_normal
            )
            if abs(candidate_offset - axis_group["offset"]) <= offset_tolerance:
                selected = axis_group
                break
        if selected is None:
            selected = {
                "direction": direction,
                "normal": normal,
                "offset": offset,
                "values": [],
            }
            axis_groups.append(selected)
        selected["values"].append(value)

    slice_by_index = {value.index: value for value in slices}
    result: list[dict] = []
    all_indices = set(slice_by_index)
    for axis_index, axis_group in enumerate(axis_groups):
        direction = axis_group["direction"]
        normal = axis_group["normal"]
        offset = axis_group["offset"]
        records = []
        boundaries = set()
        for value in axis_group["values"]:
            coordinates = np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]]
            interval = tuple(sorted((coordinates @ direction).tolist()))
            records.append((interval, value, coordinates))
            boundaries.update(interval)
        boundaries = sorted(boundaries)
        atomic: list[tuple[float, float, list[dict], list[np.ndarray]]] = []
        for start, end in zip(boundaries, boundaries[1:]):
            if end - start < 1e-8:
                continue
            midpoint = (start + end) / 2.0
            active = [
                (value, coordinates)
                for interval, value, coordinates in records
                if interval[0] - 1e-8 <= midpoint <= interval[1] + 1e-8
            ]
            if not active:
                continue
            atomic.append(
                (start, end, [value for value, _ in active], [coords for _, coords in active])
            )

        for segment_index, (start, end, active, active_coordinates) in enumerate(atomic):
            observed = sorted(
                set().union(*(set(value["slice_indices"]) for value in active))
            )
            missing = sorted(all_indices - set(observed))
            inferred = [
                index
                for index in missing
                if index > min(all_indices)
                and index < max(all_indices)
                and index - 1 in observed
                and index + 1 in observed
            ]
            unknown = [index for index in missing if index not in inferred]

            def endpoint_at(position: float) -> np.ndarray:
                candidates = []
                for coordinates in active_coordinates:
                    for point in coordinates:
                        error = abs(float(point @ direction) - position)
                        if error <= 1e-6:
                            candidates.append((error, point))
                if candidates:
                    return min(candidates, key=lambda item: item[0])[1]
                return direction * position + normal * offset

            line = LineString([endpoint_at(start), endpoint_at(end)])
            observed_ranges = _merge_height_ranges(
                [
                    (slice_by_index[index].z_min_m, slice_by_index[index].z_max_m)
                    for index in observed
                ]
            )
            if len(observed) == len(slices):
                state = "full_observed"
            elif min(observed) == min(all_indices) and max(observed) < max(all_indices):
                state = "lower_observed"
            elif min(observed) > min(all_indices) and max(observed) == max(all_indices):
                state = "upper_observed"
            else:
                state = "partial_observed"
            source_ids = sorted(
                set().union(
                    *(
                        set(value.get("source_wall_ids", [value["wall_id"]]))
                        for value in active
                    )
                )
            )
            result.append(
                {
                    "group": -1,
                    "wall_id": source_ids[0] if len(source_ids) == 1 else f"C{axis_index:04d}",
                    "source_wall_ids": source_ids,
                    "deduplicated_source_count": int(len(active)),
                    "segment_id": f"C{axis_index:04d}_S{segment_index:03d}",
                    "line_ref": line,
                    "z_min_m": float(min(value[0] for value in observed_ranges)),
                    "z_max_m": float(max(value[1] for value in observed_ranges)),
                    "observed_z_ranges_m": observed_ranges,
                    "slice_indices": observed,
                    "inferred_slice_indices": inferred,
                    "unknown_slice_indices": unknown,
                    "slice_fraction": float(len(observed) / max(1, len(slices))),
                    "height_state": state,
                    "is_strict_intersection": len(observed) == len(slices),
                    "confidence": float(max(value.get("confidence", 0.0) for value in active)),
                }
            )
    return result


def _consensus_geometry(
    groups: list[dict],
    slices: list[HeightSlice],
    cfg: dict,
) -> tuple[list[LineString], list[dict]]:
    minimum_length = float(cfg.get("consensus_atomic_min_line_m", 0.05))
    merge_gap = float(cfg.get("consensus_observed_merge_gap_m", 0.01))
    junction_tolerance = float(cfg.get("calibration_consensus_junction_tolerance_m", 0.03))
    intersection: list[LineString] = []
    union: list[dict] = []
    slice_by_index = {value.index: value for value in slices}
    for group_index, group in enumerate(groups):
        direction, normal, offset = group["direction"], group["normal"], group["offset"]
        by_slice: dict[int, list[tuple[float, float]]] = {}
        for entry in group["entries"]:
            interval = tuple(
                sorted(
                    (
                        np.asarray(entry["calibrated"].coords, dtype=float)[[0, -1]]
                        @ direction
                    ).tolist()
                )
            )
            by_slice.setdefault(entry["slice"], []).append(interval)
        slice_intervals = {
            index: _merge_intervals(values, merge_gap) for index, values in by_slice.items()
        }
        boundaries = sorted(
            {
                coordinate
                for intervals in slice_intervals.values()
                for interval in intervals
                for coordinate in interval
            }
            | {
                float(np.asarray(value["point"]) @ direction)
                for value in group.get("junctions", [])
            }
        )
        atomic: list[tuple[float, float, tuple[int, ...]]] = []
        for start, end in zip(boundaries, boundaries[1:]):
            if end - start < 1e-7:
                continue
            midpoint = (start + end) / 2.0
            present = tuple(
                sorted(
                    index
                    for index, intervals in slice_intervals.items()
                    if any(value[0] - 1e-8 <= midpoint <= value[1] + 1e-8 for value in intervals)
                )
            )
            if not present:
                continue
            if atomic and atomic[-1][2] == present and start - atomic[-1][1] <= 1e-7:
                atomic[-1] = (atomic[-1][0], end, present)
            else:
                atomic.append((start, end, present))
        for segment_index, (start, end, present_tuple) in enumerate(atomic):
            if end - start < minimum_length:
                continue
            present = list(present_tuple)
            line = LineString(
                [
                    _group_axis_point(group, start, junction_tolerance),
                    _group_axis_point(group, end, junction_tolerance),
                ]
            )
            is_strict = len(present) == len(slices)
            if is_strict:
                intersection.append(line)
            observed_ranges = _merge_height_ranges(
                [(slice_by_index[index].z_min_m, slice_by_index[index].z_max_m) for index in present]
            )
            missing = [index for index in range(len(slices)) if index not in present]
            inferred = [
                index
                for index in missing
                if index > 0
                and index + 1 < len(slices)
                and index - 1 in present
                and index + 1 in present
            ]
            evidence_values = [
                float(entry.get("evidence", 0.5))
                for entry in group["entries"]
                if entry["slice"] in present
            ]
            if is_strict:
                height_state = "full_observed"
            elif min(present) == 0 and max(present) < len(slices) - 1:
                height_state = "lower_observed"
            elif min(present) > 0 and max(present) == len(slices) - 1:
                height_state = "upper_observed"
            else:
                height_state = "partial_observed"
            union.append(
                {
                    "group": group_index,
                    "wall_id": f"W{group_index:04d}",
                    "segment_id": f"W{group_index:04d}_S{segment_index:03d}",
                    "line_ref": line,
                    "z_min_m": float(min(value[0] for value in observed_ranges)),
                    "z_max_m": float(max(value[1] for value in observed_ranges)),
                    "observed_z_ranges_m": observed_ranges,
                    "slice_indices": present,
                    "inferred_slice_indices": inferred,
                    "unknown_slice_indices": [index for index in missing if index not in inferred],
                    "slice_fraction": float(len(present) / max(1, len(slices))),
                    "height_state": height_state,
                    "is_strict_intersection": is_strict,
                    "confidence": float(
                        (len(present) / max(1, len(slices)))
                        * (np.mean(evidence_values) if evidence_values else 0.5)
                    ),
                }
            )
    union = _deduplicate_consensus_segments(union, slices, cfg)
    intersection = [
        value["line_ref"] for value in union if value["is_strict_intersection"]
    ]
    return intersection, union


def _robust_intersection_geometry(
    union: list[dict], slices: list[HeightSlice], cfg: dict
) -> tuple[list[dict], int]:
    """Keep common structure despite one or two height-window dropouts.

    This is deliberately separate from the exact N/N intersection.  With the
    default 75% quorum, nine xh23 slices require seven observations.  Requiring
    support in each low/middle/high index band prevents a tall-window-only or
    floor-only object from being called common building structure.
    """
    slice_count = len(slices)
    fraction = float(cfg.get("consensus_robust_intersection_min_fraction", 0.75))
    minimum = max(1, int(math.ceil(slice_count * fraction - 1e-12)))
    require_bands = bool(
        cfg.get("consensus_robust_intersection_require_height_bands", True)
    )
    bands = [set(map(int, values)) for values in np.array_split(np.arange(slice_count), 3)]
    result = []
    for value in union:
        observed = set(map(int, value.get("slice_indices", [])))
        if len(observed) < minimum:
            value["is_robust_intersection"] = False
            continue
        if require_bands and any(band and not (observed & band) for band in bands):
            value["is_robust_intersection"] = False
            continue
        value["is_robust_intersection"] = True
        value["robust_min_slice_count"] = minimum
        result.append(value)
    return result, minimum


def _materialize_calibrated_slices_from_consensus(
    slices: list[HeightSlice], union: list[dict]
) -> None:
    """Make per-height deliverables reference the exact shared wall segments.

    The calibrated observations and the set-algebra outputs must not be two
    independently reconstructed approximations.  Materialising each observed
    slice from the atomic consensus segments makes the strict intersection and
    maximum union exact subsets/unions of the delivered per-slice geometry.
    Inferred and unknown slices are intentionally excluded here.
    """
    by_slice: dict[int, list[LineString]] = {value.index: [] for value in slices}
    for segment in union:
        for index in segment["slice_indices"]:
            by_slice[index].append(segment["line_ref"])
    for height_slice in slices:
        height_slice.calibrated_lines_ref = by_slice[height_slice.index]


def _consensus_topology_metrics(
    intersection: list[LineString], union: list[dict]
) -> dict:
    lines = [value["line_ref"] for value in union]
    if not lines:
        return {
            "height_maximum_union_total_length_m": 0.0,
            "height_maximum_union_duplicate_length_m": 0.0,
            "height_union_dangling_node_count": 0,
            "height_union_shared_node_count": 0,
            "height_union_shared_node_max_spread_m": None,
            "height_minimum_intersection_total_length_m": 0.0,
        }
    combined = unary_union(lines)
    duplicate_length = max(0.0, float(sum(line.length for line in lines) - combined.length))
    endpoints = np.vstack([np.asarray(line.coords, dtype=float)[[0, -1]] for line in lines])
    parent = np.arange(len(endpoints))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = int(parent[index])
        return index

    for first, second in cKDTree(endpoints).query_pairs(0.001):
        first_root, second_root = root(first), root(second)
        if first_root != second_root:
            parent[second_root] = first_root
    components: dict[int, list[int]] = {}
    for index in range(len(endpoints)):
        components.setdefault(root(index), []).append(index)
    shared = [values for values in components.values() if len(values) > 1]
    spreads = [
        float(
            np.max(
                np.linalg.norm(
                    endpoints[indices] - np.mean(endpoints[indices], axis=0), axis=1
                )
            )
        )
        for indices in shared
    ]
    return {
        "height_maximum_union_total_length_m": float(combined.length),
        "height_maximum_union_duplicate_length_m": duplicate_length,
        "height_union_dangling_node_count": int(
            sum(len(values) == 1 for values in components.values())
        ),
        "height_union_shared_node_count": int(len(shared)),
        "height_union_shared_node_max_spread_m": (
            None if not spreads else float(max(spreads))
        ),
        "height_minimum_intersection_total_length_m": float(
            sum(line.length for line in intersection)
        ),
    }


def _add_dxf_line(layout, line: LineString, layer: str, xdata: list[tuple[int, str]] | None = None):
    entity = layout.add_lwpolyline(
        [(float(x), float(y)) for x, y in line.coords],
        close=False,
        dxfattribs={"layer": layer},
    )
    if xdata:
        entity.set_xdata("LIDAR2OUTLINE", xdata)
    return entity


def _new_dxf() -> ezdxf.document.Drawing:
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6
    if "LIDAR2OUTLINE" not in document.appids:
        document.appids.add("LIDAR2OUTLINE")
    return document


def _merge_display_linework(lines: list[LineString]) -> list[LineString]:
    """Merge contiguous collinear atoms without changing their geometric set."""
    if not lines:
        return []
    geometry = unary_union(lines)
    if geometry.geom_type not in {"LineString", "LinearRing"}:
        geometry = linemerge(geometry)
    if geometry.geom_type in {"LineString", "LinearRing"}:
        return [LineString(geometry.coords)]
    return [
        LineString(value.coords)
        for value in geometry.geoms
        if value.geom_type in {"LineString", "LinearRing"}
        and value.length > 1e-9
    ]


def _slice_color(index: int, count: int) -> int:
    palette = [1, 30, 2, 3, 4, 5, 6, 140, 200, 210, 220, 230]
    return palette[index % len(palette)]


def _export_slice_dxf(
    path: Path,
    height_slice: HeightSlice,
    transform_cad_from_ref: np.ndarray,
    slice_count: int,
    calibrated: bool = True,
) -> None:
    document = _new_dxf()
    layer = f"Z_{height_slice.z_min_m:.2f}_{height_slice.z_max_m:.2f}"
    document.layers.add(layer, color=_slice_color(height_slice.index, slice_count))
    layout = document.modelspace()
    lines = (
        height_slice.calibrated_lines_ref if calibrated else height_slice.raw_lines_ref
    )
    for line in lines:
        _add_dxf_line(
            layout,
            _transform_line(line, transform_cad_from_ref),
            layer,
            [(1000, f"z_min_m={height_slice.z_min_m:.3f}"), (1000, f"z_max_m={height_slice.z_max_m:.3f}")],
        )
    document.saveas(path)


def _height_state_color(value: dict) -> int:
    return {
        "full_observed": 7,
        "lower_observed": 1,
        "upper_observed": 6,
        "partial_observed": 3,
    }.get(value.get("height_state"), 8)


def _segment_xdata(value: dict) -> list[tuple[int, str]]:
    tags = [
        (1000, f"wall_id={value['wall_id']}"),
        (1000, f"segment_id={value['segment_id']}"),
        (1000, f"height_state={value['height_state']}"),
        (1000, f"observed_z_min_m={value['z_min_m']:.3f}"),
        (1000, f"observed_z_max_m={value['z_max_m']:.3f}"),
        (
            1000,
            "observed_z_ranges_m="
            + ";".join(f"{item[0]:.3f}:{item[1]:.3f}" for item in value["observed_z_ranges_m"]),
        ),
        (1000, "observed_slice_indices=" + ",".join(map(str, value["slice_indices"]))),
        (
            1000,
            "inferred_slice_indices=" + ",".join(map(str, value["inferred_slice_indices"])),
        ),
        (
            1000,
            "unknown_slice_indices=" + ",".join(map(str, value["unknown_slice_indices"])),
        ),
        (1000, f"slice_fraction={value['slice_fraction']:.3f}"),
        (1000, f"confidence={value['confidence']:.3f}"),
    ]
    if value.get("recovered_slice_indices"):
        tags.append(
            (
                1000,
                "recovered_slice_indices="
                + ",".join(map(str, value["recovered_slice_indices"])),
            )
        )
    if value.get("support_interval_m"):
        tags.append(
            (
                1000,
                "support_interval_m="
                + ":".join(f"{item:.3f}" for item in value["support_interval_m"]),
            )
        )
    if value.get("inference_reasons"):
        tags.append(
            (1000, "inference_reasons=" + ",".join(value["inference_reasons"]))
        )
    tags.append(
        (
            1000,
            f"is_calibrated_common={str(bool(value.get('is_calibrated_common', False))).lower()}",
        )
    )
    return tags


def _export_consensus_dxfs(
    output_dir: Path,
    slices: list[HeightSlice],
    intersection: list[LineString],
    robust_intersection: list[dict],
    union: list[dict],
    transform_cad_from_ref: np.ndarray,
) -> None:
    minimum = _new_dxf()
    minimum.layers.add("MIN_INTERSECTION", color=3)
    for line in intersection:
        _add_dxf_line(
            minimum.modelspace(),
            _transform_line(line, transform_cad_from_ref),
            "MIN_INTERSECTION",
            [(1000, "support=all_observed_slices")],
        )
    minimum.saveas(output_dir / "minimum_intersection.dxf")

    robust = _new_dxf()
    robust.layers.add("ROBUST_INTERSECTION", color=4)
    for value in robust_intersection:
        _add_dxf_line(
            robust.modelspace(),
            _transform_line(value["line_ref"], transform_cad_from_ref),
            "ROBUST_INTERSECTION",
            [
                *_segment_xdata(value),
                (
                    1000,
                    f"robust_min_slice_count={value.get('robust_min_slice_count', 0)}",
                ),
            ],
        )
    robust.saveas(output_dir / "robust_intersection.dxf")

    maximum = _new_dxf()
    maximum.layers.add("MAX_UNION", color=7)
    for line in _merge_display_linework(
        [value["line_ref"] for value in union]
    ):
        _add_dxf_line(
            maximum.modelspace(),
            _transform_line(line, transform_cad_from_ref),
            "MAX_UNION",
            [(1000, "regularized_from_shared_wall_graph=true")],
        )
    maximum.saveas(output_dir / "maximum_union.dxf")

    combined = _new_dxf()
    combined.layers.add("MIN_INTERSECTION", color=3)
    combined.layers.add("ROBUST_INTERSECTION", color=4)
    combined.layers.add("MAX_UNION", color=7)
    combined.layers.add("INFERRED_HEIGHT", color=2, linetype="DASHED")
    combined.layers.add("UNKNOWN_HEIGHT", color=8, linetype="DASHDOT")
    combined.layers.add("HEIGHT_LABELS", color=8)
    combined.layers.get("HEIGHT_LABELS").off()
    layout = combined.modelspace()
    for height_slice in slices:
        raw_layer = f"RAW_SLICE_{height_slice.index:02d}_{height_slice.z_min_m:.2f}_{height_slice.z_max_m:.2f}"
        calibrated_layer = f"CAL_SLICE_{height_slice.index:02d}_{height_slice.z_min_m:.2f}_{height_slice.z_max_m:.2f}"
        combined.layers.add(raw_layer, color=8)
        combined.layers.add(calibrated_layer, color=_slice_color(height_slice.index, len(slices)))
        combined.layers.get(raw_layer).off()
        combined.layers.get(calibrated_layer).off()
        for line in height_slice.raw_lines_ref:
            _add_dxf_line(layout, _transform_line(line, transform_cad_from_ref), raw_layer)
        for line in height_slice.calibrated_lines_ref:
            _add_dxf_line(layout, _transform_line(line, transform_cad_from_ref), calibrated_layer)
    for line in intersection:
        entity = _add_dxf_line(
            layout, _transform_line(line, transform_cad_from_ref), "MIN_INTERSECTION"
        )
        entity.dxf.lineweight = 50
    for value in robust_intersection:
        entity = _add_dxf_line(
            layout,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            "ROBUST_INTERSECTION",
            _segment_xdata(value),
        )
        entity.dxf.lineweight = 35
    for value in union:
        entity = _add_dxf_line(
            layout,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            "MAX_UNION",
            _segment_xdata(value),
        )
        entity.dxf.color = _height_state_color(value)
        if value["inferred_slice_indices"]:
            inferred_entity = _add_dxf_line(
                layout,
                _transform_line(value["line_ref"], transform_cad_from_ref),
                "INFERRED_HEIGHT",
                _segment_xdata(value),
            )
            inferred_entity.dxf.linetype = "DASHED"
        if value["unknown_slice_indices"]:
            unknown_entity = _add_dxf_line(
                layout,
                _transform_line(value["line_ref"], transform_cad_from_ref),
                "UNKNOWN_HEIGHT",
                _segment_xdata(value),
            )
            unknown_entity.dxf.linetype = "DASHDOT"
        midpoint = _transform_line(value["line_ref"], transform_cad_from_ref).interpolate(0.5, normalized=True)
        layout.add_text(
            f"{value['segment_id']} {value['height_state']} obs={','.join(map(str, value['slice_indices']))}",
            dxfattribs={
                "layer": "HEIGHT_LABELS",
                "height": 0.12,
                "insert": (float(midpoint.x), float(midpoint.y)),
            },
        )
    combined.saveas(output_dir / "height_aware_combined.dxf")


def _export_post_fusion_outputs(
    output_dir: Path,
    result: PostFusionResult,
    raw_union: list[dict],
    transform_cad_from_ref: np.ndarray,
    clean_points: np.ndarray,
    grid_m: float,
) -> dict:
    """Export the post-merge wall network without changing observed-set semantics."""
    document = _new_dxf()
    document.layers.add("REGULARIZED_OBSERVED", color=7)
    document.layers.add("MORPH_GAP_INFERRED", color=2, linetype="DASHED")
    document.layers.add("CORNER_INFERRED", color=4, linetype="DASHED")
    document.layers.add("RAW_MAX_UNION", color=8)
    document.layers.get("RAW_MAX_UNION").off()
    layout = document.modelspace()
    for line in result.observed:
        _add_dxf_line(
            layout,
            _transform_line(line, transform_cad_from_ref),
            "REGULARIZED_OBSERVED",
            [(1000, "source=post_fusion_shared_axis_fit"), (1000, "observed=true")],
        )
    for values, layer in (
        (result.gap_inferred, "MORPH_GAP_INFERRED"),
        (result.corner_inferred, "CORNER_INFERRED"),
    ):
        for value in values:
            _add_dxf_line(
                layout,
                _transform_line(value["line_ref"], transform_cad_from_ref),
                layer,
                [
                    (1000, f"kind={value['kind']}"),
                    (1000, f"score={value['score']:.4f}"),
                    (1000, "observed=false"),
                    (1000, "inferred=true"),
                ],
            ).dxf.linetype = "DASHED"
    for value in raw_union:
        _add_dxf_line(
            layout,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            "RAW_MAX_UNION",
        )
    document.saveas(output_dir / "final_merged.dxf")
    document.saveas(output_dir / "postprocessed_merged.dxf")

    cad_points = transform_points(clean_points, transform_cad_from_ref)
    cad_origin, cad_shape = _common_raster(cad_points, grid_m, 0.50)
    density = _density_base(cad_points, cad_origin, cad_shape, grid_m)
    background = cv2.cvtColor(
        np.clip(density * 0.22, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR
    )
    raw_image = background.copy()
    final_image = background.copy()
    for value in raw_union:
        _draw_line(
            raw_image,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin,
            grid_m,
            (235, 235, 235),
            2,
        )
    for line in result.observed:
        _draw_line(
            final_image,
            _transform_line(line, transform_cad_from_ref),
            cad_origin,
            grid_m,
            (245, 245, 245),
            2,
        )
    for value in result.gap_inferred:
        _draw_patterned_line(
            final_image,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin,
            grid_m,
            (30, 220, 255),
            2,
        )
    for value in result.corner_inferred:
        _draw_patterned_line(
            final_image,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin,
            grid_m,
            (255, 190, 50),
            2,
        )
    raw_image = np.flipud(raw_image).copy()
    final_image = np.flipud(final_image).copy()
    raw_physical_count = int(
        result.metrics.get("post_fusion_raw_physical_line_count", len(raw_union))
    )
    final_physical_count = int(
        result.metrics.get("post_fusion_regularized_observed_line_count", 0)
    )
    labels = (
        f"V8 OBSERVED UNION - {raw_physical_count} physical lines",
        (
            f"V9 POST-FUSION - {final_physical_count} observed lines - "
            f"{len(result.gap_inferred)} gaps + {len(result.corner_inferred)} corners"
        ),
    )
    for image, label in ((raw_image, labels[0]), (final_image, labels[1])):
        cv2.putText(
            image,
            label,
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            (245, 245, 245),
            2,
            cv2.LINE_AA,
        )
        _height_set_scale_bar(image, grid_m)
    cv2.putText(
        final_image,
        "white=regularized observed  yellow=morphological gap  cyan=corner extension",
        (14, 55),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        (230, 230, 230),
        1,
        cv2.LINE_AA,
    )
    cv2.imwrite(str(output_dir / "final_merged.png"), final_image)
    cv2.imwrite(str(output_dir / "postprocessed_merged.png"), final_image)
    cv2.imwrite(
        str(output_dir / "maximum_union_postprocessed_comparison.png"),
        np.hstack([raw_image, final_image]),
    )
    audit = {
        "metrics": result.metrics,
        "gap_connections": [
            {
                **{key: value for key, value in item.items() if key != "line_ref"},
                "coordinates_reference_slam": np.asarray(
                    item["line_ref"].coords, dtype=float
                ).tolist(),
            }
            for item in result.gap_inferred
        ],
        "corner_connections": [
            {
                **{key: value for key, value in item.items() if key != "line_ref"},
                "coordinates_reference_slam": np.asarray(
                    item["line_ref"].coords, dtype=float
                ).tolist(),
            }
            for item in result.corner_inferred
        ],
    }
    write_json(output_dir / "post_fusion_audit.json", audit)
    return {
        "final_merged_dxf": str(output_dir / "final_merged.dxf"),
        "final_merged_png": str(output_dir / "final_merged.png"),
        "postprocessed_merged_dxf": str(output_dir / "postprocessed_merged.dxf"),
        "postprocessed_merged_png": str(output_dir / "postprocessed_merged.png"),
        "maximum_union_postprocessed_comparison_png": str(
            output_dir / "maximum_union_postprocessed_comparison.png"
        ),
        "post_fusion_audit_json": str(output_dir / "post_fusion_audit.json"),
    }


def _export_morphology_reextract_outputs(
    output_dir: Path,
    result: MorphologyRevectorResult,
    source: PostFusionResult,
    transform_cad_from_ref: np.ndarray,
    clean_points: np.ndarray,
    display_grid_m: float,
) -> dict:
    document = _new_dxf()
    document.layers.add("MORPH_REEXTRACTED", color=7)
    document.layers.add("POST_FUSION_SOURCE", color=8)
    document.layers.get("POST_FUSION_SOURCE").off()
    layout = document.modelspace()
    for line in result.lines:
        _add_dxf_line(
            layout,
            _transform_line(line, transform_cad_from_ref),
            "MORPH_REEXTRACTED",
            [
                (1000, "source=dilate_erode_skeleton_revectorization"),
                (1000, "observed_semantics=postprocessed"),
            ],
        )
    for line in source.observed:
        _add_dxf_line(
            layout,
            _transform_line(line, transform_cad_from_ref),
            "POST_FUSION_SOURCE",
        )
    document.saveas(output_dir / "morphology_reextracted.dxf")
    document.saveas(output_dir / "final_morphology.dxf")

    cad_points = transform_points(clean_points, transform_cad_from_ref)
    cad_origin, cad_shape = _common_raster(cad_points, display_grid_m, 0.50)
    rotation = np.asarray(transform_cad_from_ref, dtype=float)[:2, :2]
    translation = np.asarray(transform_cad_from_ref, dtype=float)[:2, 3]
    source_center_origin = result.origin + 0.5 * result.grid_m
    affine = np.column_stack(
        [
            rotation * (result.grid_m / display_grid_m),
            (
                rotation @ source_center_origin
                + translation
                - cad_origin
            )
            / display_grid_m
            - 0.5,
        ]
    ).astype(np.float32)
    masks = (
        (result.input_mask, "1 INPUT RASTER", "morphology_input_mask.png"),
        (result.dilated_mask, "2 DILATION", "morphology_dilated_mask.png"),
        (result.closed_mask, "3 EROSION / CLOSED", "morphology_closed_mask.png"),
        (result.skeleton, "4 SKELETON", "morphology_skeleton.png"),
    )
    mask_panels = []
    for mask, label, filename in masks:
        cad_mask = cv2.warpAffine(
            mask,
            affine,
            (cad_shape[1], cad_shape[0]),
            flags=cv2.INTER_NEAREST,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )
        cad_mask = np.flipud(cad_mask).copy()
        cv2.imwrite(str(output_dir / filename), cad_mask)
        panel = cv2.cvtColor(cad_mask, cv2.COLOR_GRAY2BGR)
        cv2.putText(
            panel,
            label,
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            (40, 220, 255),
            2,
            cv2.LINE_AA,
        )
        mask_panels.append(panel)
    cv2.imwrite(str(output_dir / "morphology_process.png"), np.hstack(mask_panels))

    density = _density_base(cad_points, cad_origin, cad_shape, display_grid_m)
    background = cv2.cvtColor(
        np.clip(density * 0.22, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR
    )
    before = background.copy()
    after = background.copy()
    for line in source.observed:
        _draw_line(
            before,
            _transform_line(line, transform_cad_from_ref),
            cad_origin,
            display_grid_m,
            (225, 225, 225),
            2,
        )
    for value in [*source.gap_inferred, *source.corner_inferred]:
        _draw_patterned_line(
            before,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin,
            display_grid_m,
            (30, 220, 255),
            2,
        )
    for line in result.lines:
        _draw_line(
            after,
            _transform_line(line, transform_cad_from_ref),
            cad_origin,
            display_grid_m,
            (245, 245, 245),
            2,
        )
    before = np.flipud(before).copy()
    after = np.flipud(after).copy()
    labels = (
        "V9 GEOMETRIC POST-FUSION SOURCE",
        f"V10 MORPHOLOGY RE-EXTRACTED - {len(result.lines)} lines",
    )
    for image, label in ((before, labels[0]), (after, labels[1])):
        cv2.putText(
            image,
            label,
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            (245, 245, 245),
            2,
            cv2.LINE_AA,
        )
        _height_set_scale_bar(image, display_grid_m)
    cv2.imwrite(str(output_dir / "morphology_reextracted.png"), after)
    cv2.imwrite(
        str(output_dir / "postfusion_morphology_comparison.png"),
        np.hstack([before, after]),
    )
    write_json(
        output_dir / "morphology_reextract_audit.json",
        {
            "metrics": result.metrics,
            "line_coordinates_reference_slam": [
                np.asarray(value.coords, dtype=float).tolist() for value in result.lines
            ],
        },
    )
    return {
        "morphology_reextracted_dxf": str(output_dir / "morphology_reextracted.dxf"),
        "final_morphology_dxf": str(output_dir / "final_morphology.dxf"),
        "morphology_reextracted_png": str(output_dir / "morphology_reextracted.png"),
        "morphology_process_png": str(output_dir / "morphology_process.png"),
        "postfusion_morphology_comparison_png": str(
            output_dir / "postfusion_morphology_comparison.png"
        ),
        "morphology_reextract_audit_json": str(
            output_dir / "morphology_reextract_audit.json"
        ),
    }


def _reference_mask_to_cad(
    mask: np.ndarray,
    source_origin: np.ndarray,
    source_grid_m: float,
    transform_cad_from_ref: np.ndarray,
    cad_origin: np.ndarray,
    cad_shape: tuple[int, int],
    cad_grid_m: float,
) -> np.ndarray:
    rotation = np.asarray(transform_cad_from_ref, dtype=float)[:2, :2]
    translation = np.asarray(transform_cad_from_ref, dtype=float)[:2, 3]
    source_center_origin = source_origin + 0.5 * source_grid_m
    affine = np.column_stack(
        [
            rotation * (source_grid_m / cad_grid_m),
            (
                rotation @ source_center_origin + translation - cad_origin
            )
            / cad_grid_m
            - 0.5,
        ]
    ).astype(np.float32)
    return cv2.warpAffine(
        mask,
        affine,
        (cad_shape[1], cad_shape[0]),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )


def _export_thick_slice_outputs(
    output_dir: Path,
    slices: list[HeightSlice],
    intersection: list[LineString],
    union: list[dict],
    transform_cad_from_ref: np.ndarray,
    clean_points: np.ndarray,
    source_origin: np.ndarray,
    source_grid_m: float,
) -> dict:
    raw_dir = output_dir / "raw_slices_thick"
    calibrated_dir = output_dir / "calibrated_slices_thick"
    projection_dir = output_dir / "projections_thick"
    overlay_dir = output_dir / "overlays_after_thick"
    for directory in (raw_dir, calibrated_dir, projection_dir, overlay_dir):
        directory.mkdir(parents=True, exist_ok=True)
    for value in slices:
        name = f"thick_{value.index:02d}_{value.z_min_m:.2f}_{value.z_max_m:.2f}.dxf"
        _export_slice_dxf(
            raw_dir / name, value, transform_cad_from_ref, len(slices), calibrated=False
        )
        _export_slice_dxf(
            calibrated_dir / name, value, transform_cad_from_ref, len(slices), calibrated=True
        )

    minimum = _new_dxf()
    minimum.layers.add("THICK_MIN_INTERSECTION", color=3)
    for line in intersection:
        _add_dxf_line(
            minimum.modelspace(),
            _transform_line(line, transform_cad_from_ref),
            "THICK_MIN_INTERSECTION",
            [(1000, "scale=thick_1.00m"), (1000, "support=all_thick_windows")],
        )
    minimum.saveas(output_dir / "thick_minimum_intersection.dxf")
    maximum = _new_dxf()
    maximum.layers.add("THICK_MAX_UNION", color=7)
    for line in _merge_display_linework([value["line_ref"] for value in union]):
        _add_dxf_line(
            maximum.modelspace(),
            _transform_line(line, transform_cad_from_ref),
            "THICK_MAX_UNION",
            [(1000, "scale=thick_1.00m")],
        )
    maximum.saveas(output_dir / "thick_maximum_union.dxf")

    cad_points = transform_points(clean_points, transform_cad_from_ref)
    cad_origin, cad_shape = _common_raster(cad_points, source_grid_m, 0.50)
    density = _density_base(cad_points, cad_origin, cad_shape, source_grid_m)
    background = cv2.cvtColor(
        np.clip(density * 0.22, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR
    )
    panels = []
    for value in slices:
        cad_mask = _reference_mask_to_cad(
            value.mask,
            source_origin,
            source_grid_m,
            transform_cad_from_ref,
            cad_origin,
            cad_shape,
            source_grid_m,
        )
        projection = np.flipud(cad_mask).copy()
        cv2.imwrite(
            str(projection_dir / f"thick_{value.index:02d}_projection.png"), projection
        )
        overlay = background.copy()
        for line in value.calibrated_lines_ref:
            _draw_line(
                overlay,
                _transform_line(line, transform_cad_from_ref),
                cad_origin,
                source_grid_m,
                (245, 245, 245),
                2,
            )
        overlay = np.flipud(overlay).copy()
        cv2.putText(
            overlay,
            f"THICK {value.z_min_m:.2f}-{value.z_max_m:.2f} m",
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.60,
            (245, 245, 245),
            2,
            cv2.LINE_AA,
        )
        cv2.imwrite(
            str(overlay_dir / f"thick_{value.index:02d}_after.png"), overlay
        )
        panels.append(cv2.resize(overlay, (overlay.shape[1] // 2, overlay.shape[0] // 2)))
    if panels:
        rows = []
        columns = 3
        blank = np.zeros_like(panels[0])
        for start in range(0, len(panels), columns):
            row = panels[start : start + columns]
            rows.append(np.hstack([*row, *[blank] * (columns - len(row))]))
        cv2.imwrite(str(output_dir / "thick_slice_overview.png"), np.vstack(rows))

    for filename, values, color, label in (
        ("thick_minimum_intersection.png", intersection, (80, 255, 120), "THICK STRICT INTERSECTION"),
        (
            "thick_maximum_union.png",
            [value["line_ref"] for value in union],
            (245, 245, 245),
            "THICK MAXIMUM UNION",
        ),
    ):
        image = background.copy()
        for line in values:
            _draw_line(
                image,
                _transform_line(line, transform_cad_from_ref),
                cad_origin,
                source_grid_m,
                color,
                2,
            )
        image = np.flipud(image).copy()
        cv2.putText(
            image, label, (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.60,
            (245, 245, 245), 2, cv2.LINE_AA,
        )
        _height_set_scale_bar(image, source_grid_m)
        cv2.imwrite(str(output_dir / filename), image)
    return {
        "thick_minimum_intersection_dxf": str(output_dir / "thick_minimum_intersection.dxf"),
        "thick_maximum_union_dxf": str(output_dir / "thick_maximum_union.dxf"),
        "thick_minimum_intersection_png": str(output_dir / "thick_minimum_intersection.png"),
        "thick_maximum_union_png": str(output_dir / "thick_maximum_union.png"),
        "thick_slice_overview_png": str(output_dir / "thick_slice_overview.png"),
    }


def _closed_layout_record(value: dict) -> dict:
    def json_value(item):
        if isinstance(item, np.generic):
            return item.item()
        if isinstance(item, dict):
            return {str(key): json_value(value) for key, value in item.items()}
        if isinstance(item, (list, tuple)):
            return [json_value(value) for value in item]
        return item

    result = {
        key: json_value(item)
        for key, item in value.items()
        if key not in {"line_ref", "polygon_ref"}
    }
    if "line_ref" in value:
        result["coordinates_reference_slam"] = np.asarray(
            value["line_ref"].coords, dtype=float
        ).tolist()
    if "polygon_ref" in value:
        result["coordinates_reference_slam"] = np.asarray(
            value["polygon_ref"].exterior.coords, dtype=float
        ).tolist()
    return result


def _export_closed_layout_outputs(
    output_dir: Path,
    result: ClosedLayoutResult,
    morphology: MorphologyRevectorResult,
    thick_union: list[dict],
    transform_cad_from_ref: np.ndarray,
    clean_points: np.ndarray,
    display_grid_m: float,
    cfg: dict,
) -> dict:
    document = _new_dxf()
    document.layers.add("CLOSED_REGION", color=3)
    document.layers.add("OBSERVED_WALL", color=7)
    document.layers.add("INFERRED_WALL", color=30, linetype="DASHED")
    document.layers.add("DOOR_OPENING", color=5, linetype="DASHDOT")
    document.layers.add("UNKNOWN_DETAIL", color=8)
    document.layers.add("THICK_SCALE_SUPPORT", color=9)
    document.layers.get("UNKNOWN_DETAIL").off()
    document.layers.get("THICK_SCALE_SUPPORT").off()
    layout = document.modelspace()
    for region in result.regions:
        line = _transform_line(
            LineString(region["polygon_ref"].exterior.coords), transform_cad_from_ref
        )
        entity = layout.add_lwpolyline(
            list(line.coords)[:-1],
            close=True,
            dxfattribs={"layer": "CLOSED_REGION"},
        )
        entity.set_xdata(
            "LIDAR2OUTLINE",
            [
                (1000, f"region_id={region['region_id']}"),
                (1000, f"area_m2={region['area_m2']:.3f}"),
                (
                    1000,
                    f"observed_perimeter_fraction={region['observed_perimeter_fraction']:.4f}",
                ),
                (
                    1000,
                    f"inferred_perimeter_fraction={region['inferred_perimeter_fraction']:.4f}",
                ),
            ],
        )
    for line in result.observed_lines:
        _add_dxf_line(
            layout,
            _transform_line(line, transform_cad_from_ref),
            "OBSERVED_WALL",
            [(1000, "source=multiscale_regularized_observation")],
        )
    for values, layer in (
        (result.inferred_walls, "INFERRED_WALL"),
        (result.openings, "DOOR_OPENING"),
    ):
        for value in values:
            entity = _add_dxf_line(
                layout,
                _transform_line(value["line_ref"], transform_cad_from_ref),
                layer,
                [
                    (1000, f"candidate_id={value['candidate_id']}"),
                    (1000, f"kind={value['kind']}"),
                    (1000, f"score={value['score']:.4f}"),
                    (1000, f"point_fraction={value['point_fraction']:.4f}"),
                    (1000, f"thick_fraction={value['thick_fraction']:.4f}"),
                    (1000, "inferred=true"),
                ],
            )
            entity.dxf.linetype = "DASHED" if layer == "INFERRED_WALL" else "DASHDOT"
    for line in morphology.lines:
        _add_dxf_line(
            layout, _transform_line(line, transform_cad_from_ref), "UNKNOWN_DETAIL"
        )
    for value in thick_union:
        _add_dxf_line(
            layout,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            "THICK_SCALE_SUPPORT",
        )
    closed_layout_path = output_dir / "closed_layout.dxf"
    document.saveas(closed_layout_path)

    # The default drafting deliverable follows the visually strongest observed
    # high-slice backbone.  Closure hypotheses stay available in
    # ``closed_layout.dxf`` as separate layers instead of competing with the
    # observed plan in the clean CAD file.
    observed_document = _new_dxf()
    observed_document.layers.add("OBSERVED_WALL", color=7)
    observed_layout = observed_document.modelspace()
    for line in result.observed_lines:
        _add_dxf_line(
            observed_layout,
            _transform_line(line, transform_cad_from_ref),
            "OBSERVED_WALL",
            [(1000, "source=high_slice_observed_backbone")],
        )
    observed_plan_path = output_dir / "final_observed_wall_plan.dxf"
    observed_document.saveas(observed_plan_path)

    # Re-open the actual delivery rather than trusting in-memory objects.  This
    # catches an exporter accidentally writing open polylines or a CAD round
    # trip producing an invalid ring.
    disk_document = ezdxf.readfile(closed_layout_path)
    disk_regions = [
        entity
        for entity in disk_document.modelspace().query("LWPOLYLINE")
        if entity.dxf.layer == "CLOSED_REGION"
    ]
    disk_closed_count = 0
    disk_valid_count = 0
    disk_self_intersection_count = 0
    for entity in disk_regions:
        coordinates = [
            (float(point[0]), float(point[1])) for point in entity.get_points()
        ]
        if bool(entity.closed):
            disk_closed_count += 1
        polygon = Polygon(coordinates) if len(coordinates) >= 3 else Polygon()
        if bool(entity.closed) and polygon.is_valid and polygon.area > 0:
            disk_valid_count += 1
        elif not polygon.is_empty and not polygon.is_valid:
            disk_self_intersection_count += 1
    result.metrics.update(
        {
            "closed_layout_disk_region_count": len(disk_regions),
            "closed_layout_disk_closed_region_count": disk_closed_count,
            "closed_layout_disk_valid_region_count": disk_valid_count,
            "closed_layout_disk_self_intersection_count": disk_self_intersection_count,
            "closed_layout_disk_all_regions_closed_valid": bool(
                disk_regions
                and disk_closed_count == len(disk_regions)
                and disk_valid_count == len(disk_regions)
                and disk_self_intersection_count == 0
            ),
        }
    )

    cad_points = transform_points(clean_points, transform_cad_from_ref)
    cad_origin, cad_shape = _common_raster(cad_points, display_grid_m, 0.50)
    density = _density_base(cad_points, cad_origin, cad_shape, display_grid_m)
    background = cv2.cvtColor(
        np.clip(density * 0.22, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR
    )
    observed_plan = background.copy()
    for line in result.observed_lines:
        _draw_line(
            observed_plan, _transform_line(line, transform_cad_from_ref), cad_origin,
            display_grid_m, (245, 245, 245), 2,
        )
    closed_overlay = observed_plan.copy()
    for value in result.inferred_walls:
        _draw_patterned_line(
            closed_overlay, _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin, display_grid_m, (30, 160, 255), 3, 0.12, 0.06,
        )
    for value in result.openings:
        _draw_patterned_line(
            closed_overlay, _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin, display_grid_m, (255, 120, 30), 3, 0.08, 0.05,
        )
    region_diagnostic = background.copy()
    for region in result.regions:
        _draw_line(
            region_diagnostic,
            _transform_line(
                LineString(region["polygon_ref"].exterior.coords), transform_cad_from_ref
            ),
            cad_origin,
            display_grid_m,
            (80, 255, 120),
            2,
        )
    region_diagnostic = np.flipud(region_diagnostic).copy()
    cv2.putText(
        region_diagnostic,
        f"CLOSED REGION DIAGNOSTIC - {len(result.regions)} valid polygons",
        (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (245, 245, 245), 2, cv2.LINE_AA,
    )
    _height_set_scale_bar(region_diagnostic, display_grid_m)
    cv2.imwrite(str(output_dir / "closed_regions_diagnostic.png"), region_diagnostic)
    final = np.flipud(observed_plan).copy()
    cv2.putText(
        final,
        (
            "FINAL OBSERVED WALL PLAN - "
            f"{len(result.observed_lines)} lines - high-slice backbone"
        ),
        (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (245, 245, 245), 2, cv2.LINE_AA,
    )
    _height_set_scale_bar(final, display_grid_m)
    cv2.imwrite(str(output_dir / "final_dxf.png"), final)
    closed_overlay = np.flipud(closed_overlay).copy()
    cv2.putText(
        closed_overlay,
        (
            f"CLOSED LAYOUT - {len(result.regions)} regions - "
            "white observed / orange inferred / blue opening"
        ),
        (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (245, 245, 245), 2, cv2.LINE_AA,
    )
    _height_set_scale_bar(closed_overlay, display_grid_m)
    cv2.imwrite(str(output_dir / "closed_layout.png"), closed_overlay)

    v10 = background.copy()
    for line in morphology.lines:
        _draw_line(
            v10, _transform_line(line, transform_cad_from_ref), cad_origin,
            display_grid_m, (245, 245, 245), 2,
        )
    v10 = np.flipud(v10).copy()
    points_panel = np.flipud(cv2.cvtColor(density, cv2.COLOR_GRAY2BGR)).copy()
    panels = [
        (points_panel, "CLEANED LIDAR"),
        (v10, "V10 MORPHOLOGY"),
        (final.copy(), "V12 HIGH-SLICE OBSERVED BACKBONE"),
    ]
    for panel, label in panels:
        cv2.putText(
            panel, label, (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.58,
            (245, 245, 245), 2, cv2.LINE_AA,
        )
        _height_set_scale_bar(panel, display_grid_m)
    comparison = np.hstack([value[0] for value in panels])
    cv2.imwrite(str(output_dir / "lidar_v10_v12_comparison.png"), comparison)
    # Keep the former artifact name as a compatibility alias for existing
    # manifests and reports; new callers should use the V12 name.
    cv2.imwrite(str(output_dir / "lidar_v10_v11_comparison.png"), comparison)

    selected_ids = {
        value["candidate_id"] for value in [*result.inferred_walls, *result.openings]
    }
    diagnostic = background.copy()
    for value in result.candidates:
        color = (30, 220, 255) if value["candidate_id"] in selected_ids else (90, 90, 90)
        _draw_line(
            diagnostic, _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin, display_grid_m, color, 1,
        )
    diagnostic = np.flipud(diagnostic).copy()
    cv2.putText(
        diagnostic, "CONNECTION CANDIDATES - yellow selected / gray rejected",
        (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (245, 245, 245), 2, cv2.LINE_AA,
    )
    cv2.imwrite(str(output_dir / "connection_candidates.png"), diagnostic)

    morphology_panels = []
    for name, mask in [("input", result.input_mask), *result.morphology_masks.items()]:
        cad_mask = _reference_mask_to_cad(
            mask, result.origin, result.grid_m, transform_cad_from_ref,
            cad_origin, cad_shape, display_grid_m,
        )
        cad_mask = np.flipud(cad_mask).copy()
        filename = f"closure_morph_{name.replace('.', '_')}m.png" if name != "input" else "closure_morph_input.png"
        cv2.imwrite(str(output_dir / filename), cad_mask)
        panel = cv2.cvtColor(cad_mask, cv2.COLOR_GRAY2BGR)
        cv2.putText(
            panel, name.upper(), (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.58,
            (40, 220, 255), 2, cv2.LINE_AA,
        )
        morphology_panels.append(panel)
    cv2.imwrite(str(output_dir / "closure_morphology_scales.png"), np.hstack(morphology_panels))

    skeleton_panels = []
    revector_features = []
    for name, skeleton in result.morphology_skeletons.items():
        cad_skeleton = _reference_mask_to_cad(
            skeleton,
            result.origin,
            result.grid_m,
            transform_cad_from_ref,
            cad_origin,
            cad_shape,
            display_grid_m,
        )
        cad_skeleton = np.flipud(cad_skeleton).copy()
        cv2.imwrite(
            str(output_dir / f"closure_skeleton_{name.replace('.', '_')}.png"),
            cad_skeleton,
        )
        panel = cv2.cvtColor(cad_skeleton, cv2.COLOR_GRAY2BGR)
        cv2.putText(
            panel,
            f"{name.upper()} SKELETON",
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.58,
            (40, 220, 255),
            2,
            cv2.LINE_AA,
        )
        skeleton_panels.append(panel)
        for line in result.morphology_vectors.get(name, []):
            revector_features.append(
                {
                    "type": "Feature",
                    "geometry": mapping(
                        _transform_line(line, transform_cad_from_ref)
                    ),
                    "properties": {
                        "class": "MORPHOLOGY_REVECTOR_CANDIDATE",
                        "scale": name,
                        "selected_directly": False,
                    },
                }
            )
    if skeleton_panels:
        cv2.imwrite(
            str(output_dir / "closure_skeleton_scales.png"),
            np.hstack(skeleton_panels),
        )
    write_json(
        output_dir / "closure_morphology_revector.geojson",
        {
            "type": "FeatureCollection",
            "description": (
                "Per-scale skeleton re-vectorization. These are proposal evidence; "
                "only scored topology candidates enter closed_layout.dxf."
            ),
            "features": revector_features,
        },
    )

    crop_outputs = {}
    for filename, bounds in cfg.get("closure_detail_crops_cad", {}).items():
        xmin, ymin, xmax, ymax = map(float, bounds)
        x0 = max(0, int(math.floor((xmin - cad_origin[0]) / display_grid_m)))
        x1 = min(cad_shape[1], int(math.ceil((xmax - cad_origin[0]) / display_grid_m)))
        y0 = max(0, int(math.floor(cad_shape[0] - (ymax - cad_origin[1]) / display_grid_m)))
        y1 = min(cad_shape[0], int(math.ceil(cad_shape[0] - (ymin - cad_origin[1]) / display_grid_m)))
        if x1 <= x0 or y1 <= y0:
            continue
        crop = comparison[y0:y1, np.hstack([
            np.arange(x0, x1),
            np.arange(x0, x1) + cad_shape[1],
            np.arange(x0, x1) + 2 * cad_shape[1],
        ])]
        cv2.imwrite(str(output_dir / filename), crop)
        crop_outputs[filename] = str(output_dir / filename)

    geojson_features = []
    for line in result.observed_lines:
        geojson_features.append({
            "type": "Feature",
            "geometry": mapping(_transform_line(line, transform_cad_from_ref)),
            "properties": {"class": "OBSERVED_WALL"},
        })
    for value in [*result.inferred_walls, *result.openings]:
        geojson_features.append({
            "type": "Feature",
            "geometry": mapping(_transform_line(value["line_ref"], transform_cad_from_ref)),
            "properties": {
                "class": "INFERRED_WALL" if value in result.inferred_walls else "DOOR_OPENING",
                **{key: item for key, item in value.items() if key not in {"line_ref", "endpoint_keys", "morphology_by_scale"}},
            },
        })
    for region in result.regions:
        ring = _transform_line(
            LineString(region["polygon_ref"].exterior.coords), transform_cad_from_ref
        )
        geojson_features.append({
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [[list(point) for point in ring.coords]]},
            "properties": {
                "class": "CLOSED_REGION",
                **{key: item for key, item in region.items() if key not in {"polygon_ref", "required_candidates"}},
            },
        })
    write_json(
        output_dir / "closed_layout.geojson",
        {
            "type": "FeatureCollection",
            "local_coordinate_system": {
                "units": "metre",
                "T_cad_reference_slam": np.asarray(transform_cad_from_ref).tolist(),
                "T_reference_slam_cad": np.linalg.inv(transform_cad_from_ref).tolist(),
            },
            "features": geojson_features,
        },
    )
    write_json(
        output_dir / "closed_layout_audit.json",
        {
            "metrics": result.metrics,
            "regions": [_closed_layout_record(value) for value in result.regions],
            "selected_inferred_walls": [_closed_layout_record(value) for value in result.inferred_walls],
            "selected_openings": [_closed_layout_record(value) for value in result.openings],
            "candidates": [_closed_layout_record(value) for value in result.candidates],
        },
    )
    return {
        "closed_layout_dxf": str(output_dir / "closed_layout.dxf"),
        "final_observed_wall_plan_dxf": str(
            output_dir / "final_observed_wall_plan.dxf"
        ),
        "closed_layout_png": str(output_dir / "closed_layout.png"),
        "closed_layout_geojson": str(output_dir / "closed_layout.geojson"),
        "closed_layout_audit_json": str(output_dir / "closed_layout_audit.json"),
        "lidar_v10_v11_comparison_png": str(output_dir / "lidar_v10_v11_comparison.png"),
        "lidar_v10_v12_comparison_png": str(output_dir / "lidar_v10_v12_comparison.png"),
        "connection_candidates_png": str(output_dir / "connection_candidates.png"),
        "closure_morphology_scales_png": str(output_dir / "closure_morphology_scales.png"),
        "closure_skeleton_scales_png": str(output_dir / "closure_skeleton_scales.png"),
        "closure_morphology_revector_geojson": str(
            output_dir / "closure_morphology_revector.geojson"
        ),
        "closed_regions_diagnostic_png": str(output_dir / "closed_regions_diagnostic.png"),
        **crop_outputs,
    }


def _read_dxf_lines(path: Path, layers: set[str] | None = None) -> list[LineString]:
    document = ezdxf.readfile(path)
    result = []
    for entity in document.modelspace().query("LWPOLYLINE"):
        if layers is not None and entity.dxf.layer not in layers:
            continue
        coordinates = [(float(point[0]), float(point[1])) for point in entity.get_points()]
        if len(coordinates) >= 2:
            result.append(LineString(coordinates))
    return result


def audit_exported_height_set(
    output_dir: Path,
    slices: list[HeightSlice],
    tolerance_m: float,
    robust_min_slice_count: int,
) -> dict:
    """Re-open all delivered DXFs and verify observed set algebra from disk."""
    calibrated = []
    strict = _read_dxf_lines(output_dir / "minimum_intersection.dxf")
    robust = _read_dxf_lines(output_dir / "robust_intersection.dxf")
    maximum = _read_dxf_lines(output_dir / "maximum_union.dxf")
    for value in slices:
        path = output_dir / "calibrated_slices" / (
            f"slice_{value.index:02d}_{value.z_min_m:.2f}_{value.z_max_m:.2f}.dxf"
        )
        calibrated.append(_read_dxf_lines(path))
    slice_geometries = [unary_union(value) for value in calibrated]
    slice_areas = [value.buffer(tolerance_m) for value in slice_geometries]
    strict_unsupported = 0.0
    for line in strict:
        for support in slice_areas:
            strict_unsupported += float(line.difference(support).length)
    observed_geometry = unary_union(
        [line for values in calibrated for line in values]
    )
    maximum_geometry = unary_union(maximum)
    robust_geometry = unary_union(robust)
    maximum_missing = float(
        observed_geometry.difference(maximum_geometry.buffer(tolerance_m)).length
    )
    maximum_extra = float(
        maximum_geometry.difference(observed_geometry.buffer(tolerance_m)).length
    )
    robust_extra = float(
        robust_geometry.difference(maximum_geometry.buffer(tolerance_m)).length
    )
    robust_document = ezdxf.readfile(output_dir / "robust_intersection.dxf")
    robust_support_violations = 0
    for entity in robust_document.modelspace().query("LWPOLYLINE"):
        values = {}
        if entity.has_xdata("LIDAR2OUTLINE"):
            for tag in entity.get_xdata("LIDAR2OUTLINE"):
                text = str(tag.value)
                if "=" in text:
                    key, item = text.split("=", 1)
                    values[key] = item
        observed = [
            value
            for value in values.get("observed_slice_indices", "").split(",")
            if value
        ]
        if len(observed) < robust_min_slice_count:
            robust_support_violations += 1
    combined = ezdxf.readfile(output_dir / "height_aware_combined.dxf")
    inferred_in_observed_layers = sum(
        entity.dxf.layer == "MAX_UNION"
        and any(
            str(tag.value).lower() in {
                "class=inferred_connection",
                "observed=false",
            }
            for tag in (
                entity.get_xdata("LIDAR2OUTLINE")
                if entity.has_xdata("LIDAR2OUTLINE")
                else []
            )
        )
        for entity in combined.modelspace().query("LWPOLYLINE")
    )
    result = {
        "slice_count": len(calibrated),
        "strict_intersection_unsupported_length_m": strict_unsupported,
        "maximum_union_missing_observed_length_m": maximum_missing,
        "maximum_union_extra_length_m": maximum_extra,
        "robust_intersection_extra_length_m": robust_extra,
        "robust_intersection_support_violation_count": int(
            robust_support_violations
        ),
        "robust_intersection_min_slice_count": int(robust_min_slice_count),
        "inferred_entity_in_observed_layer_count": int(inferred_in_observed_layers),
        "tolerance_m": tolerance_m,
    }
    write_json(output_dir / "height_set_disk_audit.json", result)
    return result


def audit_shared_wall_outputs(
    output_dir: Path,
    intersection: list[LineString],
    union: list[dict],
    transform_cad_from_ref: np.ndarray,
    tolerance_m: float,
) -> dict:
    path = output_dir / "calibrated_common.dxf"
    document = ezdxf.readfile(path)
    observed = _read_dxf_lines(path, {"COMMON_ALL_OBSERVED"})
    inferred = _read_dxf_lines(path, {"COMMON_INFERRED"})
    strict_cad = [
        _transform_line(value, transform_cad_from_ref) for value in intersection
    ]
    union_cad = [
        _transform_line(value["line_ref"], transform_cad_from_ref) for value in union
    ]
    observed_geometry = unary_union(observed)
    strict_geometry = unary_union(strict_cad)
    union_geometry = unary_union(union_cad)
    inferred_geometry = unary_union(inferred)
    observed_missing = float(
        strict_geometry.difference(observed_geometry.buffer(tolerance_m)).length
    )
    observed_extra = float(
        observed_geometry.difference(strict_geometry.buffer(tolerance_m)).length
    )
    inferred_outside_union = float(
        inferred_geometry.difference(union_geometry.buffer(tolerance_m)).length
    )
    inferred_in_observed = 0
    for entity in document.modelspace().query("LWPOLYLINE"):
        if entity.dxf.layer != "COMMON_ALL_OBSERVED":
            continue
        if entity.has_xdata("LIDAR2OUTLINE") and any(
            str(tag.value).startswith("inferred_slice_indices=")
            and str(tag.value) != "inferred_slice_indices="
            for tag in entity.get_xdata("LIDAR2OUTLINE")
        ):
            inferred_in_observed += 1
    result = {
        "strict_common_missing_length_m": observed_missing,
        "strict_common_extra_length_m": observed_extra,
        "inferred_common_outside_observed_union_length_m": inferred_outside_union,
        "inferred_entity_in_observed_common_layer_count": int(inferred_in_observed),
        "common_observed_entity_count": len(observed),
        "common_inferred_entity_count": len(inferred),
        "tolerance_m": tolerance_m,
    }
    write_json(output_dir / "shared_wall_audit.json", result)
    return result


def _draw_line(image: np.ndarray, line: LineString, origin: np.ndarray, grid_m: float, color, width=1):
    pixels = np.rint((np.asarray(line.coords) - origin) / grid_m - 0.5).astype(np.int32)
    cv2.polylines(image, [pixels], False, color, width, cv2.LINE_AA)


def _draw_patterned_line(
    image: np.ndarray,
    line: LineString,
    origin: np.ndarray,
    grid_m: float,
    color,
    width: int = 1,
    dash_m: float = 0.14,
    gap_m: float = 0.10,
) -> None:
    if line.length <= 1e-9:
        return
    value = 0.0
    while value < line.length:
        end = min(line.length, value + dash_m)
        segment = LineString([line.interpolate(value).coords[0], line.interpolate(end).coords[0]])
        _draw_line(image, segment, origin, grid_m, color, width)
        value += dash_m + gap_m


def _density_base(points: np.ndarray, origin: np.ndarray, shape: tuple[int, int], grid_m: float) -> np.ndarray:
    density = np.zeros(shape, np.uint32)
    ij = np.floor((points[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0) & (ij[:, 1] >= 0) & (ij[:, 0] < shape[1]) & (ij[:, 1] < shape[0])
    )
    np.add.at(density, (ij[valid, 1], ij[valid, 0]), 1)
    log_density = np.log1p(density.astype(np.float32))
    nonzero = log_density[log_density > 0]
    log_density /= max(float(np.quantile(nonzero, 0.99)) if len(nonzero) else 1.0, 1e-6)
    return np.clip(log_density * 180, 0, 180).astype(np.uint8)


def _state_bgr(value: dict) -> tuple[int, int, int]:
    return {
        "full_observed": (255, 255, 255),
        "lower_observed": (40, 60, 255),
        "upper_observed": (220, 40, 220),
        "partial_observed": (80, 230, 80),
    }.get(value.get("height_state"), (170, 170, 170))


def _height_set_scale_bar(image: np.ndarray, grid_m: float, length_m: float = 10.0) -> None:
    x0, y0 = 24, image.shape[0] - 28
    x1 = min(image.shape[1] - 24, x0 + int(round(length_m / grid_m)))
    cv2.line(image, (x0, y0), (x1, y0), (245, 245, 245), 3, cv2.LINE_AA)
    cv2.putText(
        image,
        f"{length_m:g} m",
        (x0, y0 - 8),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.48,
        (245, 245, 245),
        1,
        cv2.LINE_AA,
    )


def render_height_set_images(
    output_dir: Path,
    cad_points: np.ndarray,
    strict_lines_cad: list[LineString],
    robust_lines_cad: list[LineString],
    union_lines_cad: list[LineString],
    grid_m: float,
    padding_m: float = 0.50,
) -> dict:
    """Render strict intersection and observed maximum union at one CAD scale."""
    output_dir.mkdir(parents=True, exist_ok=True)
    cad_origin, cad_shape = _common_raster(cad_points, grid_m, padding_m)
    density = _density_base(cad_points, cad_origin, cad_shape, grid_m)
    background = cv2.cvtColor(
        np.clip(density * 0.30, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR
    )

    strict_raw = background.copy()
    robust_raw = background.copy()
    union_raw = background.copy()
    overlay_raw = background.copy()
    for line in union_lines_cad:
        _draw_line(union_raw, line, cad_origin, grid_m, (245, 245, 245), 2)
        _draw_line(overlay_raw, line, cad_origin, grid_m, (155, 155, 155), 1)
    for line in robust_lines_cad:
        _draw_line(robust_raw, line, cad_origin, grid_m, (255, 190, 50), 3)
        _draw_line(overlay_raw, line, cad_origin, grid_m, (255, 190, 50), 3)
    for line in strict_lines_cad:
        _draw_line(strict_raw, line, cad_origin, grid_m, (80, 255, 120), 3)
        _draw_line(overlay_raw, line, cad_origin, grid_m, (80, 255, 120), 3)

    # The source raster indexes rows downward; flip before adding labels so the
    # delivered images use the same Y-up convention as CAD/DXF.
    strict = np.flipud(strict_raw).copy()
    robust = np.flipud(robust_raw).copy()
    maximum = np.flipud(union_raw).copy()
    overlay = np.flipud(overlay_raw).copy()
    strict_length = float(sum(line.length for line in strict_lines_cad))
    robust_length = float(sum(line.length for line in robust_lines_cad))
    union_length = float(sum(line.length for line in union_lines_cad))
    labels = [
        f"STRICT INTERSECTION - {len(strict_lines_cad)} lines - {strict_length:.1f} m",
        f"ROBUST INTERSECTION - {len(robust_lines_cad)} lines - {robust_length:.1f} m",
        f"MAXIMUM OBSERVED UNION - {len(union_lines_cad)} lines - {union_length:.1f} m",
        "OVERLAY - green=9/9 - cyan=robust quorum - gray=at least 1/9",
    ]
    for image, label in zip((strict, robust, maximum, overlay), labels):
        cv2.putText(
            image,
            label,
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            (245, 245, 245),
            2,
            cv2.LINE_AA,
        )
        _height_set_scale_bar(image, grid_m)
    cv2.imwrite(str(output_dir / "minimum_intersection.png"), strict)
    cv2.imwrite(str(output_dir / "robust_intersection.png"), robust)
    cv2.imwrite(str(output_dir / "maximum_union.png"), maximum)
    cv2.imwrite(
        str(output_dir / "intersection_union_comparison.png"),
        np.hstack([strict, robust, maximum, overlay]),
    )
    return {
        "minimum_intersection_png": str(output_dir / "minimum_intersection.png"),
        "robust_intersection_png": str(output_dir / "robust_intersection.png"),
        "maximum_union_png": str(output_dir / "maximum_union.png"),
        "intersection_union_comparison_png": str(
            output_dir / "intersection_union_comparison.png"
        ),
    }


def _support_matrix_image(records: list[dict], slice_count: int) -> np.ndarray:
    colors = {
        "unknown": (35, 35, 35),
        "observed": (245, 245, 245),
        "recovered": (255, 190, 50),
        "inferred": (30, 220, 255),
    }
    states = []
    separators = []
    cursor = 0
    for record in records:
        value = np.asarray(record.get("states", []), dtype=object)
        if value.shape[0] != slice_count or value.shape[1] == 0:
            continue
        states.append(value)
        cursor += value.shape[1]
        separators.append(cursor)
    if not states:
        return np.zeros((360, 960, 3), dtype=np.uint8)
    matrix = np.hstack(states)
    maximum_width = 2400
    if matrix.shape[1] > maximum_width:
        indices = np.minimum(
            matrix.shape[1] - 1,
            np.floor(np.linspace(0, matrix.shape[1], maximum_width, endpoint=False)).astype(int),
        )
        matrix = matrix[:, indices]
        separators = [int(round(value * maximum_width / len(np.hstack(states).T))) for value in separators]
    cell_height = 54
    image = np.zeros((slice_count * cell_height + 92, matrix.shape[1] + 150, 3), dtype=np.uint8)
    for row in range(slice_count):
        y0 = 50 + (slice_count - 1 - row) * cell_height
        for column, state in enumerate(matrix[row]):
            image[y0 : y0 + cell_height, 135 + column] = colors.get(str(state), colors["unknown"])
        cv2.putText(
            image,
            f"slice {row:02d}",
            (18, y0 + 34),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (230, 230, 230),
            1,
            cv2.LINE_AA,
        )
    for boundary in separators[:-1]:
        x = 135 + min(matrix.shape[1] - 1, boundary)
        cv2.line(image, (x, 50), (x, 50 + slice_count * cell_height), (90, 90, 90), 1)
    cv2.putText(
        image,
        "SHARED WALL SUPPORT - white=original  cyan=point recovered  yellow=inferred  dark=unknown",
        (18, 28),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.58,
        (245, 245, 245),
        2,
        cv2.LINE_AA,
    )
    return image


def _export_shared_wall_outputs(
    output_dir: Path,
    recovery: SharedWallRecovery,
    architectural_inferred: list[dict],
    transform_cad_from_ref: np.ndarray,
    clean_points_ref: np.ndarray,
    bootstrap_intersection: list[LineString],
    prior_intersection: list[LineString],
    grid_m: float,
    cfg: dict,
) -> dict:
    raw_union = recovery.raw_union or recovery.union
    raw_document = _new_dxf()
    raw_document.layers.add("RAW_OBSERVED_UNION", color=8)
    for value in raw_union:
        _add_dxf_line(
            raw_document.modelspace(),
            _transform_line(value["line_ref"], transform_cad_from_ref),
            "RAW_OBSERVED_UNION",
            _segment_xdata(value),
        )
    raw_document.saveas(output_dir / "raw_observed_union.dxf")

    document = _new_dxf()
    document.layers.add("COMMON_ALL_OBSERVED", color=3)
    document.layers.add("COMMON_INFERRED", color=2, linetype="DASHED")
    document.layers.add("INFERRED_CONNECTION", color=6, linetype="DASHED")
    layout = document.modelspace()
    for value in recovery.calibrated_common:
        layer = (
            "COMMON_INFERRED"
            if value.get("inferred_slice_indices")
            else "COMMON_ALL_OBSERVED"
        )
        entity = _add_dxf_line(
            layout,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            layer,
            _segment_xdata(value),
        )
        entity.dxf.lineweight = 35
    for index, value in enumerate(architectural_inferred):
        line = value.get("line_ref")
        if line is None or line.length > float(
            cfg.get("architectural_collinear_gap_max_m", 0.80)
        ):
            continue
        _add_dxf_line(
            layout,
            _transform_line(line, transform_cad_from_ref),
            "INFERRED_CONNECTION",
            [
                (1000, f"segment_id=ARCH_INF_{index:04d}"),
                (1000, "observed=false"),
                (1000, "reason=point_supported_shared_wall_connection"),
            ],
        )
    document.saveas(output_dir / "calibrated_common.dxf")

    features = []
    structural_segment_ids = {
        str(value.get("segment_id", "")) for value in recovery.union
    }
    for value in raw_union:
        features.append(
            {
                "type": "Feature",
                "geometry": mapping(
                    _transform_line(value["line_ref"], transform_cad_from_ref)
                ),
                "properties": {
                    "class": "SHARED_WALL_SEGMENT",
                    "included_in_structural_union": str(
                        value.get("segment_id", "")
                    )
                    in structural_segment_ids,
                    **{
                        key: item
                        for key, item in value.items()
                        if key not in {"line_ref", "group"}
                    },
                },
            }
        )
    write_json(
        output_dir / "shared_wall_model.geojson",
        {
            "type": "FeatureCollection",
            "local_coordinate_system": {
                "units": "metre",
                "T_cad_reference_slam": np.asarray(transform_cad_from_ref).tolist(),
                "T_reference_slam_cad": np.linalg.inv(transform_cad_from_ref).tolist(),
            },
            "shared_wall_graph": {
                "node_count": 0 if recovery.graph is None else len(recovery.graph.nodes),
                "nodes_reference_slam": {}
                if recovery.graph is None
                else recovery.graph.nodes,
            },
            "features": features,
        },
    )
    write_json(
        output_dir / "support_matrix.json",
        {
            "sample_step_m": recovery.metrics.get("shared_wall_sample_step_m"),
            "states": ["observed", "recovered", "inferred", "unknown"],
            "walls": recovery.support_records,
        },
    )
    cv2.imwrite(
        str(output_dir / "support_matrix.png"),
        _support_matrix_image(
            recovery.support_records,
            max(
                (
                    len(value.get("states", []))
                    for value in recovery.support_records
                ),
                default=0,
            ),
        ),
    )

    cad_points = transform_points(clean_points_ref, transform_cad_from_ref)
    origin, shape = _common_raster(
        cad_points, grid_m, float(cfg.get("raster_padding_m", 0.50))
    )
    density = _density_base(cad_points, origin, shape, grid_m)
    background = cv2.cvtColor(
        np.clip(density * 0.30, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR
    )
    raw_image = background.copy()
    for value in raw_union:
        _draw_line(
            raw_image,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            origin,
            grid_m,
            (165, 165, 165),
            1,
        )
    raw_image = np.flipud(raw_image).copy()
    cv2.putText(
        raw_image,
        "RAW OBSERVED CANDIDATES - audit only - includes uncertain detail",
        (14, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.60,
        (245, 245, 245),
        2,
        cv2.LINE_AA,
    )
    _height_set_scale_bar(raw_image, grid_m)
    cv2.imwrite(str(output_dir / "raw_observed_union.png"), raw_image)
    common_image = background.copy()
    for value in recovery.calibrated_common:
        line = _transform_line(value["line_ref"], transform_cad_from_ref)
        if value.get("inferred_slice_indices"):
            _draw_patterned_line(common_image, line, origin, grid_m, (30, 220, 255), 3)
        else:
            _draw_line(common_image, line, origin, grid_m, (80, 255, 120), 3)
    common_image = np.flipud(common_image).copy()
    cv2.putText(
        common_image,
        "CALIBRATED COMMON - green=all observed - yellow=evidence constrained inference",
        (14, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.60,
        (245, 245, 245),
        2,
        cv2.LINE_AA,
    )
    _height_set_scale_bar(common_image, grid_m)
    cv2.imwrite(str(output_dir / "calibrated_common.png"), common_image)

    point_panel = np.flipud(cv2.cvtColor(density, cv2.COLOR_GRAY2BGR)).copy()
    old_panel = background.copy()
    new_panel = background.copy()
    comparison_reference = prior_intersection or bootstrap_intersection
    for line in comparison_reference:
        _draw_line(
            old_panel,
            _transform_line(line, transform_cad_from_ref),
            origin,
            grid_m,
            (80, 255, 120),
            3,
        )
    for line in recovery.intersection:
        _draw_line(
            new_panel,
            _transform_line(line, transform_cad_from_ref),
            origin,
            grid_m,
            (255, 190, 50),
            3,
        )
    old_panel = np.flipud(old_panel).copy()
    new_panel = np.flipud(new_panel).copy()
    labels = (
        "CLEANED LIDAR",
        f"V7 STRICT - {sum(line.length for line in comparison_reference):.1f} m",
        f"V8 STRICT - {sum(line.length for line in recovery.intersection):.1f} m",
    )
    for image, label in zip((point_panel, old_panel, new_panel), labels):
        cv2.putText(
            image,
            label,
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.60,
            (245, 245, 245),
            2,
            cv2.LINE_AA,
        )
        _height_set_scale_bar(image, grid_m)
    cv2.imwrite(
        str(output_dir / "v7_v8_intersection_comparison.png"),
        np.hstack([point_panel, old_panel, new_panel]),
    )
    return {
        "raw_observed_union_dxf": str(output_dir / "raw_observed_union.dxf"),
        "raw_observed_union_png": str(output_dir / "raw_observed_union.png"),
        "calibrated_common_dxf": str(output_dir / "calibrated_common.dxf"),
        "calibrated_common_png": str(output_dir / "calibrated_common.png"),
        "shared_wall_model_geojson": str(output_dir / "shared_wall_model.geojson"),
        "support_matrix_json": str(output_dir / "support_matrix.json"),
        "support_matrix_png": str(output_dir / "support_matrix.png"),
        "v7_v8_intersection_comparison_png": str(
            output_dir / "v7_v8_intersection_comparison.png"
        ),
    }


def _render_outputs(
    output_dir: Path,
    clean_points: np.ndarray,
    origin: np.ndarray,
    shape: tuple[int, int],
    grid_m: float,
    slices: list[HeightSlice],
    intersection: list[LineString],
    robust_intersection: list[dict],
    union: list[dict],
    transform_cad_from_ref: np.ndarray,
    cfg: dict,
) -> None:
    del origin, shape
    cad_points = transform_points(clean_points, transform_cad_from_ref)
    cad_origin, cad_shape = _common_raster(
        cad_points, grid_m, float(cfg.get("raster_padding_m", 0.50))
    )
    base = _density_base(cad_points, cad_origin, cad_shape, grid_m)
    cv2.imwrite(str(output_dir / "clean_interior_projection.png"), np.flipud(base))
    projection_dir = output_dir / "projections"
    before_dir = output_dir / "overlays_before"
    after_dir = output_dir / "overlays_after"
    for directory in (projection_dir, before_dir, after_dir):
        directory.mkdir(parents=True, exist_ok=True)

    panels = []
    overall_before = cv2.cvtColor(np.clip(base * 0.35, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR)
    overall_after = overall_before.copy()
    for height_slice in slices:
        band = cad_points[
            (cad_points[:, 2] >= height_slice.z_min_m)
            & (cad_points[:, 2] < height_slice.z_max_m)
        ]
        projection = _density_base(band, cad_origin, cad_shape, grid_m)
        pure = cv2.cvtColor(projection, cv2.COLOR_GRAY2BGR)
        before = pure.copy()
        after = pure.copy()
        color = tuple(int(value) for value in np.asarray(colorsys.hsv_to_rgb(height_slice.index / max(1, len(slices)), 0.8, 1.0)) * 255)
        color = (color[2], color[1], color[0])
        for line in height_slice.raw_lines_ref:
            cad_line = _transform_line(line, transform_cad_from_ref)
            _draw_line(before, cad_line, cad_origin, grid_m, color, 2)
            _draw_line(overall_before, cad_line, cad_origin, grid_m, color, 1)
        for line in height_slice.calibrated_lines_ref:
            cad_line = _transform_line(line, transform_cad_from_ref)
            _draw_line(after, cad_line, cad_origin, grid_m, color, 2)
            _draw_line(overall_after, cad_line, cad_origin, grid_m, color, 1)
        pure = np.flipud(pure).copy()
        before = np.flipud(before).copy()
        after = np.flipud(after).copy()
        label = f"{height_slice.index:02d}: {height_slice.z_min_m:.2f}-{height_slice.z_max_m:.2f} m"
        for image in (pure, before, after):
            cv2.putText(image, label, (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (245, 245, 245), 2, cv2.LINE_AA)
        panels.append(after)
        cv2.imwrite(str(projection_dir / f"slice_{height_slice.index:02d}_projection.png"), pure)
        cv2.imwrite(str(before_dir / f"slice_{height_slice.index:02d}_before.png"), before)
        cv2.imwrite(str(after_dir / f"slice_{height_slice.index:02d}_after.png"), after)
        cv2.imwrite(str(output_dir / f"slice_{height_slice.index:02d}_projection.png"), pure)
    if panels:
        target_width = 520
        resized = [
            cv2.resize(value, (target_width, max(1, int(value.shape[0] * target_width / value.shape[1]))))
            for value in panels
        ]
        panel_h = resized[0].shape[0]
        columns = 3
        rows = int(math.ceil(len(resized) / columns))
        overview = np.zeros((rows * panel_h, columns * target_width, 3), np.uint8)
        for index, panel in enumerate(resized):
            row, column = divmod(index, columns)
            overview[row * panel_h : (row + 1) * panel_h, column * target_width : (column + 1) * target_width] = panel
        cv2.imwrite(str(output_dir / "slice_overview.png"), overview)

    overall_before = np.flipud(overall_before).copy()
    overall_after = np.flipud(overall_after).copy()
    comparison = np.hstack([overall_before, overall_after])
    cv2.putText(comparison, "BEFORE CALIBRATION", (14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.70, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(comparison, "AFTER CALIBRATION", (overall_before.shape[1] + 14, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.70, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.imwrite(str(output_dir / "calibration_before_after.png"), comparison)
    height, width = overall_before.shape[:2]
    crop_specs = {
        "detail_top_annex.png": (0, int(height * 0.40), int(width * 0.35), width),
        "detail_central_junctions.png": (
            int(height * 0.28),
            int(height * 0.72),
            int(width * 0.20),
            int(width * 0.72),
        ),
        "detail_oblique_wall.png": (
            int(height * 0.55),
            int(height * 0.92),
            int(width * 0.18),
            int(width * 0.70),
        ),
    }
    for filename, (row_start, row_end, column_start, column_end) in crop_specs.items():
        crop = np.hstack(
            [
                overall_before[row_start:row_end, column_start:column_end],
                overall_after[row_start:row_end, column_start:column_end],
            ]
        )
        cv2.imwrite(str(output_dir / filename), crop)

    canvas = cv2.cvtColor(np.clip(base * 0.45, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR)
    for value in union:
        _draw_line(
            canvas,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin,
            grid_m,
            _state_bgr(value),
            2,
        )
        cad_line = _transform_line(value["line_ref"], transform_cad_from_ref)
        if value["inferred_slice_indices"]:
            _draw_patterned_line(canvas, cad_line, cad_origin, grid_m, (40, 210, 255), 2)
        if value["unknown_slice_indices"]:
            _draw_patterned_line(
                canvas, cad_line, cad_origin, grid_m, (145, 145, 145), 1, 0.05, 0.16
            )
    for line in intersection:
        _draw_line(canvas, _transform_line(line, transform_cad_from_ref), cad_origin, grid_m, (255, 255, 255), 3)
    canvas = np.flipud(canvas).copy()
    cv2.putText(
        canvas,
        "Observed: red=lower, magenta=upper, green=partial; yellow dash=inferred; gray dot=unknown; white=all",
        (14, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.64,
        (245, 245, 245),
        2,
        cv2.LINE_AA,
    )
    cv2.imwrite(str(output_dir / "height_consensus.png"), canvas)

    render_height_set_images(
        output_dir,
        cad_points,
        [
            _transform_line(line, transform_cad_from_ref)
            for line in intersection
        ],
        [
            _transform_line(value["line_ref"], transform_cad_from_ref)
            for value in robust_intersection
        ],
        [
            _transform_line(line, transform_cad_from_ref)
            for line in _merge_display_linework(
                [value["line_ref"] for value in union]
            )
        ],
        grid_m,
        float(cfg.get("raster_padding_m", 0.50)),
    )

    final_canvas = np.zeros_like(canvas)
    for value in union:
        _draw_line(
            final_canvas,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            cad_origin,
            grid_m,
            _state_bgr(value),
            2,
        )
        cad_line = _transform_line(value["line_ref"], transform_cad_from_ref)
        if value["inferred_slice_indices"]:
            _draw_patterned_line(final_canvas, cad_line, cad_origin, grid_m, (40, 210, 255), 2)
        if value["unknown_slice_indices"]:
            _draw_patterned_line(
                final_canvas, cad_line, cad_origin, grid_m, (145, 145, 145), 1, 0.05, 0.16
            )
    for line in intersection:
        _draw_line(final_canvas, _transform_line(line, transform_cad_from_ref), cad_origin, grid_m, (255, 255, 255), 3)
    cv2.imwrite(str(output_dir / "final_dxf.png"), np.flipud(final_canvas))


def run_height_slice_stage(
    points_ref: np.ndarray,
    transform_cad_from_ref: np.ndarray,
    ceiling_hint_m: float | None,
    main_angle: float,
    output_dir: str | Path,
    cfg: dict,
    vector_cfg: dict,
    session_points_ref: list[tuple[str, np.ndarray]] | None = None,
    semantic_objects_cad: list[dict] | None = None,
    reuse_from: str | Path | None = None,
) -> dict:
    """Create calibrated sliding-height LiDAR DXFs and height consensus."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    raw_slices_dir = output_dir / "raw_slices"
    calibrated_slices_dir = output_dir / "calibrated_slices"
    masks_dir = output_dir / "masks"
    session_dir = output_dir / "clean_sessions"
    for directory in (raw_slices_dir, calibrated_slices_dir, masks_dir, session_dir):
        directory.mkdir(parents=True, exist_ok=True)
    reuse_dir = None if reuse_from is None else Path(reuse_from)
    reuse_summary = None
    if reuse_dir is not None:
        summary_path = reuse_dir / "summary.json"
        clean_path = reuse_dir / "clean_interior.pcd"
        if not summary_path.is_file() or not clean_path.is_file():
            raise ValueError(
                f"Reusable height-slice data is incomplete: {reuse_dir}"
            )
        reuse_summary = read_json(summary_path)
        prior_metrics = reuse_summary.get("metrics", {})
        floor_m = float(prior_metrics["height_floor_m"])
        ceiling_m = float(prior_metrics["height_ceiling_m"])
        clean_points = read_point_cloud(clean_path)
        detection_metrics = {
            key: value
            for key, value in prior_metrics.items()
            if key.startswith("floor_")
            or key.startswith("ceiling_")
            or key in {"floor_detection", "ceiling_detection"}
        }
        detection_metrics["height_reused_from"] = str(reuse_dir.resolve())
        filter_metrics = {
            key: value
            for key, value in prior_metrics.items()
            if key.startswith("volume_")
            or key.startswith("removed_")
            or key.endswith("_removed_points")
        }
        write_point_cloud(output_dir / "clean_interior.pcd", clean_points)
        prior_profile = reuse_dir / "height_density_profile.json"
        if prior_profile.is_file():
            write_json(
                output_dir / "height_density_profile.json", read_json(prior_profile)
            )
        else:
            write_json(
                output_dir / "height_density_profile.json",
                _height_density_profile(points_ref, floor_m, ceiling_m, cfg),
            )
        clean_session_points = []
        for name, _ in session_points_ref or []:
            path = reuse_dir / "clean_sessions" / f"{name}.pcd"
            if path.is_file():
                selected = read_point_cloud(path)
                clean_session_points.append((name, selected))
                write_point_cloud(session_dir / f"{name}.pcd", selected)
        if not clean_session_points:
            clean_session_points = [("combined", clean_points)]
        session_clean_counts = {
            name: int(len(values)) for name, values in clean_session_points
        }
    else:
        floor_m, ceiling_m, detection_metrics = _detect_floor_ceiling(
            points_ref, ceiling_hint_m, cfg
        )
        filter_cfg = dict(cfg)
        if detection_metrics.get("floor_plane"):
            filter_cfg["_floor_plane_coefficients"] = detection_metrics["floor_plane"][
                "coefficients"
            ]
        if detection_metrics.get("ceiling_plane"):
            filter_cfg["_ceiling_plane_coefficients"] = detection_metrics["ceiling_plane"][
                "coefficients"
            ]
        clean_points, filter_metrics, filter_reasons = _filter_interior_volume_detailed(
            points_ref, floor_m, ceiling_m, filter_cfg
        )
        write_point_cloud(output_dir / "clean_interior.pcd", clean_points)
        reason_outputs = {
            "floor_boundary": 1,
            "ceiling_boundary": 2,
            "residual_horizontal": 3,
            "sparse_volume": 4,
        }
        for name, code in reason_outputs.items():
            selected = points_ref[filter_reasons == code]
            if len(selected):
                write_point_cloud(output_dir / f"removed_{name}.pcd", selected)
        for name in ("floor", "ceiling"):
            plane = detection_metrics.get(f"{name}_plane")
            if not plane:
                continue
            coefficients = np.asarray(plane["coefficients"], dtype=float)
            residual = np.abs(
                points_ref[:, 2]
                - (points_ref[:, :2] @ coefficients[:2] + coefficients[2])
            )
            inliers = points_ref[
                np.all(np.isfinite(points_ref), axis=1)
                & (residual <= float(plane["residual_threshold_m"]))
            ]
            if len(inliers):
                write_point_cloud(output_dir / f"{name}_plane_inliers.pcd", inliers)
        write_json(
            output_dir / "height_density_profile.json",
            _height_density_profile(points_ref, floor_m, ceiling_m, cfg),
        )
        session_clean_counts = {}
        clean_session_points: list[tuple[str, np.ndarray]] = []
        if session_points_ref:
            start = 0
            for name, session_points in session_points_ref:
                end = start + len(session_points)
                selected = session_points[filter_reasons[start:end] == 0]
                session_clean_counts[name] = int(len(selected))
                clean_session_points.append((name, selected))
                if len(selected):
                    write_point_cloud(session_dir / f"{name}.pcd", selected)
                start = end
        else:
            clean_session_points = [("combined", clean_points)]
    grid_m = float(cfg.get("grid_m", 0.05))
    origin, shape = _common_raster(clean_points, grid_m, float(cfg.get("raster_padding_m", 0.50)))
    slice_width = float(cfg.get("slice_height_m", 0.50))
    slice_step = float(cfg.get("slice_step_m", 0.30))
    thick_slice_width = float(cfg.get("thick_slice_height_m", 1.00))
    thick_slice_step = float(cfg.get("thick_slice_step_m", 0.50))
    vector_settings = dict(vector_cfg)
    vector_settings.update({key: value for key, value in cfg.items() if key.startswith("vector_")})
    slices = _build_height_windows(
        clean_points,
        floor_m,
        ceiling_m,
        slice_width,
        slice_step,
        "thin_0.50m",
        origin,
        shape,
        grid_m,
        main_angle,
        cfg,
        vector_settings,
    )
    thick_slices = _build_height_windows(
        clean_points,
        floor_m,
        ceiling_m,
        thick_slice_width,
        thick_slice_step,
        "thick_1.00m",
        origin,
        shape,
        grid_m,
        main_angle,
        cfg,
        vector_settings,
    )

    for height_slice in slices:
        raw_name = f"slice_{height_slice.index:02d}_{height_slice.z_min_m:.2f}_{height_slice.z_max_m:.2f}.dxf"
        _export_slice_dxf(
            raw_slices_dir / raw_name,
            height_slice,
            transform_cad_from_ref,
            len(slices),
            calibrated=False,
        )

    calibration_cfg = dict(cfg)
    calibration_cfg["_origin"] = origin
    calibration_cfg["grid_m"] = grid_m
    groups, calibration_metrics = _calibrate_slices(slices, calibration_cfg)
    bootstrap_intersection, bootstrap_union = _consensus_geometry(groups, slices, cfg)
    thick_groups, thick_calibration_metrics = _calibrate_slices(
        thick_slices, calibration_cfg
    )
    thick_intersection, thick_union = _consensus_geometry(
        thick_groups, thick_slices, cfg
    )
    architectural_result = None
    architectural_outputs: dict = {}
    shared_wall_outputs: dict = {}
    shared_recovery = None
    if bool(cfg.get("architectural_enabled", True)):
        architectural_result = optimize_architectural_plan(
            bootstrap_union,
            clean_points,
            clean_session_points,
            floor_m,
            ceiling_m,
            main_angle,
            cfg,
            raw_slices=slices,
        )
    if (
        architectural_result is not None
        and str(cfg.get("calibration_strategy", "")) == "shared_wall_evidence"
    ):
        prior_intersection = []
        prior_path = output_dir.parent / "height_slices_v7" / "minimum_intersection.dxf"
        if not prior_path.is_file():
            prior_path = output_dir.parent / "height_slices_v6" / "minimum_intersection.dxf"
        if prior_path.is_file() and prior_path.resolve() != (
            output_dir / "minimum_intersection.dxf"
        ).resolve():
            transform_ref_from_cad = np.linalg.inv(transform_cad_from_ref)
            prior_intersection = [
                _transform_line(line, transform_ref_from_cad)
                for line in _read_dxf_lines(prior_path, {"MIN_INTERSECTION"})
            ]
        shared_recovery = recover_shared_wall_model(
            architectural_result.walls,
            architectural_result.low_structures,
            slices,
            clean_points,
            clean_session_points,
            floor_m,
            ceiling_m,
            bootstrap_intersection,
            bootstrap_union,
            cfg,
            prior_intersection=prior_intersection,
        )
        materialize_architectural_graph(architectural_result, shared_recovery)
        refresh_architectural_result_metrics(
            architectural_result,
            clean_points,
            clean_session_points,
            cfg,
        )
        intersection = shared_recovery.intersection
        union = shared_recovery.union
    else:
        intersection, union = bootstrap_intersection, bootstrap_union
    post_fusion_result = (
        regularize_merged_wall_network(union, clean_points, cfg)
        if bool(cfg.get("post_fusion_enabled", True))
        else None
    )
    morphology_reextract_result = (
        morphology_revectorize_wall_network(post_fusion_result, clean_points, cfg)
        if post_fusion_result is not None
        and bool(cfg.get("post_fusion_reextract_enabled", True))
        else None
    )
    closed_layout_result = None
    if morphology_reextract_result is not None and bool(
        cfg.get("closed_layout_enabled", True)
    ):
        closed_cfg = dict(cfg)
        closure_backbone_lines = None
        closure_backbone_lines, backbone_selection = _select_closure_backbone(
            slices,
            cfg,
            ceiling_m,
        )
        closed_cfg["_closure_backbone_selection"] = backbone_selection
        selected_index = backbone_selection.get("selected_slice_index")
        if selected_index is not None:
            closed_cfg["_closure_backbone_slice_index"] = int(selected_index)
            closed_cfg["_closure_backbone_source"] = (
                f"thin_slice_{int(selected_index):02d}_"
                f"{backbone_selection.get('geometry', 'raw')}"
            )
        closed_layout_result = optimize_closed_layout(
            morphology_reextract_result,
            thick_union,
            clean_points,
            closed_cfg,
            backbone_lines=closure_backbone_lines,
        )
    robust_intersection, robust_min_slice_count = _robust_intersection_geometry(
        union, slices, cfg
    )
    _materialize_calibrated_slices_from_consensus(slices, union)
    final_evidence = _slice_evidence_metrics(slices, origin, grid_m, True)
    final_reverse = _slice_reverse_coverage_metrics(slices, origin, grid_m, True)
    calibration_metrics.update(final_evidence)
    calibration_metrics.update(final_reverse)
    calibration_metrics["height_calibration_independent_p95_change_m"] = (
        None
        if calibration_metrics.get("height_raw_evidence_p95_m") is None
        or final_evidence.get("height_calibrated_evidence_p95_m") is None
        else float(
            final_evidence["height_calibrated_evidence_p95_m"]
            - calibration_metrics["height_raw_evidence_p95_m"]
        )
    )
    calibration_metrics["height_calibration_independent_support_change"] = float(
        final_evidence["height_calibrated_evidence_support_fraction"]
        - calibration_metrics["height_raw_evidence_support_fraction"]
    )
    calibration_metrics["height_calibration_reverse_coverage_change"] = float(
        final_reverse["height_calibrated_evidence_to_line_coverage_fraction"]
        - calibration_metrics["height_raw_evidence_to_line_coverage_fraction"]
    )
    calibration_metrics["height_calibration_materialized_atomic_line_count"] = int(
        sum(len(value.calibrated_lines_ref) for value in slices)
    )
    for height_slice in slices:
        calibrated_name = f"slice_{height_slice.index:02d}_{height_slice.z_min_m:.2f}_{height_slice.z_max_m:.2f}.dxf"
        _export_slice_dxf(
            calibrated_slices_dir / calibrated_name,
            height_slice,
            transform_cad_from_ref,
            len(slices),
        )
        cv2.imwrite(str(masks_dir / f"slice_{height_slice.index:02d}_mask.png"), height_slice.mask)
    _export_consensus_dxfs(
        output_dir,
        slices,
        intersection,
        robust_intersection,
        union,
        transform_cad_from_ref,
    )
    _render_outputs(
        output_dir,
        clean_points,
        origin,
        shape,
        grid_m,
        slices,
        intersection,
        robust_intersection,
        union,
        transform_cad_from_ref,
        cfg,
    )
    thick_slice_outputs = _export_thick_slice_outputs(
        output_dir,
        thick_slices,
        thick_intersection,
        thick_union,
        transform_cad_from_ref,
        clean_points,
        origin,
        grid_m,
    )
    post_fusion_outputs = (
        {}
        if post_fusion_result is None
        else _export_post_fusion_outputs(
            output_dir,
            post_fusion_result,
            union,
            transform_cad_from_ref,
            clean_points,
            grid_m,
        )
    )
    morphology_reextract_outputs = (
        {}
        if morphology_reextract_result is None or post_fusion_result is None
        else _export_morphology_reextract_outputs(
            output_dir,
            morphology_reextract_result,
            post_fusion_result,
            transform_cad_from_ref,
            clean_points,
            grid_m,
        )
    )
    if architectural_result is not None:
        architectural_outputs = export_architectural_outputs(
            output_dir,
            architectural_result,
            transform_cad_from_ref,
            clean_points,
            union,
            cfg,
            semantic_objects_cad=semantic_objects_cad,
        )
        architectural_outputs.update(
            _render_v7_v8_architectural_comparison(
                output_dir,
                clean_points,
                transform_cad_from_ref,
                architectural_result,
                grid_m,
                cfg,
            )
        )
    if shared_recovery is not None:
        shared_wall_outputs = _export_shared_wall_outputs(
            output_dir,
            shared_recovery,
            [] if architectural_result is None else architectural_result.inferred,
            transform_cad_from_ref,
            clean_points,
            bootstrap_intersection,
            prior_intersection,
            grid_m,
            cfg,
        )
    # V12 is the default delivery, so export it after every legacy comparison
    # renderer that also writes ``final_dxf.png``.
    closed_layout_outputs = (
        {}
        if closed_layout_result is None or morphology_reextract_result is None
        else _export_closed_layout_outputs(
            output_dir,
            closed_layout_result,
            morphology_reextract_result,
            thick_union,
            transform_cad_from_ref,
            clean_points,
            grid_m,
            cfg,
        )
    )
    semantic_object_result = None
    semantic_object_outputs: dict = {}
    if str(cfg.get("reconstruction_strategy", "")).strip().lower() == "semantic_objects":
        # V13 is exported last on purpose: legacy stages remain available for
        # ablations, while the default architectural_plan/final_dxf products
        # must come from the one shared building-object graph.
        cfg["_semantic_session_count"] = int(len(clean_session_points))
        semantic_object_result = run_semantic_object_stage(
            output_dir,
            clean_points,
            floor_m,
            ceiling_m,
            origin,
            shape,
            slices,
            thick_slices,
            transform_cad_from_ref,
            cfg,
        )
        semantic_object_outputs = semantic_object_result.outputs
        architectural_outputs.update(semantic_object_outputs)
    point_distance_metrics = _slice_point_distance_metrics(slices, clean_points)

    geojson_features = []
    for value in union:
        geojson_features.append(
            {
                "type": "Feature",
                "geometry": mapping(_transform_line(value["line_ref"], transform_cad_from_ref)),
                "properties": {
                    "class": "HEIGHT_AWARE_STRUCTURE",
                    **{key: item for key, item in value.items() if key not in ("line_ref", "group")},
                },
            }
        )
    write_json(
        output_dir / "height_aware.geojson",
        {
            "type": "FeatureCollection",
            "local_coordinate_system": {
                "units": "metre",
                "z_datum": "detected_floor",
                "T_cad_reference_slam": np.asarray(transform_cad_from_ref).tolist(),
                "T_reference_slam_cad": np.linalg.inv(transform_cad_from_ref).tolist(),
            },
            "features": geojson_features,
        },
    )
    slice_geometries = [
        unary_union(value.calibrated_lines_ref) for value in slices
    ]
    tolerance = float(cfg.get("consensus_audit_tolerance_m", 0.001))
    # Buffering a large MultiLineString dominates this audit; it is invariant
    # within a slice and must not be recomputed for every atomic segment.
    slice_support_areas = [geometry.buffer(tolerance) for geometry in slice_geometries]
    strict_unsupported = 0.0
    for line in intersection:
        for support_area in slice_support_areas:
            strict_unsupported += float(line.difference(support_area).length)
    union_attribution_unsupported = 0.0
    for value in union:
        for index in value["slice_indices"]:
            union_attribution_unsupported += float(
                value["line_ref"].difference(slice_support_areas[index]).length
            )
    topology_metrics = _consensus_topology_metrics(intersection, union)
    disk_set_audit = audit_exported_height_set(
        output_dir, slices, tolerance, robust_min_slice_count
    )
    shared_wall_audit = (
        {}
        if shared_recovery is None
        else audit_shared_wall_outputs(
            output_dir,
            intersection,
            union,
            transform_cad_from_ref,
            tolerance,
        )
    )
    shared_wall_checks = {}
    if shared_recovery is not None:
        recovery_metrics = shared_recovery.metrics
        recovered_p95 = recovery_metrics.get(
            "shared_wall_recovered_axis_distance_p95_m"
        )
        plane_p95 = recovery_metrics.get("shared_wall_recovered_plane_rmse_p95_m")
        shared_wall_checks = {
            "frozen_recoverable_coverage_pass": recovery_metrics.get(
                "shared_wall_frozen_recoverable_coverage", 0.0
            )
            >= float(cfg.get("shared_wall_accept_frozen_coverage", 0.95)),
            "v6_valid_strict_retention_pass": recovery_metrics.get(
                "shared_wall_v6_valid_strict_retention_fraction", 0.0
            )
            >= float(cfg.get("shared_wall_accept_v6_valid_retention", 0.98)),
            "recovered_line_distance_pass": recovered_p95 is not None
            and recovered_p95
            <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
            "recovered_vertical_plane_pass": plane_p95 is not None
            and plane_p95 <= float(cfg.get("shared_wall_plane_rmse_m", 0.05)),
            "common_observed_matches_strict_pass": shared_wall_audit.get(
                "strict_common_missing_length_m", float("inf")
            )
            <= tolerance
            and shared_wall_audit.get(
                "strict_common_extra_length_m", float("inf")
            )
            <= tolerance,
            "common_inference_isolated_pass": shared_wall_audit.get(
                "inferred_entity_in_observed_common_layer_count", 1
            )
            == 0,
        }
        write_json(
            output_dir / "v8_recovery_audit.json",
            {
                "metrics": recovery_metrics,
                "disk_checks": shared_wall_audit,
                "checks": shared_wall_checks,
                "passed": all(shared_wall_checks.values()),
            },
        )
    metrics = {
        "height_slices_enabled": True,
        "height_floor_m": float(floor_m),
        "height_ceiling_m": float(ceiling_m),
        "height_slice_count": int(len(slices)),
        "height_slice_width_m": slice_width,
        "height_slice_step_m": slice_step,
        "height_slice_raw_line_count": int(sum(len(value.raw_lines_ref) for value in slices)),
        "height_slice_calibrated_line_count": int(
            sum(len(value.calibrated_lines_ref) for value in slices)
        ),
        "height_thick_slice_count": int(len(thick_slices)),
        "height_thick_slice_width_m": thick_slice_width,
        "height_thick_slice_step_m": thick_slice_step,
        "height_thick_slice_raw_line_count": int(
            sum(len(value.raw_lines_ref) for value in thick_slices)
        ),
        "height_thick_slice_calibrated_line_count": int(
            sum(len(value.calibrated_lines_ref) for value in thick_slices)
        ),
        "height_thick_minimum_intersection_line_count": int(
            len(thick_intersection)
        ),
        "height_thick_maximum_union_line_count": int(len(thick_union)),
        "height_minimum_intersection_line_count": int(len(intersection)),
        "height_robust_intersection_line_count": int(len(robust_intersection)),
        "height_robust_intersection_total_length_m": float(
            sum(value["line_ref"].length for value in robust_intersection)
        ),
        "height_robust_intersection_min_slice_count": int(
            robust_min_slice_count
        ),
        "height_maximum_union_line_count": int(len(union)),
        "height_maximum_union_regularized_line_count": int(
            len(
                _merge_display_linework(
                    [value["line_ref"] for value in union]
                )
            )
        ),
        "height_inferred_segment_count": int(
            sum(bool(value["inferred_slice_indices"]) for value in union)
        ),
        "height_unknown_segment_count": int(
            sum(bool(value["unknown_slice_indices"]) for value in union)
        ),
        "height_strict_intersection_unsupported_length_m": strict_unsupported,
        "height_union_attribution_unsupported_length_m": union_attribution_unsupported,
        "height_consensus_audit_tolerance_m": tolerance,
        "height_session_clean_point_counts": session_clean_counts,
        **detection_metrics,
        **filter_metrics,
        **calibration_metrics,
        **point_distance_metrics,
        **topology_metrics,
        **({} if post_fusion_result is None else post_fusion_result.metrics),
        **(
            {}
            if morphology_reextract_result is None
            else morphology_reextract_result.metrics
        ),
        **{
            f"thick_{key}": value
            for key, value in thick_calibration_metrics.items()
        },
        **({} if closed_layout_result is None else closed_layout_result.metrics),
        "height_disk_set_audit": disk_set_audit,
        "shared_wall_disk_audit": shared_wall_audit,
        **({} if shared_recovery is None else shared_recovery.metrics),
        **({} if architectural_result is None else architectural_result.metrics),
        **({} if semantic_object_result is None else {
            f"semantic_object_{key}": value
            for key, value in semantic_object_result.metrics.items()
        }),
    }
    summary = {
        "algorithm_version": (
            "height-slices-v14-semantic-points"
            if semantic_object_result is not None and cfg.get("semantic_probability_path")
            else "height-slices-v13-semantic-objects"
            if semantic_object_result is not None
            else "height-slices-v12-high-slice-observed-backbone"
        ),
        "metrics": metrics,
        "slices": [
            {
                "index": value.index,
                "window_id": value.window_id,
                "scale_id": value.scale_id,
                "z_min_m": value.z_min_m,
                "z_max_m": value.z_max_m,
                "point_count": value.point_count,
                "raw_line_count": len(value.raw_lines_ref),
                "calibrated_line_count": len(value.calibrated_lines_ref),
                "overlap_weight": value.overlap_weight,
                "raw_dxf": str(raw_slices_dir / f"slice_{value.index:02d}_{value.z_min_m:.2f}_{value.z_max_m:.2f}.dxf"),
                "calibrated_dxf": str(calibrated_slices_dir / f"slice_{value.index:02d}_{value.z_min_m:.2f}_{value.z_max_m:.2f}.dxf"),
            }
            for value in slices
        ],
        "thick_slices": [
            {
                "index": value.index,
                "window_id": value.window_id,
                "scale_id": value.scale_id,
                "z_min_m": value.z_min_m,
                "z_max_m": value.z_max_m,
                "point_count": value.point_count,
                "raw_line_count": len(value.raw_lines_ref),
                "calibrated_line_count": len(value.calibrated_lines_ref),
                "overlap_weight": value.overlap_weight,
                "raw_dxf": str(
                    output_dir
                    / "raw_slices_thick"
                    / f"thick_{value.index:02d}_{value.z_min_m:.2f}_{value.z_max_m:.2f}.dxf"
                ),
                "calibrated_dxf": str(
                    output_dir
                    / "calibrated_slices_thick"
                    / f"thick_{value.index:02d}_{value.z_min_m:.2f}_{value.z_max_m:.2f}.dxf"
                ),
            }
            for value in thick_slices
        ],
        "outputs": {
            "minimum_intersection_dxf": str(output_dir / "minimum_intersection.dxf"),
            "robust_intersection_dxf": str(output_dir / "robust_intersection.dxf"),
            "maximum_union_dxf": str(output_dir / "maximum_union.dxf"),
            "minimum_intersection_png": str(output_dir / "minimum_intersection.png"),
            "robust_intersection_png": str(output_dir / "robust_intersection.png"),
            "maximum_union_png": str(output_dir / "maximum_union.png"),
            "intersection_union_comparison_png": str(
                output_dir / "intersection_union_comparison.png"
            ),
            "combined_height_dxf": str(output_dir / "height_aware_combined.dxf"),
            "height_geojson": str(output_dir / "height_aware.geojson"),
            "height_consensus_png": str(output_dir / "height_consensus.png"),
            "slice_overview_png": str(output_dir / "slice_overview.png"),
            "calibration_before_after_png": str(output_dir / "calibration_before_after.png"),
            "final_dxf_png": str(output_dir / "final_dxf.png"),
            "height_density_profile_json": str(output_dir / "height_density_profile.json"),
            "height_set_disk_audit_json": str(output_dir / "height_set_disk_audit.json"),
            **shared_wall_outputs,
            **post_fusion_outputs,
            **morphology_reextract_outputs,
            **thick_slice_outputs,
            **closed_layout_outputs,
            **(
                {}
                if shared_recovery is None
                else {
                    "shared_wall_audit_json": str(
                        output_dir / "shared_wall_audit.json"
                    ),
                    "v8_recovery_audit_json": str(
                        output_dir / "v8_recovery_audit.json"
                    ),
                }
            ),
            **architectural_outputs,
        },
        "shared_wall_acceptance": shared_wall_checks,
        "shared_wall_acceptance_passed": bool(shared_wall_checks)
        and all(shared_wall_checks.values()),
        "architectural_acceptance": (
            {} if architectural_result is None else architectural_result.audit
        ),
        "architectural_acceptance_passed": (
            False if architectural_result is None else all(architectural_result.audit.values())
        ),
    }
    write_json(output_dir / "summary.json", summary)
    return summary


def run_semantic_objects_from_reuse(
    reuse_from: str | Path,
    output_dir: str | Path,
    transform_cad_from_ref: np.ndarray,
    cfg: dict,
) -> dict:
    """Rebuild only V13 object products from a compatible V12 height run."""
    reuse_dir = Path(reuse_from).resolve()
    output_dir = Path(output_dir).resolve()
    summary_path = reuse_dir / "summary.json"
    clean_path = reuse_dir / "clean_interior.pcd"
    if not summary_path.is_file() or not clean_path.is_file():
        raise ValueError(f"Reusable V12 height products are incomplete: {reuse_dir}")
    if reuse_dir != output_dir:
        shutil.copytree(reuse_dir, output_dir, dirs_exist_ok=True)
    reused = read_json(summary_path)
    clean_points = read_point_cloud(clean_path)
    metrics = reused.get("metrics", {})
    floor_m = float(metrics["height_floor_m"])
    ceiling_m = float(metrics["height_ceiling_m"])
    grid_m = float(cfg.get("grid_m", 0.05))
    origin, shape = _common_raster(
        clean_points, grid_m, float(cfg.get("raster_padding_m", 0.50))
    )

    def restore_window(row: dict, thick: bool) -> HeightSlice:
        index = int(row["index"])
        z_min = float(row["z_min_m"])
        z_max = float(row["z_max_m"])
        mask_path = reuse_dir / "masks" / f"slice_{index:02d}_mask.png"
        mask = None if thick else cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
        if mask is None or mask.shape != shape:
            mask, heatmap, point_count = _slice_projection(
                clean_points,
                z_min,
                z_max,
                origin,
                shape,
                grid_m,
                cfg,
            )
        else:
            heatmap = (mask.astype(np.float32) / 255.0)
            point_count = int(
                np.count_nonzero(
                    (clean_points[:, 2] >= z_min) & (clean_points[:, 2] < z_max)
                )
            )
        return HeightSlice(
            index=index,
            z_min_m=z_min,
            z_max_m=z_max,
            point_count=point_count,
            mask=mask,
            heatmap=heatmap,
            raw_lines_ref=[],
            calibrated_lines_ref=[],
            overlap_weight=float(row.get("overlap_weight", 1.0)),
            scale_id=str(row.get("scale_id") or ("thick_1.00m" if thick else "thin_0.50m")),
            window_id=str(row.get("window_id") or f"{'thick' if thick else 'thin'}:{z_min:.3f}:{z_max:.3f}"),
        )

    thin_slices = [restore_window(row, False) for row in reused.get("slices", [])]
    thick_slices = [restore_window(row, True) for row in reused.get("thick_slices", [])]
    if not thin_slices or not thick_slices:
        raise ValueError("Reusable V12 summary contains no thin/thick height windows")
    result = run_semantic_object_stage(
        output_dir,
        clean_points,
        floor_m,
        ceiling_m,
        origin,
        shape,
        thin_slices,
        thick_slices,
        transform_cad_from_ref,
        cfg,
    )
    summary = copy.deepcopy(reused)
    old_root = str(reuse_dir)
    new_root = str(output_dir)

    def relocate(value):
        if isinstance(value, str):
            return value.replace(old_root, new_root)
        if isinstance(value, list):
            return [relocate(item) for item in value]
        if isinstance(value, dict):
            return {key: relocate(item) for key, item in value.items()}
        return value

    summary = relocate(summary)
    summary["algorithm_version"] = (
        "height-slices-v14-semantic-points"
        if cfg.get("semantic_probability_path")
        else "height-slices-v13-semantic-objects"
    )
    summary.setdefault("metrics", {}).update(
        {
            f"semantic_object_{key}": value
            for key, value in result.metrics.items()
        }
    )
    summary["metrics"]["semantic_object_reused_height_products_from"] = str(reuse_dir)
    summary.setdefault("outputs", {}).update(result.outputs)
    if int(cfg.get("_semantic_session_count", 1)) <= 1:
        # A leave-one-acquisition-out refit is mathematically inapplicable to a
        # single-map data set. Preserve that fact as a passing N/A condition,
        # rather than retaining the stale V13 `False` copied for comparison.
        architectural = summary.get("architectural_acceptance", {})
        if "leave_one_session_out_pass" in architectural:
            architectural["leave_one_session_out_pass"] = True
            summary["architectural_acceptance_passed"] = all(
                bool(value) for value in architectural.values()
            )
    write_json(output_dir / "summary.json", summary)
    return summary


def _render_v7_v8_architectural_comparison(
    output_dir: Path,
    clean_points: np.ndarray,
    transform_cad_from_ref: np.ndarray,
    architectural_result,
    grid_m: float,
    cfg: dict,
) -> dict:
    cad_points = transform_points(clean_points, transform_cad_from_ref)
    origin, shape = _common_raster(
        cad_points, grid_m, float(cfg.get("raster_padding_m", 0.50))
    )
    density = _density_base(cad_points, origin, shape, grid_m)
    background = cv2.cvtColor(
        np.clip(density * 0.30, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2BGR
    )
    point_panel = np.flipud(cv2.cvtColor(density, cv2.COLOR_GRAY2BGR)).copy()
    v7_panel = background.copy()
    v8_panel = background.copy()
    prior_path = output_dir.parent / "height_slices_v7" / "architectural_plan.dxf"
    prior_lines = (
        _read_dxf_lines(prior_path, {"ARCH_WALL", "LOW_STRUCTURE"})
        if prior_path.is_file()
        else []
    )
    for line in prior_lines:
        _draw_line(v7_panel, line, origin, grid_m, (255, 190, 50), 2)
    for value in architectural_result.walls:
        _draw_line(
            v8_panel,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            origin,
            grid_m,
            (80, 255, 120),
            2,
        )
    for value in architectural_result.low_structures:
        _draw_line(
            v8_panel,
            _transform_line(value["line_ref"], transform_cad_from_ref),
            origin,
            grid_m,
            (255, 190, 50),
            2,
        )
    v7_panel = np.flipud(v7_panel).copy()
    v8_panel = np.flipud(v8_panel).copy()
    for image, label in zip(
        (point_panel, v7_panel, v8_panel),
        ("CLEANED LIDAR", "V7 ARCHITECTURAL", "V8 SCORED WALL GRAPH"),
    ):
        cv2.putText(
            image,
            label,
            (14, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.60,
            (245, 245, 245),
            2,
            cv2.LINE_AA,
        )
        _height_set_scale_bar(image, grid_m)
    comparison_path = output_dir / "architectural_v7_v8_comparison.png"
    cv2.imwrite(str(comparison_path), np.hstack([point_panel, v7_panel, v8_panel]))

    detail_outputs = {}
    for name, bounds in cfg.get("architectural_detail_crops_cad", {}).items():
        xmin, ymin, xmax, ymax = map(float, bounds)
        column_start = max(0, int(math.floor((xmin - origin[0]) / grid_m)))
        column_end = min(shape[1], int(math.ceil((xmax - origin[0]) / grid_m)))
        row_start = max(0, shape[0] - int(math.ceil((ymax - origin[1]) / grid_m)))
        row_end = min(
            shape[0], shape[0] - int(math.floor((ymin - origin[1]) / grid_m))
        )
        if row_end <= row_start or column_end <= column_start:
            continue
        panels = [
            image[row_start:row_end, column_start:column_end]
            for image in (point_panel, v7_panel, v8_panel)
        ]
        detail_path = output_dir / f"v7_v8_{Path(name).name}"
        cv2.imwrite(str(detail_path), np.hstack(panels))
        detail_outputs[f"v7_v8_{Path(name).stem}_png"] = str(detail_path)
    return {
        "architectural_v7_v8_comparison_png": str(comparison_path),
        **detail_outputs,
    }
