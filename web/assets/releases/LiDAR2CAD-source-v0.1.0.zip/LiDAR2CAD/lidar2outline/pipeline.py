from __future__ import annotations

import math
import os
import shutil
import traceback
from pathlib import Path

import numpy as np

from .bag import inspect_bag, require_valid_report
from .calibration import (
    CalibrationEstimate,
    average_estimates,
    choose_pilot_candidate,
    estimates_agree,
    parse_li_init_result,
    seed_estimate,
)
from .cloud import level_cloud, read_trajectory, vertical_structural_cells, voxel_downsample
from .deep_layout import run_deep_layout_stage
from .errors import DataQualityError, PipelineError
from .export import export_dxf, export_geojson, export_transforms
from .external import require_ros_runtime, run_li_init, run_lio_sam, write_li_init_config, write_lio_sam_config
from .height_slices import run_height_slice_stage, run_semantic_objects_from_reuse
from .io import cache_valid, ensure_dirs, fingerprint, read_json, read_point_cloud, write_json, write_point_cloud
from .qa import (
    save_density,
    save_lidar_dxf_comparison,
    save_mask,
    save_outline_overlay,
    save_prediction_dxf_comparison,
    save_registration,
)
from .quality import assess_session
from .registration import register_se2
from .transforms import invert_transform, matrix_json, transform_points
from .vectorize import vectorize_sessions


def _calibration_from_json(value: dict) -> CalibrationEstimate:
    return CalibrationEstimate(
        np.asarray(value["rotation"], dtype=float),
        np.asarray(value["translation"], dtype=float),
        float(value["imu_stamp_correction_sec"]),
        value.get("source", "cached"),
    )


def inspect_inputs(cfg: dict, force: bool = False) -> dict:
    dirs = ensure_dirs(cfg["project"]["output_dir"])
    paths = [s["bag"] for s in cfg["inputs"]["sessions"]] + cfg["inputs"].get("calibration_bags", [])
    digest = fingerprint(paths, {"inputs": cfg["inputs"]}, "inspect-v2")
    report_path = dirs["inspect"] / "bags.json"
    manifest = dirs["inspect"] / "manifest.json"
    if not force and cache_valid(manifest, digest, [report_path]):
        return read_json(report_path)
    reports = []
    for path in paths:
        reports.append(inspect_bag(path, cfg["inputs"]["point_topic"], cfg["inputs"]["imu_topic"]))
    output = {"valid": all(item["valid"] for item in reports), "bags": reports}
    write_json(report_path, output)
    write_json(manifest, {"fingerprint": digest, "outputs": [str(report_path)]})
    return output


def _run_calibration_once(cfg: dict, bag: str, index: int, dirs: dict[str, Path], force: bool) -> CalibrationEstimate:
    config_path = dirs["calibration"] / f"li_init_{index}.yaml"
    result_path = dirs["calibration"] / f"li_init_{index}.txt"
    manifest = dirs["calibration"] / f"li_init_{index}.manifest.json"
    write_li_init_config(config_path, cfg)
    digest = fingerprint([bag], {"calibration": cfg["calibration"], "inputs": cfg["inputs"]}, "li-init-v1")
    if force or not cache_valid(manifest, digest, [result_path]):
        run_li_init(bag, result_path, config_path, cfg, dirs["logs"] / f"li_init_{index}.log")
        write_json(manifest, {"fingerprint": digest, "outputs": [str(result_path)]})
    return parse_li_init_result(result_path)


def _pilot_metric(map_path: Path, trajectory_path: Path, cfg: dict) -> dict:
    report, _ = assess_session(read_point_cloud(map_path), trajectory_path, cfg)
    return {
        "trajectory_continuous": bool(report.get("trajectory", {}).get("continuous", False)),
        "floor_rmse_m": report["floor_rmse_m"],
        "wall_thickness_m": report["wall_thickness_m"],
    }


def calibrate(cfg: dict, force: bool = False) -> tuple[CalibrationEstimate, dict]:
    dirs = ensure_dirs(cfg["project"]["output_dir"])
    output = dirs["calibration"] / "calibration.json"
    bags = cfg["inputs"].get("calibration_bags", [])
    if len(bags) < 2:
        raise PipelineError("Two calibration bags are required")
    digest = fingerprint(bags, cfg["calibration"], "calibration-v3")
    manifest = dirs["calibration"] / "manifest.json"
    if not force and cache_valid(manifest, digest, [output]):
        value = read_json(output)
        return _calibration_from_json(value["selected"]), value

    require_ros_runtime(cfg)

    estimates = []
    calibration_failures = []
    for index, bag in enumerate(bags[:2]):
        try:
            estimates.append(_run_calibration_once(cfg, bag, index + 1, dirs, force))
        except Exception as exc:
            calibration_failures.append(
                {
                    "bag": bag,
                    "error": str(exc),
                    "type": type(exc).__name__,
                }
            )

    difference = None
    pilot_scores = None
    if len(estimates) == 2:
        agreed, difference = estimates_agree(estimates[0], estimates[1], cfg["calibration"]["agreement"])
    else:
        agreed = False

    if len(estimates) == 2 and agreed:
        selected = average_estimates(estimates)
        confidence = 0.95
        selection = "consistent_mean"
    elif estimates:
        candidates = estimates + [seed_estimate(cfg["calibration"])]
        pilot_scores = []
        first_session = cfg["inputs"]["sessions"][0]
        for index, candidate in enumerate(candidates):
            pilot_dir = dirs["calibration"] / f"pilot_{index + 1}"
            params = pilot_dir / "lio_sam.yaml"
            pilot_dir.mkdir(parents=True, exist_ok=True)
            write_lio_sam_config(params, cfg, candidate, f"calibration_pilot_{index + 1}")
            pilot_manifest = pilot_dir / "manifest.json"
            pilot_digest = fingerprint(
                [first_session["bag"]],
                {"candidate": candidate.as_dict(), "seconds": cfg["calibration"]["pilot_seconds"], "slam": cfg["slam"]},
                "calibration-pilot-v1",
            )
            pilot_outputs = [pilot_dir / "GlobalMap.pcd", pilot_dir / "trajectory.csv"]
            if force or not cache_valid(pilot_manifest, pilot_digest, pilot_outputs):
                run_lio_sam(
                    first_session["bag"],
                    pilot_dir,
                    params,
                    candidate,
                    cfg,
                    dirs["logs"] / f"calibration_pilot_{index + 1}.log",
                    float(cfg["calibration"]["pilot_seconds"]),
                )
                write_json(pilot_manifest, {"fingerprint": pilot_digest, "outputs": [str(path) for path in pilot_outputs]})
            pilot_scores.append(_pilot_metric(pilot_dir / "GlobalMap.pcd", pilot_dir / "trajectory.csv", cfg))
        selected, pilot_scores = choose_pilot_candidate(candidates, pilot_scores)
        confidence = 0.70
        selection = "pilot_score"
    else:
        # A calibration recording can be perfectly readable yet lack the
        # independent rotations LI-Init needs.  Preserve that fact in the
        # report and continue with the configured fixed-mount seed rather than
        # treating LI-Init's zero-valued shutdown printout as an estimate.
        selected = seed_estimate(cfg["calibration"])
        confidence = 0.35
        selection = "configured_seed_after_li_init_failure"
    value = {
        "selected": selected.as_dict(),
        "confidence": confidence,
        "selection": selection,
        "agreement": difference,
        "estimates": [item.as_dict() for item in estimates],
        "failures": calibration_failures,
        "pilot_scores": pilot_scores,
    }
    write_json(output, value)
    write_json(manifest, {"fingerprint": digest, "outputs": [str(output)]})
    return selected, value


def run_slam_sessions(cfg: dict, calibration: CalibrationEstimate, force: bool = False) -> list[dict]:
    dirs = ensure_dirs(cfg["project"]["output_dir"])
    outcomes = []
    for session in cfg["inputs"]["sessions"]:
        name = session["name"]
        session_dir = dirs["slam"] / name
        session_dir.mkdir(parents=True, exist_ok=True)
        map_path = session_dir / "GlobalMap.pcd"
        trajectory_path = session_dir / "trajectory.csv"
        quality_path = session_dir / "quality.json"
        params_path = session_dir / "lio_sam.yaml"
        manifest = session_dir / "manifest.json"
        digest = fingerprint([session["bag"]], {"slam": cfg["slam"], "calibration": calibration.as_dict()}, "lio-sam-v2")
        try:
            write_lio_sam_config(params_path, cfg, calibration, name)
            if force or not cache_valid(manifest, digest, [map_path, trajectory_path, quality_path]):
                run_lio_sam(session["bag"], session_dir, params_path, calibration, cfg, dirs["logs"] / f"{name}.log")
                quality, _ = assess_session(read_point_cloud(map_path), trajectory_path, cfg)
                write_json(quality_path, quality)
                write_json(manifest, {"fingerprint": digest, "outputs": [str(map_path), str(trajectory_path), str(quality_path)]})
            quality = read_json(quality_path)
            outcomes.append({"name": name, "accepted": True, "map": str(map_path), "trajectory": str(trajectory_path), "quality": quality})
        except Exception as exc:
            failure = {"name": name, "accepted": False, "reason": str(exc), "traceback": traceback.format_exc()}
            write_json(session_dir / "failure.json", failure)
            outcomes.append(failure)
    if not any(item["accepted"] for item in outcomes):
        raise DataQualityError("All SLAM sessions failed; no outline was generated")
    return outcomes


def _structural_for_registration(points: np.ndarray, cfg: dict, ceiling: float | None) -> np.ndarray:
    s = cfg["structure"]
    upper = float(s["max_height_m"])
    if ceiling is not None:
        upper = min(upper, ceiling - float(s["ceiling_margin_m"]))
    structural, _ = vertical_structural_cells(
        points,
        float(s["grid_m"]),
        float(s["height_bin_m"]),
        float(s["min_height_m"]),
        upper,
        float(s["vertical_span_m"]),
        int(s["min_height_bins"]),
    )
    return structural


def _height_slice_acceptance(metrics: dict, cfg: dict) -> dict[str, bool]:
    """Acceptance based on source evidence and exact observed-set geometry."""
    audit_tolerance = float(cfg.get("consensus_audit_tolerance_m", 0.001))
    point_p95 = metrics.get("height_calibrated_point_distance_p95_m")
    shared_strategy = cfg.get("calibration_strategy") == "shared_wall_evidence"
    independent = metrics.get(
        "leave_one_session_out_residual",
        metrics.get("architectural_independent_session_residual", {}),
    ) or {}
    independent_p95 = independent.get("p95_m")
    independent_applicable = bool(
        independent.get("applicable", bool(independent.get("by_session")))
    )
    independent_pass = (
        not independent_applicable
        or (
            independent_p95 is not None
            and independent_p95
            <= float(cfg.get("architectural_independent_session_p95_m", 0.05))
        )
    )
    checks = {
        "slices_present": metrics.get("height_slice_count", 0) >= 2,
        "observed_union_present": metrics.get("height_maximum_union_line_count", 0) > 0,
        "height_range_valid": metrics.get("height_ceiling_m", 0.0)
        > metrics.get("height_floor_m", 0.0),
        "line_to_point_p95": point_p95 is not None
        and point_p95 <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
        "line_point_support": metrics.get(
            "height_calibrated_point_support_fraction", 0.0
        )
        >= float(cfg.get("accept_line_support_fraction", 0.95)),
        "raster_support_not_regressed": (
            metrics.get("height_calibrated_evidence_support_fraction", 0.0)
            >= float(cfg.get("accept_line_support_fraction", 0.95))
            if shared_strategy
            else metrics.get("height_calibration_independent_support_change", -1.0)
            >= -float(cfg.get("calibration_max_evidence_support_regression", 0.03))
        ),
        # A scored structural union intentionally excludes furniture/detail
        # evidence.  Judge it against the frozen building evidence; retain the
        # all-evidence reverse-coverage metric in the report as a diagnostic.
        "coverage_not_regressed": (
            metrics.get("frozen_coverage_change", -1.0)
            if shared_strategy
            else metrics.get("height_calibration_reverse_coverage_change", -1.0)
        )
        >= -float(cfg.get("calibration_max_reverse_coverage_regression", 0.02)),
        "strict_intersection_exact": metrics.get(
            "height_strict_intersection_unsupported_length_m", float("inf")
        )
        <= audit_tolerance,
        "union_attribution_exact": metrics.get(
            "height_union_attribution_unsupported_length_m", float("inf")
        )
        <= audit_tolerance,
        "shared_nodes_exact": metrics.get(
            "height_union_shared_node_max_spread_m", float("inf")
        )
        <= 0.001,
        "no_duplicate_union_lines": metrics.get(
            "height_maximum_union_duplicate_length_m", float("inf")
        )
        <= 0.01,
        "disk_height_set_exact": (
            metrics.get("height_disk_set_audit", {}).get(
                "strict_intersection_unsupported_length_m", float("inf")
            )
            <= audit_tolerance
            and metrics.get("height_disk_set_audit", {}).get(
                "maximum_union_missing_observed_length_m", float("inf")
            )
            <= audit_tolerance
            and metrics.get("height_disk_set_audit", {}).get(
                "maximum_union_extra_length_m", float("inf")
            )
            <= audit_tolerance
            and metrics.get("height_disk_set_audit", {}).get(
                "robust_intersection_extra_length_m", float("inf")
            )
            <= audit_tolerance
            and metrics.get("height_disk_set_audit", {}).get(
                "robust_intersection_support_violation_count", 1
            )
            == 0
            and metrics.get("height_disk_set_audit", {}).get(
                "inferred_entity_in_observed_layer_count", 1
            )
            == 0
        ),
    }
    if shared_strategy:
        shared_audit = metrics.get("shared_wall_disk_audit", {})
        checks.update(
            {
                "shared_wall_frozen_recovery": metrics.get(
                    "shared_wall_frozen_recoverable_coverage", 0.0
                )
                >= float(cfg.get("shared_wall_accept_frozen_coverage", 0.95)),
                "shared_wall_v6_valid_strict_retention": metrics.get(
                    "shared_wall_v6_valid_strict_retention_fraction", 0.0
                )
                >= float(cfg.get("shared_wall_accept_v6_valid_retention", 0.98)),
                "shared_wall_recovered_distance": metrics.get(
                    "shared_wall_recovered_axis_distance_p95_m", float("inf")
                )
                <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
                "shared_wall_disk_exact": shared_audit.get(
                    "strict_common_missing_length_m", float("inf")
                )
                <= audit_tolerance
                and shared_audit.get(
                    "strict_common_extra_length_m", float("inf")
                )
                <= audit_tolerance
                and shared_audit.get(
                    "inferred_entity_in_observed_common_layer_count", 1
                )
                == 0,
            }
        )
    if metrics.get("post_fusion_enabled", False):
        raw_p95 = metrics.get("post_fusion_raw_line_to_point_p95_m")
        final_p95 = metrics.get("post_fusion_complete_line_to_point_p95_m")
        checks.update(
            {
                "post_fusion_geometry_present": metrics.get(
                    "post_fusion_regularized_observed_line_count", 0
                )
                > 0,
                "post_fusion_point_fit_not_regressed": raw_p95 is not None
                and final_p95 is not None
                and final_p95 - raw_p95
                <= float(cfg.get("post_fusion_accept_p95_regression_m", 0.02)),
                "post_fusion_topology_not_regressed": metrics.get(
                    "post_fusion_dangling_reduction", -1
                )
                >= 0,
                "post_fusion_observed_length_preserved": metrics.get(
                    "post_fusion_observed_length_ratio", 0.0
                )
                >= float(cfg.get("post_fusion_accept_min_length_ratio", 0.995)),
            }
        )
    if metrics.get("morphology_reextract_enabled", False):
        checks.update(
            {
                "morphology_reextract_present": metrics.get(
                    "morphology_reextract_final_line_count", 0
                )
                > 0,
                "morphology_reextract_source_coverage": metrics.get(
                    "morphology_reextract_original_coverage_0_15m", 0.0
                )
                >= float(cfg.get("post_fusion_reextract_accept_coverage", 0.95)),
                "morphology_reextract_geometry_p95": metrics.get(
                    "morphology_reextract_final_to_original_p95_m", float("inf")
                )
                <= float(cfg.get("post_fusion_reextract_accept_p95_m", 0.10)),
                "morphology_reextract_point_p95": metrics.get(
                    "morphology_reextract_line_to_point_p95_m", float("inf")
                )
                <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
                "morphology_reextract_topology_not_regressed": metrics.get(
                    "morphology_reextract_dangling_reduction", -1
                )
                >= 0,
            }
        )
    if metrics.get("closed_layout_enabled", False):
        minimum_perimeter = metrics.get(
            "closed_layout_min_observed_perimeter_fraction"
        )
        maximum_inferred = metrics.get(
            "closed_layout_max_inferred_perimeter_fraction"
        )
        checks.update(
            {
                "closed_layout_regions_present": metrics.get(
                    "closed_layout_region_count", 0
                )
                > 0,
                "closed_layout_perimeter_supported": minimum_perimeter is not None
                and minimum_perimeter
                >= float(cfg.get("closure_min_observed_perimeter_fraction", 0.80)),
                "closed_layout_inference_bounded": maximum_inferred is not None
                and maximum_inferred
                <= float(cfg.get("closure_max_inferred_perimeter_fraction", 0.20))
                + 1e-9,
                "closed_layout_multiscale_present": metrics.get(
                    "height_thick_slice_count", 0
                )
                > 0,
                "closed_layout_connectivity_improved": metrics.get(
                    "closed_layout_topology_after", {}
                ).get("dangling_endpoint_count", float("inf"))
                < metrics.get("closed_layout_topology_before", {}).get(
                    "dangling_endpoint_count", -1
                ),
                "closed_layout_repair_target": metrics.get(
                    "closed_layout_repair_fraction", 0.0
                )
                >= float(cfg.get("closure_accept_repair_fraction", 0.90)),
                "closed_layout_observed_point_fit": metrics.get(
                    "closed_layout_observed_point_p95_m", float("inf")
                )
                <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
                "closed_layout_observed_point_support": metrics.get(
                    "closed_layout_observed_15cm_support_fraction", 0.0
                )
                >= float(cfg.get("accept_line_support_fraction", 0.95)),
                "closed_layout_disk_regions_valid": bool(
                    metrics.get("closed_layout_disk_all_regions_closed_valid", False)
                ),
            }
        )
    if cfg.get("architectural_enabled", True):
        checks.update(
            {
                "architectural_plan_present": metrics.get(
                    "architectural_wall_count", 0
                )
                > 0,
                "architectural_line_to_point_p95": metrics.get(
                    "architectural_line_to_point_p95_m", float("inf")
                )
                <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
                "architectural_line_support": metrics.get(
                    "architectural_line_support_fraction_0_15m", 0.0
                )
                >= float(cfg.get("accept_line_support_fraction", 0.95)),
                "architectural_frozen_evidence": metrics.get(
                    "frozen_coverage_change",
                    metrics.get("solver", {}).get("coverage_change", -1.0),
                )
                >= -float(cfg.get("architectural_max_coverage_regression", 0.02)),
                "architectural_short_spurs": metrics.get(
                    "unsupported_short_spur_reduction_fraction", -1.0
                )
                >= float(cfg.get("architectural_target_spur_reduction", 0.60)),
                "architectural_duplicate_walls": metrics.get(
                    "near_parallel_duplicate_reduction_fraction", -1.0
                )
                >= float(cfg.get("architectural_target_duplicate_reduction", 0.80)),
                # A one-session data set has no independent acquisition to
                # hold out.  Treat that check as not applicable rather than
                # crashing on ``None <= threshold`` or reporting a false
                # geometric failure.
                "architectural_independent_session_residual": independent_pass,
                "architectural_shared_nodes": metrics.get(
                    "architectural_shared_node_max_spread_m", float("inf")
                )
                <= 0.001,
                "architectural_disk_dxf": (
                    metrics.get("architectural_disk_dxf_audit", {}).get(
                        "required_layers_present", False
                    )
                    and metrics.get("architectural_disk_dxf_audit", {}).get(
                        "uncertain_layer_off", False
                    )
                    and metrics.get("architectural_disk_dxf_audit", {}).get(
                        "inferred_layer_off", False
                    )
                    and metrics.get("architectural_disk_dxf_audit", {}).get(
                        "finite_geometry", False
                    )
                    and metrics.get("architectural_disk_dxf_audit", {}).get(
                        "class_layer_mismatch_count", 1
                    )
                    == 0
                    and metrics.get("architectural_disk_dxf_audit", {}).get(
                        "shared_node_max_spread_m", float("inf")
                    )
                    <= 0.001
                ),
            }
        )
        if str(metrics.get("algorithm_version", "")).startswith(
            "structure-graph-v5"
        ):
            checks.update(
                {
                    "architectural_frozen_evidence": metrics.get(
                        "frozen_coverage_change", -1.0
                    )
                    >= -float(
                        cfg.get("architectural_max_coverage_regression", 0.02)
                    ),
                    "architectural_short_spurs": metrics.get(
                        "unsupported_short_spur_reduction_fraction", -1.0
                    )
                    >= float(cfg.get("architectural_target_spur_reduction", 0.60)),
                    "architectural_duplicate_walls": metrics.get(
                        "near_parallel_duplicate_reduction_fraction", -1.0
                    )
                    >= float(
                        cfg.get("architectural_target_duplicate_reduction", 0.80)
                    ),
                    "architectural_independent_session_residual": independent_pass,
                }
            )
    if cfg.get("reconstruction_strategy") == "semantic_objects":
        # V13 replaces V11's region-closure deliverable with a shared object
        # graph.  Do not fail it on stale V11 products copied for comparison.
        for key in [value for value in checks if value.startswith("closed_layout_")]:
            checks.pop(key, None)
        semantic_v14 = bool(cfg.get("semantic_probability_path"))
        prefix = "v14" if semantic_v14 else "v13"
        semantic_point_audit = metrics.get("semantic_object_semantic_point_audit", {}) or {}
        semantic_model_audit = metrics.get("semantic_object_semantic_model_audit", {}) or {}
        frozen_retention = (
            metrics.get(
                "semantic_object_previous_frozen_reliable_evidence_retention_fraction"
            )
            if semantic_v14
            else metrics.get(
                "semantic_object_frozen_reliable_structural_evidence_15cm_coverage_fraction"
            )
        )
        checks.update(
            {
                f"{prefix}_shared_object_graph_present": metrics.get(
                    "semantic_object_wall_count", 0
                )
                > 0,
                f"{prefix}_multiscale_evidence_present": metrics.get(
                    "height_thick_slice_count", 0
                )
                > 0,
                f"{prefix}_native_curves_present": (
                    metrics.get("semantic_object_arc_primitive_count", 0)
                    + metrics.get("semantic_object_spline_primitive_count", 0)
                )
                > 0,
                f"{prefix}_wall_point_p95": metrics.get(
                    "semantic_object_wall_to_point_p95_m", float("inf")
                )
                <= float(cfg.get("accept_line_to_point_p95_m", 0.10)),
                f"{prefix}_wall_point_support": metrics.get(
                    "semantic_object_wall_15cm_support_fraction", 0.0
                )
                >= float(cfg.get("accept_line_support_fraction", 0.95)),
                f"{prefix}_frozen_structure_retention": (
                    0.0 if frozen_retention is None else float(frozen_retention)
                )
                >= float(cfg.get("semantic_accept_structure_retention", 0.98)),
                f"{prefix}_native_dxf_valid": bool(
                    metrics.get("semantic_object_native_dxf_valid", False)
                ),
                f"{prefix}_human_semantics_ready": (
                    bool(semantic_point_audit.get("accepted_voxel_count", 0))
                    and bool(semantic_model_audit.get("candidate_augmentation_enabled", False))
                    and semantic_model_audit.get("backend") == "sonata_ptv3"
                    if semantic_v14
                    else metrics.get("semantic_object_semantic_model_status")
                    == "accepted_human_label_model"
                ),
            }
        )
    return checks


def run_height_slices_from_cached(
    cfg: dict,
    output_dir: str | Path,
    force: bool = False,
    reuse_from: str | Path | None = None,
) -> dict:
    """Run only height-aware vectorisation from cached SLAM maps/transforms."""
    height_cfg = cfg.get("height_slices", {})
    root = Path(height_cfg.get("source_output_dir", cfg["project"]["output_dir"]))
    output_dir = Path(output_dir).resolve()
    reuse_dir = None if reuse_from is None else Path(reuse_from).resolve()
    report_path = root / "report.json"
    transforms_path = root / "transforms" / "transforms.json"
    if not transforms_path.is_file():
        raise PipelineError(
            "Cached transforms are missing; run the main pipeline before height-slices"
        )
    transforms = read_json(transforms_path)
    session_transforms = transforms.get("T_reference_slam_session", {})
    if report_path.is_file():
        report = read_json(report_path)
    elif reuse_dir is not None and (reuse_dir / "summary.json").is_file():
        # PCD-only vectorize runs predate the root report.  Their cleaned
        # reference-frame cloud and rigid transforms are sufficient for an
        # explicitly requested reusable height-slice run.
        report = {
            "accepted_sessions": list(session_transforms),
            "session_quality": {},
            "outline": {},
            "report_reconstructed_from_reuse": str(reuse_dir),
        }
    else:
        raise PipelineError(
            "Cached report is missing; provide --reuse-from with a complete height-slice run"
        )
    accepted_names = report.get("accepted_sessions") or list(session_transforms)
    if not accepted_names:
        raise PipelineError("No accepted cached SLAM sessions were found")

    map_paths: list[Path] = []
    named_points: list[tuple[str, np.ndarray]] = []
    for name in accepted_names:
        map_path = root / "slam" / name / "GlobalMap.pcd"
        transform_value = session_transforms.get(name, {}).get(
            "T_reference_slam_session_slam"
        )
        if map_path.is_file() and transform_value is not None:
            map_paths.append(map_path)
            named_points.append(
                (
                    name,
                    transform_points(
                        read_point_cloud(map_path), np.asarray(transform_value, dtype=float)
                    ),
                )
            )
            continue
        reused_session = None if reuse_dir is None else reuse_dir / "clean_sessions" / f"{name}.pcd"
        if reused_session is not None and reused_session.is_file():
            map_paths.append(reused_session)
            named_points.append((name, read_point_cloud(reused_session)))
            continue
        if reuse_dir is not None and len(accepted_names) == 1 and (reuse_dir / "clean_interior.pcd").is_file():
            reused_clean = reuse_dir / "clean_interior.pcd"
            map_paths.append(reused_clean)
            named_points.append((name, read_point_cloud(reused_clean)))
            continue
        raise PipelineError(f"Missing cached map/transform or reusable cleaned session for {name}")

    digest_inputs = [*map_paths, transforms_path]
    if report_path.is_file():
        digest_inputs.append(report_path)
    if reuse_dir is not None:
        digest_inputs.extend(
            [reuse_dir / "summary.json", reuse_dir / "clean_interior.pcd"]
        )
    semantic_report = height_cfg.get("semantic_model_report")
    if semantic_report and Path(semantic_report).is_file():
        digest_inputs.append(Path(semantic_report))
    semantic_labels = height_cfg.get("semantic_labels_path")
    if semantic_labels and Path(semantic_labels).is_file():
        digest_inputs.append(Path(semantic_labels))
    semantic_probability = height_cfg.get("semantic_probability_path")
    if semantic_probability:
        probability_path = Path(semantic_probability)
        if not probability_path.is_file():
            raise PipelineError(
                f"Configured semantic point probabilities are missing: {probability_path}"
            )
        digest_inputs.append(probability_path)
    digest = fingerprint(
        digest_inputs,
        {
            "height_slices": height_cfg,
            "vision_vector_settings": {
                key: value
                for key, value in cfg.get("vision_layout", {}).items()
                if key.startswith("vector_")
            },
        },
        "height-slices-v14-semantic-points"
        if height_cfg.get("semantic_probability_path")
        else "height-slices-v13-semantic-objects"
        if height_cfg.get("reconstruction_strategy") == "semantic_objects"
        else "height-slices-v12-high-slice-observed-backbone",
    )
    summary_path = output_dir / "summary.json"
    manifest_path = output_dir / "manifest.json"
    required = [
        summary_path,
        output_dir / "height_aware_combined.dxf",
        output_dir / "minimum_intersection.dxf",
        output_dir / "robust_intersection.dxf",
        output_dir / "maximum_union.dxf",
        output_dir / "minimum_intersection.png",
        output_dir / "robust_intersection.png",
        output_dir / "maximum_union.png",
        output_dir / "intersection_union_comparison.png",
        output_dir / "height_aware.geojson",
        output_dir / "final_dxf.png",
        output_dir / "calibration_before_after.png",
        output_dir / "architectural_plan.dxf",
        output_dir / "architectural_plan.geojson",
        output_dir / "architectural_comparison.png",
        output_dir / "architectural_v7_v8_comparison.png",
        output_dir / "high_backbone_reference.png",
        output_dir / "backbone_v4_v5_comparison.png",
        output_dir / "architectural_audit.json",
        output_dir / "structure_evidence.npz",
        output_dir / "full_observation.png",
        output_dir / "architectural_height.png",
        output_dir / "inferred_connections_diagnostic.png",
        output_dir / "detail_oblique_wall.png",
        output_dir / "detail_central_junctions.png",
        output_dir / "detail_top_annex.png",
        output_dir / "height_set_disk_audit.json",
        output_dir / "final_merged.dxf",
        output_dir / "final_merged.png",
        output_dir / "postprocessed_merged.dxf",
        output_dir / "postprocessed_merged.png",
        output_dir / "maximum_union_postprocessed_comparison.png",
        output_dir / "post_fusion_audit.json",
        output_dir / "morphology_reextracted.dxf",
        output_dir / "final_morphology.dxf",
        output_dir / "morphology_reextracted.png",
        output_dir / "morphology_process.png",
        output_dir / "postfusion_morphology_comparison.png",
        output_dir / "morphology_reextract_audit.json",
        output_dir / "thick_minimum_intersection.dxf",
        output_dir / "thick_maximum_union.dxf",
        output_dir / "thick_minimum_intersection.png",
        output_dir / "thick_maximum_union.png",
        output_dir / "thick_slice_overview.png",
        output_dir / "closed_layout.dxf",
        output_dir / "final_observed_wall_plan.dxf",
        output_dir / "closed_layout.png",
        output_dir / "closed_layout.geojson",
        output_dir / "closed_layout_audit.json",
        output_dir / "lidar_v10_v11_comparison.png",
        output_dir / "lidar_v10_v12_comparison.png",
        output_dir / "connection_candidates.png",
        output_dir / "closure_morphology_scales.png",
        output_dir / "closure_skeleton_scales.png",
        output_dir / "closure_morphology_revector.geojson",
        output_dir / "closed_regions_diagnostic.png",
    ]
    if height_cfg.get("calibration_strategy") == "shared_wall_evidence":
        required.extend(
            [
                output_dir / "calibrated_common.dxf",
                output_dir / "calibrated_common.png",
                output_dir / "shared_wall_model.geojson",
                output_dir / "support_matrix.json",
                output_dir / "support_matrix.png",
                output_dir / "v7_v8_intersection_comparison.png",
                output_dir / "shared_wall_audit.json",
                output_dir / "v8_recovery_audit.json",
                output_dir / "raw_observed_union.dxf",
                output_dir / "raw_observed_union.png",
            ]
        )
    if height_cfg.get("reconstruction_strategy") == "semantic_objects":
        required.extend(
            [
                output_dir / "building_object_complete.dxf",
                output_dir / "building_object_complete.png",
                output_dir / "building_object_graph.json",
                output_dir / "semantic_object_audit.json",
                output_dir / "semantic_evidence_heatmap.png",
                output_dir / "semantic_evidence.npz",
                output_dir / "semantic_label_candidates.json",
                output_dir / "semantic_label_atlas.png",
                output_dir / "v13_strict_intersection.dxf",
                output_dir / "v13_observed_union.dxf",
                output_dir / "v13_strict_intersection.png",
                output_dir / "v13_observed_union.png",
                output_dir / "v13_thick_strict_intersection.dxf",
                output_dir / "v13_thick_observed_union.dxf",
                output_dir / "v13_thick_strict_intersection.png",
                output_dir / "v13_thick_observed_union.png",
                output_dir / "lidar_v12_v13_comparison.png",
                output_dir / "detail_bottom_curve_lidar_v12_v13.png",
                output_dir / "detail_top_turn_lidar_v12_v13.png",
                output_dir / "detail_column_cluster_lidar_v12_v13.png",
                output_dir / "detail_uncertain_interference_lidar_v12_v13.png",
            ]
        )
    if summary_path.is_file():
        cached_summary = read_json(summary_path)
        for row in cached_summary.get("slices", []):
            index = int(row["index"])
            required.extend(
                [
                    Path(row["raw_dxf"]),
                    Path(row["calibrated_dxf"]),
                    output_dir / "projections" / f"slice_{index:02d}_projection.png",
                    output_dir / "overlays_before" / f"slice_{index:02d}_before.png",
                    output_dir / "overlays_after" / f"slice_{index:02d}_after.png",
                ]
            )
            if height_cfg.get("reconstruction_strategy") == "semantic_objects":
                required.append(
                    output_dir / "semantic_overlays" / f"slice_{index:02d}_semantic.png"
                )
        for row in cached_summary.get("thick_slices", []):
            index = int(row["index"])
            required.extend(
                [
                    Path(row["raw_dxf"]),
                    Path(row["calibrated_dxf"]),
                    output_dir
                    / "projections_thick"
                    / f"thick_{index:02d}_projection.png",
                    output_dir
                    / "overlays_after_thick"
                    / f"thick_{index:02d}_after.png",
                ]
            )
            if height_cfg.get("reconstruction_strategy") == "semantic_objects":
                required.append(
                    output_dir / "semantic_overlays_thick" / f"thick_{index:02d}_semantic.png"
                )
    if not force and cache_valid(manifest_path, digest, required):
        return read_json(summary_path)

    if (
        height_cfg.get("reconstruction_strategy") == "semantic_objects"
        and reuse_dir is not None
    ):
        height_cfg["_semantic_session_count"] = int(len(named_points))
        summary = run_semantic_objects_from_reuse(
            reuse_dir,
            output_dir,
            np.asarray(transforms["T_cad_reference_slam"], dtype=float),
            height_cfg,
        )
        checks = _height_slice_acceptance(summary["metrics"], height_cfg)
        summary["acceptance"] = checks
        summary["acceptance_passed"] = all(checks.values())
        summary["algorithm_version"] = (
            "height-slices-v14-semantic-points"
            if height_cfg.get("semantic_probability_path")
            else "height-slices-v13-semantic-objects"
        )
        write_json(summary_path, summary)
        completed_required = list(required)
        for row in summary.get("slices", []):
            index = int(row["index"])
            completed_required.extend(
                [
                    Path(row["raw_dxf"]),
                    Path(row["calibrated_dxf"]),
                    output_dir / "projections" / f"slice_{index:02d}_projection.png",
                    output_dir / "overlays_before" / f"slice_{index:02d}_before.png",
                    output_dir / "overlays_after" / f"slice_{index:02d}_after.png",
                    output_dir / "semantic_overlays" / f"slice_{index:02d}_semantic.png",
                ]
            )
        for row in summary.get("thick_slices", []):
            index = int(row["index"])
            completed_required.extend(
                [
                    Path(row["raw_dxf"]),
                    Path(row["calibrated_dxf"]),
                    output_dir / "projections_thick" / f"thick_{index:02d}_projection.png",
                    output_dir / "overlays_after_thick" / f"thick_{index:02d}_after.png",
                    output_dir / "semantic_overlays_thick" / f"thick_{index:02d}_semantic.png",
                ]
            )
        completed_required = list(dict.fromkeys(completed_required))
        missing_outputs = [
            str(path) for path in completed_required if not Path(path).is_file()
        ]
        if missing_outputs:
            raise PipelineError(
                "V13 reused output set is incomplete:\n" + "\n".join(missing_outputs)
            )
        write_json(
            manifest_path,
            {
                "fingerprint": digest,
                "algorithm_version": summary["algorithm_version"],
                "inputs": [str(path) for path in map_paths],
                "outputs": [str(path) for path in completed_required],
                "reuse_from": str(reuse_dir),
            },
        )
        return summary

    quality = report.get("session_quality", {})
    ceiling_values = [
        quality.get(name, {}).get("ceiling_height_m") for name in accepted_names
    ]
    ceiling_values = [float(value) for value in ceiling_values if value is not None]
    ceiling_hint = float(np.median(ceiling_values)) if ceiling_values else None
    main_angle = math.radians(
        float(report.get("outline", {}).get("detail_main_direction_deg") or 0.0)
    )
    semantic_objects_cad = []
    semantic_path = root / "cad" / "outline.geojson"
    if semantic_path.is_file():
        for feature in read_json(semantic_path).get("features", []):
            class_name = str(feature.get("properties", {}).get("class", "")).upper()
            geometry = feature.get("geometry", {})
            if class_name in {"COLUMN", "CORE"} and geometry.get("type") == "Polygon":
                coordinates = geometry.get("coordinates", [[]])[0]
                if len(coordinates) >= 3:
                    semantic_objects_cad.append(
                        {"class": class_name, "coordinates": coordinates}
                    )
    summary = run_height_slice_stage(
        np.vstack([points for _, points in named_points]),
        np.asarray(transforms["T_cad_reference_slam"], dtype=float),
        ceiling_hint,
        main_angle,
        output_dir,
        height_cfg,
        cfg.get("vision_layout", {}),
        session_points_ref=named_points,
        semantic_objects_cad=semantic_objects_cad,
        reuse_from=reuse_dir,
    )
    checks = _height_slice_acceptance(summary["metrics"], height_cfg)
    summary["acceptance"] = checks
    summary["acceptance_passed"] = all(checks.values())
    summary["algorithm_version"] = (
        "height-slices-v14-semantic-points"
        if height_cfg.get("semantic_probability_path")
        else "height-slices-v13-semantic-objects"
        if height_cfg.get("reconstruction_strategy") == "semantic_objects"
        else "height-slices-v12-high-slice-observed-backbone"
        if height_cfg.get("calibration_strategy") == "shared_wall_evidence"
        else "height-slices-v5-high-slice-backbone"
    )
    write_json(summary_path, summary)
    completed_required = list(required)
    for row in summary.get("slices", []):
        index = int(row["index"])
        completed_required.extend(
            [
                Path(row["raw_dxf"]),
                Path(row["calibrated_dxf"]),
                output_dir / "projections" / f"slice_{index:02d}_projection.png",
                output_dir / "overlays_before" / f"slice_{index:02d}_before.png",
                output_dir / "overlays_after" / f"slice_{index:02d}_after.png",
            ]
        )
        if height_cfg.get("reconstruction_strategy") == "semantic_objects":
            completed_required.append(
                output_dir / "semantic_overlays" / f"slice_{index:02d}_semantic.png"
            )
    for row in summary.get("thick_slices", []):
        index = int(row["index"])
        completed_required.extend(
            [
                Path(row["raw_dxf"]),
                Path(row["calibrated_dxf"]),
                output_dir / "projections_thick" / f"thick_{index:02d}_projection.png",
                output_dir / "overlays_after_thick" / f"thick_{index:02d}_after.png",
            ]
        )
        if height_cfg.get("reconstruction_strategy") == "semantic_objects":
            completed_required.append(
                output_dir / "semantic_overlays_thick" / f"thick_{index:02d}_semantic.png"
            )
    completed_required = list(dict.fromkeys(completed_required))
    missing_outputs = [str(path) for path in completed_required if not Path(path).is_file()]
    if missing_outputs:
        raise PipelineError(
            "Height-slice output set is incomplete:\n" + "\n".join(missing_outputs)
        )
    write_json(
        manifest_path,
        {
            "fingerprint": digest,
            "algorithm_version": summary["algorithm_version"],
            "inputs": [str(path) for path in map_paths],
            "outputs": [str(path) for path in completed_required],
        },
    )
    return summary


def process_maps(cfg: dict, sessions: list[dict], force: bool = False) -> dict:
    dirs = ensure_dirs(cfg["project"]["output_dir"])
    successful = [item for item in sessions if item["accepted"]]
    if not successful:
        raise DataQualityError("No successful maps")
    report_path = Path(cfg["project"]["output_dir"]) / "report.json"
    final_outputs = [
        dirs["maps"] / "merged.pcd",
        dirs["maps"] / "structural.pcd",
        dirs["maps"] / "detail_source.pcd",
        dirs["cad"] / "outline.dxf",
        dirs["cad"] / "outline.png",
        dirs["cad"] / "outline.geojson",
        dirs["transforms"] / "transforms.json",
        dirs["qa"] / "density.png",
        dirs["qa"] / "structural_mask.png",
        dirs["qa"] / "session_registration.png",
        dirs["qa"] / "outline_overlay.png",
        dirs["qa"] / "lidar_dxf_comparison.png",
        report_path,
    ]
    if cfg.get("deep_layout", {}).get("enabled", False):
        final_outputs.insert(-1, Path(cfg["project"]["output_dir"]) / "deep_layout" / "prediction_summary.json")
    if cfg.get("vision_layout", {}).get("enabled", False):
        vision_dir = Path(cfg["project"]["output_dir"]) / "vision_layout"
        final_outputs[-1:-1] = [
            vision_dir / "lane2structure.pt",
            vision_dir / "metrics.json",
            vision_dir / "accepted_mask.png",
            vision_dir / "bev_model_comparison.png",
        ]
    if cfg.get("height_slices", {}).get("enabled", False):
        height_dir = Path(cfg["project"]["output_dir"]) / "height_slices"
        final_outputs[-1:-1] = [
            height_dir / "summary.json",
            height_dir / "clean_interior.pcd",
            height_dir / "minimum_intersection.dxf",
            height_dir / "robust_intersection.dxf",
            height_dir / "maximum_union.dxf",
            height_dir / "minimum_intersection.png",
            height_dir / "robust_intersection.png",
            height_dir / "maximum_union.png",
            height_dir / "intersection_union_comparison.png",
            height_dir / "height_aware_combined.dxf",
            height_dir / "height_aware.geojson",
            height_dir / "height_consensus.png",
            height_dir / "slice_overview.png",
            height_dir / "final_dxf.png",
            height_dir / "calibration_before_after.png",
            height_dir / "final_merged.dxf",
            height_dir / "final_merged.png",
            height_dir / "postprocessed_merged.dxf",
            height_dir / "postprocessed_merged.png",
            height_dir / "maximum_union_postprocessed_comparison.png",
            height_dir / "post_fusion_audit.json",
            height_dir / "morphology_reextracted.dxf",
            height_dir / "final_morphology.dxf",
            height_dir / "morphology_reextracted.png",
            height_dir / "morphology_process.png",
            height_dir / "postfusion_morphology_comparison.png",
            height_dir / "morphology_reextract_audit.json",
            height_dir / "thick_minimum_intersection.dxf",
            height_dir / "thick_maximum_union.dxf",
            height_dir / "thick_minimum_intersection.png",
            height_dir / "thick_maximum_union.png",
            height_dir / "thick_slice_overview.png",
            height_dir / "closed_layout.dxf",
            height_dir / "final_observed_wall_plan.dxf",
            height_dir / "closed_layout.png",
            height_dir / "closed_layout.geojson",
            height_dir / "closed_layout_audit.json",
            height_dir / "lidar_v10_v11_comparison.png",
            height_dir / "lidar_v10_v12_comparison.png",
            height_dir / "connection_candidates.png",
            height_dir / "closure_morphology_scales.png",
            height_dir / "closure_skeleton_scales.png",
            height_dir / "closure_morphology_revector.geojson",
            height_dir / "closed_regions_diagnostic.png",
        ]
        if cfg.get("height_slices", {}).get("calibration_strategy") == "shared_wall_evidence":
            final_outputs[-1:-1] = [
                height_dir / "calibrated_common.dxf",
                height_dir / "calibrated_common.png",
                height_dir / "shared_wall_model.geojson",
                height_dir / "support_matrix.json",
                height_dir / "support_matrix.png",
                height_dir / "v7_v8_intersection_comparison.png",
                height_dir / "shared_wall_audit.json",
                height_dir / "v8_recovery_audit.json",
                height_dir / "raw_observed_union.dxf",
                height_dir / "raw_observed_union.png",
            ]
    map_paths = [item["map"] for item in successful]
    digest = fingerprint(
        map_paths,
        {
            "registration": cfg["registration"],
            "structure": cfg["structure"],
            "vision_layout": cfg.get("vision_layout", {}),
            "height_slices": cfg.get("height_slices", {}),
            "deep_layout": cfg.get("deep_layout", {}),
            "acceptance": cfg["acceptance"],
        },
        "fusion-v30-multiscale-closed-layout",
    )
    fusion_manifest = Path(cfg["project"]["output_dir"]) / "fusion.manifest.json"
    if not force and cache_valid(fusion_manifest, digest, final_outputs):
        return read_json(report_path)
    loaded = []
    for item in successful:
        raw = read_point_cloud(item["map"])
        quality, leveled = assess_session(raw, item.get("trajectory"), cfg)
        item["quality"] = quality
        structural = _structural_for_registration(leveled.points, cfg, leveled.ceiling_height_m)
        loaded.append({**item, "raw": raw, "leveled": leveled, "structural": structural})
    reference = max(loaded, key=lambda item: item["quality"]["score"])
    transforms_level_ref: dict[str, np.ndarray] = {reference["name"]: np.eye(4)}
    registration_reports = {reference["name"]: {"accepted": True, "reference": True, "rmse_m": 0.0, "overlap": 1.0}}
    accepted = [reference]
    for item in loaded:
        if item is reference:
            continue
        result = register_se2(reference["structural"][:, :2], item["structural"][:, :2], cfg["registration"])
        registration_reports[item["name"]] = {
            "accepted": result.accepted,
            "rmse_m": result.rmse_m,
            "overlap": result.overlap,
            "wall_direction_residual_deg": result.wall_direction_residual_deg,
            "score": result.score,
        }
        if result.accepted:
            transforms_level_ref[item["name"]] = result.transform_ref_from_moving
            accepted.append(item)

    session_points_ref = []
    named_session_points_ref: list[tuple[str, np.ndarray]] = []
    trajectories_ref = []
    transforms_json = {}
    for item in accepted:
        se2 = transforms_level_ref[item["name"]]
        full = se2 @ item["leveled"].transform_level_from_input
        inverse = invert_transform(full)
        transforms_json[item["name"]] = {
            "T_reference_slam_session_slam": matrix_json(full),
            "T_session_slam_reference_slam": matrix_json(inverse),
        }
        transformed_session = transform_points(item["raw"], full)
        session_points_ref.append(transformed_session)
        named_session_points_ref.append((item["name"], transformed_session))
        trajectory = read_trajectory(item.get("trajectory"))
        if trajectory is not None:
            trajectories_ref.append(transform_points(trajectory[1], full))

    merged = voxel_downsample(np.vstack(session_points_ref), float(cfg["structure"]["grid_m"]))
    write_point_cloud(dirs["maps"] / "merged.pcd", merged)
    ceiling_values = [item["leveled"].ceiling_height_m for item in accepted if item["leveled"].ceiling_height_m]
    result = vectorize_sessions(
        session_points_ref,
        {**cfg["structure"], "shell_support_distance_m": cfg["acceptance"]["shell_support_distance_m"]},
        np.vstack(trajectories_ref) if trajectories_ref else None,
        float(np.median(ceiling_values)) if ceiling_values else None,
        cfg.get("vision_layout", {}),
        str(Path(cfg["project"]["output_dir"]) / "vision_layout"),
        force,
    )
    deep_cfg = cfg.get("deep_layout", {})
    if deep_cfg.get("enabled", False):
        result = run_deep_layout_stage(
            result,
            Path(cfg["project"]["output_dir"]) / "deep_layout",
            deep_cfg,
            force,
        )
    height_summary: dict = {}
    if cfg.get("height_slices", {}).get("enabled", False):
        height_summary = run_height_slice_stage(
            np.vstack(session_points_ref),
            result.transform_cad_from_ref,
            float(np.median(ceiling_values)) if ceiling_values else None,
            math.radians(float(result.metrics.get("detail_main_direction_deg") or 0.0)),
            Path(cfg["project"]["output_dir"]) / "height_slices",
            cfg.get("height_slices", {}),
            cfg.get("vision_layout", {}),
            session_points_ref=named_session_points_ref,
            semantic_objects_cad=[
                {
                    "class": klass,
                    "coordinates": np.asarray(polygon.exterior.coords, dtype=float).tolist(),
                }
                for klass, polygon, _ in result.internals_cad
                if str(klass).upper() in {"COLUMN", "CORE"}
            ],
        )
        result.metrics.update(height_summary["metrics"])
    write_point_cloud(dirs["maps"] / "structural.pcd", result.structural_points_ref)
    write_point_cloud(dirs["maps"] / "detail_source.pcd", result.detail_points_ref)
    multi_session = len(accepted) >= 2
    confidence = (
        0.95
        if multi_session and result.metrics.get("deep_layout_accepted", False)
        else 0.9
        if multi_session and not result.metrics["fallback_shell"]
        else 0.45
    )
    export_dxf(dirs["cad"] / "outline.dxf", result)
    export_geojson(dirs["cad"] / "outline.geojson", result, cfg["project"]["level"], confidence)
    export_transforms(dirs["transforms"] / "transforms.json", result, transforms_json)
    save_density(dirs["qa"] / "density.png", result.detail_points_ref, float(cfg["structure"].get("detail_grid_m", cfg["structure"]["grid_m"])))
    save_mask(dirs["qa"] / "structural_mask.png", result.raster)
    save_registration(
        dirs["qa"] / "session_registration.png",
        [item["leveled"].points for item in accepted],
        [transforms_level_ref[item["name"]] for item in accepted],
        float(cfg["structure"]["grid_m"]),
    )
    save_outline_overlay(dirs["qa"] / "outline_overlay.png", result, trajectories_ref)
    save_lidar_dxf_comparison(
        dirs["qa"] / "lidar_dxf_comparison.png",
        result,
        dirs["cad"] / "outline.png",
    )
    if result.metrics.get("wall_topology_source") == "vision_prediction_skeleton_graph":
        save_prediction_dxf_comparison(dirs["qa"] / "prediction_dxf_comparison.png", result)

    metrics = result.metrics
    internal_objects = [
        {"class": klass, "area_m2": float(polygon.area), "session_confidence": float(object_confidence)}
        for klass, polygon, object_confidence in result.internals_cad
    ]
    acceptance = {
        "valid_closed_shell": bool(metrics["closed"] and metrics["valid"] and not metrics["self_intersects"]),
        "registration_rmse": all(
            row.get("rmse_m", 0.0) <= float(cfg["registration"]["rmse_max_m"])
            for row in registration_reports.values()
            if row["accepted"]
        ),
        "outline_median": metrics["outline_distance_median_m"] <= float(cfg["acceptance"]["outline_median_m"]),
        "outline_p95": metrics["outline_distance_p95_m"] <= float(cfg["acceptance"]["outline_p95_m"]),
        "shell_support": metrics["shell_support_fraction"] >= float(cfg["acceptance"]["shell_support_fraction"]),
        "internal_stability": all(item["session_confidence"] >= 1.0 for item in internal_objects),
        "detailed_plan_present": metrics["wall_polygon_count"] > 0 and metrics["wall_centerline_count"] > 0,
        "straight_wall_accuracy": (
            metrics.get("straight_wall_distance_median_m") is not None
            and metrics["straight_wall_distance_median_m"] <= float(cfg["acceptance"]["outline_median_m"])
            and metrics["straight_wall_distance_p95_m"] <= float(cfg["acceptance"]["outline_p95_m"])
            and metrics["straight_wall_support_fraction"] >= float(cfg["acceptance"]["shell_support_fraction"])
        ),
        "wall_evidence_coverage": metrics.get("raw_wall_structural_evidence_coverage_fraction", 0.0)
        >= float(cfg["acceptance"].get("wall_evidence_coverage_fraction", 0.80)),
        "topological_wall_network": (
            metrics.get("straight_wall_connected_endpoint_fraction", 0.0)
            >= float(cfg["acceptance"].get("topology_connected_endpoint_fraction", 0.70))
            and metrics.get("topology_outside_shell_fraction", 1.0)
            <= float(cfg["acceptance"].get("topology_outside_shell_fraction", 0.02))
        ),
        "height_slice_consensus": (
            not cfg.get("height_slices", {}).get("enabled", False)
            or all(
                _height_slice_acceptance(
                    metrics, cfg.get("height_slices", {})
                ).values()
            )
        ),
        "transform_round_trip": all(
            np.allclose(np.asarray(value["T_reference_slam_session_slam"]) @ np.asarray(value["T_session_slam_reference_slam"]), np.eye(4), atol=1e-7)
            for value in transforms_json.values()
        ),
    }
    detailed_plan_acceptance_keys = (
        "registration_rmse",
        "internal_stability",
        "detailed_plan_present",
        "straight_wall_accuracy",
        "wall_evidence_coverage",
        "topological_wall_network",
        "height_slice_consensus",
        "transform_round_trip",
    )
    report = {
        "project": cfg["project"]["name"],
        "reference_session": reference["name"],
        "accepted_sessions": [item["name"] for item in accepted],
        "excluded_sessions": [item["name"] for item in loaded if item["name"] not in {value["name"] for value in accepted}]
        + [item["name"] for item in sessions if not item["accepted"]],
        "registration": registration_reports,
        "session_quality": {item["name"]: item.get("quality") for item in successful},
        "session_failures": {item["name"]: item.get("reason") for item in sessions if not item["accepted"]},
        "outline": metrics,
        "internal_objects": internal_objects,
        "detailed_plan": {
            "source": (
                "vision_cleaned_dense_merged_lidar"
                if metrics.get("vision_layout_accepted", False)
                else "dense_merged_lidar"
            ),
            "source_point_count": metrics["detail_source_point_count"],
            "wall_polygon_count": metrics["wall_polygon_count"],
            "wall_centerline_count": metrics["wall_centerline_count"],
            "scan_detail_line_count": metrics["scan_detail_line_count"],
            "inferred_space_count": metrics["inferred_space_count"],
            "straight_wall_error_median_m": metrics.get("straight_wall_distance_median_m"),
            "straight_wall_error_p95_m": metrics.get("straight_wall_distance_p95_m"),
            "straight_wall_support_fraction": metrics.get("straight_wall_support_fraction"),
            "straight_wall_evidence_coverage_fraction": metrics.get("straight_wall_evidence_coverage_fraction"),
            "straight_wall_structural_evidence_coverage_fraction": metrics.get(
                "straight_wall_structural_evidence_coverage_fraction"
            ),
            "straight_wall_connected_endpoint_fraction": metrics.get(
                "straight_wall_connected_endpoint_fraction"
            ),
            "topology_source": metrics.get("wall_topology_source"),
            "topology_component_count": metrics.get("topology_component_count"),
            "topology_outside_shell_fraction": metrics.get("topology_outside_shell_fraction"),
            "raw_wall_evidence_line_count": metrics.get("raw_wall_evidence_line_count"),
            "raw_wall_evidence_coverage_fraction": metrics.get("raw_wall_evidence_coverage_fraction"),
            "raw_wall_structural_evidence_coverage_fraction": metrics.get(
                "raw_wall_structural_evidence_coverage_fraction"
            ),
            "vision_layout": {
                "backend": metrics.get("vision_layout_backend"),
                "architecture": metrics.get("vision_layout_architecture"),
                "accepted": metrics.get("vision_layout_accepted", False),
                "device": metrics.get("vision_layout_device"),
                "parameter_count": metrics.get("vision_layout_parameter_count"),
                "epochs": metrics.get("vision_layout_epoch_count"),
                "pseudo_iou": metrics.get("vision_layout_pseudo_iou"),
                "pseudo_f1": metrics.get("vision_layout_pseudo_f1"),
                "evidence_precision": metrics.get("vision_layout_evidence_precision"),
                "scatter_rejected_cells": metrics.get("vision_layout_scatter_rejected_cells"),
                "gap_completed_cells": metrics.get("vision_layout_gap_completed_cells"),
                "error": metrics.get("vision_layout_error"),
            },
            "deep_layout": {
                "backend": metrics.get("deep_layout_backend"),
                "accepted": metrics.get("deep_layout_accepted", False),
                "wall_fusion_accepted": metrics.get("deep_layout_wall_fusion_accepted", False),
                "fixture_fusion_accepted": metrics.get("deep_layout_fixture_fusion_accepted", False),
                "tile_count": metrics.get("deep_layout_tile_count", 0),
                "raw_wall_count": metrics.get("deep_layout_raw_wall_count", 0),
                "refined_wall_count": metrics.get("deep_layout_refined_wall_count", 0),
                "door_count": metrics.get("deep_layout_door_count", 0),
                "window_count": metrics.get("deep_layout_window_count", 0),
                "candidate_error_median_m": metrics.get("deep_layout_candidate_median_error_m"),
                "candidate_error_p95_m": metrics.get("deep_layout_candidate_p95_error_m"),
                "candidate_support_fraction": metrics.get("deep_layout_candidate_support_fraction"),
            },
            "height_slices": height_summary,
            "layers": ["OUTER_SHELL", "WALL", "DOOR", "WINDOW", "WALL_FOOTPRINT", "SCAN_DETAIL", "SPACE", "COLUMN", "CORE", "MIN_INTERSECTION", "MAX_UNION", "SLICE_Z_*"],
        },
        "confidence": confidence,
        "acceptance": acceptance,
        "detailed_plan_acceptance_passed": all(acceptance[key] for key in detailed_plan_acceptance_keys),
        "acceptance_passed": all(acceptance.values()),
    }
    write_json(report_path, report)
    write_json(fusion_manifest, {"fingerprint": digest, "outputs": [str(path) for path in final_outputs]})
    return report


def vectorize_pcds(cfg: dict, pcds: list[str], force: bool = False) -> dict:
    sessions = []
    for index, path in enumerate(pcds):
        source = Path(path).expanduser().resolve()
        session_name = f"pcd-{index + 1}"
        # PCD-only runs have no LIO-SAM directory.  Cache the source under the
        # same stable session layout used by ROS runs so a later
        # ``height-slices`` command can resume without a second vectorize pass.
        # NTFS hard links avoid duplicating very large maps; copying is a
        # portable fallback when source and output live on different volumes.
        cached = (
            Path(cfg["project"]["output_dir"])
            / "slam"
            / session_name
            / "GlobalMap.pcd"
        )
        cached.parent.mkdir(parents=True, exist_ok=True)
        same_file = False
        if cached.exists():
            try:
                same_file = os.path.samefile(source, cached)
            except OSError:
                same_file = False
        if not same_file:
            temporary = cached.with_name(f".{cached.name}.tmp")
            temporary.unlink(missing_ok=True)
            try:
                os.link(source, temporary)
            except OSError:
                shutil.copy2(source, temporary)
            temporary.replace(cached)
        quality, _ = assess_session(read_point_cloud(cached), None, cfg)
        sessions.append(
            {
                "name": session_name,
                "accepted": True,
                "map": str(cached),
                "source_map": str(source),
                "quality": quality,
            }
        )
    return process_maps(cfg, sessions, force)


def run_pipeline(cfg: dict, force: bool = False) -> dict:
    inspection = inspect_inputs(cfg, force)
    for report in inspection["bags"]:
        require_valid_report(report)
    calibration, calibration_report = calibrate(cfg, force)
    sessions = run_slam_sessions(cfg, calibration, force)
    report = process_maps(cfg, sessions, force)
    report["calibration"] = calibration_report
    report["inspection"] = {"valid": inspection["valid"], "bag_count": len(inspection["bags"])}
    write_json(Path(cfg["project"]["output_dir"]) / "report.json", report)
    return report
