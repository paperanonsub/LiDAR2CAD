from __future__ import annotations

import copy
import hashlib
import heapq
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import cv2
import ezdxf
import numpy as np
from scipy.interpolate import splprep, splev
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Point, Polygon, mapping
from shapely.ops import substring
from skimage.morphology import closing, disk, skeletonize

from .io import read_json, write_json
from .transforms import transform_points


V13_VERSION = "semantic-objects-v13.0"
V14_VERSION = "semantic-objects-v14.0"


def _semantic_algorithm_version(cfg: dict) -> str:
    """Return the delivered object-model version, not the reused baseline version."""
    return V14_VERSION if cfg.get("semantic_probability_path") else V13_VERSION


def _restore_previous_reliable_wall_segments(
    walls: list[dict], evidence: "EvidenceGrid", cfg: dict
) -> tuple[list[dict], dict]:
    """Protect geometry-baseline wall pieces that still have independent evidence.

    The previous drawing is only a proposal source. A piece is restored when the
    current multi-height evidence still marks it reliable and the semantic graph
    has actually left it uncovered. This prevents semantic augmentation from
    deleting trusted geometry without copying the whole previous model.
    """
    if not cfg.get("semantic_probability_path"):
        return walls, {"restored_segment_count": 0, "restored_length_m": 0.0}
    previous_dir = cfg.get("semantic_comparison_previous_dir")
    if not previous_dir:
        return walls, {"restored_segment_count": 0, "restored_length_m": 0.0}
    graph_path = Path(str(previous_dir)) / "building_object_graph.json"
    if not graph_path.is_file():
        return walls, {"restored_segment_count": 0, "restored_length_m": 0.0}

    reliable_mask = (
        evidence.structural_mask
        & (evidence.vertical_span_m >= float(cfg.get("semantic_reliable_min_vertical_span_m", 1.20)))
        & (evidence.height_bin_count >= int(cfg.get("semantic_reliable_min_height_bins", 6)))
        & (evidence.thin_vote >= float(cfg.get("semantic_reliable_min_thin_vote", 0.30)))
        & (evidence.thick_vote >= float(cfg.get("semantic_reliable_min_thick_vote", 0.30)))
    )
    rows, cols = np.nonzero(reliable_mask)
    reliable_xy = evidence.origin + np.column_stack([cols, rows]) * evidence.grid_m
    if not len(reliable_xy):
        return walls, {"restored_segment_count": 0, "restored_length_m": 0.0}
    evidence_tree = cKDTree(reliable_xy)
    current_samples = [
        _sample_line(LineString(value["primitive"]["coordinates_ref"]), 0.05)
        for value in walls
        if value.get("class") == "WALL" and len(value.get("primitive", {}).get("coordinates_ref", [])) >= 2
    ]
    current_tree = cKDTree(np.vstack(current_samples)) if current_samples else None
    previous = read_json(graph_path)
    restored: list[dict] = []
    restored_length = 0.0
    step_m = 0.05
    minimum_run_m = float(cfg.get("semantic_geometry_protection_min_run_m", 0.10))
    support_m = float(cfg.get("semantic_geometry_protection_support_m", 0.15))
    uncovered_m = float(cfg.get("semantic_geometry_protection_uncovered_m", 0.15))
    for wall in previous.get("walls", []):
        coordinates = np.asarray(wall.get("primitive", {}).get("coordinates_ref", []), dtype=float)
        if len(coordinates) < 2:
            continue
        line = LineString(coordinates)
        if line.length < minimum_run_m:
            continue
        distances = np.arange(0.0, line.length + step_m * 0.5, step_m)
        if distances[-1] < line.length:
            distances = np.append(distances, line.length)
        samples = np.asarray([line.interpolate(float(value)).coords[0] for value in distances])
        supported = evidence_tree.query(samples, k=1)[0] <= support_m
        uncovered = (
            np.ones(len(samples), dtype=bool)
            if current_tree is None
            else current_tree.query(samples, k=1)[0] > uncovered_m
        )
        eligible = supported & uncovered
        # Bridge a single 5 cm evidence-cell dropout, never a physical long gap.
        if len(eligible) >= 3:
            eligible[1:-1] |= eligible[:-2] & eligible[2:]
        start = None
        run_index = 0
        for index in range(len(eligible) + 1):
            active = index < len(eligible) and bool(eligible[index])
            if active and start is None:
                start = index
            if (not active or index == len(eligible)) and start is not None:
                end = index - 1
                lower = max(0.0, float(distances[start]) - step_m * 0.5)
                upper = min(float(line.length), float(distances[end]) + step_m * 0.5)
                if upper - lower >= minimum_run_m:
                    segment = substring(line, lower, upper)
                    segment_coordinates = np.asarray(segment.coords, dtype=float)
                    if len(segment_coordinates) >= 2:
                        clone = copy.deepcopy(wall)
                        clone["object_id"] = f"protected-{wall.get('object_id', 'wall')}-{run_index:02d}"
                        clone["class"] = "WALL"
                        clone["primitive"] = {
                            "kind": "line" if wall.get("primitive", {}).get("kind") == "line" else "spline",
                            "coordinates_ref": segment_coordinates.tolist(),
                            "fit_rmse_m": float(
                                wall.get("primitive", {}).get("fit_rmse_m", 0.0)
                            ),
                        }
                        clone["semantic_source"] = "geometry_protected_multiscale_evidence"
                        clone["protection_source_object_id"] = wall.get("object_id")
                        clone["confidence"] = max(float(clone.get("confidence", 0.0)), 0.90)
                        restored.append(clone)
                        restored_length += float(segment.length)
                        run_index += 1
                start = None
    return [*walls, *restored], {
        "restored_segment_count": len(restored),
        "restored_length_m": restored_length,
    }


@dataclass
class EvidenceGrid:
    origin: np.ndarray
    grid_m: float
    probability: np.ndarray
    point_count: np.ndarray
    height_bin_count: np.ndarray
    vertical_span_m: np.ndarray
    vertical_continuity: np.ndarray
    thin_vote: np.ndarray
    thick_vote: np.ndarray
    structural_mask: np.ndarray
    wall_probability: np.ndarray | None = None
    column_probability: np.ndarray | None = None


def _semantic_probability_rasters(
    path: str | Path,
    origin: np.ndarray,
    shape: tuple[int, int],
    grid_m: float,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Project accepted V14 3-D voxel predictions into the common XY grid."""
    path = Path(path)
    if not path.is_file():
        raise ValueError(f"Semantic point probabilities are missing: {path}")
    with np.load(path, allow_pickle=False) as values:
        coordinates = np.asarray(values["coordinates"], dtype=float)
        probabilities = np.asarray(values["probabilities"], dtype=float)
        accepted = np.asarray(values["accepted"], dtype=bool)
        votes = np.asarray(values["votes"], dtype=np.uint8)
    if probabilities.shape != (len(coordinates), 2) or len(accepted) != len(coordinates):
        raise ValueError(f"Invalid V14 semantic probability arrays in {path}")
    if not np.all(np.isfinite(coordinates)) or not np.all(np.isfinite(probabilities)):
        raise ValueError(f"Non-finite V14 semantic probabilities in {path}")
    pixels = np.floor((coordinates[:, :2] - np.asarray(origin)) / grid_m).astype(int)
    valid = (
        accepted
        & (pixels[:, 0] >= 0)
        & (pixels[:, 0] < shape[1])
        & (pixels[:, 1] >= 0)
        & (pixels[:, 1] < shape[0])
    )
    flat = pixels[:, 1] * shape[1] + pixels[:, 0]
    wall = np.zeros(shape[0] * shape[1], np.float32)
    column = np.zeros_like(wall)
    wall_selected = valid & (probabilities[:, 0] >= probabilities[:, 1])
    column_selected = valid & (probabilities[:, 1] > probabilities[:, 0])
    np.maximum.at(wall, flat[wall_selected], probabilities[wall_selected, 0])
    np.maximum.at(column, flat[column_selected], probabilities[column_selected, 1])
    audit = {
        "path": str(path.resolve()),
        "voxel_count": int(len(coordinates)),
        "accepted_voxel_count": int(np.sum(valid)),
        "wall_voxel_count": int(np.sum(wall_selected)),
        "column_voxel_count": int(np.sum(column_selected)),
        "minimum_seed_votes": int(np.min(np.max(votes[accepted], axis=1))) if np.any(accepted) else None,
    }
    return wall.reshape(shape), column.reshape(shape), audit


@dataclass
class BuildingObjectGraph:
    walls: list[dict]
    columns: list[dict]
    uncertain: list[dict]
    connections: list[dict]
    nodes: dict[str, list[float]]
    metrics: dict


@dataclass
class SemanticObjectResult:
    graph: BuildingObjectGraph
    evidence: EvidenceGrid
    outputs: dict[str, str]
    metrics: dict


def _remove_small_components(mask: np.ndarray, minimum_cells: int) -> np.ndarray:
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        np.asarray(mask, dtype=np.uint8), 8
    )
    result = np.zeros(mask.shape, dtype=bool)
    for component in range(1, count):
        if int(stats[component, cv2.CC_STAT_AREA]) >= int(minimum_cells):
            result[labels == component] = True
    return result


def _line_kernel(length: int, angle: float) -> np.ndarray:
    length = max(3, int(length) | 1)
    result = np.zeros((length, length), np.uint8)
    center = (length - 1) / 2.0
    radius = center
    dx = math.cos(angle) * radius
    dy = math.sin(angle) * radius
    cv2.line(
        result,
        (int(round(center - dx)), int(round(center - dy))),
        (int(round(center + dx)), int(round(center + dy))),
        1,
        1,
    )
    return result


def _normalise_window_votes(windows: Iterable[Any], shape: tuple[int, int]) -> np.ndarray:
    vote = np.zeros(shape, np.float32)
    weight_sum = 0.0
    for window in windows:
        weight = float(getattr(window, "overlap_weight", 1.0))
        mask = np.asarray(window.mask) > 0
        if mask.shape != shape:
            continue
        vote += mask.astype(np.float32) * weight
        weight_sum += weight
    if weight_sum > 0:
        vote /= weight_sum
    return np.clip(vote, 0.0, 1.0)


def build_unique_evidence_grid(
    points: np.ndarray,
    floor_m: float,
    ceiling_m: float,
    origin: np.ndarray,
    shape: tuple[int, int],
    thin_slices: list[Any],
    thick_slices: list[Any],
    cfg: dict,
) -> EvidenceGrid:
    """Build one XY-Z evidence index; overlapping windows never add Z evidence."""
    grid_m = float(cfg.get("semantic_object_grid_m", cfg.get("grid_m", 0.05)))
    z_bin_m = float(cfg.get("semantic_object_height_bin_m", 0.10))
    height, width = shape
    finite = np.asarray(points, dtype=float)
    finite = finite[np.all(np.isfinite(finite), axis=1)]
    ij = np.floor((finite[:, :2] - np.asarray(origin)) / grid_m).astype(np.int64)
    z_index = np.floor((finite[:, 2] - floor_m) / z_bin_m).astype(np.int64)
    z_count_total = max(1, int(math.ceil((ceiling_m - floor_m) / z_bin_m)))
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 0] < width)
        & (ij[:, 1] >= 0)
        & (ij[:, 1] < height)
        & (z_index >= 0)
        & (z_index < z_count_total)
    )
    ij = ij[valid]
    z_index = z_index[valid]
    cell = ij[:, 1] * width + ij[:, 0]
    cells = height * width
    point_count = np.bincount(cell, minlength=cells).reshape(shape).astype(np.int32)

    pairs = np.unique(np.column_stack([cell, z_index]), axis=0)
    pair_cell = pairs[:, 0]
    pair_z = pairs[:, 1]
    bin_count_flat = np.bincount(pair_cell, minlength=cells).astype(np.int16)
    z_min = np.full(cells, z_count_total, np.int32)
    z_max = np.full(cells, -1, np.int32)
    np.minimum.at(z_min, pair_cell, pair_z)
    np.maximum.at(z_max, pair_cell, pair_z)
    occupied = bin_count_flat > 0
    span_bins = np.zeros(cells, np.int16)
    span_bins[occupied] = (z_max[occupied] - z_min[occupied] + 1).astype(np.int16)
    continuity = np.zeros(cells, np.float32)
    continuity[occupied] = bin_count_flat[occupied] / np.maximum(span_bins[occupied], 1)
    vertical_span = span_bins.reshape(shape).astype(np.float32) * z_bin_m
    height_bin_count = bin_count_flat.reshape(shape)
    vertical_continuity = continuity.reshape(shape)

    thin_vote = _normalise_window_votes(thin_slices, shape)
    thick_vote = _normalise_window_votes(thick_slices, shape)
    minimum_bins = max(2, int(cfg.get("semantic_object_min_height_bins", 4)))
    minimum_span = float(cfg.get("semantic_object_min_vertical_span_m", 1.0))
    bin_score = np.clip(height_bin_count.astype(np.float32) / max(minimum_bins + 3, 1), 0, 1)
    span_score = np.clip(vertical_span / max(minimum_span, 1e-6), 0, 1)
    density_score = np.log1p(point_count.astype(np.float32))
    if np.any(density_score > 0):
        density_score /= max(float(np.quantile(density_score[density_score > 0], 0.98)), 1e-6)
    probability = (
        0.29 * bin_score
        + 0.24 * span_score
        + 0.17 * vertical_continuity
        + 0.13 * thin_vote
        + 0.13 * thick_vote
        + 0.04 * np.clip(density_score, 0, 1)
    )
    wall_probability = np.zeros(shape, np.float32)
    column_probability = np.zeros(shape, np.float32)
    semantic_path = cfg.get("semantic_probability_path")
    if semantic_path:
        wall_probability, column_probability, semantic_audit = _semantic_probability_rasters(
            semantic_path, np.asarray(origin), shape, grid_m
        )
        cfg["_semantic_point_audit"] = semantic_audit
        semantic_gate = (
            (height_bin_count >= max(2, minimum_bins // 2))
            & (vertical_span >= float(cfg.get("semantic_object_min_candidate_span_m", 0.65)))
        )
        # Semantics may recover a missed candidate but never suppress reliable geometry.
        probability = np.clip(
            probability
            + float(cfg.get("semantic_wall_probability_weight", 0.22))
            * wall_probability
            * semantic_gate,
            0.0,
            1.0,
        )
    threshold = float(cfg.get("semantic_object_evidence_threshold", 0.40))
    structural = (
        (probability >= threshold)
        & (height_bin_count >= max(2, minimum_bins // 2))
        & (vertical_span >= float(cfg.get("semantic_object_min_candidate_span_m", 0.65)))
    )
    structural |= (
        (thick_vote >= float(cfg.get("semantic_object_thick_vote_threshold", 0.30)))
        & (height_bin_count >= max(2, minimum_bins // 2))
        & (vertical_span >= 0.50)
    )
    if semantic_path:
        structural |= (
            (wall_probability >= float(cfg.get("semantic_prediction_min_confidence", 0.80)))
            & (height_bin_count >= max(2, minimum_bins // 2))
            & (vertical_span >= float(cfg.get("semantic_object_min_candidate_span_m", 0.65)))
        )
    structural = closing(structural, disk(1))
    structural = _remove_small_components(
        structural, int(cfg.get("semantic_object_min_component_cells", 5))
    )
    return EvidenceGrid(
        origin=np.asarray(origin, dtype=float),
        grid_m=grid_m,
        probability=np.asarray(probability, dtype=np.float32),
        point_count=point_count,
        height_bin_count=height_bin_count,
        vertical_span_m=vertical_span,
        vertical_continuity=vertical_continuity,
        thin_vote=thin_vote,
        thick_vote=thick_vote,
        structural_mask=np.asarray(structural, dtype=bool),
        wall_probability=wall_probability,
        column_probability=column_probability,
    )


def _sample_line(line: LineString, step_m: float) -> np.ndarray:
    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    return np.asarray(
        [line.interpolate(value).coords[0] for value in np.linspace(0, line.length, count)],
        dtype=float,
    )


def _raster_values(points: np.ndarray, raster: np.ndarray, evidence: EvidenceGrid) -> np.ndarray:
    pixels = np.floor((points - evidence.origin) / evidence.grid_m).astype(int)
    valid = (
        (pixels[:, 0] >= 0)
        & (pixels[:, 0] < raster.shape[1])
        & (pixels[:, 1] >= 0)
        & (pixels[:, 1] < raster.shape[0])
    )
    result = np.zeros(len(points), dtype=float)
    result[valid] = raster[pixels[valid, 1], pixels[valid, 0]]
    return result


def _rectangle_edges(points: np.ndarray) -> list[LineString]:
    return [LineString([points[index], points[(index + 1) % 4]]) for index in range(4)]


def _column_edges(points: np.ndarray) -> list[LineString]:
    return [LineString([points[index], points[(index + 1) % len(points)]]) for index in range(len(points))]


def _edge_support(edge: LineString, evidence: EvidenceGrid, radius_m: float) -> float:
    samples = _sample_line(edge, max(evidence.grid_m, 0.04))
    # Adjacent observed faces legitimately support the two corners.  Exclude
    # those corner neighbourhoods so they cannot make an entirely missing face
    # appear measured.
    if len(samples) >= 7:
        trim = max(1, int(math.floor(len(samples) * 0.20)))
        samples = samples[trim:-trim]
    radius = max(1, int(math.ceil(radius_m / evidence.grid_m)))
    mask = cv2.dilate(evidence.structural_mask.astype(np.uint8), disk(radius).astype(np.uint8))
    return float(np.mean(_raster_values(samples, mask, evidence) > 0))


def _column_candidates(
    evidence: EvidenceGrid,
    cfg: dict,
    candidate_mask: np.ndarray | None = None,
    id_prefix: str = "column",
) -> tuple[list[dict], list[dict], np.ndarray]:
    radius = max(1, int(round(float(cfg.get("semantic_column_group_radius_m", 0.10)) / evidence.grid_m)))
    source_mask = evidence.structural_mask if candidate_mask is None else np.asarray(candidate_mask, dtype=bool)
    grouped = closing(source_mask, disk(radius))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(grouped.astype(np.uint8), 8)
    accepted: list[dict] = []
    uncertain: list[dict] = []
    column_mask = np.zeros_like(grouped, np.uint8)
    max_size = float(cfg.get("semantic_column_max_size_m", 1.80))
    min_size = float(cfg.get("semantic_column_min_size_m", 0.15))
    support_radius = float(cfg.get("semantic_column_support_distance_m", 0.12))
    edge_threshold = float(cfg.get("semantic_column_edge_support_fraction", 0.60))
    for component in range(1, count):
        x, y, w, h, area = [int(value) for value in stats[component]]
        width_m, height_m = w * evidence.grid_m, h * evidence.grid_m
        if area < 4 or min(width_m, height_m) < min_size or max(width_m, height_m) > max_size:
            continue
        rows, cols = np.nonzero(labels == component)
        if len(rows) < 4:
            continue
        pixels = np.column_stack([cols, rows]).astype(np.float32)
        rectangle = cv2.minAreaRect(pixels)
        box_px = cv2.boxPoints(rectangle)
        box = evidence.origin + box_px.astype(float) * evidence.grid_m
        polygon = Polygon(box)
        if not polygon.is_valid or polygon.area < float(cfg.get("semantic_column_min_area_m2", 0.025)):
            continue
        rectangle_edges = _rectangle_edges(box)
        component_mask = (labels == component).astype(np.uint8)
        contours, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        contour_raw = max(contours, key=cv2.contourArea)
        contour = contour_raw.reshape(-1, 2).astype(float)
        contour_ref = evidence.origin + contour * evidence.grid_m
        rectangle_rmse = float(
            np.sqrt(
                np.mean(
                    [
                        min(edge.distance(Point(value)) for edge in rectangle_edges) ** 2
                        for value in contour_ref
                    ]
                )
            )
        )
        (circle_x, circle_y), circle_radius_px = cv2.minEnclosingCircle(contour.astype(np.float32))
        circle_center = evidence.origin + np.asarray([circle_x, circle_y]) * evidence.grid_m
        circle_radius_m = float(circle_radius_px * evidence.grid_m)
        radial = np.linalg.norm(contour_ref - circle_center, axis=1)
        circle_rmse = float(np.sqrt(np.mean((radial - circle_radius_m) ** 2)))
        perimeter_px = float(cv2.arcLength(contour_raw, True))
        contour_area_px = float(cv2.contourArea(contour_raw))
        circularity = 4.0 * math.pi * contour_area_px / max(perimeter_px * perimeter_px, 1e-9)
        circle_diameter = 2.0 * circle_radius_m
        use_circle = (
            min_size <= circle_diameter <= max_size
            and circularity >= float(cfg.get("semantic_column_circle_min_circularity", 0.72))
            and circle_rmse + 1e-6 < rectangle_rmse * float(cfg.get("semantic_column_circle_rmse_ratio", 0.85))
        )
        if use_circle:
            angles = np.linspace(0.0, 2.0 * math.pi, 64, endpoint=False)
            geometry = circle_center + circle_radius_m * np.column_stack([np.cos(angles), np.sin(angles)])
            edges = [LineString(np.vstack([geometry, geometry[0]]))]
            dimensions = [circle_diameter, circle_diameter]
            angle_deg = 0.0
            shape_name = "circle"
        else:
            geometry = box
            edges = rectangle_edges
            dimensions = sorted([float(rectangle[1][0] * evidence.grid_m), float(rectangle[1][1] * evidence.grid_m)])
            angle_deg = float(rectangle[2])
            shape_name = "rectangle"
        edge_support = [_edge_support(edge, evidence, support_radius) for edge in edges]
        component_span = float(np.median(evidence.vertical_span_m[rows, cols]))
        supported_edges = int(sum(value >= edge_threshold for value in edge_support))
        support_completeness = float(np.mean(np.asarray(edge_support) >= edge_threshold))
        semantic_column = (
            float(np.median(evidence.column_probability[rows, cols]))
            if evidence.column_probability is not None and len(rows)
            else 0.0
        )
        confidence = float(
            0.42 * np.mean(edge_support)
            + 0.30 * min(1.0, component_span / 1.2)
            + 0.18 * support_completeness
            + 0.10 * min(1.0, len(rows) / 30.0)
            + float(cfg.get("semantic_column_probability_weight", 0.20)) * semantic_column
        )
        confidence = min(confidence, 1.0)
        geometry_complete = (
            edge_support[0] >= edge_threshold
            if shape_name == "circle"
            else supported_edges >= 3
        )
        record = {
            "object_id": f"{id_prefix}-{component:04d}",
            "class": "COLUMN" if geometry_complete and component_span >= 1.0 else "UNKNOWN_COLUMN",
            "shape": shape_name,
            "coordinates_ref": geometry.tolist(),
            "center_ref": (circle_center if shape_name == "circle" else np.mean(box, axis=0)).tolist(),
            "dimensions_m": dimensions,
            "angle_deg": angle_deg,
            "circle_radius_m": circle_radius_m if shape_name == "circle" else None,
            "shape_fit_rmse_m": circle_rmse if shape_name == "circle" else rectangle_rmse,
            "edge_support": [float(value) for value in edge_support],
            "observed_edge_indices": [index for index, value in enumerate(edge_support) if value >= edge_threshold],
            "inferred_edge_indices": [index for index, value in enumerate(edge_support) if value < edge_threshold],
            "vertical_span_m": component_span,
            "confidence": confidence,
            "semantic_column_probability": semantic_column,
            "semantic_source": "geometric_baseline",
            "label": None,
        }
        if record["class"] == "COLUMN" and confidence >= float(cfg.get("semantic_column_min_confidence", 0.62)):
            accepted.append(record)
            geometry_px = np.round((geometry - evidence.origin) / evidence.grid_m).astype(np.int32)
            cv2.fillPoly(column_mask, [geometry_px], 1)
        else:
            uncertain.append(record)
    return accepted, uncertain, column_mask.astype(bool)


def _skeleton_paths(mask: np.ndarray, origin: np.ndarray, grid_m: float) -> list[LineString]:
    skeleton = skeletonize(mask > 0)
    coords = {tuple(value) for value in np.argwhere(skeleton)}
    if not coords:
        return []
    offsets = [
        (-1, -1), (-1, 0), (-1, 1), (0, -1),
        (0, 1), (1, -1), (1, 0), (1, 1),
    ]

    def neighbours(node: tuple[int, int]) -> list[tuple[int, int]]:
        return [(node[0] + dr, node[1] + dc) for dr, dc in offsets if (node[0] + dr, node[1] + dc) in coords]

    degree = {node: len(neighbours(node)) for node in coords}
    terminals = {node for node, value in degree.items() if value != 2}
    visited: set[frozenset[tuple[int, int]]] = set()
    paths: list[list[tuple[int, int]]] = []

    def walk(start: tuple[int, int], nxt: tuple[int, int]) -> list[tuple[int, int]]:
        path = [start, nxt]
        previous, current = start, nxt
        visited.add(frozenset([previous, current]))
        while current not in terminals:
            options = [value for value in neighbours(current) if value != previous]
            if not options:
                break
            candidate = options[0]
            edge = frozenset([current, candidate])
            if edge in visited:
                break
            visited.add(edge)
            path.append(candidate)
            previous, current = current, candidate
        return path

    for node in terminals:
        for nxt in neighbours(node):
            if frozenset([node, nxt]) not in visited:
                paths.append(walk(node, nxt))
    for node in coords:
        for nxt in neighbours(node):
            if frozenset([node, nxt]) not in visited:
                paths.append(walk(node, nxt))

    result = []
    for path in paths:
        xy = np.asarray([[origin[0] + col * grid_m, origin[1] + row * grid_m] for row, col in path])
        if len(xy) < 2:
            continue
        line = LineString(xy).simplify(max(grid_m * 0.75, 0.025), preserve_topology=False)
        if line.geom_type == "LineString" and line.length > 1e-6:
            result.append(line)
    return result


def _endpoint_tangent(line: LineString, endpoint: int) -> np.ndarray:
    coords = np.asarray(line.coords, dtype=float)
    if len(coords) < 2:
        return np.asarray([1.0, 0.0])
    if endpoint == 0:
        vector = coords[0] - coords[min(len(coords) - 1, 2)]
    else:
        vector = coords[-1] - coords[max(0, len(coords) - 3)]
    return vector / max(float(np.linalg.norm(vector)), 1e-12)


def _angle_difference(a: np.ndarray, b: np.ndarray) -> float:
    cosine = float(np.clip(np.dot(a, b), -1.0, 1.0))
    return math.acos(cosine)


def _orientation_lifted_path(
    start_xy: np.ndarray,
    end_xy: np.ndarray,
    start_direction: np.ndarray,
    end_direction: np.ndarray,
    evidence: EvidenceGrid,
    cfg: dict,
) -> tuple[np.ndarray | None, dict]:
    """Small orientation-state shortest path used only between compatible wall ends."""
    bins = int(cfg.get("semantic_trace_orientation_bins", 16))
    start_px = np.round((start_xy - evidence.origin) / evidence.grid_m).astype(int)
    end_px = np.round((end_xy - evidence.origin) / evidence.grid_m).astype(int)
    margin = max(4, int(math.ceil(float(cfg.get("semantic_trace_margin_m", 0.35)) / evidence.grid_m)))
    x0, x1 = max(0, min(start_px[0], end_px[0]) - margin), min(evidence.probability.shape[1] - 1, max(start_px[0], end_px[0]) + margin)
    y0, y1 = max(0, min(start_px[1], end_px[1]) - margin), min(evidence.probability.shape[0] - 1, max(start_px[1], end_px[1]) + margin)
    if x1 <= x0 or y1 <= y0:
        return None, {"reason": "empty_search_window"}
    probability = evidence.probability[y0:y1 + 1, x0:x1 + 1]
    start = (int(start_px[1] - y0), int(start_px[0] - x0))
    target = (int(end_px[1] - y0), int(end_px[0] - x0))
    angles = np.arange(bins, dtype=float) * 2 * math.pi / bins
    motions = np.column_stack([np.round(np.sin(angles)), np.round(np.cos(angles))]).astype(int)
    start_theta = int(round((math.atan2(start_direction[1], start_direction[0]) % (2 * math.pi)) / (2 * math.pi) * bins)) % bins
    target_theta = int(round((math.atan2(-end_direction[1], -end_direction[0]) % (2 * math.pi)) / (2 * math.pi) * bins)) % bins
    initial = (start[0], start[1], start_theta)
    queue = [(0.0, initial)]
    distance = {initial: 0.0}
    parent: dict[tuple[int, int, int], tuple[int, int, int]] = {}
    curvature_weight = float(cfg.get("semantic_trace_curvature_weight", 0.45))
    data_weight = float(cfg.get("semantic_trace_data_weight", 3.0))
    maximum_steps = int(cfg.get("semantic_trace_max_expansions", 75000))
    best = None
    expansions = 0
    while queue and expansions < maximum_steps:
        _, state = heapq.heappop(queue)
        base_cost = distance[state]
        row, col, theta = state
        expansions += 1
        if abs(row - target[0]) <= 1 and abs(col - target[1]) <= 1:
            theta_error = min((theta - target_theta) % bins, (target_theta - theta) % bins)
            if theta_error <= 2:
                best = state
                break
        for delta in (-1, 0, 1):
            next_theta = (theta + delta) % bins
            dr, dc = motions[next_theta]
            if dr == 0 and dc == 0:
                continue
            nr, nc = row + int(dr), col + int(dc)
            if nr < 0 or nc < 0 or nr >= probability.shape[0] or nc >= probability.shape[1]:
                continue
            step = math.sqrt(float(dr * dr + dc * dc))
            local = float(probability[nr, nc])
            new_cost = base_cost + step * (1.0 + data_weight * (1.0 - local)) + curvature_weight * abs(delta)
            next_state = (nr, nc, next_theta)
            if new_cost + 1e-9 < distance.get(next_state, float("inf")):
                distance[next_state] = new_cost
                parent[next_state] = state
                heuristic = math.hypot(nr - target[0], nc - target[1])
                heapq.heappush(queue, (new_cost + heuristic, next_state))
    if best is None:
        return None, {"reason": "no_orientation_path", "expansions": expansions}
    states = [best]
    while states[-1] != initial:
        states.append(parent[states[-1]])
    states.reverse()
    points = np.asarray(
        [evidence.origin + np.asarray([col + x0, row + y0]) * evidence.grid_m for row, col, _ in states],
        dtype=float,
    )
    values = _raster_values(points, evidence.probability, evidence)
    return points, {
        "reason": "accepted_candidate",
        "mean_probability": float(np.mean(values)),
        "strong_fraction": float(np.mean(values >= float(cfg.get("semantic_trace_strong_probability", 0.45)))),
        "path_length_m": float(LineString(points).length),
        "expansions": expansions,
    }


def _gap_connections(lines: list[LineString], evidence: EvidenceGrid, cfg: dict) -> tuple[list[dict], list[dict]]:
    endpoints = []
    for line_index, line in enumerate(lines):
        if line.length < float(cfg.get("semantic_trace_min_seed_length_m", 0.30)):
            continue
        coords = np.asarray(line.coords, dtype=float)
        for endpoint in (0, 1):
            endpoints.append((line_index, endpoint, coords[0] if endpoint == 0 else coords[-1], _endpoint_tangent(line, endpoint)))
    if not endpoints:
        return [], []
    tree = cKDTree(np.asarray([value[2] for value in endpoints]))
    maximum_gap = float(cfg.get("semantic_trace_max_gap_m", 1.20))
    max_angle = math.radians(float(cfg.get("semantic_trace_endpoint_angle_deg", 32.0)))
    selected, rejected = [], []
    occupied: set[tuple[int, int]] = set()
    candidates = []
    for left, neighbours in enumerate(tree.query_ball_tree(tree, maximum_gap)):
        a = endpoints[left]
        for right in neighbours:
            if right <= left:
                continue
            b = endpoints[right]
            if a[0] == b[0]:
                continue
            vector = b[2] - a[2]
            distance = float(np.linalg.norm(vector))
            if distance < evidence.grid_m * 1.5:
                continue
            direction = vector / distance
            angle_a = _angle_difference(a[3], direction)
            angle_b = _angle_difference(b[3], -direction)
            if angle_a > max_angle or angle_b > max_angle:
                continue
            candidates.append((angle_a + angle_b + distance / maximum_gap, left, right))
    for _, left, right in sorted(candidates):
        a, b = endpoints[left], endpoints[right]
        endpoint_keys = {(a[0], a[1]), (b[0], b[1])}
        if endpoint_keys & occupied:
            continue
        path, audit = _orientation_lifted_path(a[2], b[2], a[3], b[3], evidence, cfg)
        record = {
            "source_endpoints": [[int(a[0]), int(a[1])], [int(b[0]), int(b[1])]],
            "direct_distance_m": float(np.linalg.norm(b[2] - a[2])),
            **audit,
        }
        if path is None:
            rejected.append(record)
            continue
        direct = record["direct_distance_m"]
        score = (
            0.55 * float(audit["mean_probability"])
            + 0.30 * float(audit["strong_fraction"])
            + 0.15 * min(1.0, 0.45 / max(direct, 1e-6))
        )
        record["score"] = float(score)
        record["coordinates_ref"] = path.tolist()
        short_supported = direct <= float(cfg.get("semantic_trace_short_gap_m", 0.35)) and audit["strong_fraction"] >= 0.15
        if score >= float(cfg.get("semantic_trace_min_score", 0.46)) and (audit["strong_fraction"] >= 0.25 or short_supported):
            record["status"] = "inferred_connection"
            selected.append(record)
            occupied.update(endpoint_keys)
        else:
            record["reason"] = "insufficient_cross_height_evidence"
            rejected.append(record)
    return selected, rejected


def _circle_fit(points: np.ndarray) -> tuple[np.ndarray, float, float]:
    x, y = points[:, 0], points[:, 1]
    matrix = np.column_stack([2 * x, 2 * y, np.ones(len(points))])
    rhs = x * x + y * y
    solution, *_ = np.linalg.lstsq(matrix, rhs, rcond=None)
    center = solution[:2]
    radius = math.sqrt(max(float(solution[2] + center @ center), 0.0))
    residual = np.abs(np.linalg.norm(points - center, axis=1) - radius)
    return center, radius, float(np.sqrt(np.mean(residual * residual)))


def fit_curve_primitive(line: LineString, cfg: dict) -> dict:
    step = float(cfg.get("semantic_curve_fit_step_m", 0.05))
    points = _sample_line(line, step)
    center = np.mean(points, axis=0)
    _, _, vh = np.linalg.svd(points - center, full_matrices=False)
    direction = vh[0]
    projections = (points - center) @ direction
    fitted_line = center + projections[:, None] * direction
    line_rmse = float(np.sqrt(np.mean(np.sum((points - fitted_line) ** 2, axis=1))))
    line_endpoints = np.asarray([fitted_line[np.argmin(projections)], fitted_line[np.argmax(projections)]])
    candidates = [(line_rmse, 2, "line")]
    arc = None
    if len(points) >= 5:
        circle_center, radius, arc_rmse = _circle_fit(points)
        angles = np.unwrap(np.arctan2(points[:, 1] - circle_center[1], points[:, 0] - circle_center[0]))
        span = float(abs(angles[-1] - angles[0]))
        if radius >= float(cfg.get("semantic_curve_min_radius_m", 0.35)) and math.radians(4) <= span <= math.radians(340):
            arc = (circle_center, radius, angles, arc_rmse)
            candidates.append((arc_rmse, 3, "arc"))
    spline_points = None
    spline_rmse = float("inf")
    if len(points) >= 7 and line.length >= float(cfg.get("semantic_spline_min_length_m", 1.0)):
        try:
            smooth = len(points) * float(cfg.get("semantic_spline_smoothing_m", 0.035)) ** 2
            tck, u = splprep(points.T, s=smooth, k=min(3, len(points) - 1))
            fitted = np.column_stack(splev(u, tck))
            spline_rmse = float(np.sqrt(np.mean(np.sum((points - fitted) ** 2, axis=1))))
            dense_u = np.linspace(0.0, 1.0, max(8, int(math.ceil(line.length / 0.10)) + 1))
            spline_points = np.column_stack(splev(dense_u, tck))
            candidates.append((spline_rmse, 5, "spline"))
        except (TypeError, ValueError):
            spline_points = None
    complexity = float(cfg.get("semantic_curve_complexity_penalty_m", 0.008))
    score, _, kind = min(candidates, key=lambda value: value[0] + complexity * value[1])
    # A curved model must provide a meaningful gain; this prevents long straight
    # walls from becoming imperceptibly wavy splines.
    if kind != "line" and score > line_rmse * float(cfg.get("semantic_curve_required_gain", 0.82)):
        kind = "line"
    record: dict[str, Any] = {
        "kind": kind,
        "source_length_m": float(line.length),
        "line_rmse_m": line_rmse,
    }
    if kind == "line":
        ordered = line_endpoints
        if np.linalg.norm(ordered[0] - points[0]) > np.linalg.norm(ordered[-1] - points[0]):
            ordered = ordered[::-1]
        record.update({"coordinates_ref": ordered.tolist(), "fit_rmse_m": line_rmse})
    elif kind == "arc" and arc is not None:
        circle_center, radius, angles, arc_rmse = arc
        dense_angles = np.linspace(angles[0], angles[-1], max(8, int(math.ceil(line.length / 0.08)) + 1))
        sampled = circle_center + radius * np.column_stack([np.cos(dense_angles), np.sin(dense_angles)])
        record.update(
            {
                "coordinates_ref": sampled.tolist(),
                "center_ref": circle_center.tolist(),
                "radius_m": float(radius),
                "start_angle_rad": float(angles[0]),
                "end_angle_rad": float(angles[-1]),
                "fit_rmse_m": float(arc_rmse),
            }
        )
    else:
        record.update(
            {
                "coordinates_ref": np.asarray(spline_points).tolist(),
                "fit_points_ref": np.asarray(spline_points).tolist(),
                "fit_rmse_m": float(spline_rmse),
            }
        )
    return record


def _support_ranges(primitive: dict, windows: list[Any], evidence: EvidenceGrid, cfg: dict) -> list[dict]:
    line = LineString(primitive["coordinates_ref"])
    step = float(cfg.get("semantic_support_step_m", 0.05))
    distances = np.linspace(0.0, line.length, max(2, int(math.ceil(line.length / step)) + 1))
    points = np.asarray([line.interpolate(value).coords[0] for value in distances])
    radius = max(1, int(math.ceil(float(cfg.get("semantic_support_distance_m", 0.10)) / evidence.grid_m)))
    records = []
    for window in windows:
        dilated = cv2.dilate((np.asarray(window.mask) > 0).astype(np.uint8), disk(radius).astype(np.uint8))
        supported = _raster_values(points, dilated, evidence) > 0
        runs = []
        start = None
        for index, value in enumerate(np.r_[supported, False]):
            if value and start is None:
                start = index
            elif not value and start is not None:
                end = index - 1
                if distances[end] - distances[start] >= step * 0.5:
                    runs.append([float(distances[start]), float(distances[end])])
                start = None
        records.append(
            {
                "window_id": str(getattr(window, "window_id", "")),
                "scale_id": str(getattr(window, "scale_id", "")),
                "index": int(getattr(window, "index", -1)),
                "z_min_m": float(getattr(window, "z_min_m", 0.0)),
                "z_max_m": float(getattr(window, "z_max_m", 0.0)),
                "observed_ranges_m": runs,
                "observed_fraction": float(np.mean(supported)),
            }
        )
    return records


def _extract_wall_graph(
    evidence: EvidenceGrid,
    columns: list[dict],
    column_mask: np.ndarray,
    thin_slices: list[Any],
    thick_slices: list[Any],
    cfg: dict,
) -> tuple[list[dict], list[dict], list[dict]]:
    base = evidence.structural_mask.copy()
    base |= evidence.thick_vote >= float(cfg.get("semantic_wall_thick_seed", 0.23))
    base |= evidence.thin_vote >= float(cfg.get("semantic_wall_thin_seed", 0.18))
    if np.any(column_mask):
        exclusion = cv2.dilate(column_mask.astype(np.uint8), disk(1).astype(np.uint8)) > 0
        base &= ~exclusion
    base = _remove_small_components(
        base, int(cfg.get("semantic_wall_min_component_cells", 7))
    )
    # Only a modest image close is used here. Longer gaps are evaluated by the
    # orientation-state path search so that morphology cannot silently invent walls.
    closed = base.copy()
    close_m = float(cfg.get("semantic_wall_seed_close_m", 0.20))
    for angle in np.linspace(0, math.pi, int(cfg.get("semantic_wall_direction_bins", 12)), endpoint=False):
        kernel = _line_kernel(max(3, int(round(close_m / evidence.grid_m))), float(angle))
        closed |= cv2.morphologyEx(base.astype(np.uint8), cv2.MORPH_CLOSE, kernel) > 0
    lines = [
        value
        for value in _skeleton_paths(closed, evidence.origin, evidence.grid_m)
        if value.length >= float(cfg.get("semantic_wall_min_seed_length_m", 0.28))
    ]
    connections, rejected = _gap_connections(lines, evidence, cfg)
    if connections:
        augmented = closed.astype(np.uint8)
        for value in connections:
            pixels = np.round((np.asarray(value["coordinates_ref"]) - evidence.origin) / evidence.grid_m).astype(np.int32)
            cv2.polylines(augmented, [pixels], False, 1, 1, cv2.LINE_8)
        lines = [
            value
            for value in _skeleton_paths(augmented > 0, evidence.origin, evidence.grid_m)
            if value.length >= float(cfg.get("semantic_wall_min_output_length_m", 0.35))
        ]
    walls = []
    all_windows = [*thin_slices, *thick_slices]
    for index, line in enumerate(sorted(lines, key=lambda value: (-value.length, value.bounds))):
        primitive = fit_curve_primitive(line, cfg)
        samples = np.asarray(primitive["coordinates_ref"], dtype=float)
        probability = _raster_values(samples, evidence.probability, evidence)
        support = _support_ranges(primitive, all_windows, evidence, cfg)
        thin_support = [value["observed_fraction"] for value in support if value["scale_id"].startswith("thin")]
        thick_support = [value["observed_fraction"] for value in support if value["scale_id"].startswith("thick")]
        confidence = float(
            0.52 * np.mean(probability)
            + 0.23 * min(1.0, line.length / 2.0)
            + 0.15 * (max(thick_support) if thick_support else 0.0)
            + 0.10 * (max(thin_support) if thin_support else 0.0)
        )
        building = line.length >= float(cfg.get("semantic_wall_min_building_length_m", 0.55)) and confidence >= float(cfg.get("semantic_wall_min_confidence", 0.40))
        walls.append(
            {
                "object_id": f"wall-{index:05d}",
                "class": "WALL" if building else "UNKNOWN_WALL",
                "confidence": confidence,
                "semantic_source": "geometric_baseline",
                "label": None,
                "primitive": primitive,
                "height_support": support,
                "mean_evidence_probability": float(np.mean(probability)),
                "minimum_evidence_probability": float(np.min(probability)),
            }
        )
    return walls, connections, rejected


def _node_graph(
    walls: list[dict], tolerance_m: float
) -> tuple[dict[str, list[float]], float, int]:
    endpoints = []
    owners: list[tuple[dict, str, int]] = []
    for wall in walls:
        coords = np.asarray(wall["primitive"]["coordinates_ref"], dtype=float)
        endpoints.extend([coords[0], coords[-1]])
        owners.extend([(wall, "start_node_id", 0), (wall, "end_node_id", -1)])
    if not endpoints:
        return {}, 0.0, 0
    array = np.asarray(endpoints)
    tree = cKDTree(array)
    visited: set[int] = set()
    result = {}
    maximum_move = 0.0
    shared_count = 0

    def single_node(endpoint_index: int) -> None:
        node_id = f"node-{len(result):05d}"
        result[node_id] = array[endpoint_index].tolist()
        owner, key, _ = owners[endpoint_index]
        owner[key] = node_id

    for index in range(len(array)):
        if index in visited:
            continue
        group = [value for value in tree.query_ball_point(array[index], tolerance_m) if value not in visited]
        visited.update(group)
        if len(group) == 1:
            single_node(group[0])
            continue
        # Prefer an observed arc endpoint as the node anchor: moving an ARC
        # endpoint off its fitted circle would make the DXF endpoint differ
        # from the graph node. Otherwise intersect the local endpoint tangents.
        arc_group = [
            value for value in group if owners[value][0]["primitive"]["kind"] == "arc"
        ]
        if arc_group:
            anchor_index = max(
                arc_group,
                key=lambda value: float(owners[value][0].get("confidence", 0.0)),
            )
            center = array[anchor_index].copy()
            compatible = True
            for endpoint_index in arc_group:
                primitive = owners[endpoint_index][0]["primitive"]
                radial_error = abs(
                    np.linalg.norm(center - np.asarray(primitive["center_ref"], dtype=float))
                    - float(primitive["radius_m"])
                )
                compatible &= radial_error <= 0.001
            if not compatible:
                for endpoint_index in group:
                    single_node(endpoint_index)
                continue
        else:
            normal_rows = []
            rhs = []
            for endpoint_index in group:
                wall, _, endpoint = owners[endpoint_index]
                coordinates = np.asarray(wall["primitive"]["coordinates_ref"], dtype=float)
                tangent = coordinates[1] - coordinates[0] if endpoint == 0 else coordinates[-1] - coordinates[-2]
                norm = float(np.linalg.norm(tangent))
                if norm <= 1e-9:
                    continue
                tangent /= norm
                normal = np.asarray([-tangent[1], tangent[0]])
                normal_rows.append(normal)
                rhs.append(float(np.dot(normal, array[endpoint_index])))
            if len(normal_rows) >= 2:
                matrix = np.asarray(normal_rows)
                center = np.linalg.lstsq(matrix, np.asarray(rhs), rcond=None)[0]
            else:
                center = np.mean(array[group], axis=0)
            if max(float(np.linalg.norm(center - array[value])) for value in group) > tolerance_m:
                center = np.mean(array[group], axis=0)
        moves = [float(np.linalg.norm(center - array[value])) for value in group]
        if max(moves) > tolerance_m:
            for endpoint_index in group:
                single_node(endpoint_index)
            continue
        node_id = f"node-{len(result):05d}"
        result[node_id] = center.tolist()
        for endpoint_index in group:
            owner, key, endpoint = owners[endpoint_index]
            owner[key] = node_id
            coordinates = np.asarray(owner["primitive"]["coordinates_ref"], dtype=float)
            coordinates[endpoint] = center
            owner["primitive"]["coordinates_ref"] = coordinates.tolist()
        maximum_move = max(maximum_move, max(moves))
        shared_count += 1
    return result, maximum_move, shared_count


def _load_manual_reviews(cfg: dict) -> dict[str, dict]:
    path_value = cfg.get("semantic_labels_path")
    if not path_value:
        return {}
    path = Path(str(path_value))
    if not path.is_file():
        return {}
    value = read_json(path)
    return {
        str(record["object_id"]): record
        for record in value.get("records", [])
        if record.get("object_id")
        and (record.get("label") is not None or record.get("roi_ref") is not None)
    }


def _refit_column_from_review(
    value: dict,
    review: dict | None,
    evidence: EvidenceGrid,
    cfg: dict,
) -> dict:
    """Refit a column candidate from evidence inside a human-corrected XY extent."""
    if not review or review.get("label") != "column":
        return value
    polygon_value = review.get("roi_polygon_ref")
    input_polygon = None
    if isinstance(polygon_value, list) and len(polygon_value) >= 4:
        candidate_polygon = np.asarray(polygon_value, dtype=float)
        if np.all(np.isfinite(candidate_polygon)):
            input_polygon = candidate_polygon
    roi = review.get("roi_ref")
    if input_polygon is not None:
        xmin, ymin = np.min(input_polygon, axis=0)
        xmax, ymax = np.max(input_polygon, axis=0)
    elif isinstance(roi, list) and len(roi) == 4:
        xmin, ymin, xmax, ymax = (float(item) for item in roi)
    else:
        return value
    if not np.all(np.isfinite([xmin, ymin, xmax, ymax])) or xmax <= xmin or ymax <= ymin:
        return value
    rows, cols = np.nonzero(evidence.structural_mask)
    xy = evidence.origin + np.column_stack([cols + 0.5, rows + 0.5]) * evidence.grid_m
    if input_polygon is not None:
        polygon_mask = np.zeros_like(evidence.structural_mask, dtype=np.uint8)
        polygon_px = np.round((input_polygon - evidence.origin) / evidence.grid_m).astype(np.int32)
        cv2.fillPoly(polygon_mask, [polygon_px], 1)
        inside = polygon_mask[rows, cols] > 0
    else:
        inside = (
            (xy[:, 0] >= xmin)
            & (xy[:, 0] <= xmax)
            & (xy[:, 1] >= ymin)
            & (xy[:, 1] <= ymax)
        )
    if int(np.count_nonzero(inside)) < 4:
        updated = value.copy()
        updated["manual_roi_ref"] = [xmin, ymin, xmax, ymax]
        updated["manual_roi_polygon_ref"] = (
            input_polygon.tolist() if input_polygon is not None else None
        )
        updated["manual_refit_status"] = "insufficient_structural_cells"
        return updated
    selected_xy = xy[inside]
    pixels = ((selected_xy - evidence.origin) / evidence.grid_m).astype(np.float32)
    rectangle = cv2.minAreaRect(pixels)
    box = evidence.origin + cv2.boxPoints(rectangle).astype(float) * evidence.grid_m
    fitted_polygon = Polygon(box)
    minimum_area = float(cfg.get("semantic_column_min_area_m2", 0.025))
    maximum_size = float(cfg.get("semantic_column_max_size_m", 1.80))
    dimensions = sorted(
        [float(rectangle[1][0] * evidence.grid_m), float(rectangle[1][1] * evidence.grid_m)]
    )
    if (
        not fitted_polygon.is_valid
        or fitted_polygon.area < minimum_area
        or max(dimensions, default=0.0) > maximum_size
    ):
        updated = value.copy()
        updated["manual_roi_ref"] = [xmin, ymin, xmax, ymax]
        updated["manual_roi_polygon_ref"] = (
            input_polygon.tolist() if input_polygon is not None else None
        )
        updated["manual_refit_status"] = "fitted_rectangle_outside_column_limits"
        return updated
    edges = _rectangle_edges(box)
    support_radius = float(cfg.get("semantic_column_support_distance_m", 0.12))
    edge_threshold = float(cfg.get("semantic_column_edge_support_fraction", 0.60))
    edge_support = [_edge_support(edge, evidence, support_radius) for edge in edges]
    selected_pixels = np.floor((selected_xy - evidence.origin) / evidence.grid_m).astype(int)
    span = float(
        np.median(evidence.vertical_span_m[selected_pixels[:, 1], selected_pixels[:, 0]])
    )
    updated = value.copy()
    updated.update(
        {
            "class": "COLUMN",
            "shape": "rectangle",
            "coordinates_ref": box.tolist(),
            "center_ref": np.mean(box, axis=0).tolist(),
            "dimensions_m": dimensions,
            "angle_deg": float(rectangle[2]),
            "circle_radius_m": None,
            "edge_support": [float(item) for item in edge_support],
            "observed_edge_indices": [
                index for index, item in enumerate(edge_support) if item >= edge_threshold
            ],
            "inferred_edge_indices": [
                index for index, item in enumerate(edge_support) if item < edge_threshold
            ],
            "vertical_span_m": span,
            "manual_roi_ref": [xmin, ymin, xmax, ymax],
            "manual_roi_polygon_ref": (
                input_polygon.tolist() if input_polygon is not None else None
            ),
            "manual_refit_status": "refitted_from_human_roi",
            "geometry_source": (
                "human_polygon_structural_evidence"
                if input_polygon is not None
                else "human_roi_structural_evidence"
            ),
        }
    )
    return updated


def _apply_semantic_model(
    walls: list[dict],
    columns: list[dict],
    uncertain_columns: list[dict],
    cfg: dict,
) -> tuple[list[dict], list[dict], list[dict], str, dict]:
    """Apply only a human-validated object classifier; never use pseudo labels."""
    reviews = _load_manual_reviews(cfg)

    def manual_label(value: dict) -> str | None:
        review = reviews.get(value["object_id"])
        return str(review.get("label")) if review and review.get("label") else None

    def human_only(default_status: str, audit: dict | None = None):
        reviewed_walls = []
        for value in walls:
            updated = value.copy()
            label = manual_label(value)
            if label is not None:
                updated["class"] = "WALL" if label == "wall" else "UNKNOWN_WALL"
                updated["semantic_source"] = "human_review"
            reviewed_walls.append(updated)
        selected_columns, rejected_columns = [], []
        for value in [*columns, *uncertain_columns]:
            updated = value.copy()
            label = manual_label(value)
            if label is not None:
                updated["class"] = "COLUMN" if label == "column" else "UNKNOWN_COLUMN"
                updated["semantic_source"] = "human_review"
            target = selected_columns if updated["class"] == "COLUMN" else rejected_columns
            target.append(updated)
        count = sum(
            manual_label(value) is not None for value in [*walls, *columns, *uncertain_columns]
        )
        details = dict(audit or {})
        details.update({"applied": bool(count), "human_review_count": count})
        status = "human_reviews_applied" if count else default_status
        return reviewed_walls, selected_columns, rejected_columns, status, details

    report_value = cfg.get("semantic_model_report")
    if not report_value:
        return human_only("awaiting_human_labels")
    report_path = Path(str(report_value))
    if not report_path.is_file():
        return human_only("semantic_model_report_missing", {"report": str(report_path)})
    report = read_json(report_path)
    if report.get("training_task") == "wall_column_point_joint_v14":
        return human_only(
            "point_semantics_applied_before_candidate_extraction",
            {
                "report": str(report_path),
                "backend": report.get("backend"),
                "candidate_augmentation_enabled": bool(
                    report.get("candidate_augmentation_enabled", False)
                ),
            },
        )
    if not bool(report.get("automatic_filtering_enabled", False)):
        return human_only(
            "semantic_model_rejected_by_validation", {"report": str(report_path)}
        )
    raw_predictions = report.get("object_predictions", {})
    predictions = {
        str(key): value for key, value in raw_predictions.items() if isinstance(value, dict)
    }
    confidence_min = float(cfg.get("semantic_prediction_min_confidence", 0.50))
    dataset_id = cfg.get("semantic_dataset_id")

    def prediction_for(value: dict) -> dict | None:
        if dataset_id:
            prediction = predictions.get(f"{dataset_id}:{value['object_id']}")
            if prediction is not None:
                return prediction
        return predictions.get(value["object_id"])

    predicted_count = 0

    semantic_walls: list[dict] = []
    for value in walls:
        updated = value.copy()
        human = manual_label(value)
        prediction = prediction_for(value)
        accepted = prediction is not None and float(prediction.get("confidence", 0.0)) >= confidence_min
        label = human or (str(prediction.get("label", "unknown")) if accepted else "unknown")
        updated["semantic_prediction"] = prediction
        updated["semantic_source"] = "human_review" if human else (
            "sonata_ptv3_object_head" if prediction else "missing_model_prediction"
        )
        updated["class"] = "WALL" if label == "wall" else "UNKNOWN_WALL"
        semantic_walls.append(updated)
        predicted_count += int(prediction is not None)

    all_columns = [*columns, *uncertain_columns]
    selected_columns: list[dict] = []
    rejected_columns: list[dict] = []
    for value in all_columns:
        updated = value.copy()
        human = manual_label(value)
        prediction = prediction_for(value)
        accepted = prediction is not None and float(prediction.get("confidence", 0.0)) >= confidence_min
        label = human or (str(prediction.get("label", "unknown")) if accepted else "unknown")
        updated["semantic_prediction"] = prediction
        updated["semantic_source"] = "human_review" if human else (
            "sonata_ptv3_object_head" if prediction else "missing_model_prediction"
        )
        updated["class"] = "COLUMN" if label == "column" else "UNKNOWN_COLUMN"
        (selected_columns if label == "column" else rejected_columns).append(updated)
        predicted_count += int(prediction is not None)

    total = len(walls) + len(all_columns)
    coverage = predicted_count / max(total, 1)
    if coverage < float(cfg.get("semantic_prediction_min_object_coverage", 0.95)):
        # A partially applied model would make the main drawing depend on which
        # objects happened to receive cached embeddings. Refuse that state.
        return human_only(
            "semantic_prediction_coverage_failed",
            {"report": str(report_path), "prediction_coverage": coverage},
        )
    return semantic_walls, selected_columns, rejected_columns, "accepted_human_label_model", {
        "applied": True,
        "report": str(report_path),
        "prediction_coverage": coverage,
    }


def build_semantic_object_graph(
    clean_points: np.ndarray,
    floor_m: float,
    ceiling_m: float,
    origin: np.ndarray,
    shape: tuple[int, int],
    thin_slices: list[Any],
    thick_slices: list[Any],
    cfg: dict,
) -> tuple[BuildingObjectGraph, EvidenceGrid]:
    evidence = build_unique_evidence_grid(
        clean_points, floor_m, ceiling_m, origin, shape, thin_slices, thick_slices, cfg
    )
    columns, uncertain_columns, column_mask = _column_candidates(evidence, cfg)
    semantic_column_threshold = float(cfg.get("semantic_prediction_min_confidence", 0.80))
    if evidence.column_probability is not None and np.any(
        evidence.column_probability >= semantic_column_threshold
    ):
        semantic_mask = (
            (evidence.column_probability >= semantic_column_threshold)
            & (evidence.height_bin_count >= max(2, int(cfg.get("semantic_object_min_height_bins", 4)) // 2))
            & (evidence.vertical_span_m >= float(cfg.get("semantic_object_min_candidate_span_m", 0.65)))
        )
        semantic_columns, semantic_uncertain, semantic_mask_out = _column_candidates(
            evidence, cfg, candidate_mask=semantic_mask, id_prefix="semantic-column"
        )
        for candidate in [*semantic_columns, *semantic_uncertain]:
            center = np.asarray(candidate.get("center_ref", [np.inf, np.inf]), dtype=float)
            existing = [*columns, *uncertain_columns]
            distances = [
                float(np.linalg.norm(center - np.asarray(value.get("center_ref", [np.inf, np.inf]), dtype=float)))
                for value in existing
            ]
            if distances and min(distances) <= float(cfg.get("semantic_column_group_radius_m", 0.10)) * 1.5:
                continue
            if candidate.get("class") == "COLUMN":
                columns.append(candidate)
            else:
                uncertain_columns.append(candidate)
        column_mask |= semantic_mask_out
    manual_reviews = _load_manual_reviews(cfg)
    columns = [
        _refit_column_from_review(value, manual_reviews.get(value["object_id"]), evidence, cfg)
        for value in columns
    ]
    uncertain_columns = [
        _refit_column_from_review(value, manual_reviews.get(value["object_id"]), evidence, cfg)
        for value in uncertain_columns
    ]
    # Rebuild the exclusion mask so the wall tracer sees the corrected column footprint.
    column_mask = np.zeros_like(evidence.structural_mask, dtype=np.uint8)
    for value in [*columns, *uncertain_columns]:
        if value.get("class") != "COLUMN" and value.get("manual_refit_status") != "refitted_from_human_roi":
            continue
        geometry = np.asarray(value.get("coordinates_ref", []), dtype=float)
        if len(geometry) < 3:
            continue
        geometry_px = np.round((geometry - evidence.origin) / evidence.grid_m).astype(np.int32)
        cv2.fillPoly(column_mask, [geometry_px], 1)
    column_mask = column_mask.astype(bool)
    walls, connections, rejected_connections = _extract_wall_graph(
        evidence, columns, column_mask, thin_slices, thick_slices, cfg
    )
    walls, columns, uncertain_columns, semantic_status, semantic_audit = _apply_semantic_model(
        walls, columns, uncertain_columns, cfg
    )
    building_walls = [value for value in walls if value["class"] == "WALL"]
    uncertain_walls = [value for value in walls if value["class"] != "WALL"]
    building_walls, geometry_protection = _restore_previous_reliable_wall_segments(
        building_walls, evidence, cfg
    )
    nodes, node_move_max, shared_node_count = _node_graph(
        building_walls, float(cfg.get("semantic_node_candidate_m", 0.08))
    )
    for wall in building_walls:
        wall["height_support"] = _support_ranges(
            wall["primitive"], [*thin_slices, *thick_slices], evidence, cfg
        )
    line_count = sum(value["primitive"]["kind"] == "line" for value in building_walls)
    arc_count = sum(value["primitive"]["kind"] == "arc" for value in building_walls)
    spline_count = sum(value["primitive"]["kind"] == "spline" for value in building_walls)
    wall_samples = [
        _sample_line(LineString(value["primitive"]["coordinates_ref"]), 0.05)
        for value in building_walls
    ]
    wall_samples_array = np.vstack(wall_samples) if wall_samples else np.empty((0, 2))
    point_tree = cKDTree(clean_points[:, :2]) if len(clean_points) else None
    if point_tree is not None and len(wall_samples_array):
        wall_distances, _ = point_tree.query(wall_samples_array, k=1)
        point_p95 = float(np.quantile(wall_distances, 0.95))
        point_support = float(np.mean(wall_distances <= 0.15))
    else:
        point_p95 = None
        point_support = 0.0
    model_samples = list(wall_samples)
    for column in columns:
        model_samples.extend(_sample_line(edge, 0.05) for edge in _column_edges(np.asarray(column["coordinates_ref"])))
    model_array = np.vstack(model_samples) if model_samples else np.empty((0, 2))
    structural_rows, structural_cols = np.nonzero(evidence.structural_mask)
    structural_xy = evidence.origin + np.column_stack([structural_cols, structural_rows]) * evidence.grid_m
    if len(model_array) and len(structural_xy):
        model_tree = cKDTree(model_array)
        reverse_distances, _ = model_tree.query(structural_xy, k=1)
        reverse_coverage = float(np.mean(reverse_distances <= 0.15))
    else:
        reverse_coverage = 0.0
    reliable_mask = (
        evidence.structural_mask
        & (evidence.vertical_span_m >= float(cfg.get("semantic_reliable_min_vertical_span_m", 1.20)))
        & (evidence.height_bin_count >= int(cfg.get("semantic_reliable_min_height_bins", 6)))
        & (evidence.thin_vote >= float(cfg.get("semantic_reliable_min_thin_vote", 0.30)))
        & (evidence.thick_vote >= float(cfg.get("semantic_reliable_min_thick_vote", 0.30)))
    )
    reliable_rows, reliable_cols = np.nonzero(reliable_mask)
    reliable_xy = evidence.origin + np.column_stack([reliable_cols, reliable_rows]) * evidence.grid_m
    if len(model_array) and len(reliable_xy):
        reliable_distances, _ = model_tree.query(reliable_xy, k=1)
        reliable_coverage = float(np.mean(reliable_distances <= 0.15))
    else:
        reliable_coverage = 0.0
    previous_retention = None
    previous_frozen_count = 0
    previous_dir_value = cfg.get("semantic_comparison_previous_dir")
    if previous_dir_value and len(reliable_xy) and len(model_array):
        previous_graph_path = Path(str(previous_dir_value)) / "building_object_graph.json"
        if previous_graph_path.is_file():
            previous_graph = read_json(previous_graph_path)
            previous_samples = []
            for previous_wall in previous_graph.get("walls", []):
                coordinates = np.asarray(
                    previous_wall.get("primitive", {}).get("coordinates_ref", []),
                    dtype=float,
                )
                if len(coordinates) >= 2:
                    previous_samples.append(_sample_line(LineString(coordinates), 0.05))
            if previous_samples:
                previous_tree = cKDTree(np.vstack(previous_samples))
                frozen = previous_tree.query(reliable_xy, k=1)[0] <= 0.15
                previous_frozen_count = int(np.count_nonzero(frozen))
                if previous_frozen_count:
                    previous_retention = float(
                        np.mean(model_tree.query(reliable_xy[frozen], k=1)[0] <= 0.15)
                    )
    metrics = {
        "algorithm_version": _semantic_algorithm_version(cfg),
        "scene_type": str(cfg.get("semantic_scene_type", "unspecified")),
        "wall_count": len(building_walls),
        "uncertain_wall_count": len(uncertain_walls),
        "column_count": len(columns),
        "uncertain_column_count": len(uncertain_columns),
        "line_primitive_count": int(line_count),
        "arc_primitive_count": int(arc_count),
        "spline_primitive_count": int(spline_count),
        "selected_connection_count": len(connections),
        "shared_node_count": shared_node_count,
        "shared_node_max_move_m": node_move_max,
        "modelled_wall_length_m": float(
            sum(LineString(value["primitive"]["coordinates_ref"]).length for value in building_walls)
        ),
        "inferred_connection_length_m": float(
            sum(LineString(value["coordinates_ref"]).length for value in connections)
        ),
        "curved_wall_length_m": float(
            sum(
                LineString(value["primitive"]["coordinates_ref"]).length
                for value in building_walls
                if value["primitive"]["kind"] in {"arc", "spline"}
            )
        ),
        "longest_curved_primitive_m": float(
            max(
                [
                    LineString(value["primitive"]["coordinates_ref"]).length
                    for value in building_walls
                    if value["primitive"]["kind"] in {"arc", "spline"}
                ]
                or [0.0]
            )
        ),
        "wall_to_point_p95_m": point_p95,
        "wall_15cm_support_fraction": point_support,
        "frozen_structural_evidence_15cm_coverage_fraction": reverse_coverage,
        "frozen_reliable_structural_evidence_15cm_coverage_fraction": reliable_coverage,
        "frozen_reliable_structural_cell_count": int(np.count_nonzero(reliable_mask)),
        "previous_frozen_reliable_evidence_cell_count": previous_frozen_count,
        "previous_frozen_reliable_evidence_retention_fraction": previous_retention,
        "rejected_connection_count": len(rejected_connections),
        "unique_xy_cell_count": int(np.count_nonzero(evidence.point_count)),
        "structural_cell_count": int(np.count_nonzero(evidence.structural_mask)),
        "semantic_model_status": semantic_status,
        "semantic_model_used_for_filtering": bool(
            semantic_audit.get("applied", False)
            and not cfg.get("semantic_probability_path")
        ),
        "semantic_point_candidate_augmentation_enabled": bool(
            cfg.get("semantic_probability_path")
        ),
        "human_review_applied": bool(
            semantic_audit.get("human_review_count", 0)
        ),
        "semantic_model_audit": semantic_audit,
        "semantic_point_audit": cfg.get("_semantic_point_audit", {}),
        "geometry_protection": geometry_protection,
        "single_session_evidence": int(cfg.get("_semantic_session_count", 1)) <= 1,
        "semantic_session_count": int(cfg.get("_semantic_session_count", 1)),
    }
    graph = BuildingObjectGraph(
        walls=building_walls,
        columns=columns,
        uncertain=[*uncertain_walls, *uncertain_columns],
        connections=connections,
        nodes=nodes,
        metrics=metrics,
    )
    return graph, evidence


def _transform_xy(points: np.ndarray, transform: np.ndarray) -> np.ndarray:
    xyz = np.column_stack([np.asarray(points, dtype=float), np.zeros(len(points))])
    return transform_points(xyz, transform)[:, :2]


def _add_native_primitive(modelspace, primitive: dict, transform: np.ndarray, layer: str) -> None:
    kind = primitive["kind"]
    points_ref = np.asarray(primitive["coordinates_ref"], dtype=float)
    points = _transform_xy(points_ref, transform)
    if kind == "line":
        modelspace.add_line(points[0], points[-1], dxfattribs={"layer": layer})
        return
    if kind == "arc":
        center = _transform_xy(np.asarray([primitive["center_ref"]]), transform)[0]
        start = points[0] - center
        end = points[-1] - center
        start_angle = math.degrees(math.atan2(start[1], start[0])) % 360
        end_angle = math.degrees(math.atan2(end[1], end[0])) % 360
        start_ref = points_ref[0] - np.asarray(primitive["center_ref"])
        end_ref = points_ref[-1] - np.asarray(primitive["center_ref"])
        cross = float(start_ref[0] * end_ref[1] - start_ref[1] * end_ref[0])
        if cross < 0:
            start_angle, end_angle = end_angle, start_angle
        modelspace.add_arc(
            center=center,
            radius=float(primitive["radius_m"]),
            start_angle=start_angle,
            end_angle=end_angle,
            dxfattribs={"layer": layer},
        )
        return
    modelspace.add_spline(fit_points=points.tolist(), dxfattribs={"layer": layer})


def _new_document() -> ezdxf.document.Drawing:
    document = ezdxf.new("R2013")
    document.units = ezdxf.units.M
    for name, color, linetype in (
        ("BUILDING_WALL", 7, "CONTINUOUS"),
        ("COLUMN_OBSERVED", 4, "CONTINUOUS"),
        ("COLUMN_INFERRED", 30, "DASHED"),
        ("INFERRED_CONNECTION", 30, "DASHED"),
        ("OPENING", 5, "DASHED"),
        ("UNCERTAIN_DETAIL", 8, "DOTTED"),
    ):
        if name not in document.layers:
            document.layers.add(name=name, color=color, linetype=linetype)
    return document


def _export_graph_dxf(path: Path, graph: BuildingObjectGraph, transform: np.ndarray, include_uncertain: bool) -> None:
    document = _new_document()
    modelspace = document.modelspace()
    for wall in graph.walls:
        _add_native_primitive(modelspace, wall["primitive"], transform, "BUILDING_WALL")
    for column in graph.columns:
        points = _transform_xy(np.asarray(column["coordinates_ref"], dtype=float), transform)
        if column.get("shape") == "circle":
            center = _transform_xy(np.asarray([column["center_ref"]], dtype=float), transform)[0]
            layer = "COLUMN_OBSERVED" if 0 in column["observed_edge_indices"] else "COLUMN_INFERRED"
            modelspace.add_circle(
                center,
                float(column["circle_radius_m"]),
                dxfattribs={"layer": layer},
            )
            continue
        for index, edge in enumerate(_column_edges(points)):
            layer = "COLUMN_OBSERVED" if index in column["observed_edge_indices"] else "COLUMN_INFERRED"
            coords = np.asarray(edge.coords)
            modelspace.add_line(coords[0], coords[-1], dxfattribs={"layer": layer})
    for connection in graph.connections:
        points = _transform_xy(np.asarray(connection["coordinates_ref"], dtype=float), transform)
        modelspace.add_lwpolyline(points.tolist(), dxfattribs={"layer": "INFERRED_CONNECTION"})
    if include_uncertain:
        for value in graph.uncertain:
            if "primitive" in value:
                _add_native_primitive(modelspace, value["primitive"], transform, "UNCERTAIN_DETAIL")
            elif "coordinates_ref" in value:
                points = _transform_xy(np.asarray(value["coordinates_ref"], dtype=float), transform)
                modelspace.add_lwpolyline(points.tolist(), close=True, dxfattribs={"layer": "UNCERTAIN_DETAIL"})
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def _window_substrings(wall: dict, window_id: str) -> list[LineString]:
    line = LineString(wall["primitive"]["coordinates_ref"])
    record = next((value for value in wall["height_support"] if value["window_id"] == window_id), None)
    if record is None:
        return []
    return [substring(line, start, end) for start, end in record["observed_ranges_m"] if end > start]


def _export_window_dxf(path: Path, graph: BuildingObjectGraph, window: Any, transform: np.ndarray) -> None:
    document = _new_document()
    modelspace = document.modelspace()
    for wall in graph.walls:
        for line in _window_substrings(wall, str(window.window_id)):
            points = _transform_xy(np.asarray(line.coords), transform)
            modelspace.add_lwpolyline(points.tolist(), dxfattribs={"layer": "BUILDING_WALL"})
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def _common_substrings(graph: BuildingObjectGraph, windows: list[Any], require_all: bool) -> list[LineString]:
    result = []
    if not windows:
        return result
    for wall in graph.walls:
        line = LineString(wall["primitive"]["coordinates_ref"])
        step = 0.05
        distances = np.linspace(0.0, line.length, max(2, int(math.ceil(line.length / step)) + 1))
        matrix = []
        for window in windows:
            intervals = next(
                (value["observed_ranges_m"] for value in wall["height_support"] if value["window_id"] == window.window_id),
                [],
            )
            matrix.append(np.asarray([any(start - 1e-9 <= value <= end + 1e-9 for start, end in intervals) for value in distances]))
        selected = np.all(matrix, axis=0) if require_all else np.any(matrix, axis=0)
        start = None
        for index, value in enumerate(np.r_[selected, False]):
            if value and start is None:
                start = index
            elif not value and start is not None:
                end = index - 1
                if distances[end] > distances[start]:
                    result.append(substring(line, float(distances[start]), float(distances[end])))
                start = None
    return result


def _export_lines_dxf(path: Path, lines: list[LineString], transform: np.ndarray, layer: str) -> None:
    document = _new_document()
    if layer not in document.layers:
        document.layers.add(layer, color=7)
    modelspace = document.modelspace()
    for line in lines:
        points = _transform_xy(np.asarray(line.coords), transform)
        modelspace.add_lwpolyline(points.tolist(), dxfattribs={"layer": layer})
    document.saveas(path)


def _render_ref_lines(
    path: Path,
    background_points: np.ndarray,
    lines: list[LineString],
    transform: np.ndarray,
    grid_m: float,
    title: str,
    color: tuple[int, int, int] = (245, 245, 245),
) -> None:
    cad_points = transform_points(background_points, transform)
    xy = cad_points[:, :2]
    minimum = np.floor(np.quantile(xy, 0.001, axis=0) / grid_m) * grid_m - 0.5
    maximum = np.ceil(np.quantile(xy, 0.999, axis=0) / grid_m) * grid_m + 0.5
    shape = tuple(np.maximum(1, np.ceil((maximum - minimum)[::-1] / grid_m).astype(int) + 1))
    canvas = np.zeros((*shape, 3), np.uint8)
    pixels = np.floor((xy - minimum) / grid_m).astype(int)
    valid = (pixels[:, 0] >= 0) & (pixels[:, 0] < shape[1]) & (pixels[:, 1] >= 0) & (pixels[:, 1] < shape[0])
    density = np.zeros(shape, np.float32)
    np.add.at(density, (pixels[valid, 1], pixels[valid, 0]), 1)
    if np.any(density > 0):
        density = np.log1p(density)
        density *= 90.0 / max(float(np.quantile(density[density > 0], 0.99)), 1e-6)
    base = np.clip(density, 0, 90).astype(np.uint8)
    canvas[:] = cv2.cvtColor(base, cv2.COLOR_GRAY2BGR)
    for line in lines:
        points = _transform_xy(np.asarray(line.coords), transform)
        px = np.round((points - minimum) / grid_m).astype(np.int32)
        cv2.polylines(canvas, [px], False, color, 2, cv2.LINE_AA)
    output = np.ascontiguousarray(np.flipud(canvas))
    cv2.putText(output, title, (18, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (245, 245, 245), 2, cv2.LINE_AA)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), output)


def _graph_features(graph: BuildingObjectGraph, transform: np.ndarray) -> list[dict]:
    features = []
    for wall in [*graph.walls, *[value for value in graph.uncertain if "primitive" in value]]:
        primitive = wall["primitive"]
        points = _transform_xy(np.asarray(primitive["coordinates_ref"]), transform)
        features.append(
            {
                "type": "Feature",
                "properties": {
                    "object_id": wall["object_id"],
                    "class": wall["class"],
                    "confidence": wall["confidence"],
                    "primitive": primitive["kind"],
                    "fit_rmse_m": primitive["fit_rmse_m"],
                    "semantic_source": wall["semantic_source"],
                    "height_support": wall["height_support"],
                    "start_node_id": wall.get("start_node_id"),
                    "end_node_id": wall.get("end_node_id"),
                },
                "geometry": mapping(LineString(points)),
            }
        )
    for column in [*graph.columns, *[value for value in graph.uncertain if "coordinates_ref" in value and "primitive" not in value]]:
        points = _transform_xy(np.asarray(column["coordinates_ref"]), transform)
        polygon = Polygon(points)
        features.append(
            {
                "type": "Feature",
                "properties": {
                    key: value
                    for key, value in column.items()
                    if key not in {"coordinates_ref", "center_ref"}
                },
                "geometry": mapping(polygon),
            }
        )
    return features


def _render_graph(
    path: Path,
    graph: BuildingObjectGraph,
    clean_points: np.ndarray,
    transform: np.ndarray,
    cfg: dict,
    include_uncertain: bool,
) -> None:
    cad_points = transform_points(clean_points, transform)
    all_xy = cad_points[:, :2]
    grid_m = float(cfg.get("semantic_render_grid_m", 0.05))
    minimum = np.floor(np.quantile(all_xy, 0.001, axis=0) / grid_m) * grid_m - 0.5
    maximum = np.ceil(np.quantile(all_xy, 0.999, axis=0) / grid_m) * grid_m + 0.5
    shape = tuple(np.maximum(1, np.ceil((maximum - minimum)[::-1] / grid_m).astype(int) + 1))
    canvas = np.zeros((*shape, 3), np.uint8)
    pixels = np.floor((all_xy - minimum) / grid_m).astype(int)
    valid = (pixels[:, 0] >= 0) & (pixels[:, 0] < shape[1]) & (pixels[:, 1] >= 0) & (pixels[:, 1] < shape[0])
    canvas[pixels[valid, 1], pixels[valid, 0]] = (35, 35, 35)

    def draw(points_ref: np.ndarray, color: tuple[int, int, int], width: int, closed: bool = False, dashed: bool = False):
        points = _transform_xy(points_ref, transform)
        px = np.round((points - minimum) / grid_m).astype(np.int32)
        if dashed:
            for index in range(0, len(px) - 1, 2):
                cv2.line(canvas, tuple(px[index]), tuple(px[index + 1]), color, width, cv2.LINE_AA)
        else:
            cv2.polylines(canvas, [px], closed, color, width, cv2.LINE_AA)

    for wall in graph.walls:
        draw(np.asarray(wall["primitive"]["coordinates_ref"]), (245, 245, 245), 2)
    for connection in graph.connections:
        draw(np.asarray(connection["coordinates_ref"]), (0, 170, 255), 2, dashed=True)
    for column in graph.columns:
        points = np.asarray(column["coordinates_ref"])
        for index, edge in enumerate(_column_edges(points)):
            draw(np.asarray(edge.coords), (255, 210, 30) if index in column["observed_edge_indices"] else (0, 170, 255), 2, dashed=index in column["inferred_edge_indices"])
    if include_uncertain:
        for value in graph.uncertain:
            points = np.asarray(value["primitive"]["coordinates_ref"] if "primitive" in value else value["coordinates_ref"])
            draw(points, (110, 110, 110), 1, closed="primitive" not in value)
    output = np.ascontiguousarray(np.flipud(canvas))
    version_label = "V14 SEMANTIC POINT BUILDING MODEL" if graph.metrics.get("algorithm_version") == V14_VERSION else "V13 BUILDING OBJECT MODEL"
    cv2.putText(output, version_label, (18, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.78, (240, 240, 240), 2, cv2.LINE_AA)
    cv2.imwrite(str(path), output)


def _read_dxf_paths(path: Path) -> list[np.ndarray]:
    """Read comparison geometry without rasterising labels or line weights."""
    if not path.is_file():
        return []
    document = ezdxf.readfile(path)
    paths: list[np.ndarray] = []
    for entity in document.modelspace():
        kind = entity.dxftype()
        try:
            if kind == "LINE":
                paths.append(np.asarray([[entity.dxf.start.x, entity.dxf.start.y], [entity.dxf.end.x, entity.dxf.end.y]], dtype=float))
            elif kind == "LWPOLYLINE":
                values = np.asarray([(p[0], p[1]) for p in entity.get_points("xy")], dtype=float)
                if entity.closed and len(values) > 1:
                    values = np.vstack([values, values[0]])
                paths.append(values)
            elif kind == "POLYLINE":
                values = np.asarray([(v.dxf.location.x, v.dxf.location.y) for v in entity.vertices], dtype=float)
                if entity.is_closed and len(values) > 1:
                    values = np.vstack([values, values[0]])
                paths.append(values)
            elif kind == "ARC":
                start = math.radians(float(entity.dxf.start_angle))
                end = math.radians(float(entity.dxf.end_angle))
                if end <= start:
                    end += 2.0 * math.pi
                count = max(8, int(math.ceil((end - start) * float(entity.dxf.radius) / 0.05)) + 1)
                angle = np.linspace(start, end, count)
                center = np.asarray([entity.dxf.center.x, entity.dxf.center.y], dtype=float)
                paths.append(center + float(entity.dxf.radius) * np.column_stack([np.cos(angle), np.sin(angle)]))
            elif kind == "SPLINE":
                paths.append(np.asarray([(p.x, p.y) for p in entity.flattening(0.01)], dtype=float))
        except (AttributeError, TypeError, ValueError):
            continue
    return [value for value in paths if value.ndim == 2 and len(value) >= 2]


def _render_v13_comparisons(
    output_dir: Path,
    graph: BuildingObjectGraph,
    clean_points: np.ndarray,
    transform: np.ndarray,
    cfg: dict,
) -> dict[str, str]:
    """Render LiDAR/V12/V13 and object-derived ROIs in one CAD frame."""
    cad_points = transform_points(clean_points, transform)[:, :2]
    grid_m = float(cfg.get("semantic_render_grid_m", 0.05))
    minimum = np.floor(np.quantile(cad_points, 0.001, axis=0) / grid_m) * grid_m - 0.5
    maximum = np.ceil(np.quantile(cad_points, 0.999, axis=0) / grid_m) * grid_m + 0.5
    height, width = np.maximum(1, np.ceil((maximum - minimum)[::-1] / grid_m).astype(int) + 1)
    density = np.zeros((height, width), np.float32)
    pixels = np.floor((cad_points - minimum) / grid_m).astype(int)
    valid = ((pixels[:, 0] >= 0) & (pixels[:, 0] < width) & (pixels[:, 1] >= 0) & (pixels[:, 1] < height))
    np.add.at(density, (pixels[valid, 1], pixels[valid, 0]), 1)
    if np.any(density > 0):
        density = np.log1p(density)
        density *= 105.0 / max(float(np.quantile(density[density > 0], 0.99)), 1e-6)
    base = cv2.cvtColor(np.clip(density, 0, 105).astype(np.uint8), cv2.COLOR_GRAY2BGR)

    def to_px(points: np.ndarray) -> np.ndarray:
        return np.round((np.asarray(points, dtype=float) - minimum) / grid_m).astype(np.int32)

    def draw_paths(canvas: np.ndarray, paths: Iterable[np.ndarray], color: tuple[int, int, int], thickness: int = 2) -> None:
        for values in paths:
            if len(values) >= 2:
                cv2.polylines(canvas, [to_px(values)], False, color, thickness, cv2.LINE_AA)

    point_panel = base.copy()
    v12_panel = base.copy()
    v13_panel = base.copy()
    source_root = Path(
        str(cfg.get("semantic_comparison_previous_dir") or cfg.get("source_output_dir", ""))
    )
    source_dir = source_root / "height_slices" if source_root.name != "height_slices" else source_root
    draw_paths(v12_panel, _read_dxf_paths(source_dir / "architectural_plan.dxf"), (245, 245, 245))
    wall_cad = [_transform_xy(np.asarray(value["primitive"]["coordinates_ref"], dtype=float), transform) for value in graph.walls]
    draw_paths(v13_panel, wall_cad, (245, 245, 245))
    for value in graph.columns:
        points = _transform_xy(np.asarray(value["coordinates_ref"], dtype=float), transform)
        cv2.polylines(v13_panel, [to_px(np.vstack([points, points[0]]))], False, (255, 210, 30), 2, cv2.LINE_AA)
    for value in graph.connections:
        px = to_px(_transform_xy(np.asarray(value["coordinates_ref"], dtype=float), transform))
        for index in range(0, len(px) - 1, 2):
            cv2.line(v13_panel, tuple(px[index]), tuple(px[index + 1]), (0, 170, 255), 2, cv2.LINE_AA)

    panels = [np.ascontiguousarray(np.flipud(value)) for value in (point_panel, v12_panel, v13_panel)]
    is_v14 = bool(cfg.get("semantic_probability_path"))
    previous_label = "V13" if cfg.get("semantic_comparison_previous_dir") else "V12"
    current_label = "V14 SEMANTIC POINTS" if is_v14 else "V13 SEMANTIC OBJECTS"
    for panel, title in zip(panels, ("LiDAR EVIDENCE", previous_label, current_label)):
        cv2.putText(panel, title, (18, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (245, 245, 245), 2, cv2.LINE_AA)
    full_path = output_dir / ("lidar_v13_v14_comparison.png" if is_v14 else "lidar_v12_v13_comparison.png")
    cv2.imwrite(str(full_path), np.hstack(panels))

    def bounds_of(values: list[np.ndarray], margin: float = 2.0) -> tuple[np.ndarray, np.ndarray] | None:
        arrays = [np.asarray(value, dtype=float) for value in values if len(value)]
        if not arrays:
            return None
        joined = np.vstack(arrays)
        return joined.min(axis=0) - margin, joined.max(axis=0) + margin

    curves = [value for value in graph.walls if value["primitive"]["kind"] in {"arc", "spline"}]
    curves.sort(key=lambda value: LineString(value["primitive"]["coordinates_ref"]).length, reverse=True)
    roi_specs: list[tuple[str, tuple[np.ndarray, np.ndarray] | None]] = []
    if curves:
        longest = _transform_xy(np.asarray(curves[0]["primitive"]["coordinates_ref"]), transform)
        roi_specs.append(("bottom_curve", bounds_of([longest], 2.5)))
        highest = max(curves, key=lambda value: float(np.mean(_transform_xy(np.asarray(value["primitive"]["coordinates_ref"]), transform)[:, 1])))
        roi_specs.append(("top_turn", bounds_of([_transform_xy(np.asarray(highest["primitive"]["coordinates_ref"]), transform)], 2.5)))
    if graph.columns:
        centers = np.asarray([np.mean(_transform_xy(np.asarray(value["coordinates_ref"]), transform), axis=0) for value in graph.columns])
        neighbourhoods = cKDTree(centers).query_ball_point(centers, r=8.0)
        selected = max(neighbourhoods, key=len)
        roi_specs.append(("column_cluster", bounds_of([centers[selected]], 3.0)))
    uncertain_paths = []
    for value in graph.uncertain:
        values = value["primitive"]["coordinates_ref"] if "primitive" in value else value.get("coordinates_ref", [])
        if len(values):
            uncertain_paths.append(_transform_xy(np.asarray(values), transform))
    if uncertain_paths:
        target = max(uncertain_paths, key=lambda value: float(np.ptp(value, axis=0).max()))
        roi_specs.append(("uncertain_interference", bounds_of([target], 2.5)))

    outputs = {
        "v14_lidar_v13_v14_comparison" if is_v14 else "v13_lidar_v12_v13_comparison": str(full_path)
    }
    for name, bounds in roi_specs:
        if bounds is None:
            continue
        lower, upper = bounds
        x0 = int(np.clip(math.floor((lower[0] - minimum[0]) / grid_m), 0, width - 1))
        x1 = int(np.clip(math.ceil((upper[0] - minimum[0]) / grid_m), x0 + 1, width))
        y0_raw = int(np.clip(math.floor((lower[1] - minimum[1]) / grid_m), 0, height - 1))
        y1_raw = int(np.clip(math.ceil((upper[1] - minimum[1]) / grid_m), y0_raw + 1, height))
        y0, y1 = height - y1_raw, height - y0_raw
        crops = [panel[y0:y1, x0:x1] for panel in panels]
        if min(crop.shape[0] for crop in crops) < 10 or min(crop.shape[1] for crop in crops) < 10:
            continue
        detail_path = output_dir / (
            f"detail_{name}_lidar_v13_v14.png" if is_v14 else f"detail_{name}_lidar_v12_v13.png"
        )
        cv2.imwrite(str(detail_path), np.hstack(crops))
        outputs[f"{'v14' if is_v14 else 'v13'}_detail_{name}"] = str(detail_path)
    return outputs


def _candidate_feature_vector(value: dict) -> list[float]:
    if "primitive" in value:
        primitive = value["primitive"]
        line = LineString(primitive["coordinates_ref"])
        return [
            float(line.length),
            float(primitive["fit_rmse_m"]),
            float(value.get("mean_evidence_probability", 0.0)),
            float(value.get("confidence", 0.0)),
            float(primitive["kind"] == "line"),
            float(primitive["kind"] == "arc"),
            float(primitive["kind"] == "spline"),
            0.0,
            0.0,
            0.0,
        ]
    dimensions = value.get("dimensions_m", [0.0, 0.0])
    return [
        0.0,
        0.0,
        float(np.mean(value.get("edge_support", [0.0]))),
        float(value.get("confidence", 0.0)),
        0.0,
        0.0,
        0.0,
        float(dimensions[0]),
        float(dimensions[1]),
        float(value.get("vertical_span_m", 0.0)),
    ]


def _write_candidate_atlas(
    path: Path,
    candidates: list[dict],
    evidence: EvidenceGrid,
) -> None:
    cell_width, cell_height, columns = 260, 220, 5
    rows = max(1, int(math.ceil(len(candidates) / columns)))
    atlas = np.zeros((rows * cell_height, columns * cell_width, 3), np.uint8)
    coloured = cv2.applyColorMap(
        np.clip(evidence.probability * 255, 0, 255).astype(np.uint8),
        cv2.COLORMAP_TURBO,
    )
    for index, value in enumerate(candidates):
        if "primitive" in value:
            geometry = np.asarray(value["primitive"]["coordinates_ref"], dtype=float)
        else:
            geometry = np.asarray(value["coordinates_ref"], dtype=float)
        center = np.mean(geometry, axis=0)
        radius_m = max(2.0, min(5.0, float(np.max(np.ptp(geometry, axis=0))) * 0.7 + 1.0))
        center_px = np.round((center - evidence.origin) / evidence.grid_m).astype(int)
        radius_px = max(5, int(round(radius_m / evidence.grid_m)))
        x0, x1 = center_px[0] - radius_px, center_px[0] + radius_px + 1
        y0, y1 = center_px[1] - radius_px, center_px[1] + radius_px + 1
        sx0, sx1 = max(0, x0), min(coloured.shape[1], x1)
        sy0, sy1 = max(0, y0), min(coloured.shape[0], y1)
        crop = np.zeros((2 * radius_px + 1, 2 * radius_px + 1, 3), np.uint8)
        crop[sy0 - y0:sy1 - y0, sx0 - x0:sx1 - x0] = coloured[sy0:sy1, sx0:sx1]
        local = np.round((geometry - evidence.origin) / evidence.grid_m).astype(np.int32)
        local[:, 0] -= x0
        local[:, 1] -= y0
        cv2.polylines(
            crop,
            [local],
            "primitive" not in value,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        crop = np.ascontiguousarray(np.flipud(crop))
        crop = cv2.resize(crop, (cell_width, cell_height - 42), interpolation=cv2.INTER_AREA)
        row, column = divmod(index, columns)
        top, left = row * cell_height, column * cell_width
        atlas[top + 42:top + cell_height, left:left + cell_width] = crop
        cv2.putText(
            atlas,
            value["object_id"],
            (left + 6, top + 17),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.43,
            (245, 245, 245),
            1,
            cv2.LINE_AA,
        )
        cv2.putText(
            atlas,
            f"candidate={value['class']}  conf={value.get('confidence', 0):.2f}",
            (left + 6, top + 36),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.34,
            (185, 210, 255),
            1,
            cv2.LINE_AA,
        )
    cv2.imwrite(str(path), atlas)


def _write_label_pack(
    output_dir: Path,
    graph: BuildingObjectGraph,
    evidence: EvidenceGrid,
    maximum: int = 60,
) -> tuple[Path, Path]:
    algorithm_version = str(graph.metrics.get("algorithm_version", V13_VERSION))
    is_v14 = algorithm_version == V14_VERSION
    candidates = [*graph.walls, *graph.columns, *graph.uncertain]
    candidates = sorted(candidates, key=lambda value: (-float(value.get("confidence", 0.0)), value["object_id"]))
    review_candidates = candidates[:maximum]
    review_ids = {value["object_id"] for value in review_candidates}
    records = []
    for priority, value in enumerate(candidates):
        bucket = int(hashlib.sha1(value["object_id"].encode()).hexdigest()[:8], 16) % 20
        split = "joint" if is_v14 else "train" if bucket < 14 else "val" if bucket < 17 else "test"
        records.append(
            {
                "object_id": value["object_id"],
                "candidate_class": value["class"],
                "label": None,
                "allowed_labels": (
                    ["wall", "column", "unknown"]
                    if is_v14
                    else ["wall", "column", "non_building", "unknown"]
                ),
                "split": split,
                "feature_vector": _candidate_feature_vector(value),
                "suggested_for_review": value["object_id"] in review_ids,
                "review_priority": priority if value["object_id"] in review_ids else None,
                "notes": "",
            }
        )
    path = output_dir / "semantic_label_candidates.json"
    atlas_path = output_dir / "semantic_label_atlas.png"
    write_json(
        path,
        {
            "algorithm_version": algorithm_version,
            "instructions": "Set label for reviewed objects only. Keep unreviewed candidates null; null is never treated as ground truth.",
            "review_candidate_count": len(review_candidates),
            "all_object_count": len(candidates),
            "feature_names": [
                "length_m", "fit_rmse_m", "evidence_probability", "confidence",
                "is_line", "is_arc", "is_spline", "width_m", "height_m", "vertical_span_m",
            ],
            "records": records,
        },
    )
    _write_candidate_atlas(atlas_path, review_candidates, evidence)
    return path, atlas_path


def export_semantic_object_result(
    output_dir: str | Path,
    graph: BuildingObjectGraph,
    evidence: EvidenceGrid,
    clean_points: np.ndarray,
    transform_cad_from_ref: np.ndarray,
    thin_slices: list[Any],
    thick_slices: list[Any],
    cfg: dict,
) -> dict[str, str]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    main_dxf = output_dir / "architectural_plan.dxf"
    complete_dxf = output_dir / "building_object_complete.dxf"
    _export_graph_dxf(main_dxf, graph, transform_cad_from_ref, include_uncertain=False)
    _export_graph_dxf(complete_dxf, graph, transform_cad_from_ref, include_uncertain=True)
    thin_dir = output_dir / "semantic_calibrated_slices"
    thick_dir = output_dir / "semantic_calibrated_slices_thick"
    for window in thin_slices:
        _export_window_dxf(thin_dir / f"slice_{window.index:02d}_{window.z_min_m:.2f}_{window.z_max_m:.2f}.dxf", graph, window, transform_cad_from_ref)
    for window in thick_slices:
        _export_window_dxf(thick_dir / f"thick_{window.index:02d}_{window.z_min_m:.2f}_{window.z_max_m:.2f}.dxf", graph, window, transform_cad_from_ref)
    strict = _common_substrings(graph, thin_slices, require_all=True)
    observed_union = _common_substrings(graph, thin_slices, require_all=False)
    thick_strict = _common_substrings(graph, thick_slices, require_all=True)
    thick_observed_union = _common_substrings(graph, thick_slices, require_all=False)
    prefix = "v14" if cfg.get("semantic_probability_path") else "v13"
    title_prefix = prefix.upper()
    strict_path = output_dir / f"{prefix}_strict_intersection.dxf"
    union_path = output_dir / f"{prefix}_observed_union.dxf"
    _export_lines_dxf(strict_path, strict, transform_cad_from_ref, f"{title_prefix}_STRICT_INTERSECTION")
    _export_lines_dxf(union_path, observed_union, transform_cad_from_ref, f"{title_prefix}_OBSERVED_UNION")
    thick_strict_path = output_dir / f"{prefix}_thick_strict_intersection.dxf"
    thick_union_path = output_dir / f"{prefix}_thick_observed_union.dxf"
    _export_lines_dxf(thick_strict_path, thick_strict, transform_cad_from_ref, f"{title_prefix}_THICK_STRICT_INTERSECTION")
    _export_lines_dxf(thick_union_path, thick_observed_union, transform_cad_from_ref, f"{title_prefix}_THICK_OBSERVED_UNION")
    render_grid = float(cfg.get("semantic_render_grid_m", 0.05))
    strict_png = output_dir / f"{prefix}_strict_intersection.png"
    union_png = output_dir / f"{prefix}_observed_union.png"
    thick_strict_png = output_dir / f"{prefix}_thick_strict_intersection.png"
    thick_union_png = output_dir / f"{prefix}_thick_observed_union.png"
    _render_ref_lines(strict_png, clean_points, strict, transform_cad_from_ref, render_grid, f"{title_prefix} THIN STRICT OBSERVED INTERSECTION", (90, 255, 90))
    _render_ref_lines(union_png, clean_points, observed_union, transform_cad_from_ref, render_grid, f"{title_prefix} THIN MAXIMUM OBSERVED UNION")
    _render_ref_lines(thick_strict_png, clean_points, thick_strict, transform_cad_from_ref, render_grid, f"{title_prefix} THICK STRICT OBSERVED INTERSECTION", (90, 255, 90))
    _render_ref_lines(thick_union_png, clean_points, thick_observed_union, transform_cad_from_ref, render_grid, f"{title_prefix} THICK MAXIMUM OBSERVED UNION")
    thin_overlay_dir = output_dir / "semantic_overlays"
    thick_overlay_dir = output_dir / "semantic_overlays_thick"
    for window in thin_slices:
        lines = [line for wall in graph.walls for line in _window_substrings(wall, str(window.window_id))]
        band = clean_points[(clean_points[:, 2] >= window.z_min_m) & (clean_points[:, 2] < window.z_max_m)]
        _render_ref_lines(thin_overlay_dir / f"slice_{window.index:02d}_semantic.png", band, lines, transform_cad_from_ref, render_grid, f"{title_prefix} THIN {window.index:02d} {window.z_min_m:.2f}-{window.z_max_m:.2f} m")
    for window in thick_slices:
        lines = [line for wall in graph.walls for line in _window_substrings(wall, str(window.window_id))]
        band = clean_points[(clean_points[:, 2] >= window.z_min_m) & (clean_points[:, 2] < window.z_max_m)]
        _render_ref_lines(thick_overlay_dir / f"thick_{window.index:02d}_semantic.png", band, lines, transform_cad_from_ref, render_grid, f"{title_prefix} THICK {window.index:02d} {window.z_min_m:.2f}-{window.z_max_m:.2f} m")

    geojson_path = output_dir / "architectural_plan.geojson"
    algorithm_version = _semantic_algorithm_version(cfg)
    write_json(
        geojson_path,
        {
            "type": "FeatureCollection",
            "properties": {
                "algorithm_version": algorithm_version,
                "coordinate_system": "local CAD metres",
                "semantic_model_status": graph.metrics["semantic_model_status"],
                "strict_intersection_semantics": "observed in every thin window only",
            },
            "features": _graph_features(graph, transform_cad_from_ref),
        },
    )
    graph_path = output_dir / "building_object_graph.json"
    write_json(
        graph_path,
        {
            "algorithm_version": algorithm_version,
            "walls": graph.walls,
            "columns": graph.columns,
            "uncertain": graph.uncertain,
            "connections": graph.connections,
            "nodes": graph.nodes,
            "metrics": graph.metrics,
        },
    )
    probability = np.clip(evidence.probability * 255, 0, 255).astype(np.uint8)
    heat_path = output_dir / "semantic_evidence_heatmap.png"
    cv2.imwrite(str(heat_path), cv2.applyColorMap(probability, cv2.COLORMAP_TURBO))
    evidence_path = output_dir / "semantic_evidence.npz"
    np.savez_compressed(
        evidence_path,
        origin=evidence.origin,
        grid_m=np.asarray([evidence.grid_m], dtype=float),
        probability=evidence.probability,
        point_count=evidence.point_count,
        height_bin_count=evidence.height_bin_count,
        vertical_span_m=evidence.vertical_span_m,
        vertical_continuity=evidence.vertical_continuity,
        thin_vote=evidence.thin_vote,
        thick_vote=evidence.thick_vote,
        structural_mask=evidence.structural_mask,
        wall_probability=(
            evidence.wall_probability
            if evidence.wall_probability is not None
            else np.zeros_like(evidence.probability)
        ),
        column_probability=(
            evidence.column_probability
            if evidence.column_probability is not None
            else np.zeros_like(evidence.probability)
        ),
    )
    wall_probability_path = output_dir / "semantic_wall_probability.png"
    column_probability_path = output_dir / "semantic_column_probability.png"
    cv2.imwrite(
        str(wall_probability_path),
        cv2.applyColorMap(
            np.clip(
                (
                    evidence.wall_probability
                    if evidence.wall_probability is not None
                    else np.zeros_like(evidence.probability)
                )
                * 255,
                0,
                255,
            ).astype(np.uint8),
            cv2.COLORMAP_TURBO,
        ),
    )
    cv2.imwrite(
        str(column_probability_path),
        cv2.applyColorMap(
            np.clip(
                (
                    evidence.column_probability
                    if evidence.column_probability is not None
                    else np.zeros_like(evidence.probability)
                )
                * 255,
                0,
                255,
            ).astype(np.uint8),
            cv2.COLORMAP_TURBO,
        ),
    )
    main_png = output_dir / "final_dxf.png"
    complete_png = output_dir / "building_object_complete.png"
    _render_graph(main_png, graph, clean_points, transform_cad_from_ref, cfg, include_uncertain=False)
    _render_graph(complete_png, graph, clean_points, transform_cad_from_ref, cfg, include_uncertain=True)
    comparison_outputs = _render_v13_comparisons(output_dir, graph, clean_points, transform_cad_from_ref, cfg)
    label_path, atlas_path = _write_label_pack(
        output_dir,
        graph,
        evidence,
        int(cfg.get("semantic_label_candidate_count", 60)),
    )
    return {
        f"{prefix}_architectural_plan_dxf": str(main_dxf),
        f"{prefix}_complete_dxf": str(complete_dxf),
        f"{prefix}_architectural_geojson": str(geojson_path),
        f"{prefix}_object_graph_json": str(graph_path),
        f"{prefix}_final_png": str(main_png),
        f"{prefix}_complete_png": str(complete_png),
        f"{prefix}_evidence_heatmap_png": str(heat_path),
        f"{prefix}_evidence_npz": str(evidence_path),
        "v14_wall_probability_png": str(wall_probability_path),
        "v14_column_probability_png": str(column_probability_path),
        f"{prefix}_strict_intersection_dxf": str(strict_path),
        f"{prefix}_observed_union_dxf": str(union_path),
        f"{prefix}_strict_intersection_png": str(strict_png),
        f"{prefix}_observed_union_png": str(union_png),
        f"{prefix}_thick_strict_intersection_dxf": str(thick_strict_path),
        f"{prefix}_thick_observed_union_dxf": str(thick_union_path),
        f"{prefix}_thick_strict_intersection_png": str(thick_strict_png),
        f"{prefix}_thick_observed_union_png": str(thick_union_png),
        f"{prefix}_semantic_label_candidates": str(label_path),
        f"{prefix}_semantic_label_atlas": str(atlas_path),
        **comparison_outputs,
    }


def run_semantic_object_stage(
    output_dir: str | Path,
    clean_points: np.ndarray,
    floor_m: float,
    ceiling_m: float,
    origin: np.ndarray,
    shape: tuple[int, int],
    thin_slices: list[Any],
    thick_slices: list[Any],
    transform_cad_from_ref: np.ndarray,
    cfg: dict,
) -> SemanticObjectResult:
    graph, evidence = build_semantic_object_graph(
        clean_points,
        floor_m,
        ceiling_m,
        origin,
        shape,
        thin_slices,
        thick_slices,
        cfg,
    )
    outputs = export_semantic_object_result(
        output_dir,
        graph,
        evidence,
        clean_points,
        transform_cad_from_ref,
        thin_slices,
        thick_slices,
        cfg,
    )
    output_prefix = "v14" if cfg.get("semantic_probability_path") else "v13"
    main_document = ezdxf.readfile(outputs[f"{output_prefix}_architectural_plan_dxf"])
    entity_counts: dict[str, int] = {}
    finite_geometry = True
    main_entities = list(main_document.modelspace())
    for entity in main_entities:
        kind = entity.dxftype()
        entity_counts[kind] = entity_counts.get(kind, 0) + 1
        try:
            if kind == "LINE":
                values = [entity.dxf.start.x, entity.dxf.start.y, entity.dxf.end.x, entity.dxf.end.y]
            elif kind == "ARC":
                values = [entity.dxf.center.x, entity.dxf.center.y, entity.dxf.radius]
            elif kind == "LWPOLYLINE":
                values = [coordinate for point in entity.get_points("xy") for coordinate in point[:2]]
            elif kind == "SPLINE":
                values = [coordinate for point in entity.control_points for coordinate in point[:2]]
            else:
                values = []
            finite_geometry = finite_geometry and bool(np.all(np.isfinite(values)))
        except (AttributeError, TypeError, ValueError):
            finite_geometry = False
    exported_node_points: dict[str, list[np.ndarray]] = {}
    endpoint_error = []
    for wall, entity in zip(graph.walls, main_entities[: len(graph.walls)]):
        kind = entity.dxftype()
        if kind == "LINE":
            actual = np.asarray(
                [[entity.dxf.start.x, entity.dxf.start.y], [entity.dxf.end.x, entity.dxf.end.y]],
                dtype=float,
            )
        elif kind == "ARC":
            center = np.asarray([entity.dxf.center.x, entity.dxf.center.y], dtype=float)
            angles = np.radians([float(entity.dxf.start_angle), float(entity.dxf.end_angle)])
            actual = center + float(entity.dxf.radius) * np.column_stack([np.cos(angles), np.sin(angles)])
        elif kind == "SPLINE":
            flattened = np.asarray([(point.x, point.y) for point in entity.flattening(0.001)], dtype=float)
            actual = np.asarray([flattened[0], flattened[-1]])
        else:
            continue
        expected_ref = np.asarray(wall["primitive"]["coordinates_ref"], dtype=float)[[0, -1]]
        expected = _transform_xy(expected_ref, transform_cad_from_ref)
        if np.linalg.norm(actual[::-1] - expected, axis=1).sum() < np.linalg.norm(actual - expected, axis=1).sum():
            actual = actual[::-1]
        endpoint_error.extend(np.linalg.norm(actual - expected, axis=1).tolist())
        for key, point in zip(("start_node_id", "end_node_id"), actual):
            node_id = wall.get(key)
            if node_id:
                exported_node_points.setdefault(node_id, []).append(point)
    shared_spreads = []
    for values in exported_node_points.values():
        if len(values) < 2:
            continue
        array = np.asarray(values)
        shared_spreads.append(float(np.max(np.linalg.norm(array - np.mean(array, axis=0), axis=1))))
    export_node_spread = max(shared_spreads or [0.0])
    native_dxf_valid = (
        finite_geometry
        and entity_counts.get("LINE", 0) > 0
        and (entity_counts.get("ARC", 0) + entity_counts.get("SPLINE", 0)) > 0
        and export_node_spread <= 0.001
    )
    metrics = {
        **graph.metrics,
        "strict_intersection_length_m": float(
            sum(line.length for line in _common_substrings(graph, thin_slices, True))
        ),
        "observed_union_length_m": float(
            sum(line.length for line in _common_substrings(graph, thin_slices, False))
        ),
        "native_dxf_valid": bool(native_dxf_valid),
        "native_dxf_entity_counts": entity_counts,
        "native_dxf_shared_node_max_spread_m": export_node_spread,
        "native_dxf_endpoint_p95_m": float(np.quantile(endpoint_error, 0.95)) if endpoint_error else None,
    }
    write_json(Path(output_dir) / "semantic_object_audit.json", {"metrics": metrics, "outputs": outputs})
    outputs["v13_audit_json"] = str(Path(output_dir) / "semantic_object_audit.json")
    return SemanticObjectResult(graph=graph, evidence=evidence, outputs=outputs, metrics=metrics)


def _feature_diverse_records(records: list[dict], count: int) -> list[dict]:
    if count <= 0 or not records:
        return []
    ordered = sorted(records, key=lambda value: str(value.get("object_id", "")))
    features = np.asarray([value.get("feature_vector", []) for value in ordered], dtype=float)
    if features.ndim != 2 or features.shape[1] == 0 or not np.all(np.isfinite(features)):
        return ordered[:count]
    scale = np.std(features, axis=0)
    scale[scale < 1e-6] = 1.0
    normalised = (features - np.mean(features, axis=0)) / scale
    # Start with the least-confident candidate, then greedily cover feature space.
    def confidence(value: dict) -> float:
        feature = value.get("feature_vector", [])
        return float(feature[3]) if len(feature) > 3 else float(value.get("confidence", 0.0))

    chosen = [int(np.argmin([confidence(value) for value in ordered]))]
    distance = np.linalg.norm(normalised - normalised[chosen[0]], axis=1)
    while len(chosen) < min(count, len(ordered)):
        distance[chosen] = -1.0
        next_index = int(np.argmax(distance))
        chosen.append(next_index)
        distance = np.minimum(
            distance, np.linalg.norm(normalised - normalised[next_index], axis=1)
        )
    return [ordered[index] for index in chosen]


def extend_semantic_review_batch(labels_path: str | Path, additional_count: int) -> dict:
    """Promote a feature-diverse, wall/uncertainty-heavy review batch."""
    path = Path(labels_path)
    value = read_json(path)
    candidates = [
        record
        for record in value.get("records", [])
        if record.get("label") is None and not record.get("suggested_for_review", False)
    ]
    requested = max(0, min(int(additional_count), len(candidates)))
    weights = {
        "UNKNOWN_WALL": 0.40,
        "WALL": 0.35,
        "UNKNOWN_COLUMN": 0.20,
        "COLUMN": 0.05,
    }
    selected: list[dict] = []
    used: set[str] = set()
    for candidate_class, weight in weights.items():
        pool = [value for value in candidates if value.get("candidate_class") == candidate_class]
        quota = min(len(pool), int(round(requested * weight)))
        for record in _feature_diverse_records(pool, quota):
            selected.append(record)
            used.add(str(record.get("object_id")))
    remainder = [
        record for record in candidates if str(record.get("object_id")) not in used
    ]
    for record in _feature_diverse_records(remainder, requested - len(selected)):
        selected.append(record)
    existing_rounds = [int(record.get("review_round", 1)) for record in value.get("records", []) if record.get("suggested_for_review")]
    review_round = max(existing_rounds, default=1) + 1
    for priority, record in enumerate(selected):
        record["suggested_for_review"] = True
        record["review_round"] = review_round
        record["review_priority"] = priority
        record["selection_reason"] = "feature_diversity_and_class_gap"
    value["review_candidate_count"] = sum(
        bool(record.get("suggested_for_review")) for record in value.get("records", [])
    )
    write_json(path, value)
    return {
        "added": len(selected),
        "review_round": review_round,
        "review_candidate_count": value["review_candidate_count"],
        "selected_by_candidate_class": {
            key: sum(record.get("candidate_class") == key for record in selected)
            for key in weights
        },
    }


def prepare_semantic_label_manifest(
    source_dir: str | Path,
    output_path: str | Path,
    dataset_id: str | None = None,
    dataset_role: str | None = None,
) -> dict:
    source = Path(source_dir) / "semantic_label_candidates.json"
    if not source.is_file():
        raise ValueError(f"Missing V13 semantic candidates: {source}")
    value = read_json(source)
    records = value.get("records", [])
    if not any(record.get("suggested_for_review") for record in records):
        for record in records[: int(value.get("review_candidate_count", 0))]:
            record["suggested_for_review"] = True
            record.setdefault("review_round", 1)
    output_path = Path(output_path)
    if output_path.is_file():
        existing = read_json(output_path)
        reviewed = {
            record.get("object_id"): record
            for record in existing.get("records", [])
            if record.get("label") is not None
            or record.get("notes")
            or record.get("roi_ref") is not None
            or record.get("roi_polygon_ref") is not None
            or int(record.get("review_round", 1)) > 1
            or record.get("selection_reason") is not None
        }
        for record in value.get("records", []):
            previous = reviewed.get(record.get("object_id"))
            if previous is not None:
                record["label"] = previous.get("label")
                record["notes"] = previous.get("notes", "")
                if previous.get("suggested_for_review"):
                    record["suggested_for_review"] = True
                    record["review_round"] = previous.get("review_round", 1)
                    record["review_priority"] = previous.get("review_priority")
                    record["selection_reason"] = previous.get("selection_reason")
                if previous.get("roi_ref") is not None:
                    record["roi_ref"] = previous["roi_ref"]
                    record["roi_source"] = previous.get("roi_source", "human_box")
                if previous.get("roi_polygon_ref") is not None:
                    record["roi_polygon_ref"] = previous["roi_polygon_ref"]
                    record["roi_source"] = previous.get(
                        "roi_source", "human_closed_polyline"
                    )
                if previous.get("sonata_embedding"):
                    record["sonata_embedding"] = previous["sonata_embedding"]
                    record["sonata_point_count"] = previous.get("sonata_point_count")
    if dataset_role is not None and dataset_role not in {"train", "val", "test"}:
        raise ValueError("semantic dataset role must be train, val or test")
    resolved_dataset_id = dataset_id or value.get("dataset_id") or Path(source_dir).parent.name
    for record in value.get("records", []):
        record["dataset_id"] = resolved_dataset_id
        record["sample_id"] = f"{resolved_dataset_id}:{record['object_id']}"
        if dataset_role is not None:
            record["split"] = dataset_role
    value["dataset_id"] = resolved_dataset_id
    if dataset_role is not None:
        value["dataset_role"] = dataset_role
    value["review_candidate_count"] = sum(
        bool(record.get("suggested_for_review")) for record in value.get("records", [])
    )
    write_json(output_path, value)
    return {
        "candidate_count": len(value.get("records", [])),
        "suggested_review_count": int(value.get("review_candidate_count", 0)),
        "labelled_count": sum(record.get("label") is not None for record in value.get("records", [])),
        "output": str(Path(output_path).resolve()),
    }
