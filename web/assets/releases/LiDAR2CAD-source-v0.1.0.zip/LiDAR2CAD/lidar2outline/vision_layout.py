from __future__ import annotations

import hashlib
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np


@dataclass
class VisionLayoutResult:
    mask: np.ndarray
    probability: np.ndarray
    vector_heatmap: np.ndarray
    pseudo_target: np.ndarray
    metrics: dict


def _line_kernel(length: int, angle_rad: float) -> np.ndarray:
    length = max(3, int(length) | 1)
    kernel = np.zeros((length, length), np.uint8)
    center = (length - 1) / 2
    radius = center
    dx = math.cos(angle_rad) * radius
    dy = math.sin(angle_rad) * radius
    cv2.line(
        kernel,
        (int(round(center - dx)), int(round(center - dy))),
        (int(round(center + dx)), int(round(center + dy))),
        1,
        1,
    )
    return kernel


def _remove_small_components(mask: np.ndarray, minimum_cells: int) -> np.ndarray:
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        np.where(mask > 0, 255, 0).astype(np.uint8), 8
    )
    clean = np.zeros(mask.shape, np.uint8)
    for component in range(1, count):
        if int(stats[component, cv2.CC_STAT_AREA]) >= minimum_cells:
            clean[labels == component] = 255
    return clean


def _scope_mask(shape: tuple[int, int], polygon, origin: np.ndarray, grid_m: float, margin_m: float) -> np.ndarray:
    scoped = polygon.buffer(margin_m, join_style=2) if margin_m else polygon
    result = np.zeros(shape, np.uint8)
    geometries = list(scoped.geoms) if scoped.geom_type == "MultiPolygon" else [scoped]
    for geometry in geometries:
        if geometry.is_empty or geometry.geom_type != "Polygon":
            continue
        exterior = np.round((np.asarray(geometry.exterior.coords) - origin) / grid_m).astype(np.int32)
        holes = [
            np.round((np.asarray(ring.coords) - origin) / grid_m).astype(np.int32)
            for ring in geometry.interiors
        ]
        cv2.fillPoly(result, [exterior], 255)
        if holes:
            cv2.fillPoly(result, holes, 0)
    return result


def _session_raster(
    points: np.ndarray,
    origin: np.ndarray,
    shape: tuple[int, int],
    grid_m: float,
    height_bin_m: float,
    min_height_m: float,
    max_height_m: float,
) -> tuple[np.ndarray, np.ndarray]:
    height, width = shape
    band = np.asarray(points, dtype=float)
    band = band[
        np.all(np.isfinite(band), axis=1)
        & (band[:, 2] >= min_height_m)
        & (band[:, 2] <= max_height_m)
    ]
    density = np.zeros(shape, np.float32)
    vertical = np.zeros(shape, np.float32)
    if not len(band):
        return density, vertical
    ij = np.floor((band[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < width)
        & (ij[:, 1] < height)
    )
    ij = ij[valid]
    band = band[valid]
    np.add.at(density, (ij[:, 1], ij[:, 0]), 1)
    if not len(band):
        return density, vertical
    z_bin = np.floor((band[:, 2] - min_height_m) / height_bin_m).astype(np.int32)
    linear = ij[:, 1] * width + ij[:, 0]
    unique = np.unique(np.column_stack([linear, z_bin]), axis=0)
    cells, counts = np.unique(unique[:, 0], return_counts=True)
    vertical.reshape(-1)[cells] = counts.astype(np.float32)
    return density, vertical


def build_bev_features(
    session_points_ref: list[np.ndarray],
    base_mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    height_bin_m: float,
    min_height_m: float,
    max_height_m: float,
    main_angle: float | None,
    cfg: dict,
    scope_polygon=None,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Create OSM2Net-style bitmap pairs from registered LiDAR sessions.

    The four input channels are fused log-density, vertical continuity,
    cross-session recurrence, and the high-recall wall mask.  The weak target
    keeps cells repeated by independent sessions and exceptionally strong
    single-session vertical structures, then closes only along the two main
    architectural directions.
    """
    shape = tuple(base_mask.shape)
    densities: list[np.ndarray] = []
    verticals: list[np.ndarray] = []
    for points in session_points_ref:
        density, vertical = _session_raster(
            points,
            origin,
            shape,
            grid_m,
            height_bin_m,
            min_height_m,
            max_height_m,
        )
        densities.append(density)
        verticals.append(vertical)
    density_stack = np.stack(densities)
    vertical_stack = np.stack(verticals)
    fused_density = np.sum(density_stack, axis=0)
    fused_vertical = np.max(vertical_stack, axis=0)
    session_min_points = int(cfg.get("session_min_points_per_cell", 2))
    session_min_bins = int(cfg.get("session_min_height_bins", 2))
    evidence = (density_stack >= session_min_points) & (vertical_stack >= session_min_bins)
    session_support = np.sum(evidence, axis=0)
    wanted_support = min(int(cfg.get("target_min_sessions", 2)), len(session_points_ref))
    stable = session_support >= max(1, wanted_support)
    strong_single = (
        (session_support >= 1)
        & (fused_vertical >= int(cfg.get("target_strong_height_bins", 5)))
        & (fused_density >= int(cfg.get("target_strong_points_per_cell", 10)))
        & (base_mask > 0)
    )
    target = np.where(stable | strong_single, 255, 0).astype(np.uint8)

    close_pixels = max(3, int(round(float(cfg.get("target_close_gap_m", 0.35)) / grid_m)) | 1)
    angle = main_angle or 0.0
    along = cv2.morphologyEx(target, cv2.MORPH_CLOSE, _line_kernel(close_pixels, angle))
    across = cv2.morphologyEx(target, cv2.MORPH_CLOSE, _line_kernel(close_pixels, angle + math.pi / 2))
    target = cv2.max(target, cv2.max(along, across))
    target = _remove_small_components(target, int(cfg.get("target_min_component_cells", 8)))

    scope = None
    if scope_polygon is not None:
        scope = _scope_mask(
            shape,
            scope_polygon,
            origin,
            grid_m,
            float(cfg.get("scope_margin_m", 0.30)),
        )
        target = cv2.bitwise_and(target, scope)

    nonzero_density = fused_density[fused_density > 0]
    density_scale = float(np.percentile(nonzero_density, 99)) if len(nonzero_density) else 1.0
    density_feature = np.log1p(fused_density) / max(math.log1p(density_scale), 1e-6)
    total_bins = max(1, int(math.ceil((max_height_m - min_height_m) / height_bin_m)))
    vertical_feature = np.clip(fused_vertical / total_bins, 0.0, 1.0)
    recurrence_feature = session_support / max(1, len(session_points_ref))
    features = np.stack(
        [
            np.clip(density_feature, 0.0, 1.0),
            vertical_feature,
            recurrence_feature.astype(np.float32),
            (base_mask > 0).astype(np.float32),
        ]
    ).astype(np.float32)
    if scope is not None:
        features *= (scope > 0)[None, :, :]
    metadata = {
        "session_count": len(session_points_ref),
        "target_session_support": wanted_support,
        "base_evidence_cells": int(np.count_nonzero(base_mask)),
        "stable_evidence_cells": int(np.count_nonzero(stable)),
        "strong_single_session_cells": int(np.count_nonzero(strong_single)),
        "pseudo_target_cells": int(np.count_nonzero(target)),
    }
    return features, target, metadata


def _crop_pad(array: np.ndarray, top: int, left: int, size: int) -> np.ndarray:
    channels = array.ndim == 3
    height, width = array.shape[-2:]
    bottom = min(height, top + size)
    right = min(width, left + size)
    if channels:
        result = np.zeros((array.shape[0], size, size), array.dtype)
        result[:, : bottom - top, : right - left] = array[:, top:bottom, left:right]
    else:
        result = np.zeros((size, size), array.dtype)
        result[: bottom - top, : right - left] = array[top:bottom, left:right]
    return result


def _patch_coordinates(target: np.ndarray, size: int) -> list[tuple[int, int]]:
    height, width = target.shape
    stride = max(32, size // 2)
    tops = list(range(0, max(1, height - size + 1), stride))
    lefts = list(range(0, max(1, width - size + 1), stride))
    tops.append(max(0, height - size))
    lefts.append(max(0, width - size))
    coordinates = []
    for top in sorted(set(tops)):
        for left in sorted(set(lefts)):
            patch = _crop_pad(target, top, left, size)
            if np.count_nonzero(patch) >= max(24, size // 2):
                coordinates.append((top, left))
    return coordinates or [(0, 0)]


def _corrupt_real(features: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    noisy = features.copy()
    size = noisy.shape[-1]
    for _ in range(int(rng.integers(3, 9))):
        x = int(rng.integers(0, size))
        y = int(rng.integers(0, size))
        width = int(rng.integers(2, max(3, size // 18)))
        height = int(rng.integers(2, max(3, size // 18)))
        noisy[[0, 1, 3], y : min(size, y + height), x : min(size, x + width)] *= float(
            rng.uniform(0.0, 0.25)
        )
    scatter = np.zeros((size, size), np.uint8)
    for _ in range(int(rng.integers(8, 25))):
        p1 = tuple(rng.integers(0, size, 2).tolist())
        if rng.random() < 0.55:
            p2 = tuple(np.clip(np.asarray(p1) + rng.integers(-30, 31, 2), 0, size - 1).tolist())
            cv2.line(scatter, p1, p2, 255, int(rng.integers(1, 4)))
        else:
            cv2.circle(scatter, p1, int(rng.integers(1, 7)), 255, -1)
    added = scatter > 0
    noisy[0, added] = np.maximum(noisy[0, added], rng.uniform(0.25, 0.75))
    noisy[1, added] = np.maximum(noisy[1, added], rng.uniform(0.05, 0.35))
    noisy[2, added] = np.maximum(noisy[2, added], rng.uniform(0.0, 0.34))
    noisy[3, added] = 1.0
    return noisy


def _synthetic_pair(size: int, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    target = np.zeros((size, size), np.uint8)
    margin = int(rng.integers(size // 12, size // 5))
    thickness = int(rng.integers(1, 4))
    cv2.rectangle(target, (margin, margin), (size - margin, size - margin), 255, thickness)
    verticals = sorted(rng.integers(margin + 20, size - margin - 20, int(rng.integers(2, 6))).tolist())
    horizontals = sorted(rng.integers(margin + 20, size - margin - 20, int(rng.integers(2, 6))).tolist())
    for x in verticals:
        y1 = margin if rng.random() < 0.7 else int(rng.choice(horizontals))
        y2 = size - margin if rng.random() < 0.7 else int(rng.choice(horizontals))
        if y1 > y2:
            y1, y2 = y2, y1
        cv2.line(target, (int(x), y1), (int(x), y2), 255, thickness)
    for y in horizontals:
        x1 = margin if rng.random() < 0.7 else int(rng.choice(verticals))
        x2 = size - margin if rng.random() < 0.7 else int(rng.choice(verticals))
        if x1 > x2:
            x1, x2 = x2, x1
        cv2.line(target, (x1, int(y)), (x2, int(y)), 255, thickness)
    if rng.random() < 0.45:
        p1 = (int(rng.integers(margin, size // 2)), int(rng.integers(size // 2, size - margin)))
        p2 = (int(rng.integers(size // 2, size - margin)), int(rng.integers(margin, size // 2)))
        cv2.line(target, p1, p2, 255, thickness)

    sessions = []
    for _ in range(3):
        observed = target.copy()
        for _ in range(int(rng.integers(4, 12))):
            x = int(rng.integers(0, size))
            y = int(rng.integers(0, size))
            w = int(rng.integers(3, 25))
            h = int(rng.integers(3, 25))
            observed[y : min(size, y + h), x : min(size, x + w)] = 0
        sessions.append(observed > 0)
    support = np.sum(np.stack(sessions), axis=0).astype(np.float32)
    observed = np.any(np.stack(sessions), axis=0).astype(np.uint8) * 255
    scatter = np.zeros_like(target)
    for _ in range(int(rng.integers(10, 35))):
        p1 = tuple(rng.integers(0, size, 2).tolist())
        p2 = tuple(np.clip(np.asarray(p1) + rng.integers(-35, 36, 2), 0, size - 1).tolist())
        cv2.line(scatter, p1, p2, 255, int(rng.integers(1, 4)))
    raw = cv2.max(observed, scatter)
    density = cv2.GaussianBlur(raw.astype(np.float32) / 255.0, (3, 3), 0)
    vertical = np.clip((support / 3.0) * rng.uniform(0.7, 1.0), 0.0, 1.0)
    vertical[scatter > 0] = np.maximum(vertical[scatter > 0], rng.uniform(0.05, 0.35))
    recurrence = support / 3.0
    recurrence[scatter > 0] = np.maximum(recurrence[scatter > 0], rng.uniform(0.0, 0.34))
    features = np.stack([density, vertical, recurrence, raw / 255.0]).astype(np.float32)
    return features, (target > 0).astype(np.float32)


def _augment_pair(
    features: np.ndarray, target: np.ndarray, rng: np.random.Generator
) -> tuple[np.ndarray, np.ndarray]:
    if rng.random() < 0.5:
        features = features[:, :, ::-1]
        target = target[:, ::-1]
    if rng.random() < 0.5:
        features = features[:, ::-1, :]
        target = target[::-1, :]
    turns = int(rng.integers(0, 4))
    if turns:
        features = np.rot90(features, turns, axes=(-2, -1))
        target = np.rot90(target, turns)
    return np.ascontiguousarray(features), np.ascontiguousarray(target)


def _define_model(torch, nn, functional):
    class DepthwiseResidual(nn.Module):
        def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
            super().__init__()
            self.depthwise1 = nn.Conv2d(
                in_channels, in_channels, 3, stride=stride, padding=1, groups=in_channels, bias=False
            )
            self.pointwise1 = nn.Conv2d(in_channels, out_channels, 1, bias=False)
            self.norm1 = nn.BatchNorm2d(out_channels)
            self.depthwise2 = nn.Conv2d(
                out_channels, out_channels, 3, padding=1, groups=out_channels, bias=False
            )
            self.pointwise2 = nn.Conv2d(out_channels, out_channels, 1, bias=False)
            self.norm2 = nn.BatchNorm2d(out_channels)
            self.skip = (
                nn.Identity()
                if in_channels == out_channels and stride == 1
                else nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, 1, stride=stride, bias=False),
                    nn.BatchNorm2d(out_channels),
                )
            )

        def forward(self, value):
            residual = self.skip(value)
            value = functional.silu(self.norm1(self.pointwise1(self.depthwise1(value))))
            value = self.norm2(self.pointwise2(self.depthwise2(value)))
            return functional.silu(value + residual)

    class AttentionAugmentedBridge(nn.Module):
        def __init__(self, channels: int, heads: int = 4):
            super().__init__()
            self.heads = heads
            self.head_dim = channels // heads
            self.qkv = nn.Conv2d(channels, channels * 3, 1, bias=False)
            self.projection = nn.Conv2d(channels, channels, 1, bias=False)
            self.norm = nn.BatchNorm2d(channels)

        def forward(self, value):
            batch, channels, height, width = value.shape
            qkv = self.qkv(value).reshape(batch, 3, self.heads, self.head_dim, height * width)
            query = qkv[:, 0].transpose(-1, -2)
            key = qkv[:, 1].transpose(-1, -2)
            val = qkv[:, 2].transpose(-1, -2)
            attended = functional.scaled_dot_product_attention(query, key, val)
            attended = attended.transpose(-1, -2).reshape(batch, channels, height, width)
            return functional.silu(value + self.norm(self.projection(attended)))

    class Decoder(nn.Module):
        def __init__(self, in_channels: int, skip_channels: int, out_channels: int):
            super().__init__()
            self.block = DepthwiseResidual(in_channels + skip_channels, out_channels)

        def forward(self, value, skip):
            value = functional.interpolate(value, size=skip.shape[-2:], mode="bilinear", align_corners=False)
            return self.block(torch.cat([value, skip], dim=1))

    class Lane2StructureNet(nn.Module):
        def __init__(self, in_channels: int = 4, base: int = 16):
            super().__init__()
            self.stem = DepthwiseResidual(in_channels, base)
            self.encoder1 = DepthwiseResidual(base, base * 2, stride=2)
            self.encoder2 = DepthwiseResidual(base * 2, base * 3, stride=2)
            self.encoder3 = DepthwiseResidual(base * 3, base * 4, stride=2)
            self.bridge = nn.Sequential(
                DepthwiseResidual(base * 4, base * 6, stride=2),
                AttentionAugmentedBridge(base * 6, heads=4),
            )
            self.decoder3 = Decoder(base * 6, base * 4, base * 4)
            self.decoder2 = Decoder(base * 4, base * 3, base * 3)
            self.decoder1 = Decoder(base * 3, base * 2, base * 2)
            self.decoder0 = Decoder(base * 2, base, base)
            self.output = nn.Conv2d(base, 1, 1)

        def forward(self, value):
            stem = self.stem(value)
            enc1 = self.encoder1(stem)
            enc2 = self.encoder2(enc1)
            enc3 = self.encoder3(enc2)
            value = self.bridge(enc3)
            value = self.decoder3(value, enc3)
            value = self.decoder2(value, enc2)
            value = self.decoder1(value, enc1)
            value = self.decoder0(value, stem)
            return self.output(value)

    return Lane2StructureNet


def _soft_skeleton(functional, value, iterations: int = 4):
    minimum = -functional.max_pool2d(-value, 3, 1, 1)
    skeleton = functional.relu(value - functional.max_pool2d(minimum, 3, 1, 1))
    for _ in range(iterations):
        value = -functional.max_pool2d(-value, 3, 1, 1)
        opened = functional.max_pool2d(value, 3, 1, 1)
        delta = functional.relu(value - opened)
        skeleton = skeleton + functional.relu(delta - skeleton * delta)
    return skeleton


def _loss(functional, logits, target, positive_weight):
    probability = logits.sigmoid()
    bce = functional.binary_cross_entropy_with_logits(logits, target, pos_weight=positive_weight)
    intersection = (probability * target).sum(dim=(1, 2, 3))
    dice = 1.0 - ((2.0 * intersection + 1.0) / (probability.sum((1, 2, 3)) + target.sum((1, 2, 3)) + 1.0)).mean()
    predicted_skeleton = _soft_skeleton(functional, probability)
    target_skeleton = _soft_skeleton(functional, target)
    precision = (predicted_skeleton * target).sum((1, 2, 3)) / (predicted_skeleton.sum((1, 2, 3)) + 1.0)
    sensitivity = (target_skeleton * probability).sum((1, 2, 3)) / (target_skeleton.sum((1, 2, 3)) + 1.0)
    cldice = 1.0 - ((2.0 * precision * sensitivity + 1e-5) / (precision + sensitivity + 1e-5)).mean()
    return bce + 0.8 * dice + 0.2 * cldice


def _predict(torch, model, features: np.ndarray, patch_size: int, batch_size: int, device) -> np.ndarray:
    height, width = features.shape[-2:]
    stride = patch_size // 2
    tops = list(range(0, max(1, height - patch_size + 1), stride)) + [max(0, height - patch_size)]
    lefts = list(range(0, max(1, width - patch_size + 1), stride)) + [max(0, width - patch_size)]
    coordinates = [(top, left) for top in sorted(set(tops)) for left in sorted(set(lefts))]
    accumulator = np.zeros((height, width), np.float32)
    weights = np.zeros((height, width), np.float32)
    axis = np.hanning(patch_size).astype(np.float32)
    window = np.maximum(np.outer(axis, axis), 0.05)
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(coordinates), batch_size):
            batch_coordinates = coordinates[start : start + batch_size]
            batch = np.stack([_crop_pad(features, top, left, patch_size) for top, left in batch_coordinates])
            tensor = torch.from_numpy(batch).to(device)
            with torch.amp.autocast(device_type=device.type, enabled=device.type == "cuda"):
                probability = model(tensor).sigmoid().float().cpu().numpy()[:, 0]
            for (top, left), patch in zip(batch_coordinates, probability):
                bottom = min(height, top + patch_size)
                right = min(width, left + patch_size)
                ph, pw = bottom - top, right - left
                accumulator[top:bottom, left:right] += patch[:ph, :pw] * window[:ph, :pw]
                weights[top:bottom, left:right] += window[:ph, :pw]
    return accumulator / np.maximum(weights, 1e-6)


def _threshold_score(probability: np.ndarray, target: np.ndarray, threshold: float) -> tuple[float, float]:
    predicted = probability >= threshold
    expected = target > 0
    intersection = int(np.count_nonzero(predicted & expected))
    union = int(np.count_nonzero(predicted | expected))
    iou = intersection / max(1, union)
    precision = intersection / max(1, int(np.count_nonzero(predicted)))
    recall = intersection / max(1, int(np.count_nonzero(expected)))
    f1 = 2.0 * precision * recall / max(1e-9, precision + recall)
    return float(iou), float(f1)


def _write_preview(
    path: Path,
    features: np.ndarray,
    target: np.ndarray,
    probability: np.ndarray,
    prediction: np.ndarray,
) -> None:
    panels = [
        (features[0] * 255).astype(np.uint8),
        (features[1] * 255).astype(np.uint8),
        (features[2] * 255).astype(np.uint8),
        target,
        np.clip(probability * 255, 0, 255).astype(np.uint8),
        prediction,
    ]
    labels = ["log density", "vertical continuity", "session recurrence", "weak target", "network probability", "clean structure"]
    target_width = 720
    scale = min(1.0, target_width / max(panel.shape[1] for panel in panels))
    resized = [cv2.resize(panel, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) for panel in panels]
    ph, pw = resized[0].shape
    canvas = np.zeros((2 * (ph + 34), 3 * pw), np.uint8)
    for index, (panel, label) in enumerate(zip(resized, labels)):
        row, column = divmod(index, 3)
        top = row * (ph + 34)
        left = column * pw
        canvas[top + 34 : top + 34 + ph, left : left + pw] = panel
        cv2.putText(canvas, label, (left + 8, top + 24), cv2.FONT_HERSHEY_SIMPLEX, 0.58, 230, 1, cv2.LINE_AA)
    cv2.imwrite(str(path), canvas)


def run_vision_layout(
    session_points_ref: list[np.ndarray],
    base_mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    height_bin_m: float,
    min_height_m: float,
    max_height_m: float,
    main_angle: float | None,
    scope_polygon,
    cfg: dict,
    output_dir: str | Path,
    force: bool = False,
) -> VisionLayoutResult:
    """Train/infer a compact Lane2Net-inspired BEV structural segmenter."""
    import torch
    from torch import nn
    from torch.nn import functional
    from torch.utils.data import DataLoader, Dataset

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    seed = int(cfg.get("seed", 23))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    features, target, feature_metrics = build_bev_features(
        session_points_ref,
        base_mask,
        origin,
        grid_m,
        height_bin_m,
        min_height_m,
        max_height_m,
        main_angle,
        cfg,
        scope_polygon,
    )
    patch_size = int(cfg.get("patch_size", 256))
    coordinates = _patch_coordinates(target, patch_size)
    validation_coordinates = [coord for index, coord in enumerate(coordinates) if index % 5 == 0]
    training_coordinates = [coord for index, coord in enumerate(coordinates) if index % 5 != 0]
    training_coordinates = training_coordinates or coordinates
    validation_coordinates = validation_coordinates or coordinates[:1]

    class TrainingDataset(Dataset):
        def __init__(self):
            self.samples = int(cfg.get("samples_per_epoch", 192))
            self.synthetic_fraction = float(cfg.get("synthetic_fraction", 0.40))

        def __len__(self):
            return self.samples

        def __getitem__(self, index):
            rng = np.random.default_rng(seed * 100003 + index * 7919)
            if rng.random() < self.synthetic_fraction:
                sample, expected = _synthetic_pair(patch_size, rng)
            else:
                top, left = training_coordinates[index % len(training_coordinates)]
                sample = _crop_pad(features, top, left, patch_size)
                expected = (_crop_pad(target, top, left, patch_size) > 0).astype(np.float32)
                sample = _corrupt_real(sample, rng)
            sample, expected = _augment_pair(sample, expected, rng)
            return torch.from_numpy(sample), torch.from_numpy(expected[None].astype(np.float32))

    Lane2StructureNet = _define_model(torch, nn, functional)
    base_channels = int(cfg.get("base_channels", 16))
    model = Lane2StructureNet(4, base_channels)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    parameter_count = int(sum(parameter.numel() for parameter in model.parameters()))
    checkpoint_path = output_dir / "lane2structure.pt"
    fingerprint = hashlib.sha256()
    fingerprint.update(b"lane2structure-v1")
    fingerprint.update(features.tobytes())
    fingerprint.update(target.tobytes())
    # CAD vectorization settings do not alter model weights. Restrict the
    # checkpoint key to feature/target construction and training settings so
    # changing skeleton simplification never triggers an unnecessary retrain.
    training_keys = {
        key: value
        for key, value in cfg.items()
        if not key.startswith("vector_") and key != "direct_vectorization_enabled"
    }
    fingerprint.update(json.dumps(training_keys, sort_keys=True, default=str).encode())
    digest = fingerprint.hexdigest()
    cache_hit = False
    history: list[dict] = []
    if checkpoint_path.is_file() and not force:
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        compatible_legacy = (
            checkpoint.get("fingerprint_version") is None
            and checkpoint.get("architecture") == "Lane2StructureNet-ResUNet-AttAugConv-DWConv"
        )
        if checkpoint.get("fingerprint") == digest or compatible_legacy:
            try:
                model.load_state_dict(checkpoint["state_dict"])
                history = checkpoint.get("history", [])
                cache_hit = True
                if checkpoint.get("fingerprint") != digest:
                    checkpoint["fingerprint"] = digest
                    checkpoint["fingerprint_version"] = 2
                    torch.save(checkpoint, checkpoint_path)
            except RuntimeError:
                cache_hit = False

    positive_fraction = max(1e-5, float(np.mean(target > 0)))
    positive_weight = torch.tensor(
        [min(12.0, max(2.0, (1.0 - positive_fraction) / positive_fraction))],
        dtype=torch.float32,
        device=device,
    )
    if not cache_hit:
        loader = DataLoader(
            TrainingDataset(),
            batch_size=int(cfg.get("batch_size", 6)),
            shuffle=True,
            num_workers=0,
            pin_memory=device.type == "cuda",
        )
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=float(cfg.get("learning_rate", 1e-3)),
            weight_decay=float(cfg.get("weight_decay", 1e-4)),
        )
        epochs = int(cfg.get("epochs", 14))
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, epochs))
        scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
        for epoch in range(epochs):
            model.train()
            losses = []
            for batch_features, batch_target in loader:
                batch_features = batch_features.to(device, non_blocking=True)
                batch_target = batch_target.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                with torch.amp.autocast(device_type=device.type, enabled=device.type == "cuda"):
                    logits = model(batch_features)
                    loss = _loss(functional, logits, batch_target, positive_weight)
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
                losses.append(float(loss.detach().cpu()))
            scheduler.step()
            history.append(
                {
                    "epoch": epoch + 1,
                    "loss": float(np.mean(losses)),
                    "learning_rate": float(optimizer.param_groups[0]["lr"]),
                }
            )
        torch.save(
            {
                "fingerprint": digest,
                "fingerprint_version": 2,
                "state_dict": model.state_dict(),
                "history": history,
                "architecture": "Lane2StructureNet-ResUNet-AttAugConv-DWConv",
            },
            checkpoint_path,
        )

    probability = _predict(
        torch,
        model,
        features,
        patch_size,
        int(cfg.get("inference_batch_size", 6)),
        device,
    )
    heat_weights = np.asarray(
        [
            float(cfg.get("vector_heatmap_probability_weight", 0.55)),
            float(cfg.get("vector_heatmap_density_weight", 0.20)),
            float(cfg.get("vector_heatmap_vertical_weight", 0.15)),
            float(cfg.get("vector_heatmap_recurrence_weight", 0.10)),
        ],
        dtype=np.float32,
    )
    heat_weights /= max(float(np.sum(heat_weights)), 1e-6)
    # The vectorizer needs more than a hard segmentation threshold.  Fuse the
    # network response with physical LiDAR evidence so a short, dense and
    # vertically continuous wall fragment receives more attention than an
    # equally short single-session scatter return.
    vector_heatmap = np.clip(
        heat_weights[0] * probability
        + heat_weights[1] * features[0]
        + heat_weights[2] * features[1]
        + heat_weights[3] * features[2],
        0.0,
        1.0,
    ).astype(np.float32)
    threshold_candidates = np.arange(
        float(cfg.get("threshold_min", 0.25)),
        float(cfg.get("threshold_max", 0.76)),
        float(cfg.get("threshold_step", 0.05)),
    )
    scores = [(float(value), *_threshold_score(probability, target, float(value))) for value in threshold_candidates]
    threshold, full_iou, full_f1 = max(scores, key=lambda row: (row[1], row[2]))
    prediction = np.where(probability >= threshold, 255, 0).astype(np.uint8)
    # Stable observations are survey evidence, not hallucinations.  Preserve
    # them while allowing the network to reject isolated raw-mask clutter.
    prediction = cv2.max(prediction, target)
    close_pixels = max(3, int(round(float(cfg.get("output_close_gap_m", 0.30)) / grid_m)) | 1)
    angle = main_angle or 0.0
    prediction = cv2.max(
        prediction,
        cv2.morphologyEx(prediction, cv2.MORPH_CLOSE, _line_kernel(close_pixels, angle)),
    )
    prediction = cv2.max(
        prediction,
        cv2.morphologyEx(prediction, cv2.MORPH_CLOSE, _line_kernel(close_pixels, angle + math.pi / 2)),
    )
    prediction = _remove_small_components(prediction, int(cfg.get("output_min_component_cells", 10)))
    scope = _scope_mask(
        prediction.shape,
        scope_polygon,
        origin,
        grid_m,
        float(cfg.get("scope_margin_m", 0.30)),
    )
    prediction = cv2.bitwise_and(prediction, scope)

    distance = cv2.distanceTransform(np.where(base_mask > 0, 0, 255).astype(np.uint8), cv2.DIST_L2, 5) * grid_m
    predicted_cells = prediction > 0
    evidence_precision = float(
        np.mean(distance[predicted_cells] <= float(cfg.get("evidence_distance_m", 0.25)))
    ) if np.any(predicted_cells) else 0.0
    predicted_count = int(np.count_nonzero(prediction))
    base_count = max(1, int(np.count_nonzero(base_mask)))
    prediction_ratio = predicted_count / base_count
    accepted = (
        full_iou >= float(cfg.get("min_pseudo_iou", 0.55))
        and evidence_precision >= float(cfg.get("min_evidence_precision", 0.65))
        and float(cfg.get("min_prediction_ratio", 0.20)) <= prediction_ratio <= float(cfg.get("max_prediction_ratio", 1.35))
    )
    final_mask = prediction if accepted else base_mask.copy()
    metrics = {
        **feature_metrics,
        "vision_layout_backend": "Lane2StructureNet",
        "vision_layout_architecture": "ResUNet+AttentionAugmentedBridge+DepthwiseSeparableConv",
        "vision_layout_accepted": bool(accepted),
        "vision_layout_cache_hit": bool(cache_hit),
        "vision_layout_device": str(device),
        "vision_layout_parameter_count": parameter_count,
        "vision_layout_epoch_count": len(history),
        "vision_layout_final_train_loss": history[-1]["loss"] if history else None,
        "vision_layout_threshold": float(threshold),
        "vision_layout_pseudo_iou": float(full_iou),
        "vision_layout_pseudo_f1": float(full_f1),
        "vision_layout_evidence_precision": evidence_precision,
        "vision_layout_prediction_ratio": float(prediction_ratio),
        "vision_layout_prediction_cells": predicted_count,
        "vision_layout_scatter_rejected_cells": int(np.count_nonzero((base_mask > 0) & (prediction == 0))),
        "vision_layout_gap_completed_cells": int(np.count_nonzero((prediction > 0) & (base_mask == 0))),
    }
    (output_dir / "training_history.json").write_text(
        json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output_dir / "metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    cv2.imwrite(str(output_dir / "pseudo_target.png"), target)
    cv2.imwrite(str(output_dir / "probability.png"), np.clip(probability * 255, 0, 255).astype(np.uint8))
    cv2.imwrite(
        str(output_dir / "vector_heatmap.png"),
        np.clip(vector_heatmap * 255, 0, 255).astype(np.uint8),
    )
    cv2.imwrite(str(output_dir / "prediction.png"), prediction)
    cv2.imwrite(str(output_dir / "accepted_mask.png"), final_mask)
    _write_preview(output_dir / "bev_model_comparison.png", features, target, probability, prediction)
    return VisionLayoutResult(final_mask, probability, vector_heatmap, target, metrics)
