from __future__ import annotations

import shlex
import subprocess
import re
from pathlib import Path
from typing import Sequence

import numpy as np
import yaml

from .calibration import CalibrationEstimate
from .errors import ExternalToolError


REPOSITORY_ROOT = Path(__file__).resolve().parent.parent


def ros_runtime_report(cfg: dict) -> dict:
    distribution = cfg["runtime"]["wsl_distribution"]
    ros_setup = cfg["runtime"]["ros_setup"]
    workspace = cfg["runtime"]["workspace"]
    workspace_expression = f'"${{HOME}}/{workspace[2:]}"' if workspace.startswith("~/") else shlex.quote(workspace)
    command = f"""
if [[ -f {shlex.quote(ros_setup)} ]]; then echo ros_setup=ok; else echo ros_setup=missing; fi
if [[ -f {workspace_expression}/devel/setup.bash ]]; then echo workspace_build=ok; else echo workspace_build=missing; fi
if [[ -f {shlex.quote(ros_setup)} ]]; then source {shlex.quote(ros_setup)}; fi
if [[ -f {workspace_expression}/devel/setup.bash ]]; then source {workspace_expression}/devel/setup.bash; fi
rospack find lio_sam >/dev/null 2>&1 && echo lio_sam=ok || echo lio_sam=missing
rospack find lidar_imu_init >/dev/null 2>&1 && echo li_init=ok || echo li_init=missing
rospack find livox_ros_driver >/dev/null 2>&1 && echo livox_ros_driver=ok || echo livox_ros_driver=missing
ldconfig -p 2>/dev/null | grep -q libgtsam && echo gtsam=ok || echo gtsam=missing
ldconfig -p 2>/dev/null | grep -q libceres && echo ceres=ok || echo ceres=missing
"""
    process = subprocess.run(
        ["wsl", "-d", distribution, "--", "bash", "-lc", command],
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    checks = {}
    for line in process.stdout.splitlines():
        if "=" in line:
            key, value = line.strip().split("=", 1)
            checks[key] = value
    required = ("ros_setup", "workspace_build", "lio_sam", "li_init", "livox_ros_driver", "gtsam", "ceres")
    clean_stderr = "\n".join(line for line in process.stderr.splitlines() if "\x00" not in line)
    return {
        "wsl_distribution": distribution,
        "workspace": workspace,
        "checks": checks,
        "ready": process.returncode == 0 and all(checks.get(key) == "ok" for key in required),
        "stderr": clean_stderr.strip().encode("ascii", "backslashreplace").decode("ascii"),
    }


def require_ros_runtime(cfg: dict) -> dict:
    report = ros_runtime_report(cfg)
    if not report["ready"]:
        missing = [key for key, value in report["checks"].items() if value != "ok"]
        raise ExternalToolError(
            "WSL ROS runtime is not ready; missing: "
            + ", ".join(missing or ["unknown components"])
            + ". Follow docs/ROS_SETUP.md and run scripts/bootstrap_ros.sh."
        )
    return report


def windows_to_wsl(path: str | Path, distribution: str) -> str:
    value = str(Path(path).resolve())
    # Passing a Windows path containing backslashes through wsl.exe is not
    # reliable on every WSL release: some builds consume the backslashes as
    # command-line escapes before wslpath sees them.  Drive-mounted paths have
    # a deterministic representation, so convert them without another shell.
    drive_path = re.match(r"^([A-Za-z]):[\\/](.*)$", value)
    if drive_path:
        drive = drive_path.group(1).lower()
        suffix = drive_path.group(2).replace("\\", "/")
        return f"/mnt/{drive}/{suffix}"
    process = subprocess.run(
        ["wsl", "-d", distribution, "--", "wslpath", "-a", value],
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if process.returncode:
        raise ExternalToolError(f"wslpath failed for {value}: {process.stderr.strip()}")
    return process.stdout.strip()


def run_wsl_script(script: Path, arguments: Sequence[str], cfg: dict, log_path: Path) -> None:
    distribution = cfg["runtime"]["wsl_distribution"]
    script_wsl = windows_to_wsl(script, distribution)
    command = " ".join(["bash", shlex.quote(script_wsl), *[shlex.quote(str(value)) for value in arguments]])
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.run(
            ["wsl", "-d", distribution, "--", "bash", "-lc", command],
            text=True,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if process.returncode:
        raise ExternalToolError(f"External ROS stage failed ({process.returncode}). See {log_path}")


def write_li_init_config(path: str | Path, cfg: dict) -> None:
    calibration = cfg["calibration"]
    inputs = cfg["inputs"]
    value = {
        "common": {"lid_topic": inputs["point_topic"], "imu_topic": inputs["imu_topic"]},
        "preprocess": {"lidar_type": 2, "scan_line": 16, "blind": 0.5, "feature_extract_en": False},
        "initialization": {
            "cut_frame_num": int(calibration["cut_frame_num"]),
            "orig_odom_freq": float(calibration["lidar_rate_hz"]),
            "mean_acc_norm": float(cfg["slam"].get("imu_gravity", 9.80511)),
            "online_refine_time": float(calibration["refine_seconds"]),
            "data_accum_length": 800,
            "Rot_LI_cov": [0.00005] * 3,
            "Trans_LI_cov": [0.0001] * 3,
        },
        "mapping": {
            "filter_size_surf": float(calibration["lidar_voxel_m"]),
            "filter_size_map": float(calibration["map_voxel_m"]),
            "gyr_cov": 0.5,
            "acc_cov": 0.5,
            "b_acc_cov": 0.0001,
            "b_gyr_cov": 0.0001,
            "det_range": 100.0,
        },
        "publish": {"path_en": True, "scan_publish_en": True, "dense_publish_en": False, "scan_bodyframe_pub_en": True},
        "pcd_save": {"pcd_save_en": False, "interval": -1},
    }
    Path(path).write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")


def write_lio_sam_config(path: str | Path, cfg: dict, calibration: CalibrationEstimate, run_name: str) -> None:
    slam = cfg["slam"]
    inputs = cfg["inputs"]
    rotation = calibration.rotation_imu_from_lidar.reshape(-1).tolist()
    value = {
        "lio_sam": {
            "pointCloudTopic": inputs["point_topic"].lstrip("/"),
            "imuTopic": "imu_corrected" if abs(calibration.imu_stamp_correction_sec) > 1e-9 else inputs["imu_topic"].lstrip("/"),
            "odomTopic": "odometry/imu",
            "gpsTopic": "odometry/gps_unused",
            "lidarFrame": "base_link",
            "baselinkFrame": "base_link",
            "odometryFrame": "odom",
            "mapFrame": "map",
            "useImuHeadingInitialization": False,
            "useGpsElevation": False,
            "gpsCovThreshold": 2.0,
            "poseCovThreshold": 25.0,
            "savePCD": True,
            "savePCDDirectory": f"/lidar2outline_lio/{run_name}/",
            "sensor": slam["sensor"],
            "N_SCAN": int(slam["n_scan"]),
            "Horizon_SCAN": int(slam["horizon_scan"]),
            "downsampleRate": 1,
            "lidarMinRange": float(slam["lidar_min_range"]),
            "lidarMaxRange": float(slam["lidar_max_range"]),
            "imuAccNoise": float(slam.get("imu_acc_noise", 0.01)),
            "imuGyrNoise": float(slam.get("imu_gyr_noise", 0.001)),
            "imuAccBiasN": float(slam.get("imu_acc_bias_n", 0.0004)),
            "imuGyrBiasN": float(slam.get("imu_gyr_bias_n", 0.00004)),
            "imuGravity": float(slam.get("imu_gravity", 9.80511)),
            "imuRPYWeight": float(slam.get("imu_rpy_weight", 0.01)),
            "extrinsicTrans": calibration.translation_imu_from_lidar.tolist(),
            "extrinsicRot": rotation,
            "extrinsicRPY": rotation,
            "edgeThreshold": 1.0,
            "surfThreshold": 0.1,
            "edgeFeatureMinValidNum": 10,
            "surfFeatureMinValidNum": 100,
            "odometrySurfLeafSize": float(slam["odometry_surface_leaf"]),
            "mappingCornerLeafSize": float(slam["mapping_corner_leaf"]),
            "mappingSurfLeafSize": float(slam["mapping_surface_leaf"]),
            "z_tollerance": 1000.0,
            "rotation_tollerance": 1000.0,
            "numberOfCores": int(slam.get("cores", 4)),
            "mappingProcessInterval": 0.15,
            "surroundingkeyframeAddingDistThreshold": 1.0,
            "surroundingkeyframeAddingAngleThreshold": 0.2,
            "surroundingKeyframeDensity": 2.0,
            "surroundingKeyframeSearchRadius": 50.0,
            "loopClosureEnableFlag": bool(slam["loop_closure"]),
            "loopClosureFrequency": 1.0,
            "surroundingKeyframeSize": 50,
            "historyKeyframeSearchRadius": 15.0,
            "historyKeyframeSearchTimeDiff": 30.0,
            "historyKeyframeSearchNum": 25,
            "historyKeyframeFitnessScore": 0.3,
            "globalMapVisualizationSearchRadius": 1000.0,
            "globalMapVisualizationPoseDensity": 10.0,
            "globalMapVisualizationLeafSize": 1.0,
        }
    }
    Path(path).write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")


def run_li_init(bag: str | Path, output_result: str | Path, generated_config: str | Path, cfg: dict, log_path: Path) -> None:
    distribution = cfg["runtime"]["wsl_distribution"]
    args = [
        cfg["runtime"]["ros_setup"],
        cfg["runtime"]["workspace"],
        windows_to_wsl(bag, distribution),
        windows_to_wsl(generated_config, distribution),
        windows_to_wsl(output_result, distribution),
        str(cfg["runtime"].get("playback_rate", 1.0)),
    ]
    run_wsl_script(REPOSITORY_ROOT / "scripts" / "run_li_init.sh", args, cfg, log_path)


def run_lio_sam(
    bag: str | Path,
    output_dir: str | Path,
    generated_config: str | Path,
    calibration: CalibrationEstimate,
    cfg: dict,
    log_path: Path,
    duration_sec: float | None = None,
) -> None:
    distribution = cfg["runtime"]["wsl_distribution"]
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    args = [
        cfg["runtime"]["ros_setup"],
        cfg["runtime"]["workspace"],
        windows_to_wsl(bag, distribution),
        windows_to_wsl(generated_config, distribution),
        windows_to_wsl(output_dir, distribution),
        str(cfg["runtime"].get("playback_rate", 1.0)),
        str(calibration.imu_stamp_correction_sec),
        cfg["inputs"]["imu_topic"],
        str(duration_sec or 0.0),
        windows_to_wsl(REPOSITORY_ROOT, distribution),
    ]
    run_wsl_script(REPOSITORY_ROOT / "scripts" / "run_lio_sam.sh", args, cfg, log_path)
