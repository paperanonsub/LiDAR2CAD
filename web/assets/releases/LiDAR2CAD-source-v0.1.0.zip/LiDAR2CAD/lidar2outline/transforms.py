from __future__ import annotations

import math
from typing import Iterable

import numpy as np
from scipy.spatial.transform import Rotation


def transform_points(points: np.ndarray, transform: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=float)
    transform = np.asarray(transform, dtype=float)
    return points @ transform[:3, :3].T + transform[:3, 3]


def invert_transform(transform: np.ndarray) -> np.ndarray:
    transform = np.asarray(transform, dtype=float)
    result = np.eye(4)
    result[:3, :3] = transform[:3, :3].T
    result[:3, 3] = -result[:3, :3] @ transform[:3, 3]
    return result


def se2_matrix(yaw: float, x: float, y: float, z: float = 0.0) -> np.ndarray:
    c, s = math.cos(yaw), math.sin(yaw)
    result = np.eye(4)
    result[:3, :3] = [[c, -s, 0], [s, c, 0], [0, 0, 1]]
    result[:3, 3] = [x, y, z]
    return result


def rotation_angle_deg(a: np.ndarray, b: np.ndarray) -> float:
    relative = Rotation.from_matrix(np.asarray(a) @ np.asarray(b).T)
    return float(np.degrees(relative.magnitude()))


def average_rotations(matrices: Iterable[np.ndarray]) -> np.ndarray:
    rotations = Rotation.from_matrix(np.asarray(list(matrices), dtype=float))
    return rotations.mean().as_matrix()


def matrix_json(matrix: np.ndarray) -> list[list[float]]:
    return np.asarray(matrix, dtype=float).tolist()


def validate_rigid(transform: np.ndarray, atol: float = 1e-6) -> None:
    transform = np.asarray(transform, dtype=float)
    if transform.shape != (4, 4):
        raise ValueError("Transform must be 4x4")
    if not np.allclose(transform[3], [0, 0, 0, 1], atol=atol):
        raise ValueError("Invalid homogeneous transform bottom row")
    rotation = transform[:3, :3]
    if not np.allclose(rotation.T @ rotation, np.eye(3), atol=atol) or np.linalg.det(rotation) < 0:
        raise ValueError("Transform rotation is not a proper orthonormal matrix")

