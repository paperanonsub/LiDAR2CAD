from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .config import load_config, validate_config
from .errors import PipelineError
from .export import export_osm
from .external import ros_runtime_report
from .pipeline import (
    inspect_inputs,
    run_height_slices_from_cached,
    run_pipeline,
    vectorize_pcds,
)
from .semantic_learning import (
    extract_sonata_object_embeddings,
    merge_joint_wall_manifests,
    train_semantic_head,
)
from .semantic_label_ui import run_semantic_label_ui
from .semantic_wall_label_ui import (
    derive_wall_object_labels_from_regions,
    extract_wall_edges_from_regions,
    run_semantic_wall_label_ui,
)
from .semantic_objects import extend_semantic_review_batch, prepare_semantic_label_manifest
from .semantic_v14 import extract_joint_features, prepare_joint_supervision


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="lidar2outline", description="Indoor ROS1 bag to structural CAD outline")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run = subparsers.add_parser("run", help="Run inspection, calibration, SLAM, fusion, vectorization and export")
    run.add_argument("--config", required=True)
    run.add_argument("--force", action="store_true")

    inspect = subparsers.add_parser("inspect-bag", help="Inspect all bags in the configuration")
    inspect.add_argument("--config", required=True)
    inspect.add_argument("--force", action="store_true")

    doctor = subparsers.add_parser("doctor", help="Check WSL, ROS and native Python runtime prerequisites")
    doctor.add_argument("--config", required=True)

    vectorize = subparsers.add_parser("vectorize", help="Fuse and vectorize existing PCD maps")
    vectorize.add_argument("--config", required=True)
    vectorize.add_argument("--pcd", nargs="+", required=True)
    vectorize.add_argument("--force", action="store_true")

    height_slices = subparsers.add_parser(
        "height-slices",
        help="Rebuild height-aware DXFs from cached SLAM maps and transforms",
    )
    height_slices.add_argument("--config", required=True)
    height_slices.add_argument("--output", required=True)
    height_slices.add_argument(
        "--reuse-from",
        help="Reuse compatible cleaned point clouds and height metadata from an earlier height-slice run",
    )
    height_slices.add_argument("--force", action="store_true")

    labels = subparsers.add_parser(
        "semantic-labels",
        help="Copy and validate a V13 object candidate manifest for human review",
    )
    labels.add_argument("--config", required=True)
    labels.add_argument("--source", required=True, help="V13 height_slices directory")
    labels.add_argument("--output", required=True, help="Editable label JSON")
    labels.add_argument(
        "--extract-sonata",
        action="store_true",
        help="Attach frozen Sonata/PTv3 object embeddings (requires optional CUDA environment)",
    )
    labels.add_argument(
        "--extend-review-by",
        type=int,
        default=0,
        help="Promote an additional feature-diverse batch for manual review",
    )

    label_ui = subparsers.add_parser(
        "semantic-label-ui",
        help="Open the local V13 wall/column/non-building review interface",
    )
    label_ui.add_argument("--config", required=True)
    label_ui.add_argument("--source", required=True, help="V13 height_slices directory")
    label_ui.add_argument("--labels", required=True, help="Editable label JSON")
    label_ui.add_argument("--host", default="127.0.0.1")
    label_ui.add_argument("--port", type=int, default=8765)
    label_ui.add_argument("--no-browser", action="store_true")
    label_ui.add_argument("--extend-review-by", type=int, default=0)

    wall_label_ui = subparsers.add_parser(
        "semantic-wall-label-ui",
        help="Trace multiple wall polylines on a full-map LiDAR projection",
    )
    wall_label_ui.add_argument("--config", required=True)
    wall_label_ui.add_argument("--source", required=True, help="V13 height_slices directory")
    wall_label_ui.add_argument("--labels", required=True, help="Editable wall polyline JSON")
    wall_label_ui.add_argument("--host", default="127.0.0.1")
    wall_label_ui.add_argument("--port", type=int, default=8770)
    wall_label_ui.add_argument("--no-browser", action="store_true")

    wall_extract = subparsers.add_parser(
        "semantic-wall-extract",
        help="Extract persistent point-cloud wall evidence inside reviewed wall ROIs",
    )
    wall_extract.add_argument("--config", required=True)
    wall_extract.add_argument("--source", required=True, help="V13 height_slices directory")
    wall_extract.add_argument("--labels", required=True, help="Reviewed wall-regions-v1 JSON")
    wall_extract.add_argument("--output", required=True)
    wall_extract.add_argument("--semantic-labels", help="Existing object label manifest to augment")
    wall_extract.add_argument("--derived-labels", help="Write derived labels here; never overwrites manual labels")

    train_semantics = subparsers.add_parser(
        "train-semantics",
        help="Train the reviewed V13 wall/column/non-building classifier head",
    )
    train_semantics.add_argument("--config", required=True)
    train_semantics.add_argument("--labels", required=True)
    train_semantics.add_argument("--output", required=True)

    merge_semantics = subparsers.add_parser(
        "merge-wall-labels",
        help="Merge completed full-map wall ROI labels into one joint binary manifest",
    )
    merge_semantics.add_argument("--config", required=True)
    merge_semantics.add_argument("--labels", nargs="+", required=True)
    merge_semantics.add_argument("--output", required=True)

    supervision = subparsers.add_parser(
        "semantic-supervision",
        help="Build V14 wall/column point supervision from reviewed regions",
    )
    supervision.add_argument("--config", required=True)
    supervision.add_argument("--output", required=True)

    features = subparsers.add_parser(
        "semantic-features",
        help="Extract V14 frozen point features; Sonata failures never fall back silently",
    )
    features.add_argument("--config", required=True)
    features.add_argument("--manifest", required=True)
    features.add_argument("--output", required=True)
    features.add_argument(
        "--geometry-only",
        action="store_true",
        help="Prepare the auditable geometry baseline instead of invoking Sonata",
    )

    osm = subparsers.add_parser("export-osm", help="Georeference local GeoJSON and write OSM XML")
    osm.add_argument("--geojson", required=True)
    osm.add_argument("--lat", required=True, type=float)
    osm.add_argument("--lon", required=True, type=float)
    osm.add_argument("--yaw-deg", required=True, type=float)
    osm.add_argument("--output", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "export-osm":
            export_osm(args.geojson, args.output, args.lat, args.lon, args.yaw_deg)
            print(f"Wrote {Path(args.output).resolve()}")
            return 0
        cfg = load_config(args.config)
        validate_config(
            cfg,
            require_bags=args.command not in (
                "vectorize", "doctor", "height-slices", "semantic-labels", "semantic-label-ui", "semantic-wall-label-ui", "semantic-wall-extract", "train-semantics", "merge-wall-labels", "semantic-supervision", "semantic-features"
            ),
        )
        if args.command == "doctor":
            report = ros_runtime_report(cfg)
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0 if report["ready"] else 2
        if args.command == "inspect-bag":
            report = inspect_inputs(cfg, args.force)
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0 if report["valid"] else 2
        if args.command == "semantic-labels":
            height_cfg = cfg.get("height_slices", {})
            report = prepare_semantic_label_manifest(
                args.source,
                args.output,
                dataset_id=height_cfg.get("semantic_dataset_id"),
                dataset_role=height_cfg.get("semantic_dataset_role"),
            )
            if args.extend_review_by > 0:
                report["extended_review"] = extend_semantic_review_batch(
                    args.output, args.extend_review_by
                )
            if args.extract_sonata:
                report["sonata_features"] = extract_sonata_object_embeddings(
                    args.output, args.source, cfg.get("height_slices", {})
                )
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0
        if args.command == "semantic-label-ui":
            run_semantic_label_ui(
                args.source,
                args.labels,
                host=args.host,
                port=args.port,
                open_browser=not args.no_browser,
                cfg=cfg.get("height_slices", {}),
                extend_review_by=args.extend_review_by,
            )
            return 0
        if args.command == "semantic-wall-label-ui":
            height_cfg = cfg.get("height_slices", {})
            run_semantic_wall_label_ui(
                args.source,
                args.labels,
                dataset_id=str(
                    height_cfg.get("semantic_dataset_id", Path(args.source).parent.name)
                ),
                host=args.host,
                port=args.port,
                open_browser=not args.no_browser,
            )
            return 0
        if args.command == "semantic-wall-extract":
            report = extract_wall_edges_from_regions(args.source, args.labels, args.output)
            if args.semantic_labels:
                if not args.derived_labels:
                    raise ValueError("--derived-labels is required with --semantic-labels")
                report["object_labels"] = derive_wall_object_labels_from_regions(
                    args.source, args.output, args.semantic_labels, args.derived_labels
                )
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0
        if args.command == "train-semantics":
            label_manifest = json.loads(Path(args.labels).read_text(encoding="utf-8"))
            training_cfg = (
                cfg
                if label_manifest.get("training_task") == "wall_column_point_joint_v14"
                else cfg.get("height_slices", {})
            )
            report = train_semantic_head(
                args.labels, args.output, training_cfg
            )
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0 if report.get("automatic_filtering_enabled", False) or report.get("model_trained", False) else 3
        if args.command == "merge-wall-labels":
            report = merge_joint_wall_manifests(args.labels, args.output)
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0
        if args.command == "semantic-supervision":
            report = prepare_joint_supervision(cfg, args.output)
            print(json.dumps({key: value for key, value in report.items() if key != "scenes"}, ensure_ascii=False, indent=2))
            return 0
        if args.command == "semantic-features":
            report = extract_joint_features(
                args.manifest, args.output, cfg, geometry_only=args.geometry_only
            )
            print(json.dumps({key: value for key, value in report.items() if key != "scenes"}, ensure_ascii=False, indent=2))
            return 0
        if args.command == "vectorize":
            report = vectorize_pcds(cfg, args.pcd, args.force)
        elif args.command == "height-slices":
            report = run_height_slices_from_cached(
                cfg, args.output, args.force, reuse_from=args.reuse_from
            )
        else:
            report = run_pipeline(cfg, args.force)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report.get("acceptance_passed", True) else 3
    except (PipelineError, OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
