from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import cv2
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString
from shapely.ops import linemerge, unary_union

from .raster_vectorize import vectorize_structure_mask


@dataclass
class PostFusionResult:
    """Regularized geometry produced after all height DXFs have been fused.

    ``observed`` is a straightened representation of the measured maximum
    union.  ``gap_inferred`` and ``corner_inferred`` are deliberately kept
    separate: morphology and reverse extension may suggest a connection, but
    neither is allowed to become part of the strict observed set.
    """

    observed: list[LineString]
    gap_inferred: list[dict[str, Any]]
    corner_inferred: list[dict[str, Any]]
    metrics: dict[str, Any]


@dataclass
class MorphologyRevectorResult:
    lines: list[LineString]
    input_mask: np.ndarray
    dilated_mask: np.ndarray
    closed_mask: np.ndarray
    skeleton: np.ndarray
    origin: np.ndarray
    grid_m: float
    metrics: dict[str, Any]


def _linear_parts(geometry: Any) -> list[LineString]:
    if geometry is None or geometry.is_empty:
        return []
    if geometry.geom_type in {"LineString", "LinearRing"}:
        return [LineString(geometry.coords)]
    result: list[LineString] = []
    for value in getattr(geometry, "geoms", []):
        result.extend(_linear_parts(value))
    return result


def _physical_lines(lines: list[LineString]) -> list[LineString]:
    if not lines:
        return []
    geometry = unary_union(lines)
    try:
        geometry = linemerge(geometry)
    except ValueError:
        pass
    return [value for value in _linear_parts(geometry) if value.length > 1e-6]


def _sample_lines(lines: list[LineString], step_m: float) -> np.ndarray:
    samples = []
    for line in lines:
        count = max(2, int(math.ceil(line.length / max(step_m, 1e-3))) + 1)
        samples.extend(
            line.interpolate(value, normalized=True).coords[0]
            for value in np.linspace(0.0, 1.0, count)
        )
    return np.asarray(samples, dtype=float) if samples else np.empty((0, 2), dtype=float)


def _atomic_segments(lines: list[LineString], minimum_m: float) -> list[LineString]:
    result: list[LineString] = []
    for line in _physical_lines(lines):
        coordinates = np.asarray(line.coords, dtype=float)
        for start, end in zip(coordinates[:-1], coordinates[1:]):
            value = LineString([start, end])
            if value.length >= minimum_m:
                result.append(value)
    return result


def _canonical_axis(line: LineString) -> tuple[np.ndarray, np.ndarray, float, float]:
    coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
    direction = coordinates[1] - coordinates[0]
    length = float(np.linalg.norm(direction))
    direction /= max(length, 1e-12)
    if direction[0] < 0.0 or (
        abs(float(direction[0])) <= 1e-12 and direction[1] < 0.0
    ):
        direction *= -1.0
    angle = float(math.atan2(direction[1], direction[0]) % math.pi)
    normal = np.asarray([-direction[1], direction[0]], dtype=float)
    offset = float(np.mean(coordinates @ normal))
    return direction, normal, offset, angle


def _angle_difference(first: float, second: float) -> float:
    difference = abs(first - second) % math.pi
    return min(difference, math.pi - difference)


def _interval_gap(first: tuple[float, float], second: tuple[float, float]) -> float:
    return max(0.0, max(first[0], second[0]) - min(first[1], second[1]))


def _weighted_orientation(angles: list[float], weights: list[float]) -> float:
    sine = float(np.sum(np.sin(2.0 * np.asarray(angles)) * np.asarray(weights)))
    cosine = float(np.sum(np.cos(2.0 * np.asarray(angles)) * np.asarray(weights)))
    return float((0.5 * math.atan2(sine, cosine)) % math.pi)


def _orientation_modes(clusters: list[dict], cfg: dict) -> list[float]:
    tolerance = math.radians(float(cfg.get("post_fusion_direction_mode_deg", 1.5)))
    minimum_length = float(cfg.get("post_fusion_direction_mode_min_length_m", 3.0))
    modes: list[dict[str, Any]] = []
    for value in sorted(clusters, key=lambda item: item["length"], reverse=True):
        selected = None
        for mode in modes:
            if _angle_difference(value["angle"], mode["angle"]) <= tolerance:
                selected = mode
                break
        if selected is None:
            selected = {"angles": [], "weights": [], "angle": value["angle"]}
            modes.append(selected)
        selected["angles"].append(value["angle"])
        selected["weights"].append(value["length"])
        selected["angle"] = _weighted_orientation(
            selected["angles"], selected["weights"]
        )
    return [
        value["angle"]
        for value in modes
        if float(sum(value["weights"])) >= minimum_length
        and len(value["weights"]) >= 2
    ]


def _dominant_line_angles(lines: list[LineString], cfg: dict) -> list[float]:
    tolerance = math.radians(
        float(cfg.get("post_fusion_reextract_direction_cluster_deg", 3.0))
    )
    minimum_length = float(
        cfg.get("post_fusion_reextract_direction_min_length_m", 2.0)
    )
    maximum_count = int(cfg.get("post_fusion_reextract_direction_count", 8))
    modes: list[dict[str, Any]] = []
    for line in _atomic_segments(lines, 1e-6):
        _, _, _, angle = _canonical_axis(line)
        length = float(line.length)
        selected = None
        for mode in modes:
            if _angle_difference(angle, mode["angle"]) <= tolerance:
                selected = mode
                break
        if selected is None:
            selected = {"angles": [], "weights": [], "angle": angle}
            modes.append(selected)
        selected["angles"].append(angle)
        selected["weights"].append(length)
        selected["angle"] = _weighted_orientation(
            selected["angles"], selected["weights"]
        )
    retained = [
        value
        for value in modes
        if float(sum(value["weights"])) >= minimum_length
    ]
    retained.sort(key=lambda value: float(sum(value["weights"])), reverse=True)
    return [float(value["angle"]) for value in retained[:maximum_count]]


def _line_kernel(length: int, angle: float) -> np.ndarray:
    length = max(3, int(length) | 1)
    kernel = np.zeros((length, length), dtype=np.uint8)
    center = (length - 1) / 2.0
    delta = center * np.asarray([math.cos(angle), math.sin(angle)], dtype=float)
    cv2.line(
        kernel,
        tuple(np.rint(np.asarray([center, center]) - delta).astype(int)),
        tuple(np.rint(np.asarray([center, center]) + delta).astype(int)),
        1,
        1,
    )
    return kernel


def _regularize_axes(
    lines: list[LineString], cfg: dict
) -> tuple[list[LineString], list[dict[str, Any]], dict[str, Any]]:
    """Fit shared straight axes before any inferred connection is added."""
    minimum_m = float(cfg.get("post_fusion_min_segment_m", 0.05))
    # ``minimum_m`` is a scoring scale, not a deletion threshold. Tiny noded
    # atoms often sit exactly at a valid T/L junction; dropping them before
    # fitting destroys the topology and can remove tens of metres in aggregate.
    segments = _atomic_segments(lines, 1e-6)
    angle_limit = math.radians(float(cfg.get("post_fusion_axis_angle_deg", 2.0)))
    offset_limit = float(cfg.get("post_fusion_axis_offset_m", 0.06))
    candidate_gap = float(cfg.get("post_fusion_axis_candidate_gap_m", 0.35))
    clusters: list[dict[str, Any]] = []

    # Long, well-supported pieces seed axes; short fragments can join but may
    # not move an established wall disproportionately.
    for line in sorted(segments, key=lambda value: value.length, reverse=True):
        direction, normal, offset, angle = _canonical_axis(line)
        coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
        best = None
        best_cost = float("inf")
        for cluster in clusters:
            angular = _angle_difference(angle, cluster["angle"])
            if angular > angle_limit:
                continue
            lateral = float(
                np.max(np.abs(coordinates @ cluster["normal"] - cluster["offset"]))
            )
            if lateral > offset_limit:
                continue
            interval = tuple(sorted(map(float, coordinates @ cluster["direction"])))
            gap = min(
                _interval_gap(interval, existing)
                for existing in cluster["intervals"]
            )
            if gap > candidate_gap:
                continue
            cost = angular / max(angle_limit, 1e-9) + lateral / max(offset_limit, 1e-9)
            if cost < best_cost:
                best_cost = cost
                best = (cluster, interval)
        if best is None:
            interval = tuple(sorted(map(float, coordinates @ direction)))
            clusters.append(
                {
                    "members": [line],
                    "angles": [angle],
                    "weights": [float(line.length)],
                    "direction": direction,
                    "normal": normal,
                    "offset": offset,
                    "angle": angle,
                    "intervals": [interval],
                    "length": float(line.length),
                }
            )
            continue
        cluster, _ = best
        cluster["members"].append(line)
        cluster["angles"].append(angle)
        cluster["weights"].append(float(line.length))
        cluster["length"] += float(line.length)
        cluster["angle"] = _weighted_orientation(
            cluster["angles"], cluster["weights"]
        )
        cluster["direction"] = np.asarray(
            [math.cos(cluster["angle"]), math.sin(cluster["angle"])], dtype=float
        )
        cluster["normal"] = np.asarray(
            [-cluster["direction"][1], cluster["direction"][0]], dtype=float
        )
        endpoints = np.vstack(
            [np.asarray(value.coords, dtype=float)[[0, -1]] for value in cluster["members"]]
        )
        member_weights = np.repeat(np.asarray(cluster["weights"], dtype=float), 2)
        offsets = endpoints @ cluster["normal"]
        order = np.argsort(offsets)
        cumulative = np.cumsum(member_weights[order])
        cluster["offset"] = float(
            offsets[order[np.searchsorted(cumulative, cumulative[-1] * 0.5)]]
        )
        cluster["intervals"] = [
            tuple(
                sorted(
                    map(
                        float,
                        np.asarray(value.coords, dtype=float)[[0, -1]]
                        @ cluster["direction"],
                    )
                )
            )
            for value in cluster["members"]
        ]

    modes = _orientation_modes(clusters, cfg)
    mode_tolerance = math.radians(
        float(cfg.get("post_fusion_direction_mode_snap_deg", 1.25))
    )
    for cluster in clusters:
        if modes:
            selected = min(modes, key=lambda value: _angle_difference(cluster["angle"], value))
            if _angle_difference(cluster["angle"], selected) <= mode_tolerance:
                cluster["angle"] = selected
        cluster["direction"] = np.asarray(
            [math.cos(cluster["angle"]), math.sin(cluster["angle"])], dtype=float
        )
        cluster["normal"] = np.asarray(
            [-cluster["direction"][1], cluster["direction"][0]], dtype=float
        )
        endpoints = np.vstack(
            [np.asarray(value.coords, dtype=float)[[0, -1]] for value in cluster["members"]]
        )
        offsets = endpoints @ cluster["normal"]
        cluster["offset"] = float(np.median(offsets))
        cluster["intervals"] = sorted(
            [
                tuple(
                    sorted(
                        map(
                            float,
                            np.asarray(value.coords, dtype=float)[[0, -1]]
                            @ cluster["direction"],
                        )
                    )
                )
                for value in cluster["members"]
            ]
        )

    # Preserve the topology that existed before fitting. Every original node
    # is moved once, to the intersection of its incident fitted axes. Rebuilding
    # intervals independently would create hundreds of artificial endpoints.
    member_axis: dict[int, int] = {}
    for axis_index, cluster in enumerate(clusters):
        for member in cluster["members"]:
            member_axis[id(member)] = axis_index
    node_incidents: dict[tuple[int, int], dict[str, Any]] = {}
    endpoint_keys: dict[tuple[int, int], tuple[int, int]] = {}
    for member in segments:
        axis_index = member_axis[id(member)]
        for endpoint_index, point in enumerate(
            np.asarray(member.coords, dtype=float)[[0, -1]]
        ):
            key = tuple(np.rint(point * 1000.0).astype(int))
            endpoint_keys[(id(member), endpoint_index)] = key
            record = node_incidents.setdefault(
                key, {"point": np.asarray(point, dtype=float), "axes": []}
            )
            record["axes"].append(axis_index)

    maximum_node_shift = float(cfg.get("post_fusion_node_max_shift_m", 0.10))
    fitted_nodes: dict[tuple[int, int], np.ndarray] = {}
    fitted_intersection_count = 0
    for key, record in node_incidents.items():
        point = record["point"]
        axis_indices = list(dict.fromkeys(record["axes"]))
        selected_pair = None
        selected_cross = 0.0
        for position, first_index in enumerate(axis_indices):
            for second_index in axis_indices[position + 1 :]:
                first_direction = clusters[first_index]["direction"]
                second_direction = clusters[second_index]["direction"]
                cross = abs(
                    float(
                        first_direction[0] * second_direction[1]
                        - first_direction[1] * second_direction[0]
                    )
                )
                if cross > selected_cross:
                    selected_cross = cross
                    selected_pair = (first_index, second_index)
        fitted = None
        if selected_pair is not None and selected_cross >= math.sin(math.radians(10.0)):
            first = clusters[selected_pair[0]]
            second = clusters[selected_pair[1]]
            matrix = np.vstack([first["normal"], second["normal"]])
            try:
                candidate = np.linalg.solve(
                    matrix, np.asarray([first["offset"], second["offset"]])
                )
            except np.linalg.LinAlgError:
                candidate = None
            if candidate is not None and np.linalg.norm(candidate - point) <= maximum_node_shift:
                fitted = candidate
                fitted_intersection_count += 1
        if fitted is None:
            projected = []
            for axis_index in axis_indices:
                cluster = clusters[axis_index]
                projected.append(
                    point
                    + (
                        cluster["offset"]
                        - float(point @ cluster["normal"])
                    )
                    * cluster["normal"]
                )
            fitted = np.mean(projected, axis=0) if projected else point
            if np.linalg.norm(fitted - point) > maximum_node_shift:
                fitted = point
        fitted_nodes[key] = np.asarray(fitted, dtype=float)

    reconstructed: list[LineString] = []
    intervals_by_axis: dict[int, list[tuple[float, float]]] = {
        index: [] for index in range(len(clusters))
    }
    for member in segments:
        start = fitted_nodes[endpoint_keys[(id(member), 0)]]
        end = fitted_nodes[endpoint_keys[(id(member), 1)]]
        if np.linalg.norm(end - start) < 1e-6:
            continue
        line = LineString([start, end])
        reconstructed.append(line)
        axis_index = member_axis[id(member)]
        direction = clusters[axis_index]["direction"]
        intervals_by_axis[axis_index].append(
            tuple(sorted(map(float, np.asarray([start, end]) @ direction)))
        )
    observed = _physical_lines(reconstructed)
    simplify_tolerance = float(cfg.get("post_fusion_path_simplify_m", 0.03))
    vertices_before = int(sum(len(value.coords) for value in observed))
    if simplify_tolerance > 0.0:
        simplified = [
            LineString(value.simplify(simplify_tolerance, preserve_topology=False).coords)
            for value in observed
        ]
        observed = _physical_lines(simplified)
    vertices_after = int(sum(len(value.coords) for value in observed))

    numerical_gap = float(cfg.get("post_fusion_numeric_gap_m", 0.035))
    possible_gaps: list[dict[str, Any]] = []
    for axis_index, cluster in enumerate(clusters):
        merged: list[list[float]] = []
        for start, end in sorted(intervals_by_axis[axis_index]):
            if not merged or start - merged[-1][1] > numerical_gap:
                merged.append([start, end])
            else:
                merged[-1][1] = max(merged[-1][1], end)
        direction = cluster["direction"]
        normal = cluster["normal"]
        base = cluster["offset"] * normal
        for first, second in zip(merged[:-1], merged[1:]):
            start = base + first[1] * direction
            end = base + second[0] * direction
            possible_gaps.append(
                {
                    "line_ref": LineString([start, end]),
                    "axis_id": f"PF_AXIS_{axis_index:04d}",
                    "left_support_length_m": float(first[1] - first[0]),
                    "right_support_length_m": float(second[1] - second[0]),
                }
            )
    return observed, possible_gaps, {
        "input_atomic_segment_count": int(len(segments)),
        "shared_axis_count": int(len(clusters)),
        "orientation_mode_count": int(len(modes)),
        "fitted_existing_intersection_count": int(fitted_intersection_count),
        "path_vertices_before_simplify": vertices_before,
        "path_vertices_after_simplify": vertices_after,
    }


def _evidence_rasters(
    points: np.ndarray, lines: list[LineString], cfg: dict
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    grid_m = float(cfg.get("post_fusion_morph_grid_m", cfg.get("grid_m", 0.05)))
    padding = float(cfg.get("post_fusion_morph_padding_m", 0.50))
    line_coordinates = np.vstack([np.asarray(value.coords, dtype=float) for value in lines])
    xy = points[:, :2] if len(points) else line_coordinates
    minimum = np.minimum(np.min(xy, axis=0), np.min(line_coordinates, axis=0)) - padding
    maximum = np.maximum(np.max(xy, axis=0), np.max(line_coordinates, axis=0)) + padding
    width, height = np.maximum(1, np.ceil((maximum - minimum) / grid_m).astype(int) + 1)
    shape = (int(height), int(width))

    count = np.zeros(shape[0] * shape[1], dtype=np.int32)
    vertical = np.zeros_like(count)
    if len(points):
        ij = np.floor((points[:, :2] - minimum) / grid_m).astype(np.int64)
        valid = (
            (ij[:, 0] >= 0)
            & (ij[:, 1] >= 0)
            & (ij[:, 0] < shape[1])
            & (ij[:, 1] < shape[0])
            & np.all(np.isfinite(points), axis=1)
        )
        ij = ij[valid]
        z = points[valid, 2]
        cells = ij[:, 1] * shape[1] + ij[:, 0]
        np.add.at(count, cells, 1)
        z_bin_m = float(cfg.get("post_fusion_evidence_z_bin_m", 0.10))
        z_min = float(np.min(z)) if len(z) else 0.0
        z_bins = np.floor((z - z_min) / z_bin_m).astype(np.int64)
        z_count = max(1, int(np.max(z_bins)) + 1) if len(z_bins) else 1
        unique = np.unique(cells * z_count + z_bins)
        np.add.at(vertical, unique // z_count, 1)
    count = count.reshape(shape)
    vertical = vertical.reshape(shape)
    evidence = (
        (count >= int(cfg.get("post_fusion_evidence_min_points", 2)))
        & (vertical >= int(cfg.get("post_fusion_evidence_min_height_bins", 2)))
    ).astype(np.uint8) * 255

    line_mask = np.zeros(shape, dtype=np.uint8)
    for line in lines:
        coordinates = np.rint(
            (np.asarray(line.coords, dtype=float) - minimum) / grid_m
        ).astype(np.int32)
        cv2.polylines(line_mask, [coordinates], False, 255, 1, cv2.LINE_8)
    evidence_close_radius = float(cfg.get("post_fusion_morph_close_radius_m", 0.15))
    radius = max(1, int(math.ceil(evidence_close_radius / grid_m)))
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (2 * radius + 1, 2 * radius + 1)
    )
    combined = cv2.bitwise_or(line_mask, evidence)
    closed = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, kernel)
    return evidence, closed, minimum, grid_m


def _raster_fraction(
    line: LineString, mask: np.ndarray, origin: np.ndarray, grid_m: float
) -> float:
    count = max(2, int(math.ceil(line.length / max(grid_m * 0.5, 0.01))) + 1)
    points = np.asarray(
        [line.interpolate(value, normalized=True).coords[0] for value in np.linspace(0, 1, count)],
        dtype=float,
    )
    ij = np.rint((points - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < mask.shape[1])
        & (ij[:, 1] < mask.shape[0])
    )
    if not np.any(valid):
        return 0.0
    return float(np.mean(mask[ij[valid, 1], ij[valid, 0]] > 0))


def _oriented_evidence_fraction(
    line: LineString,
    evidence: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    lateral_m: float,
) -> float:
    """Check evidence perpendicular to the candidate, without endpoint leakage."""
    coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
    direction = coordinates[1] - coordinates[0]
    length = float(np.linalg.norm(direction))
    if length <= 1e-9:
        return 0.0
    direction /= length
    normal = np.asarray([-direction[1], direction[0]], dtype=float)
    trim = min(0.04, 0.20 * length)
    useful = max(0.0, length - 2.0 * trim)
    count = max(1, int(math.ceil(useful / max(grid_m, 0.01))))
    along = np.linspace(trim, length - trim, count)
    offsets = np.arange(-lateral_m, lateral_m + grid_m * 0.5, grid_m)
    supported = []
    for distance in along:
        samples = coordinates[0] + distance * direction + offsets[:, None] * normal
        ij = np.rint((samples - origin) / grid_m).astype(np.int64)
        valid = (
            (ij[:, 0] >= 0)
            & (ij[:, 1] >= 0)
            & (ij[:, 0] < evidence.shape[1])
            & (ij[:, 1] < evidence.shape[0])
        )
        supported.append(
            bool(
                np.any(evidence[ij[valid, 1], ij[valid, 0]] > 0)
                if np.any(valid)
                else False
            )
        )
    return float(np.mean(supported)) if supported else 0.0


def _accept_gap_candidates(
    candidates: list[dict[str, Any]],
    evidence: np.ndarray,
    closed: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    cfg: dict,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    maximum_gap = float(cfg.get("post_fusion_collinear_gap_m", 0.30))
    minimum_side = float(cfg.get("post_fusion_gap_min_side_length_m", 0.40))
    evidence_min = float(cfg.get("post_fusion_gap_min_evidence_fraction", 0.40))
    morphology_min = float(cfg.get("post_fusion_gap_min_morph_fraction", 0.85))
    small_gap = float(cfg.get("post_fusion_small_gap_m", 0.08))
    small_evidence = float(cfg.get("post_fusion_small_gap_min_evidence_fraction", 0.15))
    lateral_m = float(cfg.get("post_fusion_evidence_lateral_m", 0.10))
    accepted: list[dict[str, Any]] = []
    rejected = {
        "too_long": 0,
        "short_side_support": 0,
        "weak_morphology": 0,
        "weak_point_evidence": 0,
    }
    for value in candidates:
        line = value["line_ref"]
        if line.length <= 1e-6 or line.length > maximum_gap:
            rejected["too_long"] += 1
            continue
        if min(
            float(value.get("left_support_length_m", 0.0)),
            float(value.get("right_support_length_m", 0.0)),
        ) < minimum_side:
            rejected["short_side_support"] += 1
            continue
        point_fraction = _oriented_evidence_fraction(
            line, evidence, origin, grid_m, lateral_m
        )
        morphology_fraction = _raster_fraction(line, closed, origin, grid_m)
        minimum_point_fraction = small_evidence if line.length <= small_gap else evidence_min
        if morphology_fraction < morphology_min:
            rejected["weak_morphology"] += 1
            continue
        if point_fraction < minimum_point_fraction:
            rejected["weak_point_evidence"] += 1
            continue
        score = float(
            0.60 * point_fraction
            + 0.30 * morphology_fraction
            + 0.10 * (1.0 - line.length / max(maximum_gap, 1e-6))
        )
        accepted.append(
            {
                **value,
                "kind": "morphological_collinear_closure",
                "score": score,
                "point_evidence_fraction": point_fraction,
                "morphology_fraction": morphology_fraction,
            }
        )
    return accepted, rejected


def _line_intersection(
    first: LineString, second: LineString
) -> tuple[np.ndarray, float, float] | None:
    a = np.asarray(first.coords, dtype=float)[[0, -1]]
    b = np.asarray(second.coords, dtype=float)[[0, -1]]
    da = a[1] - a[0]
    db = b[1] - b[0]
    cross = float(da[0] * db[1] - da[1] * db[0])
    if abs(cross) <= 1e-9:
        return None
    difference = b[0] - a[0]
    ta = float((difference[0] * db[1] - difference[1] * db[0]) / cross)
    tb = float((difference[0] * da[1] - difference[1] * da[0]) / cross)
    return a[0] + ta * da, ta, tb


def _corner_connections(
    lines: list[LineString],
    evidence: np.ndarray,
    closed: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    cfg: dict,
    target_lines: list[LineString] | None = None,
) -> list[dict[str, Any]]:
    maximum_extension = float(cfg.get("post_fusion_corner_extension_m", 0.25))
    target_slack = float(cfg.get("post_fusion_corner_target_slack_m", 0.10))
    direct = float(cfg.get("post_fusion_corner_direct_m", 0.06))
    minimum_angle = math.radians(float(cfg.get("post_fusion_corner_min_angle_deg", 20.0)))
    morphology_min = float(cfg.get("post_fusion_corner_min_morph_fraction", 0.75))
    evidence_min = float(cfg.get("post_fusion_corner_min_evidence_fraction", 0.20))
    lateral_m = float(cfg.get("post_fusion_evidence_lateral_m", 0.10))
    minimum_target_length = float(cfg.get("post_fusion_corner_min_wall_length_m", 0.30))
    targets = lines if target_lines is None else target_lines
    best: dict[tuple[int, int], dict[str, Any]] = {}
    for first_index, first in enumerate(lines):
        if first.length < minimum_target_length:
            continue
        first_coordinates = np.asarray(first.coords, dtype=float)[[0, -1]]
        _, _, _, first_angle = _canonical_axis(first)
        for second_index, second in enumerate(targets):
            if second.length < minimum_target_length:
                continue
            _, _, _, second_angle = _canonical_axis(second)
            angular = _angle_difference(first_angle, second_angle)
            if angular < minimum_angle or angular > math.pi - minimum_angle:
                continue
            result = _line_intersection(first, second)
            if result is None:
                continue
            point, first_parameter, second_parameter = result
            second_length = float(second.length)
            second_distance = second_parameter * second_length
            if second_distance < -target_slack or second_distance > second_length + target_slack:
                continue
            for endpoint_index, parameter in ((0, first_parameter), (1, first_parameter)):
                if endpoint_index == 0:
                    if parameter > 1e-9:
                        continue
                elif parameter < 1.0 - 1e-9:
                    continue
                endpoint = first_coordinates[endpoint_index]
                distance = float(np.linalg.norm(point - endpoint))
                if distance <= 1e-6 or distance > maximum_extension:
                    continue
                connector = LineString([endpoint, point])
                point_fraction = _oriented_evidence_fraction(
                    connector, evidence, origin, grid_m, lateral_m
                )
                morphology_fraction = _raster_fraction(connector, closed, origin, grid_m)
                if morphology_fraction < morphology_min:
                    continue
                if distance > direct and point_fraction < evidence_min:
                    continue
                angle_score = float(math.sin(angular))
                score = float(
                    0.35 * (1.0 - distance / maximum_extension)
                    + 0.30 * point_fraction
                    + 0.20 * morphology_fraction
                    + 0.15 * angle_score
                )
                key = (first_index, endpoint_index)
                if key not in best or score > best[key]["score"]:
                    best[key] = {
                        "line_ref": connector,
                        "kind": "reverse_extended_corner",
                        "score": score,
                        "source_line_index": first_index,
                        "target_line_index": second_index,
                        "point_evidence_fraction": point_fraction,
                        "morphology_fraction": morphology_fraction,
                        "corner_angle_deg": math.degrees(angular),
                    }
    # Identical L-corner extensions can be proposed from both directions.  The
    # 1 mm key is only for removing duplicates; it never moves geometry.
    unique: dict[tuple[tuple[int, int], tuple[int, int]], dict[str, Any]] = {}
    for value in best.values():
        coordinates = np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]]
        endpoints = sorted(tuple(np.rint(point * 1000).astype(int)) for point in coordinates)
        key = (endpoints[0], endpoints[1])
        if key not in unique or value["score"] > unique[key]["score"]:
            unique[key] = value
    return list(unique.values())


def _dangling_endpoint_rays(lines: list[LineString]) -> list[LineString]:
    """Return only terminal rays; connected internal vertices cannot sprout links."""
    atomic = _atomic_segments(lines, 1e-6)
    degrees: dict[tuple[int, int], int] = {}
    for line in atomic:
        for point in np.asarray(line.coords, dtype=float)[[0, -1]]:
            key = tuple(np.rint(point * 1000.0).astype(int))
            degrees[key] = degrees.get(key, 0) + 1
    rays: list[LineString] = []
    for line in _physical_lines(lines):
        coordinates = np.asarray(line.coords, dtype=float)
        if len(coordinates) < 2:
            continue
        start_key = tuple(np.rint(coordinates[0] * 1000.0).astype(int))
        end_key = tuple(np.rint(coordinates[-1] * 1000.0).astype(int))
        if degrees.get(start_key, 0) == 1:
            rays.append(LineString([coordinates[0], coordinates[1]]))
        if degrees.get(end_key, 0) == 1:
            rays.append(LineString([coordinates[-2], coordinates[-1]]))
    return rays


def _network_topology(lines: list[LineString]) -> dict[str, int]:
    noded = unary_union(lines) if lines else None
    segments = _atomic_segments(_linear_parts(noded), 1e-6) if noded is not None else []
    degrees: dict[tuple[int, int], int] = {}
    for line in segments:
        for point in np.asarray(line.coords, dtype=float)[[0, -1]]:
            key = tuple(np.rint(point * 1000).astype(int))
            degrees[key] = degrees.get(key, 0) + 1
    return {
        "node_count": int(len(degrees)),
        "dangling_endpoint_count": int(sum(value == 1 for value in degrees.values())),
        "junction_count": int(sum(value >= 3 for value in degrees.values())),
    }


def _line_point_p95(lines: list[LineString], points: np.ndarray) -> float | None:
    if not lines or not len(points):
        return None
    samples = []
    for line in lines:
        count = max(2, int(math.ceil(line.length / 0.05)) + 1)
        samples.extend(
            line.interpolate(value, normalized=True).coords[0]
            for value in np.linspace(0.0, 1.0, count)
        )
    distances, _ = cKDTree(points[:, :2]).query(np.asarray(samples), k=1)
    return float(np.quantile(distances, 0.95))


def _minor_kink_metrics(lines: list[LineString]) -> dict[str, float | int]:
    count = 0
    total_degrees = 0.0
    for line in _physical_lines(lines):
        coordinates = np.asarray(line.coords, dtype=float)
        if len(coordinates) < 3:
            continue
        vectors = np.diff(coordinates, axis=0)
        lengths = np.linalg.norm(vectors, axis=1)
        valid = lengths > 1e-9
        directions = vectors[valid] / lengths[valid, None]
        for first, second in zip(directions[:-1], directions[1:]):
            angle = math.degrees(
                math.acos(float(np.clip(first @ second, -1.0, 1.0)))
            )
            turn = min(angle, 180.0 - angle)
            if 0.20 <= turn <= 10.0:
                count += 1
                total_degrees += turn
    return {"count": int(count), "total_degrees": float(total_degrees)}


def regularize_merged_wall_network(
    union: list[dict[str, Any]], clean_points: np.ndarray, cfg: dict
) -> PostFusionResult:
    """Straighten and reconnect a fused multi-height wall network.

    Morphological closing is used as a *proposal and scoring mechanism*.  Its
    filled pixels are never directly polygonised, which avoids turning desks,
    doors, or raster blobs into authoritative CAD walls.
    """
    raw_lines = [
        value["line_ref"] for value in union if value.get("line_ref") is not None
    ]
    raw_physical = _physical_lines(raw_lines)
    if not raw_physical:
        return PostFusionResult([], [], [], {"post_fusion_enabled": True})
    observed, gap_candidates, fit_metrics = _regularize_axes(raw_physical, cfg)
    evidence, closed, origin, grid_m = _evidence_rasters(clean_points, observed, cfg)
    accepted_gaps, gap_rejections = _accept_gap_candidates(
        gap_candidates, evidence, closed, origin, grid_m, cfg
    )
    corner_targets = _atomic_segments(observed, 1e-6)
    corner_connections = _corner_connections(
        _dangling_endpoint_rays(observed),
        evidence,
        closed,
        origin,
        grid_m,
        cfg,
        target_lines=corner_targets,
    )
    inference_lines = [
        value["line_ref"] for value in [*accepted_gaps, *corner_connections]
    ]
    before_topology = _network_topology(raw_physical)
    after_topology = _network_topology([*observed, *inference_lines])
    raw_length = float(sum(value.length for value in raw_physical))
    observed_length = float(sum(value.length for value in observed))
    inferred_length = float(sum(value.length for value in inference_lines))
    raw_kinks = _minor_kink_metrics(raw_physical)
    observed_kinks = _minor_kink_metrics(observed)
    metrics = {
        "post_fusion_enabled": True,
        "post_fusion_strategy": "v9_straight_axis_corner_morphology",
        "post_fusion_raw_physical_line_count": int(len(raw_physical)),
        "post_fusion_raw_observed_length_m": raw_length,
        "post_fusion_regularized_observed_line_count": int(len(_physical_lines(observed))),
        "post_fusion_regularized_observed_length_m": observed_length,
        "post_fusion_observed_length_ratio": float(
            observed_length / max(raw_length, 1e-9)
        ),
        "post_fusion_minor_kink_count_before": raw_kinks["count"],
        "post_fusion_minor_kink_count_after": observed_kinks["count"],
        "post_fusion_minor_kink_degrees_before": raw_kinks["total_degrees"],
        "post_fusion_minor_kink_degrees_after": observed_kinks["total_degrees"],
        "post_fusion_gap_candidate_count": int(len(gap_candidates)),
        "post_fusion_gap_inferred_count": int(len(accepted_gaps)),
        "post_fusion_gap_inferred_length_m": float(
            sum(value["line_ref"].length for value in accepted_gaps)
        ),
        "post_fusion_corner_inferred_count": int(len(corner_connections)),
        "post_fusion_corner_inferred_length_m": float(
            sum(value["line_ref"].length for value in corner_connections)
        ),
        "post_fusion_total_inferred_length_m": inferred_length,
        "post_fusion_gap_rejections": gap_rejections,
        "post_fusion_raw_line_to_point_p95_m": _line_point_p95(raw_physical, clean_points),
        "post_fusion_observed_line_to_point_p95_m": _line_point_p95(observed, clean_points),
        "post_fusion_complete_line_to_point_p95_m": _line_point_p95(
            [*observed, *inference_lines], clean_points
        ),
        "post_fusion_dangling_reduction": int(
            before_topology["dangling_endpoint_count"]
            - after_topology["dangling_endpoint_count"]
        ),
        "post_fusion_topology_before": before_topology,
        "post_fusion_topology_after": after_topology,
        **{f"post_fusion_{key}": value for key, value in fit_metrics.items()},
    }
    return PostFusionResult(observed, accepted_gaps, corner_connections, metrics)


def morphology_revectorize_wall_network(
    result: PostFusionResult, clean_points: np.ndarray, cfg: dict
) -> MorphologyRevectorResult:
    """Rasterize the fused DXF, close gaps, skeletonize, and vectorize again."""
    base_lines = [
        *result.observed,
        *[value["line_ref"] for value in result.gap_inferred],
        *[value["line_ref"] for value in result.corner_inferred],
    ]
    if not base_lines:
        empty = np.zeros((1, 1), dtype=np.uint8)
        return MorphologyRevectorResult(
            [], empty, empty, empty, empty, np.zeros(2),
            float(cfg.get("grid_m", 0.05)),
            {"morphology_reextract_enabled": True},
        )

    raster_cfg = dict(cfg)
    raster_cfg["post_fusion_morph_grid_m"] = float(
        cfg.get(
            "post_fusion_reextract_grid_m",
            cfg.get("post_fusion_morph_grid_m", cfg.get("grid_m", 0.05)),
        )
    )
    evidence, _, origin, grid_m = _evidence_rasters(
        clean_points, base_lines, raster_cfg
    )
    input_mask = np.zeros_like(evidence)
    for line in base_lines:
        coordinates = np.rint(
            (np.asarray(line.coords, dtype=float) - origin) / grid_m - 0.5
        ).astype(np.int32)
        cv2.polylines(input_mask, [coordinates], False, 255, 1, cv2.LINE_8)

    corridor_m = float(cfg.get("post_fusion_reextract_evidence_corridor_m", 0.12))
    corridor_px = max(1, int(math.ceil(corridor_m / grid_m)))
    corridor = cv2.dilate(
        input_mask,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (2 * corridor_px + 1, 2 * corridor_px + 1)
        ),
    )
    supported_evidence = cv2.bitwise_and(evidence, corridor)
    source = (
        cv2.bitwise_or(input_mask, supported_evidence)
        if bool(cfg.get("post_fusion_reextract_include_evidence_pixels", False))
        else input_mask.copy()
    )

    angles = _dominant_line_angles(result.observed, cfg)
    if not angles:
        angles = [0.0, math.pi / 2.0]
    close_gap_m = float(cfg.get("post_fusion_reextract_close_gap_m", 0.20))
    kernel_length = max(3, int(round(close_gap_m / grid_m)) + 1)
    kernel_length |= 1
    dilated = source.copy()
    closed = source.copy()
    for angle in angles:
        kernel = _line_kernel(kernel_length, angle)
        direction_dilated = cv2.dilate(source, kernel)
        direction_closed = cv2.erode(direction_dilated, kernel)
        dilated = cv2.max(dilated, direction_dilated)
        closed = cv2.max(closed, direction_closed)

    # Remove only isolated raster specks. This is the component analogue of
    # opening, without erasing one-pixel-wide diagonal walls.
    component_count, labels, stats, _ = cv2.connectedComponentsWithStats(closed, 8)
    cleaned = np.zeros_like(closed)
    minimum_cells = int(cfg.get("post_fusion_reextract_min_component_cells", 5))
    for component in range(1, component_count):
        if int(stats[component, cv2.CC_STAT_AREA]) >= minimum_cells:
            cleaned[labels == component] = 255

    heatmap = np.maximum(
        input_mask.astype(np.float32) / 255.0,
        0.85 * (supported_evidence.astype(np.float32) / 255.0),
    )
    vector_cfg = dict(cfg)
    vector_cfg.update(
        {
            "vector_close_gap_m": 0.0,
            "vector_min_component_cells": 1,
            "vector_simplify_m": float(
                cfg.get("post_fusion_reextract_simplify_m", 0.06)
            ),
            "vector_snap_angle_deg": float(
                cfg.get("post_fusion_reextract_snap_angle_deg", 5.0)
            ),
            "vector_min_line_m": float(
                cfg.get("post_fusion_reextract_min_line_m", 0.18)
            ),
            "vector_oblique_min_line_m": float(
                cfg.get("post_fusion_reextract_oblique_min_line_m", 0.45)
            ),
            "vector_short_min_line_m": float(
                cfg.get("post_fusion_reextract_short_min_line_m", 0.10)
            ),
            "vector_short_min_heat": float(
                cfg.get("post_fusion_reextract_short_min_heat", 0.45)
            ),
            "vector_short_min_lower_quartile": float(
                cfg.get("post_fusion_reextract_short_min_lower_quartile", 0.25)
            ),
        }
    )
    direct = vectorize_structure_mask(
        cleaned,
        origin,
        grid_m,
        angles[0],
        vector_cfg,
        heatmap=heatmap,
    )
    reextracted, _, fit_metrics = _regularize_axes(direct.lines, cfg)
    junction_cfg = dict(cfg)
    junction_cfg.update(
        {
            "post_fusion_corner_extension_m": float(
                cfg.get("post_fusion_reextract_junction_extension_m", 0.12)
            ),
            "post_fusion_corner_target_slack_m": float(
                cfg.get("post_fusion_reextract_junction_target_slack_m", 0.08)
            ),
            "post_fusion_corner_direct_m": float(
                cfg.get("post_fusion_reextract_junction_direct_m", 0.02)
            ),
            "post_fusion_corner_min_morph_fraction": float(
                cfg.get("post_fusion_reextract_junction_min_mask_fraction", 0.80)
            ),
            "post_fusion_corner_min_evidence_fraction": float(
                cfg.get("post_fusion_reextract_junction_min_mask_fraction", 0.80)
            ),
            "post_fusion_corner_min_wall_length_m": float(
                cfg.get("post_fusion_reextract_junction_min_wall_m", 0.20)
            ),
        }
    )
    reextract_connections = _corner_connections(
        _dangling_endpoint_rays(reextracted),
        cleaned,
        cleaned,
        origin,
        grid_m,
        junction_cfg,
        target_lines=_atomic_segments(reextracted, 1e-6),
    )
    if reextract_connections:
        reextracted = _physical_lines(
            [
                *reextracted,
                *[value["line_ref"] for value in reextract_connections],
            ]
        )

    original_samples = _sample_lines(base_lines, max(0.025, grid_m * 0.5))
    extracted_samples = _sample_lines(reextracted, max(0.025, grid_m * 0.5))
    if len(original_samples) and len(extracted_samples):
        original_distances, _ = cKDTree(extracted_samples).query(original_samples, k=1)
        extracted_distances, _ = cKDTree(original_samples).query(extracted_samples, k=1)
        original_p95 = float(np.quantile(original_distances, 0.95))
        extracted_p95 = float(np.quantile(extracted_distances, 0.95))
        original_coverage = float(np.mean(original_distances <= 0.15))
    else:
        original_p95 = None
        extracted_p95 = None
        original_coverage = 0.0
    source_topology = _network_topology(base_lines)
    final_topology = _network_topology(reextracted)
    metrics = {
        "morphology_reextract_enabled": True,
        "morphology_reextract_strategy": "directional_close_skeleton_revectorize",
        "morphology_reextract_direction_count": int(len(angles)),
        "morphology_reextract_input_cells": int(np.count_nonzero(source)),
        "morphology_reextract_dilated_cells": int(np.count_nonzero(dilated)),
        "morphology_reextract_closed_cells": int(np.count_nonzero(cleaned)),
        "morphology_reextract_skeleton_cells": int(
            np.count_nonzero(direct.skeleton)
        ),
        "morphology_reextract_raw_line_count": int(len(direct.lines)),
        "morphology_reextract_final_line_count": int(len(reextracted)),
        "morphology_reextract_junction_connection_count": int(
            len(reextract_connections)
        ),
        "morphology_reextract_junction_connection_length_m": float(
            sum(value["line_ref"].length for value in reextract_connections)
        ),
        "morphology_reextract_final_length_m": float(
            sum(value.length for value in reextracted)
        ),
        "morphology_reextract_original_to_final_p95_m": original_p95,
        "morphology_reextract_final_to_original_p95_m": extracted_p95,
        "morphology_reextract_original_coverage_0_15m": original_coverage,
        "morphology_reextract_line_to_point_p95_m": _line_point_p95(
            reextracted, clean_points
        ),
        "morphology_reextract_topology_before": source_topology,
        "morphology_reextract_topology_after": final_topology,
        "morphology_reextract_dangling_reduction": int(
            source_topology["dangling_endpoint_count"]
            - final_topology["dangling_endpoint_count"]
        ),
        **{
            f"morphology_{key}": value for key, value in direct.metrics.items()
        },
        **{
            f"morphology_fit_{key}": value for key, value in fit_metrics.items()
        },
    }
    return MorphologyRevectorResult(
        reextracted,
        source,
        dilated,
        cleaned,
        direct.skeleton,
        origin,
        grid_m,
        metrics,
    )
