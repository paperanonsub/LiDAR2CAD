from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString
from shapely.ops import unary_union


@dataclass
class SharedWallGraph:
    walls: list[dict]
    segments: list[dict]
    nodes: dict[str, list[float]]


@dataclass
class SharedWallRecovery:
    union: list[dict]
    intersection: list[LineString]
    calibrated_common: list[dict]
    support_records: list[dict]
    metrics: dict
    graph: SharedWallGraph | None = None
    raw_union: list[dict] | None = None


@dataclass
class _SliceIndex:
    points: np.ndarray
    point_indices: np.ndarray
    tree: cKDTree | None
    session_points: list[tuple[str, np.ndarray, np.ndarray, cKDTree]]
    original_tree: cKDTree | None
    effective_height_m: float


def _canonical_direction(line: LineString) -> tuple[np.ndarray, np.ndarray, float]:
    coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
    direction = coordinates[1] - coordinates[0]
    length = float(np.linalg.norm(direction))
    direction /= max(length, 1e-12)
    if direction[0] < 0 or (abs(direction[0]) < 1e-12 and direction[1] < 0):
        direction *= -1
        coordinates = coordinates[::-1]
    return coordinates[0], direction, length


def _sample_lines(lines: list[LineString], step_m: float) -> np.ndarray:
    samples = []
    for line in lines:
        length = float(line.length)
        count = max(2, int(math.ceil(length / step_m)) + 1)
        samples.append(
            np.asarray(
                [line.interpolate(value).coords[0] for value in np.linspace(0.0, length, count)],
                dtype=float,
            )
        )
    return np.vstack(samples) if samples else np.empty((0, 2), dtype=float)


def _build_slice_indices(
    slices: list[Any],
    clean_points: np.ndarray,
    session_points: list[tuple[str, np.ndarray]],
    original_sample_step_m: float,
) -> list[_SliceIndex]:
    result: list[_SliceIndex] = []
    for height_slice in slices:
        z_min = float(height_slice.z_min_m)
        z_max = float(height_slice.z_max_m)
        selected_indices = np.flatnonzero(
            (clean_points[:, 2] >= z_min) & (clean_points[:, 2] < z_max)
        )
        points = clean_points[selected_indices]
        indexed_sessions = []
        for name, values in session_points:
            indices = np.flatnonzero(
                (values[:, 2] >= z_min) & (values[:, 2] < z_max)
            )
            selected = values[indices]
            if not len(selected):
                continue
            indexed_sessions.append((name, selected, indices, cKDTree(selected[:, :2])))
        original = _sample_lines(
            list(height_slice.calibrated_lines_ref), original_sample_step_m
        )
        result.append(
            _SliceIndex(
                points=points,
                point_indices=selected_indices,
                tree=cKDTree(points[:, :2]) if len(points) else None,
                session_points=indexed_sessions,
                original_tree=cKDTree(original) if len(original) else None,
                effective_height_m=max(0.0, z_max - z_min),
            )
        )
    return result


def _angle_difference(first: np.ndarray, second: np.ndarray) -> float:
    return math.acos(float(np.clip(abs(first @ second), -1.0, 1.0)))


def _remove_short_runs(mask: np.ndarray, widths: np.ndarray, minimum_m: float) -> np.ndarray:
    result = mask.copy()
    start = 0
    while start < len(result):
        end = start + 1
        while end < len(result) and result[end] == result[start]:
            end += 1
        if result[start] and float(np.sum(widths[start:end])) < minimum_m:
            result[start:end] = False
        start = end
    return result


def _local_wall_evidence(
    center: np.ndarray,
    direction: np.ndarray,
    index: _SliceIndex,
    floor_m: float,
    cfg: dict,
    bin_width_m: float | None = None,
) -> dict:
    corridor = float(cfg.get("shared_wall_search_corridor_m", 0.12))
    along_half = float(cfg.get("shared_wall_local_plane_radius_m", 0.20))
    query_radius = math.hypot(corridor, along_half)
    empty = {
        "observed": False,
        "frozen": False,
        "voxel_count": 0,
        "broad_voxel_count": 0,
        "height_bins": [],
        "session_names": [],
        "source_point_indices": [],
        "source_point_count_by_session": {},
        "plane_rmse_m": None,
        "direction_error_deg": None,
        "vertical_normal_error_deg": None,
        "axis_distance_m": None,
        "failure_reasons": ["no_local_points"],
    }
    if index.effective_height_m < float(
        cfg.get("shared_wall_min_effective_window_m", 0.20)
    ):
        return {**empty, "failure_reasons": ["insufficient_effective_height"]}
    if index.tree is None:
        return empty
    neighbours = index.tree.query_ball_point(center, query_radius)
    if not neighbours:
        return empty
    neighbour_indices = np.asarray(neighbours, dtype=int)
    points = index.points[neighbour_indices]
    point_indices = index.point_indices[neighbour_indices]
    delta = points[:, :2] - center
    normal = np.asarray([-direction[1], direction[0]])
    along = delta @ direction
    cross = delta @ normal
    keep = (np.abs(along) <= along_half) & (np.abs(cross) <= corridor)
    points = points[keep]
    cross = cross[keep]
    along = along[keep]
    point_indices = point_indices[keep]
    if not len(points):
        return empty

    # Mechanical scans often expose both faces of a wall, and nearby furniture
    # can share the same local cylinder.  Fit the density peak closest to the
    # delivered wall axis so the residual describes one physical face rather
    # than the empty space between two faces.
    face_bin_m = float(cfg.get("shared_wall_cross_section_bin_m", 0.02))
    boundaries = np.arange(-corridor, corridor + face_bin_m * 1.5, face_bin_m)
    histogram, edges = np.histogram(cross, boundaries)
    centers = (edges[:-1] + edges[1:]) / 2.0
    scores = histogram.astype(float) - 0.75 * np.abs(centers) / max(face_bin_m, 1e-9)
    peak = float(centers[int(np.argmax(scores))])
    face_half_width = float(cfg.get("shared_wall_face_half_width_m", 0.05))
    face = np.abs(cross - peak) <= face_half_width
    if np.count_nonzero(face) >= int(cfg.get("shared_wall_min_voxels", 6)):
        points = points[face]
        cross = cross[face]
        along = along[face]
        point_indices = point_indices[face]

    xy_grid = float(cfg.get("shared_wall_xy_voxel_m", 0.05))
    z_grid = float(cfg.get("shared_wall_z_voxel_m", 0.10))
    broad_keys = np.column_stack(
        [
            np.floor(points[:, :2] / xy_grid).astype(np.int64),
            np.floor((points[:, 2] - floor_m) / z_grid).astype(np.int64),
        ]
    )
    _, unique_index = np.unique(broad_keys, axis=0, return_index=True)
    broad_voxels = points[np.sort(unique_index)]
    if len(broad_voxels) < 3:
        return {
            **empty,
            "broad_voxel_count": int(len(broad_voxels)),
            "failure_reasons": ["insufficient_plane_voxels"],
        }

    centered = broad_voxels - np.mean(broad_voxels, axis=0)
    covariance = centered.T @ centered / max(1, len(centered))
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    plane_normal = eigenvectors[:, int(np.argmin(eigenvalues))]
    plane_rmse = float(
        np.sqrt(np.mean(np.square(centered @ plane_normal)))
    )
    horizontal_normal = plane_normal[:2]
    horizontal_norm = float(np.linalg.norm(horizontal_normal))
    if horizontal_norm <= 1e-8:
        direction_error = math.pi / 2.0
    else:
        horizontal_normal /= horizontal_norm
        plane_direction = np.asarray([-horizontal_normal[1], horizontal_normal[0]])
        direction_error = _angle_difference(direction, plane_direction)
    vertical_normal_error = math.asin(float(np.clip(abs(plane_normal[2]), 0.0, 1.0)))
    local_half = min(
        along_half,
        max(
            float(cfg.get("shared_wall_bin_evidence_half_length_m", 0.035)),
            0.5 * float(bin_width_m or cfg.get("shared_wall_sample_step_m", 0.05))
            + float(cfg.get("shared_wall_bin_evidence_slack_m", 0.005)),
        ),
    )
    local_mask = np.abs(along) <= local_half
    local_points = points[local_mask]
    local_cross = cross[local_mask]
    local_point_indices = point_indices[local_mask]
    local_keys = np.column_stack(
        [
            np.floor(local_points[:, :2] / xy_grid).astype(np.int64),
            np.floor((local_points[:, 2] - floor_m) / z_grid).astype(np.int64),
        ]
    ) if len(local_points) else np.empty((0, 3), dtype=np.int64)
    _, local_unique = np.unique(local_keys, axis=0, return_index=True)
    local_voxels = local_points[np.sort(local_unique)] if len(local_points) else local_points
    height_bins = sorted(set(map(int, local_keys[:, 2]))) if len(local_keys) else []
    axis_distance = (
        None if not len(local_cross) else float(abs(np.median(local_cross)))
    )

    session_names = []
    session_counts: dict[str, int] = {}
    session_min_voxels = int(cfg.get("shared_wall_session_min_voxels", 2))
    session_min_height_bins = int(
        cfg.get("shared_wall_session_min_height_bins", 2)
    )
    for name, session_values, _, session_tree in index.session_points:
        session_neighbours = session_tree.query_ball_point(center, query_radius)
        if not session_neighbours:
            continue
        session_local = session_values[np.asarray(session_neighbours, dtype=int)]
        session_delta = session_local[:, :2] - center
        session_along = session_delta @ direction
        session_cross = session_delta @ normal
        session_keep = (
            (np.abs(session_along) <= local_half)
            & (np.abs(session_cross - peak) <= face_half_width)
        )
        session_local = session_local[session_keep]
        if not len(session_local):
            continue
        session_keys = np.column_stack(
            [
                np.floor(session_local[:, :2] / xy_grid).astype(np.int64),
                np.floor((session_local[:, 2] - floor_m) / z_grid).astype(np.int64),
            ]
        )
        session_voxels = np.unique(session_keys, axis=0)
        session_bins = set(map(int, session_voxels[:, 2]))
        session_counts[name] = int(len(session_voxels))
        if (
            len(session_voxels) >= session_min_voxels
            and len(session_bins) >= session_min_height_bins
        ):
            session_names.append(name)

    minimum_voxels = int(cfg.get("shared_wall_min_voxels", 6))
    minimum_bin_voxels = int(cfg.get("shared_wall_bin_min_voxels", 2))
    minimum_height_bins = int(cfg.get("shared_wall_min_height_bins", 2))
    minimum_sessions = int(cfg.get("shared_wall_slice_min_sessions", 1))
    direction_limit = math.radians(
        float(cfg.get("shared_wall_direction_tolerance_deg", 15.0))
    )
    plane_limit = float(cfg.get("shared_wall_plane_rmse_m", 0.05))
    distance_limit = float(cfg.get("shared_wall_observed_distance_m", 0.10))
    failure_reasons = []
    if len(broad_voxels) < minimum_voxels:
        failure_reasons.append("insufficient_plane_voxels")
    if len(local_voxels) < minimum_bin_voxels:
        failure_reasons.append("no_local_points")
    if len(height_bins) < minimum_height_bins:
        failure_reasons.append("insufficient_height_bins")
    if len(session_names) < minimum_sessions:
        failure_reasons.append("insufficient_sessions")
    if direction_error > direction_limit:
        failure_reasons.append("direction_conflict")
    if vertical_normal_error > direction_limit:
        failure_reasons.append("non_vertical_surface")
    if plane_rmse > plane_limit:
        failure_reasons.append("plane_residual")
    if axis_distance is None or axis_distance > distance_limit:
        failure_reasons.append("axis_distance")
    observed = bool(
        len(broad_voxels) >= minimum_voxels
        and len(local_voxels) >= minimum_bin_voxels
        and len(height_bins) >= minimum_height_bins
        and len(session_names) >= minimum_sessions
        and direction_error <= direction_limit
        and vertical_normal_error <= direction_limit
        and plane_rmse <= plane_limit
        and axis_distance is not None
        and axis_distance <= distance_limit
    )

    frozen = bool(
        len(broad_voxels) >= int(cfg.get("shared_wall_validator_min_voxels", 8))
        and len(local_voxels)
        >= int(cfg.get("shared_wall_validator_bin_min_voxels", 3))
        and len(height_bins) >= minimum_height_bins
        and len(session_names)
        >= int(cfg.get("shared_wall_validator_min_sessions", minimum_sessions))
        and direction_error
        <= math.radians(float(cfg.get("shared_wall_validator_direction_deg", 12.0)))
        and vertical_normal_error
        <= math.radians(float(cfg.get("shared_wall_validator_direction_deg", 12.0)))
        and plane_rmse <= float(cfg.get("shared_wall_validator_plane_rmse_m", 0.04))
        and axis_distance is not None
        and axis_distance
        <= float(cfg.get("shared_wall_validator_distance_m", 0.08))
    )
    return {
        "observed": observed,
        "frozen": frozen,
        "voxel_count": int(len(local_voxels)),
        "broad_voxel_count": int(len(broad_voxels)),
        "height_bins": height_bins,
        "session_names": session_names,
        "source_point_indices": sorted(set(map(int, local_point_indices.tolist()))),
        "source_point_count_by_session": session_counts,
        "plane_rmse_m": plane_rmse,
        "direction_error_deg": math.degrees(direction_error),
        "vertical_normal_error_deg": math.degrees(vertical_normal_error),
        "axis_distance_m": axis_distance,
        "failure_reasons": [] if observed else failure_reasons,
    }


def _infer_bounded_gaps(
    observed: np.ndarray,
    base_bins: list[list[set[int]]],
    widths: np.ndarray,
    cfg: dict,
) -> tuple[np.ndarray, dict[tuple[int, int], str]]:
    slice_count, bin_count = observed.shape
    inferred = np.zeros_like(observed)
    reasons: dict[tuple[int, int], str] = {}
    maximum_gap = float(cfg.get("shared_wall_inferred_collinear_gap_m", 0.80))
    minimum_fraction = float(cfg.get("shared_wall_inference_min_fraction", 0.75))
    quorum = max(1, int(math.ceil(slice_count * minimum_fraction - 1e-12)))
    minimum_base_bins = int(cfg.get("shared_wall_inference_min_base_bins", 6))
    bands = [set(map(int, value)) for value in np.array_split(np.arange(slice_count), 3)]
    for slice_index in range(slice_count):
        cursor = 0
        while cursor < bin_count:
            if observed[slice_index, cursor]:
                cursor += 1
                continue
            end = cursor + 1
            while end < bin_count and not observed[slice_index, end]:
                end += 1
            bounded = cursor > 0 and end < bin_count
            length = float(np.sum(widths[cursor:end]))
            if bounded and length <= maximum_gap:
                valid = True
                for bin_index in range(cursor, end):
                    present = set(np.flatnonzero(observed[:, bin_index]).tolist())
                    distinct_bins = set().union(
                        *(base_bins[value][bin_index] for value in present)
                    ) if present else set()
                    neighbour = (
                        (slice_index > 0 and observed[slice_index - 1, bin_index])
                        or (
                            slice_index + 1 < slice_count
                            and observed[slice_index + 1, bin_index]
                        )
                    )
                    if (
                        len(present) < quorum
                        or not neighbour
                        or len(distinct_bins) < minimum_base_bins
                        or any(band and not (present & band) for band in bands)
                    ):
                        valid = False
                        break
                if valid:
                    inferred[slice_index, cursor:end] = True
                    for bin_index in range(cursor, end):
                        reasons[(slice_index, bin_index)] = (
                            "bounded_gap_with_cross_height_wall_evidence"
                        )
            cursor = end
    return inferred, reasons


def _height_ranges(indices: list[int], slices: list[Any]) -> list[list[float]]:
    ranges = sorted(
        (float(slices[index].z_min_m), float(slices[index].z_max_m))
        for index in indices
    )
    result: list[list[float]] = []
    for lower, upper in ranges:
        if result and lower <= result[-1][1] + 1e-9:
            result[-1][1] = max(result[-1][1], upper)
        else:
            result.append([lower, upper])
    return result


def _state_name(observed: list[int], count: int) -> str:
    if len(observed) == count:
        return "full_observed"
    if observed and min(observed) == 0 and max(observed) < count - 1:
        return "lower_observed"
    if observed and min(observed) > 0 and max(observed) == count - 1:
        return "upper_observed"
    return "partial_observed"


def _line_coverage_fraction(reference: list[LineString], candidate: list[LineString], tolerance: float) -> float | None:
    if not reference:
        return None
    baseline = unary_union(reference)
    total = float(baseline.length)
    if total <= 1e-9:
        return None
    if not candidate:
        return 0.0
    covered = baseline.intersection(unary_union(candidate).buffer(tolerance))
    return float(covered.length / total)


def _bootstrap_supplement_candidates(
    bootstrap_union: list[dict], primary: list[tuple[dict, str]], cfg: dict
) -> list[tuple[dict, str]]:
    """Recover shared axes discarded by architectural display classification."""
    by_wall: dict[str, list[LineString]] = {}
    for value in bootstrap_union:
        by_wall.setdefault(str(value.get("wall_id", "")), []).append(value["line_ref"])
    primary_samples = _sample_lines(
        [value[0]["line_ref"] for value in primary],
        float(cfg.get("shared_wall_sample_step_m", 0.05)),
    )
    primary_tree = cKDTree(primary_samples) if len(primary_samples) else None
    match_distance = float(cfg.get("shared_wall_primary_match_distance_m", 0.08))
    minimum_length = float(cfg.get("shared_wall_bootstrap_min_length_m", 0.15))
    step = float(cfg.get("shared_wall_sample_step_m", 0.05))
    result: list[tuple[dict, str]] = []
    supplement_index = 0
    for source_wall_id, lines in by_wall.items():
        if not lines:
            continue
        _, direction, _ = _canonical_direction(max(lines, key=lambda value: value.length))
        normal = np.asarray([-direction[1], direction[0]])
        offsets = [
            float(np.mean(np.asarray(line.coords, dtype=float)[[0, -1]] @ normal))
            for line in lines
        ]
        offset = float(np.median(offsets))
        intervals = sorted(
            tuple(
                sorted(
                    (
                        np.asarray(line.coords, dtype=float)[[0, -1]] @ direction
                    ).tolist()
                )
            )
            for line in lines
        )
        merged: list[tuple[float, float]] = []
        for start, end in intervals:
            if merged and start <= merged[-1][1] + 0.01:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        for start, end in merged:
            count = max(1, int(math.ceil((end - start) / step)))
            edges = np.linspace(start, end, count + 1)
            centers = (
                direction * ((edges[:-1] + edges[1:]) / 2.0)[:, None]
                + normal * offset
            )
            novel = (
                np.ones(count, dtype=bool)
                if primary_tree is None
                else primary_tree.query(centers, k=1)[0] > match_distance
            )
            cursor = 0
            while cursor < count:
                if not novel[cursor]:
                    cursor += 1
                    continue
                run_end = cursor + 1
                while run_end < count and novel[run_end]:
                    run_end += 1
                run_start_m, run_end_m = float(edges[cursor]), float(edges[run_end])
                if run_end_m - run_start_m >= minimum_length:
                    identifier = f"V8B{supplement_index:04d}"
                    result.append(
                        (
                            {
                                "candidate_id": identifier,
                                "line_ref": LineString(
                                    [
                                        direction * run_start_m + normal * offset,
                                        direction * run_end_m + normal * offset,
                                    ]
                                ),
                                "source_wall_ids": [source_wall_id],
                                "source_segment_ids": [
                                    value.get("segment_id", "")
                                    for value in bootstrap_union
                                    if str(value.get("wall_id", "")) == source_wall_id
                                ],
                                "node_ids": [],
                                "selection_reasons": [
                                    "bootstrap_axis_missing_from_architectural_display"
                                ],
                            },
                            "unclassified_wall_candidate",
                        )
                    )
                    supplement_index += 1
                cursor = run_end
    return result


def _subtract_intervals(
    interval: tuple[float, float], covered: list[tuple[float, float]], tolerance: float
) -> list[tuple[float, float]]:
    remaining = [interval]
    for cover_start, cover_end in covered:
        updated = []
        for start, end in remaining:
            if cover_end <= start + tolerance or cover_start >= end - tolerance:
                updated.append((start, end))
                continue
            if cover_start > start + tolerance:
                updated.append((start, min(end, cover_start)))
            if cover_end < end - tolerance:
                updated.append((max(start, cover_end), end))
        remaining = updated
    return remaining


def _remove_candidate_axis_overlaps(
    candidates: list[tuple[dict, str]], cfg: dict
) -> tuple[list[tuple[dict, str]], float]:
    angle_limit = math.radians(
        float(cfg.get("shared_wall_duplicate_angle_deg", 0.05))
    )
    offset_limit = float(cfg.get("shared_wall_duplicate_offset_m", 0.002))
    minimum_length = float(cfg.get("consensus_atomic_min_line_m", 0.01))
    axis_groups: list[dict] = []
    result: list[tuple[dict, str]] = []
    removed_length = 0.0
    for candidate, classification in candidates:
        line = candidate["line_ref"]
        _, direction, length = _canonical_direction(line)
        normal = np.asarray([-direction[1], direction[0]])
        coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
        offset = float(np.mean(coordinates @ normal))
        selected = None
        for group in axis_groups:
            if _angle_difference(direction, group["direction"]) > angle_limit:
                continue
            group_normal = group["normal"]
            candidate_offset = float(np.mean(coordinates @ group_normal))
            if abs(candidate_offset - group["offset"]) <= offset_limit:
                selected = group
                break
        if selected is None:
            selected = {
                "direction": direction,
                "normal": normal,
                "offset": offset,
                "intervals": [],
            }
            axis_groups.append(selected)
        group_direction = selected["direction"]
        interval = tuple(sorted((coordinates @ group_direction).tolist()))
        novel = _subtract_intervals(interval, selected["intervals"], 1e-6)
        removed_length += max(0.0, length - sum(end - start for start, end in novel))
        for part_index, (start, end) in enumerate(novel):
            if end - start < minimum_length:
                continue
            value = dict(candidate)
            value["candidate_id"] = (
                str(candidate.get("candidate_id", "W"))
                if len(novel) == 1
                else f"{candidate.get('candidate_id', 'W')}_D{part_index:02d}"
            )
            value["line_ref"] = LineString(
                [
                    selected["direction"] * start
                    + selected["normal"] * selected["offset"],
                    selected["direction"] * end
                    + selected["normal"] * selected["offset"],
                ]
            )
            result.append((value, classification))
            selected["intervals"].append((start, end))
            selected["intervals"].sort()
    return result, removed_length


def _candidate_axis_score(
    candidate: dict,
    classification: str,
    indices: list[_SliceIndex],
    cfg: dict,
) -> tuple[float, dict]:
    """Score a physical-axis proposal before it may enter the shared graph."""
    line = candidate["line_ref"]
    _, _, length = _canonical_direction(line)
    step = float(cfg.get("shared_wall_candidate_score_step_m", 0.20))
    count = max(2, int(math.ceil(length / max(step, 1e-6))) + 1)
    samples = np.asarray(
        [line.interpolate(value).coords[0] for value in np.linspace(0.0, length, count)],
        dtype=float,
    )
    high_indices = [
        int(value)
        for value in cfg.get("high_slice_priority", [7, 6, 8])
        if 0 <= int(value) < len(indices) and indices[int(value)].tree is not None
    ]
    distance = float(cfg.get("shared_wall_candidate_score_distance_m", 0.10))
    support = np.zeros((len(high_indices), len(samples)), dtype=bool)
    for row, slice_index in enumerate(high_indices):
        support[row] = indices[slice_index].tree.query(samples, k=1)[0] <= distance
    if len(high_indices):
        any_support = float(np.mean(np.any(support, axis=0)))
        required = min(2, len(high_indices))
        repeated_support = float(np.mean(np.sum(support, axis=0) >= required))
    else:
        any_support = 0.0
        repeated_support = 0.0
    session_count = int(candidate.get("session_count", 0))
    vertical_span = float(candidate.get("vertical_span_m", 0.0))
    source_prior = {
        "building_wall": 1.0,
        "low_structure": 0.80,
        "unclassified_wall_candidate": 0.0,
    }.get(classification, 0.0)
    components = {
        "repeated_high_slice_support": repeated_support,
        "any_high_slice_support": any_support,
        "length_prior": min(1.0, length / 2.0),
        "session_prior": min(1.0, session_count / 2.0),
        "vertical_prior": min(1.0, vertical_span / 1.20),
        "source_prior": source_prior,
    }
    score = float(
        0.32 * repeated_support
        + 0.13 * any_support
        + 0.13 * components["length_prior"]
        + 0.13 * components["session_prior"]
        + 0.14 * components["vertical_prior"]
        + 0.15 * source_prior
    )
    return score, components


def _score_and_absorb_candidates(
    candidates: list[tuple[dict, str]],
    indices: list[_SliceIndex],
    cfg: dict,
) -> tuple[list[tuple[dict, str]], dict]:
    """Let strong, regular axes absorb weaker near-coincident proposals.

    Absorption happens before height support is recovered.  A weaker proposal
    may contribute a novel extension, but that extension is projected onto the
    winning axis.  Parallel faces at wall-thickness distance are deliberately
    protected by the tight lateral limit.
    """
    scored = []
    for candidate, classification in candidates:
        value = dict(candidate)
        score, components = _candidate_axis_score(value, classification, indices, cfg)
        value["candidate_score"] = score
        value["candidate_score_components"] = components
        scored.append((value, classification))
    class_priority = {
        "building_wall": 2,
        "low_structure": 1,
        "unclassified_wall_candidate": 0,
    }
    scored.sort(
        key=lambda item: (
            class_priority.get(item[1], 0),
            float(item[0].get("candidate_score", 0.0)),
            float(item[0]["line_ref"].length),
        ),
        reverse=True,
    )
    angle_limit = math.radians(
        float(cfg.get("shared_wall_absorb_angle_deg", 2.0))
    )
    offset_limit = float(cfg.get("shared_wall_absorb_offset_m", 0.08))
    minimum_overlap = float(cfg.get("shared_wall_absorb_min_overlap_m", 0.25))
    snap_gap = float(cfg.get("shared_wall_absorb_snap_gap_m", 0.15))
    minimum_length = float(cfg.get("consensus_atomic_min_line_m", 0.01))
    groups: list[dict] = []
    result: list[tuple[dict, str]] = []
    absorbed_count = 0
    absorbed_length = 0.0
    projected_extension_length = 0.0

    for candidate, classification in scored:
        line = candidate["line_ref"]
        _, direction, _ = _canonical_direction(line)
        coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
        best = None
        best_quality = -float("inf")
        for group in groups:
            if (classification == "low_structure") != (
                group["classification"] == "low_structure"
            ):
                continue
            if _angle_difference(direction, group["direction"]) > angle_limit:
                continue
            cross = coordinates @ group["normal"] - group["offset"]
            if float(np.max(np.abs(cross))) > offset_limit:
                continue
            interval = tuple(sorted((coordinates @ group["direction"]).tolist()))
            overlap = max(
                (
                    max(0.0, min(interval[1], end) - max(interval[0], start))
                    for start, end in group["intervals"]
                ),
                default=0.0,
            )
            gap = min(
                (
                    max(start - interval[1], interval[0] - end, 0.0)
                    for start, end in group["intervals"]
                ),
                default=float("inf"),
            )
            if overlap < minimum_overlap and gap > snap_gap:
                continue
            quality = overlap - 2.0 * float(np.mean(np.abs(cross))) - gap
            if quality > best_quality:
                best_quality = quality
                best = (group, interval, overlap)
        if best is None:
            normal = np.asarray([-direction[1], direction[0]])
            interval = tuple(sorted((coordinates @ direction).tolist()))
            groups.append(
                {
                    "direction": direction,
                    "normal": normal,
                    "offset": float(np.mean(coordinates @ normal)),
                    "intervals": [interval],
                    "classification": classification,
                    "winner_index": len(result),
                }
            )
            result.append((candidate, classification))
            continue

        group, interval, overlap = best
        novel = _subtract_intervals(interval, group["intervals"], 1e-6)
        removed = max(0.0, float(line.length) - sum(end - start for start, end in novel))
        if removed > 1e-9:
            absorbed_count += 1
            absorbed_length += removed
            winner = result[group["winner_index"]][0]
            winner["absorbed_candidate_ids"] = sorted(
                set(winner.get("absorbed_candidate_ids", []))
                | {str(candidate.get("candidate_id", ""))}
            )
        for part_index, (start, end) in enumerate(novel):
            if end - start < minimum_length:
                continue
            value = dict(candidate)
            value["candidate_id"] = (
                str(candidate.get("candidate_id", "W"))
                if len(novel) == 1
                else f"{candidate.get('candidate_id', 'W')}_A{part_index:02d}"
            )
            value["line_ref"] = LineString(
                [
                    group["direction"] * start + group["normal"] * group["offset"],
                    group["direction"] * end + group["normal"] * group["offset"],
                ]
            )
            value["node_ids"] = []
            value["absorbed_into_axis"] = str(
                result[group["winner_index"]][0].get("candidate_id", "")
            )
            result.append((value, classification))
            group["intervals"].append((start, end))
            projected_extension_length += end - start
        group["intervals"].sort()
    return result, {
        "input_count": len(candidates),
        "output_count": len(result),
        "absorbed_candidate_count": int(absorbed_count),
        "absorbed_overlap_length_m": float(absorbed_length),
        "projected_extension_length_m": float(projected_extension_length),
    }


def _refit_candidate_axis(
    candidate: dict,
    classification: str,
    indices: list[_SliceIndex],
    cfg: dict,
) -> tuple[dict, dict]:
    """Refit a reliable wall with high slices while bounding drift from its axis."""
    value = dict(candidate)
    line = value["line_ref"]
    if classification != "building_wall" or not bool(
        cfg.get("shared_wall_refit_enabled", True)
    ):
        return value, {"accepted": False, "reason": "not_refit_candidate"}
    high_order = [
        int(index)
        for index in cfg.get("high_slice_priority", [7, 6, 8])
        if 0 <= int(index) < len(indices)
    ]
    origin, direction, length = _canonical_direction(line)
    if length < float(cfg.get("architectural_backbone_min_length_m", 0.50)):
        return value, {"accepted": False, "reason": "short_wall"}
    midpoint = origin + direction * (length * 0.5)
    normal = np.asarray([-direction[1], direction[0]])
    corridor = float(cfg.get("shared_wall_refit_corridor_m", 0.12))
    face_bin = float(cfg.get("shared_wall_cross_section_bin_m", 0.02))
    face_half = float(cfg.get("shared_wall_face_half_width_m", 0.05))
    selected_parts = []
    for slice_index in high_order:
        points = indices[slice_index].points
        if not len(points):
            continue
        delta = points[:, :2] - midpoint
        along = delta @ direction
        cross = delta @ normal
        keep = (np.abs(along) <= length * 0.5 + 0.10) & (np.abs(cross) <= corridor)
        local = points[keep]
        local_cross = cross[keep]
        if len(local) < 8:
            continue
        edges = np.arange(-corridor, corridor + face_bin * 1.5, face_bin)
        histogram, boundaries = np.histogram(local_cross, edges)
        centers = (boundaries[:-1] + boundaries[1:]) * 0.5
        scores = histogram.astype(float) - 0.75 * np.abs(centers) / max(face_bin, 1e-9)
        peak = float(centers[int(np.argmax(scores))])
        face = np.abs(local_cross - peak) <= face_half
        if np.count_nonzero(face) >= 8:
            selected_parts.append(local[face, :2])
    if not selected_parts:
        return value, {"accepted": False, "reason": "no_high_slice_face"}
    points = np.vstack(selected_parts)
    center = np.median(points, axis=0)
    covariance = np.cov(points - center, rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    fitted_direction = eigenvectors[:, int(np.argmax(eigenvalues))]
    if float(fitted_direction @ direction) < 0:
        fitted_direction *= -1
    raw_angle = math.atan2(
        float(direction[0] * fitted_direction[1] - direction[1] * fitted_direction[0]),
        float(direction @ fitted_direction),
    )
    angle_limit = math.radians(float(cfg.get("shared_wall_refit_max_angle_deg", 2.0)))
    angle = float(np.clip(raw_angle, -angle_limit, angle_limit))
    cosine, sine = math.cos(angle), math.sin(angle)
    fitted_direction = np.asarray(
        [
            cosine * direction[0] - sine * direction[1],
            sine * direction[0] + cosine * direction[1],
        ]
    )
    fitted_normal = np.asarray([-fitted_direction[1], fitted_direction[0]])
    offset_delta = float(np.median(points @ fitted_normal) - midpoint @ fitted_normal)
    offset_limit = float(cfg.get("shared_wall_refit_max_offset_m", 0.05))
    offset_delta = float(np.clip(offset_delta, -offset_limit, offset_limit))
    fitted_midpoint = midpoint + fitted_normal * offset_delta
    original_coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
    projections = (original_coordinates - midpoint) @ fitted_direction
    fitted_line = LineString(
        [
            fitted_midpoint + fitted_direction * float(projections[0]),
            fitted_midpoint + fitted_direction * float(projections[1]),
        ]
    )
    old_residual = np.abs((points - midpoint) @ normal)
    new_residual = np.abs((points - fitted_midpoint) @ fitted_normal)
    old_p95 = float(np.quantile(old_residual, 0.95))
    new_p95 = float(np.quantile(new_residual, 0.95))
    support_limit = float(cfg.get("shared_wall_observed_distance_m", 0.10))
    old_support = float(np.mean(old_residual <= support_limit))
    new_support = float(np.mean(new_residual <= support_limit))
    accepted = bool(
        new_p95 <= old_p95 + float(cfg.get("architectural_local_p95_regression_m", 0.02))
        and new_support >= old_support
        - float(cfg.get("architectural_max_coverage_regression", 0.02))
    )
    if accepted:
        value["line_ref"] = fitted_line
        value["selection_reasons"] = sorted(
            set(value.get("selection_reasons", [])) | {"v8_bounded_high_slice_refit"}
        )
    return value, {
        "accepted": accepted,
        "reason": "accepted" if accepted else "local_quality_regression",
        "angle_change_deg": math.degrees(angle),
        "offset_change_m": offset_delta,
        "old_p95_m": old_p95,
        "new_p95_m": new_p95,
        "old_support": old_support,
        "new_support": new_support,
    }


def _snap_existing_shared_nodes(
    candidates: list[tuple[dict, str]], cfg: dict
) -> tuple[list[tuple[dict, str]], int]:
    """Recreate existing L/T nodes from fitted wall-axis intersections."""
    incident: dict[str, list[tuple[int, int]]] = {}
    result = [(dict(value), classification) for value, classification in candidates]
    for candidate_index, (value, _) in enumerate(result):
        for endpoint_index, node_id in enumerate(value.get("node_ids", [])[:2]):
            if node_id:
                incident.setdefault(str(node_id), []).append(
                    (candidate_index, endpoint_index)
                )
    maximum_extension = float(cfg.get("architectural_junction_extension_max_m", 0.30))
    updated = 0
    for members in incident.values():
        if len(members) < 2:
            continue
        normals, offsets, endpoints = [], [], []
        for candidate_index, endpoint_index in members:
            line = result[candidate_index][0]["line_ref"]
            coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
            direction = coordinates[1] - coordinates[0]
            direction /= max(float(np.linalg.norm(direction)), 1e-12)
            normal = np.asarray([-direction[1], direction[0]])
            normals.append(normal)
            offsets.append(float(np.mean(coordinates @ normal)))
            endpoints.append(coordinates[endpoint_index])
        matrix = np.asarray(normals)
        if np.linalg.matrix_rank(matrix) < 2:
            continue
        point = np.linalg.lstsq(matrix, np.asarray(offsets), rcond=None)[0]
        if any(float(np.linalg.norm(point - endpoint)) > maximum_extension for endpoint in endpoints):
            continue
        for candidate_index, endpoint_index in members:
            value = result[candidate_index][0]
            coordinates = np.asarray(value["line_ref"].coords, dtype=float)[[0, -1]]
            coordinates[endpoint_index] = point
            if float(np.linalg.norm(coordinates[1] - coordinates[0])) > 1e-6:
                value["line_ref"] = LineString(coordinates)
        updated += 1
    return result, updated


def _frozen_common_reference(
    reference: list[LineString],
    indices: list[_SliceIndex],
    floor_m: float,
    cfg: dict,
) -> list[LineString]:
    """Freeze independently point-validated common intervals before optimisation."""
    step = float(cfg.get("shared_wall_sample_step_m", 0.05))
    minimum_run = float(cfg.get("shared_wall_min_continuous_run_m", 0.15))
    result = []
    for line in reference:
        origin, direction, length = _canonical_direction(line)
        if length <= 1e-8:
            continue
        count = max(1, int(math.ceil(length / step)))
        boundaries = np.linspace(0.0, length, count + 1)
        widths = np.diff(boundaries)
        centers = origin + direction * ((boundaries[:-1] + boundaries[1:]) * 0.5)[:, None]
        mask = np.ones(count, dtype=bool)
        for slice_index in range(len(indices)):
            local = np.asarray(
                [
                    _local_wall_evidence(
                        center, direction, indices[slice_index], floor_m, cfg, widths[index]
                    )["frozen"]
                    for index, center in enumerate(centers)
                ],
                dtype=bool,
            )
            mask &= _remove_short_runs(local, widths, minimum_run)
        cursor = 0
        while cursor < count:
            if not mask[cursor]:
                cursor += 1
                continue
            end = cursor + 1
            while end < count and mask[end]:
                end += 1
            result.append(
                LineString(
                    [
                        origin + direction * float(boundaries[cursor]),
                        origin + direction * float(boundaries[end]),
                    ]
                )
            )
            cursor = end
    return result


def materialize_architectural_graph(result: Any, recovery: SharedWallRecovery) -> None:
    """Make the architectural deliverable reference the recovered shared graph."""
    if recovery.graph is None:
        return
    result.walls = [
        dict(value)
        for value in recovery.graph.walls
        if value.get("classification") == "building_wall"
    ]
    result.low_structures = [
        dict(value)
        for value in recovery.graph.walls
        if value.get("classification") == "low_structure"
    ]
    graph_uncertain = [
        dict(value)
        for value in recovery.graph.walls
        if value.get("classification") == "uncertain_detail"
    ]
    existing_ids = {str(value.get("candidate_id", "")) for value in result.uncertain}
    result.uncertain.extend(
        value
        for value in graph_uncertain
        if str(value.get("candidate_id", "")) not in existing_ids
    )


def _coordinate_node_id(point: Any) -> str:
    """Return a node identity that cannot alias geometrically distinct endpoints."""
    coordinate = np.asarray(point, dtype=float)
    return (
        f"N_{int(round(float(coordinate[0]) * 1000.0))}_"
        f"{int(round(float(coordinate[1]) * 1000.0))}"
    )


def recover_shared_wall_model(
    walls: list[dict],
    low_structures: list[dict],
    slices: list[Any],
    clean_points: np.ndarray,
    clean_session_points: list[tuple[str, np.ndarray]],
    floor_m: float,
    ceiling_m: float,
    bootstrap_intersection: list[LineString],
    bootstrap_union: list[dict],
    cfg: dict,
    prior_intersection: list[LineString] | None = None,
) -> SharedWallRecovery:
    """Rebuild all height products from one point-validated physical wall graph."""
    if not slices:
        return SharedWallRecovery(
            [], [], [], [], {}, SharedWallGraph([], [], {}), []
        )
    step_m = float(cfg.get("shared_wall_sample_step_m", 0.05))
    indices = _build_slice_indices(slices, clean_points, clean_session_points, step_m)
    floor_guard = floor_m + float(cfg.get("floor_margin_m", 0.12))
    ceiling_guard = ceiling_m - float(cfg.get("ceiling_margin_m", 0.12))
    for height_slice, index in zip(slices, indices):
        index.effective_height_m = max(
            0.0,
            min(float(height_slice.z_max_m), ceiling_guard)
            - max(float(height_slice.z_min_m), floor_guard),
        )
    frozen_reference = _frozen_common_reference(
        list(prior_intersection or bootstrap_intersection), indices, floor_m, cfg
    )

    primary: list[tuple[dict, str]] = [
        (dict(value), "building_wall") for value in walls
    ] + [(dict(value), "low_structure") for value in low_structures]
    refit_metrics = []
    candidates: list[tuple[dict, str]] = []
    for value, classification in primary:
        refitted, refit = _refit_candidate_axis(value, classification, indices, cfg)
        refit_metrics.append(refit)
        candidates.append((refitted, classification))
    supplements = _bootstrap_supplement_candidates(
        bootstrap_union, candidates, cfg
    )
    candidates.extend(supplements)
    candidates, candidate_absorption = _score_and_absorb_candidates(
        candidates, indices, cfg
    )
    candidates, candidate_duplicate_length = _remove_candidate_axis_overlaps(
        candidates, cfg
    )
    candidates, shared_node_update_count = _snap_existing_shared_nodes(candidates, cfg)
    union: list[dict] = []
    raw_union: list[dict] = []
    common: list[dict] = []
    support_records: list[dict] = []
    graph_walls: list[dict] = []
    graph_nodes: dict[str, list[float]] = {}
    recovered_distances = []
    recovered_plane_rmse = []
    recovered_voxel_count = 0
    failure_length_by_reason: dict[str, float] = {}
    single_session_observed_length = 0.0

    for wall_index, (wall, classification) in enumerate(candidates):
        source_classification = classification
        line = wall["line_ref"]
        origin, direction, length = _canonical_direction(line)
        if length <= 1e-8:
            continue
        bin_count = max(1, int(math.ceil(length / step_m)))
        boundaries = np.linspace(0.0, length, bin_count + 1)
        widths = np.diff(boundaries)
        centers = origin + direction * ((boundaries[:-1] + boundaries[1:]) / 2.0)[:, None]
        observed = np.zeros((len(slices), bin_count), dtype=bool)
        frozen = np.zeros_like(observed)
        original = np.zeros_like(observed)
        base_bins: list[list[set[int]]] = [
            [set() for _ in range(bin_count)] for _ in slices
        ]
        sessions: list[list[set[str]]] = [
            [set() for _ in range(bin_count)] for _ in slices
        ]
        diagnostics: list[list[dict]] = [[{} for _ in range(bin_count)] for _ in slices]
        for slice_index, evidence_index in enumerate(indices):
            if evidence_index.original_tree is not None:
                original[slice_index] = (
                    evidence_index.original_tree.query(centers, k=1)[0]
                    <= float(cfg.get("shared_wall_original_vector_distance_m", 0.10))
                )
            for bin_index, center in enumerate(centers):
                value = _local_wall_evidence(
                    center,
                    direction,
                    evidence_index,
                    floor_m,
                    cfg,
                    float(widths[bin_index]),
                )
                diagnostics[slice_index][bin_index] = value
                observed[slice_index, bin_index] = bool(value["observed"])
                frozen[slice_index, bin_index] = bool(value["frozen"])
                base_bins[slice_index][bin_index] = set(value["height_bins"])
                sessions[slice_index][bin_index] = set(value["session_names"])
            observed[slice_index] = _remove_short_runs(
                observed[slice_index],
                widths,
                float(cfg.get("shared_wall_min_continuous_run_m", 0.15)),
            )
            for bin_index in range(bin_count):
                if diagnostics[slice_index][bin_index].get("observed") and not observed[
                    slice_index, bin_index
                ]:
                    diagnostics[slice_index][bin_index]["failure_reasons"] = [
                        "short_support_run"
                    ]
                if observed[slice_index, bin_index] and len(
                    sessions[slice_index][bin_index]
                ) == 1:
                    single_session_observed_length += float(widths[bin_index])
                if observed[slice_index, bin_index]:
                    continue
                for reason in diagnostics[slice_index][bin_index].get(
                    "failure_reasons", ["unknown_evidence_failure"]
                ):
                    failure_length_by_reason[reason] = failure_length_by_reason.get(
                        reason, 0.0
                    ) + float(widths[bin_index])

        inferred, inference_reasons = _infer_bounded_gaps(
            observed, base_bins, widths, cfg
        )
        recovered = observed & ~original
        strict_mask = np.all(observed, axis=0)

        global_sessions = set().union(
            *(sessions[slice_index][bin_index] for slice_index in range(len(slices)) for bin_index in range(bin_count))
        )
        global_height_bins = set().union(
            *(base_bins[slice_index][bin_index] for slice_index in range(len(slices)) for bin_index in range(bin_count))
        )
        vertical_span = (
            0.0
            if not global_height_bins
            else (max(global_height_bins) - min(global_height_bins) + 1)
            * float(cfg.get("shared_wall_z_voxel_m", 0.10))
        )
        required_vertical_span = min(
            float(cfg.get("architectural_min_vertical_span_m", 1.20)),
            max(0.0, ceiling_m - floor_m),
        )
        prevalidated_reliable = bool(
            source_classification == "building_wall"
            and int(wall.get("session_count", 0))
            >= int(cfg.get("shared_wall_reliable_min_sessions", 2))
            and float(wall.get("vertical_span_m", 0.0))
            >= required_vertical_span - 1e-9
        )
        reliable_wall = bool(
            prevalidated_reliable
            or (
                len(global_sessions)
                >= int(cfg.get("shared_wall_reliable_min_sessions", 2))
                and vertical_span >= required_vertical_span - 1e-9
            )
        )
        robust_minimum = max(
            1,
            int(
                math.ceil(
                    len(slices)
                    * float(
                        cfg.get(
                            "consensus_robust_intersection_min_fraction", 0.75
                        )
                    )
                    - 1e-12
                )
            ),
        )
        robust_axis_fraction = float(
            np.mean(np.sum(observed, axis=0) >= robust_minimum)
        )
        supplement_promoted = bool(
            source_classification == "unclassified_wall_candidate"
            and reliable_wall
            and float(wall.get("candidate_score", 0.0))
            >= float(cfg.get("shared_wall_supplement_min_score", 0.55))
            and robust_axis_fraction
            >= float(cfg.get("shared_wall_supplement_min_robust_fraction", 0.25))
        )
        if classification == "unclassified_wall_candidate":
            classification = (
                "building_wall" if supplement_promoted else "uncertain_detail"
            )
            if supplement_promoted:
                wall["selection_reasons"] = sorted(
                    set(wall.get("selection_reasons", []))
                    | {"v8_scored_cross_height_supplement"}
                )
        elif classification == "building_wall" and not reliable_wall:
            classification = "uncertain_detail"
        structural_union_eligible = classification in {
            "building_wall",
            "low_structure",
        }
        eligible_common = bool(
            reliable_wall and classification == "building_wall"
        )

        wall_id = str(wall.get("candidate_id") or f"V8W{wall_index:04d}")
        wall_segments = []
        cursor = 0
        segment_index = 0
        while cursor < bin_count:
            observed_indices = tuple(np.flatnonzero(observed[:, cursor]).tolist())
            inferred_indices = tuple(np.flatnonzero(inferred[:, cursor]).tolist())
            recovered_indices = tuple(np.flatnonzero(recovered[:, cursor]).tolist())
            key = (observed_indices, inferred_indices, recovered_indices)
            end = cursor + 1
            while end < bin_count:
                next_key = (
                    tuple(np.flatnonzero(observed[:, end]).tolist()),
                    tuple(np.flatnonzero(inferred[:, end]).tolist()),
                    tuple(np.flatnonzero(recovered[:, end]).tolist()),
                )
                if next_key != key:
                    break
                end += 1
            if observed_indices:
                start_m, end_m = float(boundaries[cursor]), float(boundaries[end])
                segment_line = LineString(
                    [origin + direction * start_m, origin + direction * end_m]
                )
                observed_list = list(observed_indices)
                inferred_list = list(inferred_indices)
                covered = sorted(set(observed_list) | set(inferred_list))
                unknown = [value for value in range(len(slices)) if value not in covered]
                ranges = _height_ranges(observed_list, slices)
                segment_sessions = {
                    str(slice_index): sorted(
                        set().union(
                            *(sessions[slice_index][value] for value in range(cursor, end))
                        )
                    )
                    for slice_index in observed_list
                }
                segment_base_bins = sorted(
                    set().union(
                        *(
                            base_bins[slice_index][value]
                            for slice_index in observed_list
                            for value in range(cursor, end)
                        )
                    )
                )
                reasons = sorted(
                    {
                        inference_reasons[(slice_index, value)]
                        for slice_index in inferred_list
                        for value in range(cursor, end)
                        if (slice_index, value) in inference_reasons
                    }
                )
                all_height_validated_supplement = bool(
                    source_classification == "unclassified_wall_candidate"
                    and reliable_wall
                    and len(observed_list) == len(slices)
                )
                segment_eligible_common = bool(
                    eligible_common or all_height_validated_supplement
                )
                segment_structural_eligible = bool(
                    structural_union_eligible or all_height_validated_supplement
                )
                value = {
                    "group": wall_index,
                    "wall_id": wall_id,
                    "source_wall_ids": list(wall.get("source_wall_ids", [wall_id])),
                    "segment_id": f"{wall_id}_V8S{segment_index:03d}",
                    "line_ref": segment_line,
                    "support_interval_m": [start_m, end_m],
                    "classification": (
                        "building_wall"
                        if all_height_validated_supplement
                        else classification
                    ),
                    "structural_selection_reason": (
                        "all_height_point_validated_supplement"
                        if all_height_validated_supplement
                        else "scored_shared_wall"
                    ),
                    "node_ids": [
                        f"N_{int(round(segment_line.coords[0][0] * 1000))}_{int(round(segment_line.coords[0][1] * 1000))}",
                        f"N_{int(round(segment_line.coords[-1][0] * 1000))}_{int(round(segment_line.coords[-1][1] * 1000))}",
                    ],
                    "z_min_m": float(min(value[0] for value in ranges)),
                    "z_max_m": float(max(value[1] for value in ranges)),
                    "observed_z_ranges_m": ranges,
                    "slice_indices": observed_list,
                    "recovered_slice_indices": list(recovered_indices),
                    "inferred_slice_indices": inferred_list,
                    "unknown_slice_indices": unknown,
                    "slice_fraction": float(len(observed_list) / len(slices)),
                    "height_state": _state_name(observed_list, len(slices)),
                    "is_strict_intersection": segment_eligible_common
                    and len(observed_list) == len(slices),
                    "is_calibrated_common": segment_eligible_common
                    and len(covered) == len(slices),
                    "recovery_method": (
                        "point_recovered" if recovered_indices else "original_vector_confirmed"
                    ),
                    "inference_reasons": reasons,
                    "source_sessions_by_slice": segment_sessions,
                    "observed_base_height_bins": segment_base_bins,
                    "wall_session_names": sorted(global_sessions),
                    "wall_vertical_span_m": float(vertical_span),
                    "reliable_building_wall": reliable_wall,
                    "confidence": float(len(observed_list) / len(slices)),
                }
                for node_id, coordinate in zip(
                    value["node_ids"], np.asarray(segment_line.coords, dtype=float)[[0, -1]]
                ):
                    graph_nodes[node_id] = list(map(float, coordinate))
                raw_union.append(value)
                if segment_structural_eligible:
                    union.append(value)
                wall_segments.append(
                    {
                        key: item
                        for key, item in value.items()
                        if key not in {"line_ref", "group"}
                    }
                )
                if segment_structural_eligible and value["is_calibrated_common"]:
                    common.append(value)
                for slice_index in recovered_indices:
                    for bin_index in range(cursor, end):
                        if not recovered[slice_index, bin_index]:
                            continue
                        diagnostic = diagnostics[slice_index][bin_index]
                        if diagnostic.get("axis_distance_m") is not None:
                            recovered_distances.append(diagnostic["axis_distance_m"])
                        if diagnostic.get("plane_rmse_m") is not None:
                            recovered_plane_rmse.append(diagnostic["plane_rmse_m"])
                        recovered_voxel_count += int(diagnostic.get("voxel_count", 0))
                segment_index += 1
            cursor = end

        wall["shared_wall_id"] = wall_id
        wall["v7_support_segments"] = wall_segments
        wall["slice_indices"] = sorted(
            {
                index
                for segment in wall_segments
                for index in segment.get("slice_indices", [])
            }
        )
        wall["classification"] = classification
        wall["session_support"] = sorted(global_sessions)
        wall["vertical_span_m"] = float(vertical_span)
        wall["reliable_building_wall"] = reliable_wall

        supported_intervals = sorted(
            (
                float(segment["support_interval_m"][0]),
                float(segment["support_interval_m"][1]),
            )
            for segment in wall_segments
        )
        merged_intervals: list[list[float]] = []
        for interval_start, interval_end in supported_intervals:
            if merged_intervals and interval_start <= merged_intervals[-1][1] + 0.001:
                merged_intervals[-1][1] = max(merged_intervals[-1][1], interval_end)
            else:
                merged_intervals.append([interval_start, interval_end])
        display_intervals = (
            [[0.0, length]]
            if source_classification == "building_wall"
            and classification == "building_wall"
            and wall_segments
            else merged_intervals
        )
        for part_index, (part_start, part_end) in enumerate(display_intervals):
            part_line = LineString(
                [origin + direction * part_start, origin + direction * part_end]
            )
            part = {
                **{key: item for key, item in wall.items() if key != "line_ref"},
                "candidate_id": f"{wall_id}_P{part_index:02d}",
                "shared_wall_id": wall_id,
                "line_ref": part_line,
                "support_interval_m": [part_start, part_end],
                # V7 node identity is derived from the final, fitted endpoint.
                # Reusing a pre-refit ID here made different endpoints claim the
                # same node even though no geometric connection existed.
                "node_ids": [
                    _coordinate_node_id(part_line.coords[0]),
                    _coordinate_node_id(part_line.coords[-1]),
                ],
                "v7_support_segments": [
                    segment
                    for segment in wall_segments
                    if segment["support_interval_m"][1] > part_start - 1e-9
                    and segment["support_interval_m"][0] < part_end + 1e-9
                ],
            }
            for node_id, coordinate in zip(
                part["node_ids"], np.asarray(part_line.coords, dtype=float)[[0, -1]]
            ):
                graph_nodes[node_id] = list(map(float, coordinate))
            graph_walls.append(part)
        support_records.append(
            {
                "wall_id": wall_id,
                "classification": classification,
                "length_m": length,
                "bin_edges_m": boundaries.tolist(),
                "states": [
                    [
                        (
                            "recovered"
                            if recovered[slice_index, bin_index]
                            else "observed"
                        )
                        if observed[slice_index, bin_index]
                        else (
                            "inferred"
                            if inferred[slice_index, bin_index]
                            else "unknown"
                        )
                        for bin_index in range(bin_count)
                    ]
                    for slice_index in range(len(slices))
                ],
                "failure_reasons": [
                    [
                        diagnostics[slice_index][bin_index].get(
                            "failure_reasons", []
                        )
                        if not observed[slice_index, bin_index]
                        else []
                        for bin_index in range(bin_count)
                    ]
                    for slice_index in range(len(slices))
                ],
                "session_names": [
                    [
                        sorted(sessions[slice_index][bin_index])
                        for bin_index in range(bin_count)
                    ]
                    for slice_index in range(len(slices))
                ],
            }
        )

    intersection = [
        value["line_ref"] for value in union if value["is_strict_intersection"]
    ]
    recovered_length = float(
        sum(
            value["line_ref"].length
            for value in union
            if value["recovered_slice_indices"]
        )
    )
    inferred_length = float(
        sum(
            value["line_ref"].length
            for value in common
            if value["inferred_slice_indices"]
        )
    )
    strict_length = float(sum(value.length for value in intersection))
    common_length = float(sum(value["line_ref"].length for value in common))
    frozen_common_length = float(sum(line.length for line in frozen_reference))
    frozen_common_coverage = _line_coverage_fraction(
        frozen_reference,
        intersection,
        float(cfg.get("shared_wall_validator_distance_m", 0.08)),
    )
    v6_valid_retention = _line_coverage_fraction(
        frozen_reference,
        intersection,
        float(cfg.get("shared_wall_v5_retention_tolerance_m", 0.15)),
    )
    accepted_refits = [value for value in refit_metrics if value.get("accepted")]
    prior_retention = _line_coverage_fraction(
        list(prior_intersection or bootstrap_intersection),
        intersection,
        float(cfg.get("shared_wall_v5_retention_tolerance_m", 0.15)),
    )
    metrics = {
        "shared_wall_strategy": "shared_wall_evidence_v8_scored_absorption",
        "shared_wall_candidate_count": len(candidates),
        "shared_wall_bootstrap_supplement_count": len(supplements),
        "shared_wall_candidate_duplicate_length_removed_m": float(
            candidate_duplicate_length
        ),
        "shared_wall_candidate_absorption": candidate_absorption,
        "shared_wall_raw_segment_count": len(raw_union),
        "shared_wall_raw_union_length_m": float(
            sum(value["line_ref"].length for value in raw_union)
        ),
        "shared_wall_structural_union_length_m": float(
            sum(value["line_ref"].length for value in union)
        ),
        "shared_wall_segment_count": len(union),
        "shared_wall_sample_step_m": step_m,
        "shared_wall_recovered_segment_length_m": recovered_length,
        "shared_wall_recovered_voxel_count": int(recovered_voxel_count),
        "shared_wall_recovered_axis_distance_p95_m": (
            None
            if not recovered_distances
            else float(np.quantile(np.asarray(recovered_distances), 0.95))
        ),
        "shared_wall_recovered_plane_rmse_p95_m": (
            None
            if not recovered_plane_rmse
            else float(np.quantile(np.asarray(recovered_plane_rmse), 0.95))
        ),
        "shared_wall_strict_intersection_length_m": strict_length,
        "shared_wall_calibrated_common_length_m": common_length,
        "shared_wall_inferred_common_length_m": inferred_length,
        "shared_wall_frozen_recoverable_length_m": frozen_common_length,
        "shared_wall_frozen_recoverable_coverage": frozen_common_coverage,
        "shared_wall_validator_independent_of_output_labels": True,
        "shared_wall_failure_length_by_reason_m": {
            key: float(value) for key, value in sorted(failure_length_by_reason.items())
        },
        "shared_wall_single_session_observed_length_m": float(
            single_session_observed_length
        ),
        "shared_wall_bounded_refit_candidate_count": len(refit_metrics),
        "shared_wall_bounded_refit_accepted_count": len(accepted_refits),
        "shared_wall_bounded_refit_max_angle_deg": (
            0.0
            if not accepted_refits
            else float(max(abs(value["angle_change_deg"]) for value in accepted_refits))
        ),
        "shared_wall_bounded_refit_max_offset_m": (
            0.0
            if not accepted_refits
            else float(max(abs(value["offset_change_m"]) for value in accepted_refits))
        ),
        "shared_wall_recreated_node_count": int(shared_node_update_count),
        "shared_wall_v5_strict_retention_fraction": v6_valid_retention,
        "shared_wall_v6_strict_retention_fraction": prior_retention,
        "shared_wall_v6_raw_strict_retention_fraction": prior_retention,
        "shared_wall_v6_valid_strict_retention_fraction": v6_valid_retention,
        "shared_wall_prior_strict_retention_fraction": prior_retention,
        "shared_wall_unknown_length_m": float(
            sum(
                value["line_ref"].length
                for value in union
                if value["unknown_slice_indices"]
            )
        ),
    }
    return SharedWallRecovery(
        union=union,
        intersection=intersection,
        calibrated_common=common,
        support_records=support_records,
        metrics=metrics,
        graph=SharedWallGraph(
            walls=graph_walls,
            segments=raw_union,
            nodes=graph_nodes,
        ),
        raw_union=raw_union,
    )
