from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

from .cloud import level_cloud, read_trajectory_pose, trajectory_quality, vertical_structural_cells, voxel_downsample
from .errors import DataQualityError


def estimate_wall_thickness(structural_xy: np.ndarray, sample_count: int = 1500) -> float:
    xy = np.unique(np.round(structural_xy, 3), axis=0)
    if len(xy) < 30:
        return float("inf")
    rng = np.random.default_rng(23)
    if len(xy) > sample_count:
        xy = xy[rng.choice(len(xy), sample_count, replace=False)]
    tree = cKDTree(structural_xy)
    _, neighborhoods = tree.query(xy, k=min(16, len(structural_xy)))
    widths = []
    for indices in np.atleast_2d(neighborhoods):
        local = structural_xy[indices]
        values = np.linalg.eigvalsh(np.cov(local.T))
        widths.append(2.355 * math.sqrt(max(0.0, float(values[0]))))
    return float(np.median(widths))


def assess_session(points: np.ndarray, trajectory_path: str | Path | None, cfg: dict) -> tuple[dict, object]:
    if not len(points) or not np.all(np.isfinite(points)):
        raise DataQualityError("Map is empty or contains non-finite coordinates")
    leveled = level_cloud(points)
    structure_cfg = cfg["structure"]
    max_height = float(structure_cfg["max_height_m"])
    if leveled.ceiling_height_m is not None:
        max_height = min(max_height, leveled.ceiling_height_m - float(structure_cfg["ceiling_margin_m"]))
    structural, cells = vertical_structural_cells(
        leveled.points,
        float(structure_cfg["grid_m"]),
        float(structure_cfg["height_bin_m"]),
        float(structure_cfg["min_height_m"]),
        max_height,
        float(structure_cfg["vertical_span_m"]),
        int(structure_cfg["min_height_bins"]),
    )
    if len(structural) < 100:
        raise DataQualityError("Map has insufficient vertically continuous structure")
    wall_thickness = estimate_wall_thickness(structural[:, :2])
    coverage = len(cells) * float(structure_cfg["grid_m"]) ** 2
    trajectory_report = None
    pose = read_trajectory_pose(trajectory_path)
    if pose is not None:
        timestamps, xyz, quaternions = pose
        trajectory_report = trajectory_quality(
            timestamps,
            xyz,
            float(cfg["slam"]["max_pose_jump_m"]),
            quaternions,
            float(cfg["slam"]["max_pose_jump_deg"]),
        )
        if not trajectory_report["continuous"]:
            raise DataQualityError(f"Trajectory failed continuity gate: {trajectory_report}")
    score = math.log1p(coverage) - 20.0 * leveled.floor.rmse_m - 2.0 * min(wall_thickness, 1.0)
    report = {
        "valid": True,
        "point_count": int(len(points)),
        "floor_rmse_m": leveled.floor.rmse_m,
        "floor_inlier_count": leveled.floor.inlier_count,
        "ceiling_height_m": leveled.ceiling_height_m,
        "wall_thickness_m": wall_thickness,
        "structural_coverage_m2": coverage,
        "trajectory": trajectory_report,
        "score": score,
    }
    return report, leveled

