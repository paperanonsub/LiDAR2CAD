from __future__ import annotations

import json
import math
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString
from shapely.ops import transform as shapely_transform

from .errors import PipelineError
from .io import fingerprint, read_json, write_json
from .transforms import transform_points

if TYPE_CHECKING:
    from .vectorize import OutlineResult


_WALL_RE = re.compile(r"wall_(\d+)\s*=\s*Wall\(([^)]*)\)", re.IGNORECASE)
_FIXTURE_RE = re.compile(
    r"(door|window)_(\d+)\s*=\s*(?:Door|Window)\(wall_(\d+)\s*,\s*([^)]*)\)",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class SpatialWall:
    tile: str
    wall_id: int
    line_cad: LineString
    z_m: float
    height_m: float
    thickness_m: float


@dataclass(frozen=True)
class SpatialFixture:
    tile: str
    kind: str
    fixture_id: int
    wall_id: int
    center_cad: np.ndarray
    width_m: float
    height_m: float


@dataclass
class DeepLayoutPrediction:
    walls: list[SpatialWall]
    doors: list[SpatialFixture]
    windows: list[SpatialFixture]
    tile_count: int
    raw_text_files: list[str]


def _float_values(value: str) -> list[float]:
    values: list[float] = []
    for part in value.split(","):
        try:
            values.append(float(part.strip()))
        except ValueError:
            return []
    return values


def parse_spatiallm_layout(text: str, tile: str = "tile") -> tuple[list[SpatialWall], list[SpatialFixture], list[SpatialFixture]]:
    """Parse SpatialLM's deterministic language layout without executing it."""
    walls: list[SpatialWall] = []
    doors: list[SpatialFixture] = []
    windows: list[SpatialFixture] = []
    for match in _WALL_RE.finditer(text):
        values = _float_values(match.group(2))
        if len(values) != 8:
            continue
        ax, ay, az, bx, by, bz, height, thickness = values
        line = LineString([(ax, ay), (bx, by)])
        if not line.is_valid or line.length <= 1e-6:
            continue
        walls.append(
            SpatialWall(
                tile=tile,
                wall_id=int(match.group(1)),
                line_cad=line,
                z_m=float((az + bz) / 2),
                height_m=float(height),
                thickness_m=abs(float(thickness)),
            )
        )
    for match in _FIXTURE_RE.finditer(text):
        values = _float_values(match.group(4))
        if len(values) != 5:
            continue
        x, y, z, width, height = values
        fixture = SpatialFixture(
            tile=tile,
            kind=match.group(1).upper(),
            fixture_id=int(match.group(2)),
            wall_id=int(match.group(3)),
            center_cad=np.asarray([x, y, z], dtype=float),
            width_m=abs(float(width)),
            height_m=abs(float(height)),
        )
        (doors if fixture.kind == "DOOR" else windows).append(fixture)
    return walls, doors, windows


def _write_binary_ply(path: Path, points: np.ndarray) -> None:
    """Write XYZ-only PLY. SpatialLM intentionally sees the same zero RGB as raw LiDAR."""
    finite = np.asarray(points, dtype=np.float32)
    finite = finite[np.all(np.isfinite(finite), axis=1)]
    header = (
        "ply\n"
        "format binary_little_endian 1.0\n"
        f"element vertex {len(finite)}\n"
        "property float x\n"
        "property float y\n"
        "property float z\n"
        "end_header\n"
    ).encode("ascii")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as stream:
        stream.write(header)
        stream.write(finite.astype("<f4", copy=False).tobytes(order="C"))


def _voxel_sample(points: np.ndarray, voxel_m: float, max_points: int) -> np.ndarray:
    keys = np.floor(points / voxel_m).astype(np.int64)
    _, index = np.unique(keys, axis=0, return_index=True)
    sampled = points[np.sort(index)]
    if len(sampled) > max_points:
        rng = np.random.default_rng(23)
        sampled = sampled[np.sort(rng.choice(len(sampled), max_points, replace=False))]
    return sampled


def build_spatiallm_tiles(
    points_ref: np.ndarray,
    transform_cad_from_ref: np.ndarray,
    output_dir: str | Path,
    cfg: dict,
) -> dict:
    """Create overlapping <=32 m point-cloud tiles required by SpatialLM."""
    output_dir = Path(output_dir)
    tile_dir = output_dir / "tiles"
    tile_dir.mkdir(parents=True, exist_ok=True)
    points_cad = transform_points(points_ref, transform_cad_from_ref)
    points_cad = points_cad[
        np.all(np.isfinite(points_cad), axis=1)
        & (points_cad[:, 2] >= float(cfg.get("min_z_m", -0.15)))
        & (points_cad[:, 2] <= float(cfg.get("max_z_m", 3.20)))
    ]
    if not len(points_cad):
        raise PipelineError("No finite points are available for deep-layout inference")

    tile_size = min(31.0, float(cfg.get("tile_size_m", 27.0)))
    overlap = float(cfg.get("tile_overlap_m", 7.0))
    if tile_size <= 4.0 or overlap < 0 or overlap >= tile_size:
        raise PipelineError("deep_layout tile_size_m/tile_overlap_m are invalid")
    stride = tile_size - overlap
    min_points = int(cfg.get("min_tile_points", 8_000))
    max_points = int(cfg.get("max_tile_points", 220_000))
    voxel_m = float(cfg.get("input_voxel_m", 0.035))

    lower = np.percentile(points_cad[:, :2], 0.05, axis=0)
    upper = np.percentile(points_cad[:, :2], 99.95, axis=0)

    def starts(lo: float, hi: float) -> list[float]:
        if hi - lo <= tile_size:
            return [float(lo)]
        gap_count = int(math.ceil((hi - lo - tile_size) / stride))
        values = np.linspace(lo, hi - tile_size, gap_count + 1).tolist()
        return sorted(set(round(value, 6) for value in values))

    tiles: list[dict] = []
    for row, y0 in enumerate(starts(float(lower[1]), float(upper[1]))):
        for col, x0 in enumerate(starts(float(lower[0]), float(upper[0]))):
            x1, y1 = x0 + tile_size, y0 + tile_size
            keep = (
                (points_cad[:, 0] >= x0)
                & (points_cad[:, 0] <= x1)
                & (points_cad[:, 1] >= y0)
                & (points_cad[:, 1] <= y1)
            )
            tile_points = points_cad[keep]
            if len(tile_points) < min_points:
                continue
            tile_points = _voxel_sample(tile_points, voxel_m, max_points)
            name = f"tile_r{row:02d}_c{col:02d}"
            path = tile_dir / f"{name}.ply"
            _write_binary_ply(path, tile_points)
            tiles.append(
                {
                    "name": name,
                    "path": str(path.resolve()),
                    "bounds_cad": [x0, y0, x1, y1],
                    "point_count": int(len(tile_points)),
                }
            )
    if not tiles:
        raise PipelineError("Deep-layout tiling rejected every point-cloud tile")
    expected_names = {Path(tile["path"]).name for tile in tiles}
    for stale in tile_dir.glob("tile_*.ply"):
        if stale.name not in expected_names:
            stale.unlink()
    manifest = {
        "backend": "SpatialLM1.1-Qwen-0.5B",
        "tile_size_m": tile_size,
        "tile_overlap_m": overlap,
        "input_voxel_m": voxel_m,
        "tiles": tiles,
    }
    write_json(output_dir / "tiles.json", manifest)
    return manifest


def _auto_path(cfg: dict, key: str, relative: str) -> Path:
    configured = cfg.get(key)
    if configured:
        return Path(os.path.expandvars(str(configured))).expanduser().resolve()
    return (Path(os.environ.get("LOCALAPPDATA", Path.home())) / "lidar2outline" / relative).resolve()


def run_spatiallm_inference(
    manifest: dict,
    output_dir: str | Path,
    cfg: dict,
    force: bool = False,
) -> list[Path]:
    output_dir = Path(output_dir)
    predictions = output_dir / "predictions"
    predictions.mkdir(parents=True, exist_ok=True)
    expected = [predictions / f"{tile['name']}.txt" for tile in manifest["tiles"]]
    model_path = _auto_path(cfg, "model_path", "models/SpatialLM1.1-Qwen-0.5B")
    repo_path = _auto_path(cfg, "repo_path", "models/SpatialLM")
    python_path = _auto_path(cfg, "python", "envs/spatiallm/python.exe")
    runner = Path(__file__).resolve().parents[1] / "scripts" / "spatiallm_infer.py"
    required = [model_path / "model.safetensors", repo_path / "spatiallm", python_path, runner]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise PipelineError("SpatialLM runtime is incomplete:\n" + "\n".join(missing))

    digest = fingerprint(
        [tile["path"] for tile in manifest["tiles"]] + [model_path / "model.safetensors"],
        {
            "backend": "spatiallm1.1-qwen-0.5b",
            "seed": int(cfg.get("seed", 23)),
            "patch_size": int(cfg.get("attention_patch_size", 256)),
            "max_new_tokens": int(cfg.get("max_new_tokens", 2048)),
            "model_max_points": int(cfg.get("model_max_points", 100_000)),
            "retries": int(cfg.get("inference_retries", 4)),
            "min_walls": int(cfg.get("min_predicted_walls", 6)),
        },
        "deep-layout-v4-stable-adaptive-density",
    )
    cache = output_dir / "inference.manifest.json"
    if not force and cache.is_file() and all(path.is_file() for path in expected):
        cached = read_json(cache)
        if cached.get("fingerprint") == digest:
            return expected

    command = [
        str(python_path),
        str(runner),
        "--repo",
        str(repo_path),
        "--model",
        str(model_path),
        "--input-dir",
        str(Path(manifest["tiles"][0]["path"]).parent),
        "--output-dir",
        str(predictions),
        "--seed",
        str(int(cfg.get("seed", 23))),
        "--patch-size",
        str(int(cfg.get("attention_patch_size", 256))),
        "--max-new-tokens",
        str(int(cfg.get("max_new_tokens", 2048))),
        "--max-points",
        str(int(cfg.get("model_max_points", 100_000))),
        "--retries",
        str(int(cfg.get("inference_retries", 4))),
        "--min-walls",
        str(int(cfg.get("min_predicted_walls", 6))),
    ]
    log_path = output_dir / "spatiallm.log"
    environment = os.environ.copy()
    environment.setdefault("PYTHONUTF8", "1")
    environment.setdefault("PYTHONUNBUFFERED", "1")
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=environment, check=False)
    if process.returncode != 0:
        tail = "\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-40:])
        raise PipelineError(f"SpatialLM inference failed ({process.returncode}):\n{tail}")
    missing_outputs = [str(path) for path in expected if not path.is_file()]
    if missing_outputs:
        raise PipelineError("SpatialLM did not create all tile predictions:\n" + "\n".join(missing_outputs))
    expected_names = {path.name for path in expected}
    for stale in predictions.glob("tile_*.txt"):
        if stale.name not in expected_names:
            stale.unlink()
    write_json(cache, {"fingerprint": digest, "outputs": [str(path) for path in expected]})
    return expected


def load_spatiallm_predictions(paths: list[str | Path]) -> DeepLayoutPrediction:
    walls: list[SpatialWall] = []
    doors: list[SpatialFixture] = []
    windows: list[SpatialFixture] = []
    files: list[str] = []
    for value in paths:
        path = Path(value)
        tile = path.stem
        parsed = parse_spatiallm_layout(path.read_text(encoding="utf-8", errors="replace"), tile)
        walls.extend(parsed[0])
        doors.extend(parsed[1])
        windows.extend(parsed[2])
        files.append(str(path.resolve()))
    return DeepLayoutPrediction(walls, doors, windows, len(paths), files)


def _transform_geometry(geometry, matrix: np.ndarray):
    def fn(x, y, z=None):
        values = np.column_stack([np.asarray(x), np.asarray(y), np.zeros_like(np.asarray(x))])
        output = transform_points(values, matrix)
        return output[:, 0], output[:, 1]

    return shapely_transform(fn, geometry)


def _line_angle(line: LineString) -> float:
    values = np.asarray(line.coords, dtype=float)
    delta = values[-1] - values[0]
    return math.atan2(float(delta[1]), float(delta[0]))


def _angle_difference(a: float, b: float) -> float:
    return abs((a - b + math.pi / 2) % math.pi - math.pi / 2)


def _mask_points(result: "OutlineResult") -> np.ndarray:
    yx = np.column_stack(np.nonzero(result.raster > 0))
    return result.raster_origin + (yx[:, ::-1] + 0.5) * result.grid_m


def _refine_candidate(
    line: LineString,
    wall_xy: np.ndarray,
    wall_tree: cKDTree,
    main_angle: float | None,
    cfg: dict,
) -> tuple[LineString, float] | None:
    values = np.asarray(line.coords, dtype=float)
    a, b = values[0], values[-1]
    delta = b - a
    length = float(np.linalg.norm(delta))
    min_length = float(cfg.get("deep_wall_min_length_m", 0.65))
    if length < min_length or length > float(cfg.get("deep_wall_max_length_m", 35.0)):
        return None
    direction = delta / length
    angle = math.atan2(float(direction[1]), float(direction[0]))
    if main_angle is not None:
        frames = [main_angle, main_angle + math.pi / 2]
        nearest = min(frames, key=lambda candidate: _angle_difference(angle, candidate))
        if _angle_difference(angle, nearest) <= math.radians(float(cfg.get("deep_snap_angle_deg", 8.0))):
            direction = np.asarray([math.cos(nearest), math.sin(nearest)])
    normal = np.asarray([-direction[1], direction[0]])
    center = (a + b) / 2
    relative = wall_xy - center
    along = relative @ direction
    across = relative @ normal
    support_distance = float(cfg.get("deep_wall_fit_distance_m", 0.25))
    extension = float(cfg.get("deep_wall_endpoint_extension_m", 0.45))
    selected = (np.abs(across) <= support_distance) & (along >= -length / 2 - extension) & (along <= length / 2 + extension)
    if int(np.count_nonzero(selected)) < int(cfg.get("deep_wall_min_support_cells", 12)):
        return None
    along_support = along[selected]
    across_support = across[selected]
    # Trim isolated points, then estimate a wall centre. If two LiDAR-visible
    # faces are present, their dominant offsets are averaged.
    lo_q, hi_q = np.percentile(across_support, [5, 95])
    trimmed = across_support[(across_support >= lo_q) & (across_support <= hi_q)]
    bins = max(3, int(math.ceil(2 * support_distance / 0.025)))
    hist, edges = np.histogram(trimmed, bins=bins, range=(-support_distance, support_distance))
    peak_order = np.argsort(hist)[::-1]
    offset = float(np.median(trimmed))
    if len(peak_order) >= 2 and hist[peak_order[0]] > 0:
        first = float((edges[peak_order[0]] + edges[peak_order[0] + 1]) / 2)
        second = None
        for index in peak_order[1:]:
            candidate = float((edges[index] + edges[index + 1]) / 2)
            separation = abs(candidate - first)
            if 0.06 <= separation <= 0.35 and hist[index] >= 0.25 * hist[peak_order[0]]:
                second = candidate
                break
        offset = first if second is None else (first + second) / 2
    refined_center = center + normal * offset
    observed_lo, observed_hi = np.percentile(along_support, [1, 99])
    start = max(-length / 2 - extension, min(-length / 2, float(observed_lo)))
    end = min(length / 2 + extension, max(length / 2, float(observed_hi)))
    refined = LineString([refined_center + direction * start, refined_center + direction * end])
    sample_count = max(2, int(math.ceil(refined.length / 0.05)) + 1)
    samples = np.asarray([refined.interpolate(i / (sample_count - 1), normalized=True).coords[0] for i in range(sample_count)])
    distances, _ = wall_tree.query(samples)
    support = float(np.mean(distances <= float(cfg.get("deep_wall_verify_distance_m", 0.15))))
    if support < float(cfg.get("deep_wall_min_support_fraction", 0.55)):
        return None
    return refined, support


def _deduplicate_lines(lines: list[LineString], cfg: dict) -> list[LineString]:
    """Merge repeated tile predictions while preserving distinct wall faces."""
    angle_tolerance = math.radians(float(cfg.get("deep_merge_angle_deg", 2.0)))
    offset_tolerance = float(cfg.get("deep_merge_offset_m", 0.16))
    gap = float(cfg.get("deep_merge_gap_m", 0.35))
    groups: list[dict] = []
    for line in sorted(lines, key=lambda value: value.length, reverse=True):
        values = np.asarray(line.coords, dtype=float)
        angle = (_line_angle(line) + math.pi / 2) % math.pi - math.pi / 2
        direction = np.asarray([math.cos(angle), math.sin(angle)])
        normal = np.asarray([-direction[1], direction[0]])
        offset = float(normal @ np.mean(values, axis=0))
        interval = sorted([float(direction @ values[0]), float(direction @ values[-1])])
        target = None
        for group in groups:
            overlaps = interval[0] <= group["max"] + gap and interval[1] >= group["min"] - gap
            if overlaps and _angle_difference(angle, group["angle"]) <= angle_tolerance and abs(offset - group["offset"]) <= offset_tolerance:
                target = group
                break
        if target is None:
            groups.append(
                {
                    "angle": angle,
                    "offset": offset,
                    "weight": line.length,
                    "min": interval[0],
                    "max": interval[1],
                }
            )
        else:
            total = target["weight"] + line.length
            target["offset"] = (target["offset"] * target["weight"] + offset * line.length) / total
            target["weight"] = total
            target["min"] = min(target["min"], interval[0])
            target["max"] = max(target["max"], interval[1])
    result: list[LineString] = []
    for group in groups:
        direction = np.asarray([math.cos(group["angle"]), math.sin(group["angle"])])
        normal = np.asarray([-direction[1], direction[0]])
        result.append(
            LineString(
                [
                    direction * group["min"] + normal * group["offset"],
                    direction * group["max"] + normal * group["offset"],
                ]
            )
        )
    return result


def _supplement_uncovered(deep_lines: list[LineString], baseline: list[LineString], cfg: dict) -> list[LineString]:
    if not deep_lines:
        return list(baseline)
    distance = float(cfg.get("deep_baseline_coverage_m", 0.22))
    samples: list[tuple[float, float]] = []
    for line in deep_lines:
        count = max(2, int(math.ceil(line.length / 0.10)) + 1)
        samples.extend(line.interpolate(i / (count - 1), normalized=True).coords[0] for i in range(count))
    tree = cKDTree(np.asarray(samples))
    output = list(deep_lines)
    for line in baseline:
        count = max(2, int(math.ceil(line.length / 0.10)) + 1)
        points = np.asarray([line.interpolate(i / (count - 1), normalized=True).coords[0] for i in range(count)])
        nearest, _ = tree.query(points)
        if float(np.mean(nearest <= distance)) < float(cfg.get("deep_baseline_covered_fraction", 0.65)):
            output.append(line)
    return output


def _fixture_lines(
    fixtures: list[SpatialFixture],
    prediction: DeepLayoutPrediction,
    transform_ref_from_cad: np.ndarray,
    refined_lines_ref: list[LineString],
) -> list[LineString]:
    wall_lookup = {(wall.tile, wall.wall_id): wall for wall in prediction.walls}
    result: list[LineString] = []
    for fixture in fixtures:
        if not 0.35 <= fixture.width_m <= 4.0:
            continue
        wall = wall_lookup.get((fixture.tile, fixture.wall_id))
        if wall is None:
            continue
        direction = np.asarray(wall.line_cad.coords[-1]) - np.asarray(wall.line_cad.coords[0])
        norm = float(np.linalg.norm(direction))
        if norm <= 1e-9:
            continue
        direction /= norm
        center = fixture.center_cad[:2]
        raw = LineString([center - direction * fixture.width_m / 2, center + direction * fixture.width_m / 2])
        line_ref = _transform_geometry(raw, transform_ref_from_cad)
        if not refined_lines_ref:
            continue
        nearest = min(refined_lines_ref, key=lambda value: value.distance(line_ref.centroid))
        if nearest.distance(line_ref.centroid) > 0.30:
            continue
        coords = np.asarray(nearest.coords, dtype=float)
        wall_direction = coords[-1] - coords[0]
        wall_direction /= max(1e-9, float(np.linalg.norm(wall_direction)))
        projected = nearest.interpolate(nearest.project(line_ref.centroid))
        middle = np.asarray(projected.coords[0])
        line_ref = LineString(
            [middle - wall_direction * fixture.width_m / 2, middle + wall_direction * fixture.width_m / 2]
        )
        result.append(line_ref)
    return _deduplicate_lines(result, {"deep_merge_offset_m": 0.20, "deep_merge_gap_m": 0.10})


def enhance_outline_with_deep_layout(
    result: "OutlineResult",
    prediction: DeepLayoutPrediction,
    cfg: dict,
) -> "OutlineResult":
    """Fuse neural topology with metric LiDAR evidence; LiDAR remains authoritative."""
    from .vectorize import _snap_line_junctions, _straight_line_metrics

    wall_xy = _mask_points(result)
    if not len(wall_xy):
        raise PipelineError("Structural raster is empty during deep-layout fusion")
    wall_tree = cKDTree(wall_xy)
    main_deg = result.metrics.get("detail_main_direction_deg")
    main_angle = None if main_deg is None else math.radians(float(main_deg))
    refined: list[LineString] = []
    support_values: list[float] = []
    rejected = 0
    for wall in prediction.walls:
        if wall.height_m < float(cfg.get("deep_wall_min_height_m", 1.5)) or abs(wall.z_m) > 0.75:
            rejected += 1
            continue
        candidate_ref = _transform_geometry(wall.line_cad, result.transform_ref_from_cad)
        fitted = _refine_candidate(candidate_ref, wall_xy, wall_tree, main_angle, cfg)
        if fitted is None:
            rejected += 1
            continue
        refined.append(fitted[0])
        support_values.append(fitted[1])
    refined = _deduplicate_lines(refined, cfg)
    combined = _supplement_uncovered(refined, result.wall_centerlines_ref, cfg)
    combined = _deduplicate_lines(combined, cfg)
    combined = _snap_line_junctions(combined, float(cfg.get("deep_junction_tolerance_m", 0.32)))

    baseline_metrics = _straight_line_metrics(
        result.wall_centerlines_ref, result.raster, result.raster_origin, result.grid_m
    )
    deep_metrics = _straight_line_metrics(combined, result.raster, result.raster_origin, result.grid_m)
    baseline_structural_metrics = _straight_line_metrics(
        result.wall_centerlines_ref,
        result.structural_raster,
        result.structural_raster_origin,
        result.structural_grid_m,
    )
    deep_structural_metrics = _straight_line_metrics(
        combined,
        result.structural_raster,
        result.structural_raster_origin,
        result.structural_grid_m,
    )
    baseline_structural_coverage = float(
        baseline_structural_metrics.get("straight_wall_evidence_coverage_fraction", 0.0)
    )
    deep_structural_coverage = float(
        deep_structural_metrics.get("straight_wall_evidence_coverage_fraction", 0.0)
    )
    baseline_coverage = float(baseline_metrics.get("straight_wall_evidence_coverage_fraction", 0.0))
    deep_coverage = float(deep_metrics.get("straight_wall_evidence_coverage_fraction", 0.0))
    accurate = (
        deep_metrics.get("straight_wall_distance_median_m") is not None
        and float(deep_metrics["straight_wall_distance_median_m"]) <= float(cfg.get("max_median_error_m", 0.10))
        and float(deep_metrics["straight_wall_distance_p95_m"]) <= float(cfg.get("max_p95_error_m", 0.20))
        and float(deep_metrics["straight_wall_support_fraction"]) >= float(cfg.get("min_support_fraction", 0.80))
    )
    improved = deep_coverage >= baseline_coverage - float(cfg.get("max_coverage_regression", 0.01))
    accepted = bool(cfg.get("wall_fusion_enabled", True) and refined and accurate and improved)
    if accepted:
        result.wall_centerlines_ref = combined
        result.wall_centerlines_cad = [
            _transform_geometry(line, result.transform_cad_from_ref) for line in combined
        ]
        result.metrics.update(deep_metrics)
        result.metrics["wall_centerline_count"] = len(combined)
        result.metrics["straight_wall_structural_evidence_coverage_fraction"] = deep_structural_coverage
    else:
        result.metrics["straight_wall_structural_evidence_coverage_fraction"] = baseline_structural_coverage
    # Fixture semantics are independently useful even when the neural wall
    # geometry loses to the LiDAR baseline.  A fixture is retained only after
    # projection onto a verified final wall within 30 cm.
    fixture_walls = result.wall_centerlines_ref
    result.doors_ref = _fixture_lines(
        prediction.doors, prediction, result.transform_ref_from_cad, fixture_walls
    )
    result.windows_ref = _fixture_lines(
        prediction.windows, prediction, result.transform_ref_from_cad, fixture_walls
    )
    result.doors_cad = [
        _transform_geometry(line, result.transform_cad_from_ref) for line in result.doors_ref
    ]
    result.windows_cad = [
        _transform_geometry(line, result.transform_cad_from_ref) for line in result.windows_ref
    ]
    fixture_accepted = bool(result.doors_ref or result.windows_ref)
    result.metrics.update(
        {
            "deep_layout_backend": "SpatialLM1.1-Qwen-0.5B",
            "deep_layout_tile_count": prediction.tile_count,
            "deep_layout_raw_wall_count": len(prediction.walls),
            "deep_layout_refined_wall_count": len(refined),
            "deep_layout_rejected_wall_count": rejected,
            "deep_layout_accepted": accepted or fixture_accepted,
            "deep_layout_wall_fusion_accepted": accepted,
            "deep_layout_fixture_fusion_accepted": fixture_accepted,
            "deep_layout_mean_wall_support": float(np.mean(support_values)) if support_values else 0.0,
            "deep_layout_baseline_evidence_coverage": baseline_coverage,
            "deep_layout_fused_evidence_coverage": deep_coverage,
            "deep_layout_baseline_structural_coverage": baseline_structural_coverage,
            "deep_layout_fused_structural_coverage": deep_structural_coverage,
            "deep_layout_candidate_median_error_m": deep_metrics.get("straight_wall_distance_median_m"),
            "deep_layout_candidate_p95_error_m": deep_metrics.get("straight_wall_distance_p95_m"),
            "deep_layout_candidate_support_fraction": deep_metrics.get("straight_wall_support_fraction", 0.0),
            "deep_layout_door_count": len(result.doors_ref),
            "deep_layout_window_count": len(result.windows_ref),
            "deep_layout_final_wall_count": len(result.wall_centerlines_ref),
        }
    )
    return result


def run_deep_layout_stage(
    result: "OutlineResult",
    output_dir: str | Path,
    cfg: dict,
    force: bool = False,
) -> "OutlineResult":
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest = build_spatiallm_tiles(
        result.detail_points_ref,
        result.transform_cad_from_ref,
        output_dir,
        cfg,
    )
    prediction_paths = run_spatiallm_inference(manifest, output_dir, cfg, force)
    prediction = load_spatiallm_predictions(prediction_paths)
    write_json(
        output_dir / "prediction_summary.json",
        {
            "tile_count": prediction.tile_count,
            "wall_count": len(prediction.walls),
            "door_count": len(prediction.doors),
            "window_count": len(prediction.windows),
            "files": prediction.raw_text_files,
        },
    )
    return enhance_outline_with_deep_layout(result, prediction, cfg)
