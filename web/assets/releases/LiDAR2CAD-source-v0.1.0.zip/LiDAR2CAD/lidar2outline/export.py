from __future__ import annotations

import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Iterable

import ezdxf
from pyproj import CRS, Transformer
from shapely.geometry import LineString, Polygon, mapping, shape

from .errors import PipelineError
from .io import write_json
from .transforms import matrix_json
from .vectorize import OutlineResult


def _feature(geometry, klass: str, level: str, confidence: float, **properties) -> dict:
    return {
        "type": "Feature",
        "geometry": mapping(geometry),
        "properties": {
            "class": klass,
            "level": str(level),
            "confidence": float(confidence),
            **properties,
        },
    }


def export_geojson(path: str | Path, result: OutlineResult, level: str, confidence: float) -> None:
    features = [_feature(result.shell_cad, "OUTER_SHELL", level, confidence, indoor="wall")]
    features.extend(
        _feature(poly, "WALL_FOOTPRINT", level, confidence * 0.70, indoor="wall", area="yes", inferred=True)
        for poly in result.wall_polygons_cad
    )
    features.extend(
        _feature(line, "WALL", level, confidence * 0.90, indoor="wall", geometry_model="straight_fitted_line")
        for line in result.wall_centerlines_cad
    )
    features.extend(
        _feature(line, "DOOR", level, confidence * 0.85, door="yes", geometry_model="spatiallm_lidar_refined")
        for line in result.doors_cad
    )
    features.extend(
        _feature(line, "WINDOW", level, confidence * 0.80, window="yes", geometry_model="spatiallm_lidar_refined")
        for line in result.windows_cad
    )
    features.extend(
        _feature(
            line,
            "SCAN_DETAIL",
            level,
            confidence * 0.55,
            indoor="wall",
            inferred=True,
            verification="required",
        )
        for line in result.scan_detail_lines_cad
    )
    features.extend(
        _feature(poly, "SPACE", level, confidence * space_confidence, indoor="room", inferred=True)
        for poly, space_confidence in result.spaces_cad
    )
    features.extend(_feature(poly, klass, level, confidence * object_confidence) for klass, poly, object_confidence in result.internals_cad)
    collection = {
        "type": "FeatureCollection",
        "name": "indoor_structural_outline",
        "local_coordinate_system": {
            "units": "metre",
            "axes": "right-handed XY floor plane; longest main wall aligned with +X",
            "level": str(level),
            "T_cad_reference_slam": matrix_json(result.transform_cad_from_ref),
            "T_reference_slam_cad": matrix_json(result.transform_ref_from_cad),
            "warning": "Coordinates are local metric values, not longitude/latitude.",
        },
        "features": features,
    }
    write_json(path, collection)


def _add_polyline(layout, polygon: Polygon, layer: str) -> None:
    rings = [polygon.exterior, *polygon.interiors]
    for ring in rings:
        coordinates = [(float(x), float(y)) for x, y in ring.coords[:-1]]
        if len(coordinates) >= 3:
            layout.add_lwpolyline(coordinates, close=True, dxfattribs={"layer": layer})


def _add_line(layout, line: LineString, layer: str) -> None:
    coordinates = [(float(x), float(y)) for x, y in line.coords]
    if len(coordinates) >= 2:
        layout.add_lwpolyline(coordinates, close=False, dxfattribs={"layer": layer})


def export_dxf(path: str | Path, result: OutlineResult) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6  # metres
    colors = {
        "OUTER_SHELL": 4,
        "WALL": 7,
        "DOOR": 3,
        "WINDOW": 5,
        "WALL_FOOTPRINT": 8,
        "SCAN_DETAIL": 9,
        "SPACE": 6,
        "COLUMN": 2,
        "CORE": 1,
    }
    for layer, color in colors.items():
        if layer not in document.layers:
            document.layers.add(layer, color=color)
    # Keep diagnostic/inferred layers available without obscuring the surveyed
    # wall-footprint geometry when the drawing is first opened.
    document.layers.get("WALL_FOOTPRINT").off()
    document.layers.get("SCAN_DETAIL").off()
    document.layers.get("SPACE").off()
    # Direct prediction vectorization already contains the exterior wall
    # centre-lines.  Keep OUTER_SHELL in the deliverable for topology/GIS use,
    # but hide the older envelope by default so it cannot obscure the wall
    # network that was traced from prediction.png.
    if result.metrics.get("fallback_shell") or result.metrics.get("wall_topology_source") == "vision_prediction_skeleton_graph":
        document.layers.get("OUTER_SHELL").off()
    layout = document.modelspace()
    _add_polyline(layout, result.shell_cad, "OUTER_SHELL")
    for polygon in result.wall_polygons_cad:
        _add_polyline(layout, polygon, "WALL_FOOTPRINT")
    for line in result.wall_centerlines_cad:
        _add_line(layout, line, "WALL")
    for line in result.doors_cad:
        _add_line(layout, line, "DOOR")
    for line in result.windows_cad:
        _add_line(layout, line, "WINDOW")
    for line in result.scan_detail_lines_cad:
        _add_line(layout, line, "SCAN_DETAIL")
    for polygon, _ in result.spaces_cad:
        _add_polyline(layout, polygon, "SPACE")
    for klass, polygon, _ in result.internals_cad:
        _add_polyline(layout, polygon, klass)
    document.saveas(path)


def export_transforms(path: str | Path, result: OutlineResult, session_transforms: dict[str, dict]) -> None:
    write_json(
        path,
        {
            "convention": "column vectors; p_target = T_target_source @ p_source",
            "T_cad_reference_slam": matrix_json(result.transform_cad_from_ref),
            "T_reference_slam_cad": matrix_json(result.transform_ref_from_cad),
            "T_reference_slam_session": session_transforms,
        },
    )


def export_osm(
    geojson_path: str | Path,
    output_path: str | Path,
    anchor_lat: float,
    anchor_lon: float,
    yaw_deg: float,
) -> None:
    if not (-90 <= anchor_lat <= 90 and -180 <= anchor_lon <= 180):
        raise PipelineError("Invalid WGS84 anchor")
    data = json.loads(Path(geojson_path).read_text(encoding="utf-8"))
    if "local_coordinate_system" not in data:
        raise PipelineError("Input is not a lidar2outline local metric GeoJSON")
    local_crs = CRS.from_proj4(
        f"+proj=aeqd +lat_0={anchor_lat:.12f} +lon_0={anchor_lon:.12f} +datum=WGS84 +units=m +no_defs"
    )
    to_wgs84 = Transformer.from_crs(local_crs, "EPSG:4326", always_xy=True)
    yaw = math.radians(yaw_deg)
    c, s = math.cos(yaw), math.sin(yaw)

    root = ET.Element("osm", version="0.6", generator="lidar2outline")
    node_id = -1
    way_id = -1
    for feature in data.get("features", []):
        geometry = shape(feature["geometry"])
        if not isinstance(geometry, (Polygon, LineString)):
            continue
        coordinates = geometry.exterior.coords[:-1] if isinstance(geometry, Polygon) else geometry.coords
        refs = []
        for x, y in coordinates:
            east, north = c * x - s * y, s * x + c * y
            lon, lat = to_wgs84.transform(east, north)
            ET.SubElement(root, "node", id=str(node_id), visible="true", lat=f"{lat:.9f}", lon=f"{lon:.9f}")
            refs.append(node_id)
            node_id -= 1
        way = ET.SubElement(root, "way", id=str(way_id), visible="true")
        closed_refs = refs + refs[:1] if isinstance(geometry, Polygon) else refs
        for ref in closed_refs:
            ET.SubElement(way, "nd", ref=str(ref))
        properties = feature.get("properties", {})
        klass = properties.get("class")
        tags = {"level": str(properties.get("level", "0")), "source": "survey;lidar"}
        if klass in {"OUTER_SHELL", "WALL"}:
            tags.update({"indoor": "wall", "wall": "solid"})
        elif klass == "DOOR":
            tags.update({"door": "yes", "indoor": "door"})
        elif klass == "WINDOW":
            tags.update({"window": "yes", "indoor": "yes"})
        elif klass == "SCAN_DETAIL":
            tags.update({"indoor": "wall", "source:geometry": "lidar_projected", "fixme": "verify geometry"})
        elif klass == "WALL_FOOTPRINT":
            tags.update({"indoor": "wall", "wall": "solid", "area": "yes", "source:geometry": "lidar_raster"})
        elif klass == "SPACE":
            tags.update({"indoor": "room", "area": "yes", "source:geometry": "lidar_inferred"})
        elif klass == "COLUMN":
            tags.update({"man_made": "column", "indoor": "yes", "area": "yes"})
        else:
            tags.update({"indoor": "area", "access": "no", "area": "yes"})
        for key, value in tags.items():
            ET.SubElement(way, "tag", k=key, v=value)
        way_id -= 1
    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tree.write(output_path, encoding="utf-8", xml_declaration=True)
