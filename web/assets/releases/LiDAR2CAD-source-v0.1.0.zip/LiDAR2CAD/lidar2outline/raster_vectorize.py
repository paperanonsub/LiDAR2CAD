from __future__ import annotations

import math
from dataclasses import dataclass

import cv2
import numpy as np
from shapely.geometry import LineString
from skimage.morphology import skeletonize


@dataclass
class RasterVectorResult:
    lines: list[LineString]
    cleaned_mask: np.ndarray
    skeleton: np.ndarray
    metrics: dict


@dataclass
class ObliqueRegularizationResult:
    lines: list[LineString]
    accepted_candidates: list[LineString]
    metrics: dict


@dataclass
class JunctionConsolidationResult:
    lines: list[LineString]
    accepted_junctions: list[dict]
    metrics: dict


def _line_kernel(length: int, angle_rad: float) -> np.ndarray:
    length = max(3, int(length) | 1)
    kernel = np.zeros((length, length), np.uint8)
    center = (length - 1) / 2
    delta = center * np.asarray([math.cos(angle_rad), math.sin(angle_rad)])
    cv2.line(
        kernel,
        tuple(np.round(np.asarray([center, center]) - delta).astype(int)),
        tuple(np.round(np.asarray([center, center]) + delta).astype(int)),
        1,
        1,
    )
    return kernel


def _clean_mask(
    mask: np.ndarray,
    grid_m: float,
    main_angle: float,
    close_gap_m: float,
    minimum_component_cells: int,
) -> np.ndarray:
    clean = np.where(mask > 0, 255, 0).astype(np.uint8)
    if close_gap_m > 0:
        length = max(3, int(round(close_gap_m / grid_m)) | 1)
        for angle in (main_angle, main_angle + math.pi / 2):
            closed = cv2.morphologyEx(clean, cv2.MORPH_CLOSE, _line_kernel(length, angle))
            clean = cv2.max(clean, closed)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(clean, 8)
    retained = np.zeros_like(clean)
    for component in range(1, count):
        if int(stats[component, cv2.CC_STAT_AREA]) >= minimum_component_cells:
            retained[labels == component] = 255
    return retained


def _pixel_neighbors(pixel: tuple[int, int], pixels: set[tuple[int, int]]) -> list[tuple[int, int]]:
    y, x = pixel
    return [
        (ny, nx)
        for ny in range(y - 1, y + 2)
        for nx in range(x - 1, x + 2)
        if (ny != y or nx != x) and (ny, nx) in pixels
    ]


def _edge_key(first: tuple[int, int], second: tuple[int, int]):
    return (first, second) if first <= second else (second, first)


def _trace_pixel_graph(skeleton: np.ndarray) -> tuple[list[np.ndarray], int, int]:
    """Contract all degree-two skeleton pixels into topological paths."""
    pixels = {tuple(value) for value in np.column_stack(np.nonzero(skeleton)).tolist()}
    if not pixels:
        return [], 0, 0
    adjacency = {pixel: _pixel_neighbors(pixel, pixels) for pixel in pixels}
    node_pixels = {pixel for pixel, neighbors in adjacency.items() if len(neighbors) != 2}

    node_mask = np.zeros(skeleton.shape, np.uint8)
    for y, x in node_pixels:
        node_mask[y, x] = 1
    count, labels = cv2.connectedComponents(node_mask, 8)
    pixel_node: dict[tuple[int, int], int] = {}
    node_centers: dict[int, np.ndarray] = {}
    for node_id in range(1, count):
        yx = np.column_stack(np.nonzero(labels == node_id))
        if not len(yx):
            continue
        node_centers[node_id] = np.mean(yx[:, ::-1], axis=0)
        for y, x in yx:
            pixel_node[(int(y), int(x))] = node_id

    visited: set[tuple[tuple[int, int], tuple[int, int]]] = set()
    for pixel, neighbors in adjacency.items():
        for neighbor in neighbors:
            if pixel_node.get(pixel) is not None and pixel_node.get(pixel) == pixel_node.get(neighbor):
                visited.add(_edge_key(pixel, neighbor))

    paths: list[np.ndarray] = []

    def trace(start: tuple[int, int], first: tuple[int, int]) -> list[tuple[int, int]]:
        path = [start, first]
        previous, current = start, first
        visited.add(_edge_key(previous, current))
        while current not in pixel_node:
            choices = [
                value
                for value in adjacency[current]
                if value != previous and _edge_key(current, value) not in visited
            ]
            if not choices:
                break
            # Degree-two pixels normally leave one choice. At diagonal raster
            # ambiguities, continue in the direction with the smallest turn.
            if len(choices) > 1:
                incoming = np.asarray(current) - np.asarray(previous)
                choices.sort(
                    key=lambda value: -float(
                        incoming @ (np.asarray(value) - np.asarray(current))
                    )
                )
            following = choices[0]
            visited.add(_edge_key(current, following))
            path.append(following)
            previous, current = current, following
        return path

    for node_pixel in sorted(pixel_node):
        for neighbor in adjacency[node_pixel]:
            if _edge_key(node_pixel, neighbor) in visited:
                continue
            raw = trace(node_pixel, neighbor)
            start_node = pixel_node[node_pixel]
            end_node = pixel_node.get(raw[-1])
            xy = np.asarray([(x, y) for y, x in raw], dtype=float)
            xy[0] = node_centers[start_node]
            if end_node is not None:
                xy[-1] = node_centers[end_node]
            paths.append(xy)

    # Closed skeleton loops contain only degree-two pixels and therefore have
    # no explicit graph node. Trace every still-unvisited edge once.
    for pixel in sorted(pixels):
        for neighbor in adjacency[pixel]:
            if _edge_key(pixel, neighbor) in visited:
                continue
            raw = [pixel, neighbor]
            visited.add(_edge_key(pixel, neighbor))
            previous, current = pixel, neighbor
            while True:
                choices = [
                    value
                    for value in adjacency[current]
                    if value != previous and _edge_key(current, value) not in visited
                ]
                if not choices:
                    break
                following = choices[0]
                visited.add(_edge_key(current, following))
                raw.append(following)
                previous, current = current, following
                if current == pixel:
                    break
            paths.append(np.asarray([(x, y) for y, x in raw], dtype=float))
    return paths, len(node_centers), len(visited)


def _angle_difference(first: float, second: float) -> float:
    return abs((first - second + math.pi / 2) % math.pi - math.pi / 2)


def _cross2d(first: np.ndarray, second: np.ndarray) -> float:
    return float(first[0] * second[1] - first[1] * second[0])


def _supported_runs(supported: np.ndarray, maximum_gap: int) -> list[tuple[int, int]]:
    indices = np.flatnonzero(supported)
    if not len(indices):
        return []
    runs: list[tuple[int, int]] = []
    start = previous = int(indices[0])
    for value in indices[1:]:
        value = int(value)
        if value - previous > maximum_gap:
            runs.append((start, previous))
            start = value
        previous = value
    runs.append((start, previous))
    return runs


def _candidate_line_overlap(
    line: LineString,
    direction: np.ndarray,
    normal: np.ndarray,
    offset: float,
    interval: tuple[float, float],
    origin: np.ndarray,
    grid_m: float,
    corridor_px: float,
) -> float:
    pixels = (np.asarray(line.coords, dtype=float) - origin) / grid_m - 0.5
    delta = pixels[-1] - pixels[0]
    sample_count = max(3, int(math.ceil(float(np.linalg.norm(delta)) / 2.0)) + 1)
    samples = pixels[0] + np.linspace(0.0, 1.0, sample_count)[:, None] * delta
    perpendicular = np.abs(samples @ normal - offset)
    projected = samples @ direction
    return float(
        np.mean(
            (perpendicular <= corridor_px)
            & (projected >= interval[0] - 4.0)
            & (projected <= interval[1] + 4.0)
        )
    )


def soft_regularize_oblique_lines(
    lines: list[LineString],
    cleaned_mask: np.ndarray,
    skeleton: np.ndarray,
    heatmap: np.ndarray | None,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float | None,
    cfg: dict,
) -> ObliqueRegularizationResult:
    """Replace supported local zigzags with rewarded oblique straight lines.

    This is deliberately a soft decision. A candidate receives rewards for
    physical mask/heat support, length and reduction of angular dispersion;
    it is rejected when it lacks enough nearby fragments or would move the
    drawing away from the raster evidence. Manhattan walls are excluded and
    continue through the ordinary axis-snapping path.
    """
    empty_metrics = {
        "direct_vector_oblique_seed_count": 0,
        "direct_vector_oblique_candidate_count": 0,
        "direct_vector_oblique_accepted_count": 0,
        "direct_vector_oblique_replaced_fragment_count": 0,
        "direct_vector_oblique_mean_reward": None,
    }
    if (
        not bool(cfg.get("vector_oblique_reward_enabled", True))
        or len(lines) < 3
        or not np.any(skeleton)
    ):
        return ObliqueRegularizationResult(lines, [], empty_metrics)

    height, width = cleaned_mask.shape
    heat = (
        np.asarray(heatmap, dtype=np.float32)
        if heatmap is not None
        else (cleaned_mask > 0).astype(np.float32)
    )
    mask_distance = cv2.distanceTransform(
        np.where(cleaned_mask > 0, 0, 255).astype(np.uint8), cv2.DIST_L2, 5
    )
    seed_min_px = max(8, int(round(float(cfg.get("vector_oblique_seed_min_m", 1.0)) / grid_m)))
    hough = cv2.HoughLinesP(
        np.where(skeleton > 0, 255, 0).astype(np.uint8),
        1,
        np.pi / 720,
        threshold=int(cfg.get("vector_oblique_hough_threshold", 12)),
        minLineLength=seed_min_px,
        maxLineGap=max(2, int(round(float(cfg.get("vector_oblique_seed_gap_m", 0.60)) / grid_m))),
    )
    if hough is None:
        return ObliqueRegularizationResult(lines, [], empty_metrics)

    main = main_angle or 0.0
    axis_exclusion = math.radians(float(cfg.get("vector_oblique_axis_exclusion_deg", 8.0)))
    search_angle = float(cfg.get("vector_oblique_search_angle_deg", 6.0))
    angle_step = max(0.5, float(cfg.get("vector_oblique_search_angle_step_deg", 1.0)))
    search_offset_px = max(1.0, float(cfg.get("vector_oblique_search_offset_m", 0.30)) / grid_m)
    offset_step_px = max(1.0, float(cfg.get("vector_oblique_search_offset_step_m", 0.10)) / grid_m)
    support_px = float(cfg.get("vector_oblique_support_distance_m", 0.15)) / grid_m
    weak_support_px = float(cfg.get("vector_oblique_weak_distance_m", 0.25)) / grid_m
    weak_heat = float(cfg.get("vector_oblique_weak_min_heat", 0.30))
    maximum_gap_px = max(1, int(round(float(cfg.get("vector_oblique_max_gap_m", 0.60)) / grid_m)))
    candidate_min_m = float(cfg.get("vector_oblique_candidate_min_m", 1.50))
    candidate_min_score = float(cfg.get("vector_oblique_min_evidence_score", 0.66))
    corridor_px = float(cfg.get("vector_oblique_replace_corridor_m", 0.50)) / grid_m
    fragment_fraction = float(cfg.get("vector_oblique_fragment_fraction", 0.55))
    remove_fraction = float(cfg.get("vector_oblique_remove_fraction", 0.75))
    minimum_fragments = int(cfg.get("vector_oblique_min_fragment_count", 3))
    minimum_gain = float(cfg.get("vector_oblique_min_straightness_gain", 0.35))
    minimum_reward = float(cfg.get("vector_oblique_min_reward", 0.79))
    evidence_weight = float(cfg.get("vector_oblique_evidence_weight", 0.65))
    straightness_weight = float(cfg.get("vector_oblique_straightness_weight", 0.35))

    corners = np.asarray(
        [[0.0, 0.0], [width - 1.0, 0.0], [0.0, height - 1.0], [width - 1.0, height - 1.0]]
    )
    raw_candidates: list[dict] = []
    seeds = np.asarray(hough).reshape(-1, 4)
    for x1, y1, x2, y2 in seeds:
        first = np.asarray([x1, y1], dtype=float)
        second = np.asarray([x2, y2], dtype=float)
        seed_delta = second - first
        if float(np.linalg.norm(seed_delta)) < seed_min_px:
            continue
        seed_angle = math.atan2(seed_delta[1], seed_delta[0]) % math.pi
        if min(
            _angle_difference(seed_angle, main),
            _angle_difference(seed_angle, main + math.pi / 2),
        ) < axis_exclusion:
            continue
        seed_middle = (first + second) / 2.0
        best: dict | None = None
        for angle_delta_deg in np.arange(-search_angle, search_angle + 0.5 * angle_step, angle_step):
            angle = seed_angle + math.radians(float(angle_delta_deg))
            direction = np.asarray([math.cos(angle), math.sin(angle)])
            normal = np.asarray([-direction[1], direction[0]])
            base_offset = float(normal @ seed_middle)
            seed_interval = sorted([float(direction @ first), float(direction @ second)])
            corner_projection = corners @ direction
            sample_t = np.arange(
                math.floor(float(np.min(corner_projection))),
                math.ceil(float(np.max(corner_projection))) + 1,
                dtype=float,
            )
            for offset_delta in np.arange(
                -search_offset_px, search_offset_px + 0.5 * offset_step_px, offset_step_px
            ):
                offset = base_offset + float(offset_delta)
                sample_xy = sample_t[:, None] * direction + offset * normal
                sample_x = np.rint(sample_xy[:, 0]).astype(int)
                sample_y = np.rint(sample_xy[:, 1]).astype(int)
                valid = (
                    (sample_x >= 0)
                    & (sample_y >= 0)
                    & (sample_x < width)
                    & (sample_y < height)
                )
                distances = np.full(len(sample_t), 1e6, dtype=np.float32)
                heat_values = np.zeros(len(sample_t), dtype=np.float32)
                distances[valid] = mask_distance[sample_y[valid], sample_x[valid]]
                heat_values[valid] = heat[sample_y[valid], sample_x[valid]]
                supported = valid & (
                    (distances <= support_px)
                    | ((distances <= weak_support_px) & (heat_values >= weak_heat))
                )
                for run_start, run_end in _supported_runs(supported, maximum_gap_px):
                    if (
                        sample_t[run_end] < seed_interval[0] - 4.0
                        or sample_t[run_start] > seed_interval[1] + 4.0
                    ):
                        continue
                    length_m = float(sample_t[run_end] - sample_t[run_start]) * grid_m
                    if length_m < candidate_min_m:
                        continue
                    run = slice(run_start, run_end + 1)
                    strict_support = float(np.mean(distances[run] <= support_px))
                    mean_heat = float(np.mean(heat_values[run]))
                    lower_heat = float(np.quantile(heat_values[run], 0.25))
                    angle_prior = math.exp(
                        -abs(math.radians(float(angle_delta_deg))) / math.radians(4.0)
                    )
                    evidence_score = (
                        0.38 * strict_support
                        + 0.22 * mean_heat
                        + 0.12 * lower_heat
                        + 0.18 * min(length_m / 4.0, 1.0)
                        + 0.10 * angle_prior
                    )
                    if best is None or evidence_score > best["evidence_score"]:
                        best = {
                            "evidence_score": evidence_score,
                            "length_m": length_m,
                            "angle": angle,
                            "direction": direction,
                            "normal": normal,
                            "offset": offset,
                            "interval": (float(sample_t[run_start]), float(sample_t[run_end])),
                        }
        if best is None or best["evidence_score"] < candidate_min_score:
            continue

        selected: list[tuple[int, float, float]] = []
        for line_index, line in enumerate(lines):
            overlap = _candidate_line_overlap(
                line,
                best["direction"],
                best["normal"],
                best["offset"],
                best["interval"],
                np.asarray(origin, dtype=float),
                grid_m,
                corridor_px,
            )
            if overlap < fragment_fraction:
                continue
            coordinates = np.asarray(line.coords, dtype=float)
            line_delta = coordinates[-1] - coordinates[0]
            line_angle = math.atan2(line_delta[1], line_delta[0]) % math.pi
            selected.append(
                (
                    line_index,
                    float(line.length),
                    math.degrees(_angle_difference(line_angle, best["angle"])),
                )
            )
        total_fragment_length = sum(value[1] for value in selected)
        if len(selected) < minimum_fragments or total_fragment_length <= 1e-9:
            continue
        straightness_gain = sum(
            length * min(angle_error, 45.0) / 45.0
            for _, length, angle_error in selected
        ) / total_fragment_length
        reward = evidence_weight * best["evidence_score"] + straightness_weight * straightness_gain
        if straightness_gain < minimum_gain or reward < minimum_reward:
            continue
        best.update(
            {
                "selected": {value[0] for value in selected},
                "straightness_gain": straightness_gain,
                "reward": reward,
            }
        )
        raw_candidates.append(best)

    accepted: list[dict] = []
    for candidate in sorted(raw_candidates, key=lambda value: value["reward"], reverse=True):
        # Multiple Hough seeds usually rediscover the same wall. Replacement
        # set overlap is a topology-aware non-maximum suppression criterion.
        if any(
            len(candidate["selected"] & previous["selected"])
            / max(1, len(candidate["selected"] | previous["selected"]))
            >= 0.25
            for previous in accepted
        ):
            continue
        accepted.append(candidate)

    removed: set[int] = set()
    candidate_lines: list[LineString] = []
    for candidate in accepted:
        for line_index, line in enumerate(lines):
            overlap = _candidate_line_overlap(
                line,
                candidate["direction"],
                candidate["normal"],
                candidate["offset"],
                candidate["interval"],
                np.asarray(origin, dtype=float),
                grid_m,
                corridor_px,
            )
            if overlap >= remove_fraction:
                removed.add(line_index)
        start = candidate["direction"] * candidate["interval"][0] + candidate["normal"] * candidate["offset"]
        end = candidate["direction"] * candidate["interval"][1] + candidate["normal"] * candidate["offset"]
        candidate_lines.append(
            LineString(
                [
                    np.asarray(origin, dtype=float) + (start + 0.5) * grid_m,
                    np.asarray(origin, dtype=float) + (end + 0.5) * grid_m,
                ]
            )
        )

    output = [line for index, line in enumerate(lines) if index not in removed] + candidate_lines
    metrics = {
        "direct_vector_oblique_seed_count": int(len(seeds)),
        "direct_vector_oblique_candidate_count": int(len(raw_candidates)),
        "direct_vector_oblique_accepted_count": int(len(accepted)),
        "direct_vector_oblique_replaced_fragment_count": int(len(removed)),
        "direct_vector_oblique_mean_reward": (
            None if not accepted else float(np.mean([value["reward"] for value in accepted]))
        ),
    }
    return ObliqueRegularizationResult(output, candidate_lines, metrics)


def _junction_angle_score(
    directions: list[np.ndarray],
    straight_sigma_deg: float,
    right_sigma_deg: float,
) -> tuple[float, list[float]]:
    """Score whether every incident ray has a plausible partner at a junction.

    Both straight continuations and approximately orthogonal corners are strong
    configurations. Oblique corners retain a softer sine reward, so this does
    not turn into a global Manhattan-world constraint.
    """
    if len(directions) < 2:
        return 0.0, []
    pair_scores = np.zeros((len(directions), len(directions)), dtype=float)
    pair_angles: list[float] = []
    for first in range(len(directions)):
        for second in range(first + 1, len(directions)):
            cosine = float(np.clip(directions[first] @ directions[second], -1.0, 1.0))
            angle = math.degrees(math.acos(cosine))
            straight = math.exp(-0.5 * ((180.0 - angle) / straight_sigma_deg) ** 2)
            right = math.exp(-0.5 * ((90.0 - angle) / right_sigma_deg) ** 2)
            free_oblique = 0.72 * math.sin(math.radians(angle)) ** 0.7
            quality = max(straight, right, free_oblique)
            pair_scores[first, second] = pair_scores[second, first] = quality
            pair_angles.append(angle)
    # Requiring every ray to have one good geometric partner rejects a bundle
    # of similarly-directed raster burrs while retaining L/T/X junctions.
    per_ray = np.max(pair_scores, axis=1)
    return float(np.mean(per_ray)), pair_angles


def _sample_extension_support(
    start: np.ndarray,
    end: np.ndarray,
    mask_distance: np.ndarray,
    heatmap: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    support_distance_m: float,
    weak_heat: float,
) -> float:
    distance_m = float(np.linalg.norm(end - start))
    if distance_m <= 1e-9:
        return 1.0
    count = max(2, int(math.ceil(distance_m / max(grid_m, 1e-6))) + 1)
    world = start + np.linspace(0.0, 1.0, count)[:, None] * (end - start)
    pixels = np.rint((world - origin) / grid_m - 0.5).astype(int)
    valid = (
        (pixels[:, 0] >= 0)
        & (pixels[:, 1] >= 0)
        & (pixels[:, 0] < mask_distance.shape[1])
        & (pixels[:, 1] < mask_distance.shape[0])
    )
    supported = np.zeros(count, dtype=bool)
    supported[valid] = (
        (mask_distance[pixels[valid, 1], pixels[valid, 0]] * grid_m <= support_distance_m)
        | (heatmap[pixels[valid, 1], pixels[valid, 0]] >= weak_heat)
    )
    return float(np.mean(supported))


def soft_consolidate_junctions(
    lines: list[LineString],
    cleaned_mask: np.ndarray,
    heatmap: np.ndarray | None,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float | None,
    cfg: dict,
) -> JunctionConsolidationResult:
    """Condense dense raster corner blobs into one scored vector junction.

    Skeletonization often represents one physical corner as a short chain of
    nodes. We detect only chains joined by short connector edges, reverse-
    extend their incident lines, and select a common point using robust line
    intersection fitting. The edit is accepted only when raster/heat evidence,
    endpoint displacement and the incident-ray angles all agree.
    """
    empty_metrics = {
        "direct_vector_junction_candidate_count": 0,
        "direct_vector_junction_accepted_count": 0,
        "direct_vector_junction_collapsed_connector_count": 0,
        "direct_vector_junction_mean_angle_score": None,
        "direct_vector_junction_mean_reward": None,
    }
    if not bool(cfg.get("vector_junction_condensation_enabled", True)) or len(lines) < 3:
        return JunctionConsolidationResult(lines, [], empty_metrics)

    coordinates = [np.asarray(line.coords, dtype=float)[[0, -1]].copy() for line in lines]
    endpoints = np.vstack(coordinates)
    endpoint_parent = np.arange(len(endpoints))

    def endpoint_root(index: int) -> int:
        while endpoint_parent[index] != index:
            endpoint_parent[index] = endpoint_parent[endpoint_parent[index]]
            index = int(endpoint_parent[index])
        return index

    node_merge_m = float(cfg.get("vector_junction_node_merge_m", 0.08))
    for first in range(len(endpoints)):
        for second in range(first + 1, len(endpoints)):
            if first // 2 == second // 2:
                continue
            if float(np.linalg.norm(endpoints[first] - endpoints[second])) <= node_merge_m:
                first_root, second_root = endpoint_root(first), endpoint_root(second)
                if first_root != second_root:
                    endpoint_parent[second_root] = first_root
    endpoint_groups: dict[int, list[int]] = {}
    for endpoint_index in range(len(endpoints)):
        endpoint_groups.setdefault(endpoint_root(endpoint_index), []).append(endpoint_index)
    node_ids = {root: index for index, root in enumerate(endpoint_groups)}
    endpoint_node = np.asarray([node_ids[endpoint_root(index)] for index in range(len(endpoints))])
    node_centers = np.asarray(
        [np.mean(endpoints[indices], axis=0) for indices in endpoint_groups.values()], dtype=float
    )
    line_nodes = [(int(endpoint_node[2 * index]), int(endpoint_node[2 * index + 1])) for index in range(len(lines))]
    node_degree = np.zeros(len(node_centers), dtype=int)
    for first, second in line_nodes:
        node_degree[first] += 1
        node_degree[second] += 1

    # Short edges joining two already-connected graph nodes are the raster
    # expansion of a junction. Leaf edges are kept as possible real wall ends.
    connector_max_m = float(cfg.get("vector_junction_connector_max_m", 0.85))
    component_max_m = float(cfg.get("vector_junction_component_max_m", 1.15))
    node_parent = np.arange(len(node_centers))
    component_nodes = {index: [index] for index in range(len(node_centers))}

    def node_root(index: int) -> int:
        while node_parent[index] != index:
            node_parent[index] = node_parent[node_parent[index]]
            index = int(node_parent[index])
        return index

    connector_indices = sorted(
        (
            index
            for index, line in enumerate(lines)
            if line.length <= connector_max_m
            and line_nodes[index][0] != line_nodes[index][1]
            and node_degree[line_nodes[index][0]] >= 2
            and node_degree[line_nodes[index][1]] >= 2
        ),
        key=lambda index: lines[index].length,
    )
    for line_index in connector_indices:
        first, second = line_nodes[line_index]
        first_root, second_root = node_root(first), node_root(second)
        if first_root == second_root:
            continue
        merged = component_nodes[first_root] + component_nodes[second_root]
        centers = node_centers[merged]
        diameter = float(np.max(np.linalg.norm(centers[:, None, :] - centers[None, :, :], axis=2)))
        if diameter > component_max_m:
            continue
        node_parent[second_root] = first_root
        component_nodes[first_root] = merged
        del component_nodes[second_root]

    components: dict[int, list[int]] = {}
    for node_index in range(len(node_centers)):
        components.setdefault(node_root(node_index), []).append(node_index)

    origin = np.asarray(origin, dtype=float)
    heat = (
        np.asarray(heatmap, dtype=np.float32)
        if heatmap is not None
        else (cleaned_mask > 0).astype(np.float32)
    )
    mask_distance = cv2.distanceTransform(
        np.where(cleaned_mask > 0, 0, 255).astype(np.uint8), cv2.DIST_L2, 5
    )
    inside_distance = cv2.distanceTransform(
        np.where(cleaned_mask > 0, 255, 0).astype(np.uint8), cv2.DIST_L2, 5
    )
    search_radius_m = float(cfg.get("vector_junction_search_radius_m", 0.95))
    line_fit_m = float(cfg.get("vector_junction_line_fit_m", 0.22))
    support_distance_m = float(cfg.get("vector_junction_support_distance_m", 0.20))
    weak_heat = float(cfg.get("vector_junction_weak_min_heat", 0.35))
    blob_radius_m = float(cfg.get("vector_junction_blob_radius_m", 0.42))
    max_move_m = float(cfg.get("vector_junction_max_move_m", 0.60))
    minimum_spread_m = float(cfg.get("vector_junction_min_spread_m", 0.12))
    minimum_blob = float(cfg.get("vector_junction_min_blob_score", 0.32))
    minimum_angle = float(cfg.get("vector_junction_min_angle_score", 0.80))
    minimum_reward = float(cfg.get("vector_junction_min_reward", 0.85))
    straight_sigma = float(cfg.get("vector_junction_straight_sigma_deg", 12.0))
    right_sigma = float(cfg.get("vector_junction_right_sigma_deg", 22.0))
    minimum_incident = int(cfg.get("vector_junction_min_incident_lines", 2))

    def local_evidence(point: np.ndarray) -> tuple[float, float]:
        pixel = (point - origin) / grid_m - 0.5
        radius_px = max(2, int(math.ceil(blob_radius_m / grid_m)))
        x0, y0 = np.floor(pixel).astype(int)
        xs = np.arange(max(0, x0 - radius_px), min(cleaned_mask.shape[1], x0 + radius_px + 1))
        ys = np.arange(max(0, y0 - radius_px), min(cleaned_mask.shape[0], y0 + radius_px + 1))
        if not len(xs) or not len(ys):
            return 0.0, 0.0
        xx, yy = np.meshgrid(xs, ys)
        disk = (xx - pixel[0]) ** 2 + (yy - pixel[1]) ** 2 <= radius_px**2
        mask_values = (cleaned_mask[yy[disk], xx[disk]] > 0).astype(float)
        heat_values = heat[yy[disk], xx[disk]]
        thickness_m = float(np.max(inside_distance[yy[disk], xx[disk]])) * grid_m
        mass_score = min(1.0, float(np.mean(mask_values)) / 0.34)
        thickness_score = min(1.0, thickness_m / 0.28)
        blob_score = 0.65 * mass_score + 0.35 * thickness_score
        upper_count = max(1, int(math.ceil(0.30 * len(heat_values))))
        heat_score = float(np.mean(np.partition(heat_values, -upper_count)[-upper_count:]))
        return blob_score, float(np.clip(heat_score, 0.0, 1.0))

    accepted: list[dict] = []
    candidate_count = 0
    updated = [values.copy() for values in coordinates]
    removed: set[int] = set()
    for nodes in components.values():
        if len(nodes) < 2:
            continue
        node_set = set(nodes)
        centers = node_centers[nodes]
        spread = float(np.max(np.linalg.norm(centers[:, None, :] - centers[None, :, :], axis=2)))
        if spread < minimum_spread_m:
            continue
        incident: list[dict] = []
        internal: list[int] = []
        for line_index, (first_node, second_node) in enumerate(line_nodes):
            first_inside, second_inside = first_node in node_set, second_node in node_set
            if first_inside and second_inside:
                if lines[line_index].length <= connector_max_m * 1.25:
                    internal.append(line_index)
                continue
            if first_inside == second_inside:
                continue
            endpoint_index = 0 if first_inside else 1
            endpoint = coordinates[line_index][endpoint_index]
            outside = coordinates[line_index][1 - endpoint_index]
            delta = outside - endpoint
            length = float(np.linalg.norm(delta))
            if length <= 1e-9:
                continue
            incident.append(
                {
                    "line_index": line_index,
                    "endpoint_index": endpoint_index,
                    "endpoint": endpoint,
                    "outside": outside,
                    "direction": delta / length,
                    "length": length,
                }
            )
        if len(incident) < minimum_incident or not internal:
            continue
        candidate_count += 1
        center = np.mean(centers, axis=0)

        # Robust total-least-squares intersection of the reverse-extended
        # incident lines. A weak center prior keeps near-parallel continuations
        # finite; Huber reweighting prevents one raster burr taking control.
        base_weights = np.asarray([min(value["length"], 3.0) for value in incident])
        robust_weights = base_weights.copy()
        estimate = center.copy()
        for _ in range(4):
            matrix = np.eye(2) * max(0.05, 0.04 * float(np.sum(robust_weights)))
            vector = matrix @ center
            for weight, value in zip(robust_weights, incident):
                normal = np.asarray([-value["direction"][1], value["direction"][0]])
                projector = np.outer(normal, normal)
                matrix += weight * projector
                vector += weight * projector @ value["endpoint"]
            try:
                estimate = np.linalg.solve(matrix, vector)
            except np.linalg.LinAlgError:
                estimate = center.copy()
                break
            residuals = np.asarray(
                [abs(_cross2d(value["direction"], estimate - value["endpoint"])) for value in incident]
            )
            robust_weights = base_weights * np.minimum(1.0, line_fit_m / np.maximum(residuals, 1e-6))

        hypotheses = [center, estimate]
        # Explicit pair intersections are important at L/T corners: extending
        # the two strongest sides backwards often localizes the physical corner
        # more accurately than the center of the dense pixel blob.
        for first in range(len(incident)):
            for second in range(first + 1, len(incident)):
                first_value, second_value = incident[first], incident[second]
                denominator = _cross2d(first_value["direction"], second_value["direction"])
                if abs(denominator) < math.sin(math.radians(12.0)):
                    continue
                delta = second_value["endpoint"] - first_value["endpoint"]
                scale = _cross2d(delta, second_value["direction"]) / denominator
                intersection = first_value["endpoint"] + scale * first_value["direction"]
                if float(np.linalg.norm(intersection - center)) <= search_radius_m:
                    hypotheses.append(intersection)

        best: dict | None = None
        for point in hypotheses:
            movements = np.asarray(
                [float(np.linalg.norm(point - value["endpoint"])) for value in incident]
            )
            if float(np.max(movements)) > max_move_m:
                continue
            residuals = np.asarray(
                [abs(_cross2d(value["direction"], point - value["endpoint"])) for value in incident]
            )
            length_weights = base_weights / max(float(np.sum(base_weights)), 1e-9)
            fit_score = float(np.sum(length_weights * np.exp(-0.5 * (residuals / line_fit_m) ** 2)))
            move_score = float(np.mean(np.exp(-0.5 * (movements / (0.65 * max_move_m)) ** 2)))
            support_score = float(
                np.mean(
                    [
                        _sample_extension_support(
                            value["endpoint"],
                            point,
                            mask_distance,
                            heat,
                            origin,
                            grid_m,
                            support_distance_m,
                            weak_heat,
                        )
                        for value in incident
                    ]
                )
            )
            ray_directions = []
            for value in incident:
                ray = value["outside"] - point
                norm = float(np.linalg.norm(ray))
                if norm > 1e-9:
                    ray_directions.append(ray / norm)
            angle_score, pair_angles = _junction_angle_score(
                ray_directions, straight_sigma, right_sigma
            )
            blob_score, heat_score = local_evidence(point)
            reward = (
                0.26 * fit_score
                + 0.18 * support_score
                + 0.14 * blob_score
                + 0.12 * heat_score
                + 0.18 * angle_score
                + 0.12 * move_score
            )
            value = {
                "point": np.asarray(point, dtype=float),
                "reward": reward,
                "fit_score": fit_score,
                "support_score": support_score,
                "blob_score": blob_score,
                "heat_score": heat_score,
                "angle_score": angle_score,
                "pair_angles_deg": pair_angles,
                "max_move_m": float(np.max(movements)),
                "incident": incident,
                "internal": internal,
            }
            if best is None or reward > best["reward"]:
                best = value
        if (
            best is None
            or best["blob_score"] < minimum_blob
            or best["angle_score"] < minimum_angle
            or best["fit_score"] < 0.52
            or best["support_score"] < 0.50
            or best["reward"] < minimum_reward
        ):
            continue
        for value in best["incident"]:
            updated[value["line_index"]][value["endpoint_index"]] = best["point"]
        removed.update(best["internal"])
        accepted.append(
            {
                key: value
                for key, value in best.items()
                if key not in ("incident", "internal")
            }
            | {
                "incident_line_count": len(best["incident"]),
                "collapsed_connector_count": len(best["internal"]),
            }
        )

    output: list[LineString] = []
    for line_index, values in enumerate(updated):
        if line_index in removed or float(np.linalg.norm(values[1] - values[0])) < 0.15:
            continue
        output.append(LineString(values))
    metrics = {
        "direct_vector_junction_candidate_count": int(candidate_count),
        "direct_vector_junction_accepted_count": int(len(accepted)),
        "direct_vector_junction_collapsed_connector_count": int(len(removed)),
        "direct_vector_junction_mean_angle_score": (
            None if not accepted else float(np.mean([value["angle_score"] for value in accepted]))
        ),
        "direct_vector_junction_mean_reward": (
            None if not accepted else float(np.mean([value["reward"] for value in accepted]))
        ),
    }
    return JunctionConsolidationResult(output, accepted, metrics)


def _path_segments(
    path_xy: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float,
    simplify_m: float,
    snap_angle_deg: float,
    minimum_line_m: float,
    oblique_minimum_line_m: float,
    heatmap: np.ndarray | None,
    short_minimum_line_m: float,
    short_minimum_heat: float,
    short_minimum_lower_quartile: float,
    heat_length_power: float,
) -> tuple[list[LineString], int, int]:
    if len(path_xy) < 2:
        return [], 0, 0
    closed = len(path_xy) >= 4 and np.linalg.norm(path_xy[0] - path_xy[-1]) <= 1.5
    approximated = cv2.approxPolyDP(
        path_xy.astype(np.float32).reshape(-1, 1, 2),
        max(0.5, simplify_m / grid_m),
        closed,
    )[:, 0, :].astype(float)
    if closed and len(approximated) >= 3:
        approximated = np.vstack([approximated, approximated[0]])
    if len(approximated) < 2:
        approximated = path_xy[[0, -1]]
    world = origin + (approximated + 0.5) * grid_m
    result: list[LineString] = []
    heat_retained = 0
    heat_rejected = 0
    directions = [main_angle % math.pi, (main_angle + math.pi / 2) % math.pi]
    for pixel_start, pixel_end, start, end in zip(
        approximated[:-1], approximated[1:], world[:-1], world[1:]
    ):
        delta = end - start
        length = float(np.linalg.norm(delta))
        if length < minimum_line_m:
            if heatmap is None or length < short_minimum_line_m:
                heat_rejected += 1
                continue
            pixel_length = float(np.linalg.norm(pixel_end - pixel_start))
            sample_count = max(2, int(math.ceil(pixel_length)) + 1)
            interpolation = np.linspace(0.0, 1.0, sample_count)[:, None]
            samples = np.rint(pixel_start + (pixel_end - pixel_start) * interpolation).astype(int)
            sample_x = np.clip(samples[:, 0], 0, heatmap.shape[1] - 1)
            sample_y = np.clip(samples[:, 1], 0, heatmap.shape[0] - 1)
            heat = np.asarray(heatmap[sample_y, sample_x], dtype=float)
            mean_heat = float(np.mean(heat))
            lower_quartile = float(np.quantile(heat, 0.25))
            focus = 0.65 * mean_heat + 0.35 * lower_quartile
            required_length = short_minimum_line_m + (
                minimum_line_m - short_minimum_line_m
            ) * (1.0 - focus) ** heat_length_power
            if (
                focus < short_minimum_heat
                or lower_quartile < short_minimum_lower_quartile
                or length < required_length
            ):
                heat_rejected += 1
                continue
            heat_retained += 1
        raw_angle = math.atan2(delta[1], delta[0]) % math.pi
        nearest = min(directions, key=lambda value: _angle_difference(raw_angle, value))
        aligned = _angle_difference(raw_angle, nearest) <= math.radians(snap_angle_deg)
        short_junction_spoke = not aligned and length < oblique_minimum_line_m
        if aligned or short_junction_spoke:
            # Skeleton junction pixels form tiny diagonal spokes at otherwise
            # orthogonal T/X intersections.  Project those spokes onto the
            # nearest Manhattan axis instead of deleting them: the following
            # endpoint clustering pass reconnects them to the common node,
            # preserving topology without exporting diagonal raster burrs.
            direction = np.asarray([math.cos(nearest), math.sin(nearest)])
            normal = np.asarray([-direction[1], direction[0]])
            offset = float(normal @ ((start + end) / 2))
            start = direction * float(direction @ start) + normal * offset
            end = direction * float(direction @ end) + normal * offset
        result.append(LineString([start, end]))
    return result, heat_retained, heat_rejected


def vectorize_structure_mask(
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    main_angle: float | None,
    cfg: dict,
    heatmap: np.ndarray | None = None,
) -> RasterVectorResult:
    """Directly convert a clean prediction bitmap into a straight wall graph."""
    angle = main_angle or 0.0
    cleaned = _clean_mask(
        mask,
        grid_m,
        angle,
        float(cfg.get("vector_close_gap_m", 0.60)),
        int(cfg.get("vector_min_component_cells", 30)),
    )
    skeleton = skeletonize(cleaned > 0)
    paths, node_count, edge_count = _trace_pixel_graph(skeleton)
    lines: list[LineString] = []
    heat_retained = 0
    heat_rejected = 0
    for path in paths:
        path_lines, retained, rejected = _path_segments(
            path,
            np.asarray(origin, dtype=float),
            grid_m,
            angle,
            float(cfg.get("vector_simplify_m", 0.12)),
            float(cfg.get("vector_snap_angle_deg", 8.0)),
            float(cfg.get("vector_min_line_m", 0.60)),
            float(cfg.get("vector_oblique_min_line_m", 1.20)),
            heatmap,
            float(cfg.get("vector_short_min_line_m", 0.15)),
            float(cfg.get("vector_short_min_heat", 0.60)),
            float(cfg.get("vector_short_min_lower_quartile", 0.40)),
            float(cfg.get("vector_heat_length_power", 2.0)),
        )
        lines.extend(path_lines)
        heat_retained += retained
        heat_rejected += rejected
    metrics = {
        "direct_vector_mask_cells": int(np.count_nonzero(cleaned)),
        "direct_vector_skeleton_pixels": int(np.count_nonzero(skeleton)),
        "direct_vector_node_count": int(node_count),
        "direct_vector_pixel_edge_count": int(edge_count),
        "direct_vector_path_count": len(paths),
        "direct_vector_raw_line_count": len(lines),
        "direct_vector_heat_retained_short_line_count": int(heat_retained),
        "direct_vector_heat_rejected_short_line_count": int(heat_rejected),
    }
    return RasterVectorResult(lines, cleaned, skeleton.astype(np.uint8) * 255, metrics)
