from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from .cli import main as core_main
from .config import load_config


@dataclass(frozen=True)
class ScenarioProfile:
    """Defaults and guardrails for one independently tuned scene family."""

    program: str
    description: str
    scene_type: str
    default_config: Path
    default_output: Path
    default_reuse_from: Path | None = None


def _parser(profile: ScenarioProfile) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog=profile.program, description=profile.description)
    parser.add_argument(
        "command",
        choices=("run", "inspect-bag", "doctor", "vectorize", "height-slices"),
        help="Pipeline stage to run",
    )
    parser.add_argument("--config", type=Path, default=profile.default_config)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--reuse-from", type=Path)
    parser.add_argument("--pcd", nargs="+", type=Path)
    parser.add_argument("--force", action="store_true")
    return parser


def build_core_argv(profile: ScenarioProfile, argv: Sequence[str] | None = None) -> list[str]:
    """Validate the scene boundary and translate scenario arguments to the core CLI."""

    args = _parser(profile).parse_args(argv)
    config_path = args.config.expanduser().resolve()
    cfg = load_config(config_path)
    actual_scene = str(cfg.get("project", {}).get("scene_type", "")).strip()
    if actual_scene != profile.scene_type:
        raise SystemExit(
            f"{profile.program} only accepts project.scene_type={profile.scene_type!r}; "
            f"{config_path} declares {actual_scene or '<missing>'!r}."
        )

    core = [args.command, "--config", str(config_path)]
    if args.command == "height-slices":
        output = (args.output or profile.default_output).expanduser().resolve()
        core.extend(("--output", str(output)))
        reuse = args.reuse_from or profile.default_reuse_from
        if reuse is not None:
            core.extend(("--reuse-from", str(reuse.expanduser().resolve())))
    elif args.output is not None or args.reuse_from is not None:
        raise SystemExit("--output/--reuse-from are only valid for height-slices")

    if args.command == "vectorize":
        if not args.pcd:
            raise SystemExit("vectorize requires at least one --pcd path")
        core.append("--pcd")
        core.extend(str(value.expanduser().resolve()) for value in args.pcd)
    elif args.pcd:
        raise SystemExit("--pcd is only valid for vectorize")

    if args.force:
        if args.command == "doctor":
            raise SystemExit("--force is not valid for doctor")
        core.append("--force")
    return core


def run_profile(profile: ScenarioProfile, argv: Sequence[str] | None = None) -> int:
    return core_main(build_core_argv(profile, argv))
