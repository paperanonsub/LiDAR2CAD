"""Indoor LiDAR map to structural outline pipeline."""

__version__ = "0.1.0"

