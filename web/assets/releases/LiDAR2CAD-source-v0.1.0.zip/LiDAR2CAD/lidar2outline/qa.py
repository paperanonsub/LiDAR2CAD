from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

from .transforms import transform_points
from .vectorize import OutlineResult


def save_mask(path: str | Path, mask: np.ndarray) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), mask)


def save_density(path: str | Path, points: np.ndarray, grid_m: float = 0.05) -> None:
    lo = np.min(points[:, :2], axis=0) - 1
    hi = np.max(points[:, :2], axis=0) + 1
    scale = max(grid_m, float(np.max(hi - lo) / 4000))
    width, height = np.ceil((hi - lo) / scale).astype(int) + 1
    ij = np.floor((points[:, :2] - lo) / scale).astype(int)
    density = np.zeros((height, width), np.float32)
    np.add.at(density, (ij[:, 1], ij[:, 0]), 1)
    density = np.log1p(density)
    density = (255 * density / max(1e-9, float(np.max(density)))).astype(np.uint8)
    density = cv2.applyColorMap(np.flipud(density), cv2.COLORMAP_BONE)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), density)



def _to_pixels(xy: np.ndarray, result: OutlineResult, scale: int = 2) -> np.ndarray:
    values = np.floor((xy - result.raster_origin) / result.grid_m).astype(int)
    values[:, 1] = result.raster.shape[0] - 1 - values[:, 1]
    return values * scale


def save_outline_overlay(path: str | Path, result: OutlineResult, trajectories: list[np.ndarray] | None = None) -> None:
    image = cv2.cvtColor(np.flipud(result.raster), cv2.COLOR_GRAY2BGR)
    image = cv2.resize(image, None, fx=2, fy=2, interpolation=cv2.INTER_NEAREST)
    shell = _to_pixels(np.asarray(result.shell_ref.exterior.coords), result)
    cv2.polylines(image, [shell], True, (255, 200, 0), 2, cv2.LINE_AA)
    for polygon in result.wall_polygons_ref:
        cv2.polylines(image, [_to_pixels(np.asarray(polygon.exterior.coords), result)], True, (230, 230, 230), 1, cv2.LINE_AA)
        for interior in polygon.interiors:
            cv2.polylines(image, [_to_pixels(np.asarray(interior.coords), result)], True, (230, 230, 230), 1, cv2.LINE_AA)
    for line in result.wall_centerlines_ref:
        cv2.polylines(image, [_to_pixels(np.asarray(line.coords), result)], False, (80, 220, 80), 1, cv2.LINE_AA)
    for line in result.doors_ref:
        cv2.polylines(image, [_to_pixels(np.asarray(line.coords), result)], False, (40, 200, 255), 2, cv2.LINE_AA)
    for line in result.windows_ref:
        cv2.polylines(image, [_to_pixels(np.asarray(line.coords), result)], False, (255, 180, 60), 2, cv2.LINE_AA)
    for line in result.scan_detail_lines_ref:
        cv2.polylines(image, [_to_pixels(np.asarray(line.coords), result)], False, (120, 120, 120), 1, cv2.LINE_AA)
    for polygon, _ in result.spaces_ref:
        cv2.polylines(image, [_to_pixels(np.asarray(polygon.exterior.coords), result)], True, (180, 120, 80), 1, cv2.LINE_AA)
    for klass, polygon, _ in result.internals_ref:
        color = (0, 255, 255) if klass == "COLUMN" else (0, 100, 255)
        cv2.polylines(image, [_to_pixels(np.asarray(polygon.exterior.coords), result)], True, color, 2, cv2.LINE_AA)
    for trajectory in trajectories or []:
        if len(trajectory):
            cv2.polylines(image, [_to_pixels(trajectory[:, :2], result)], False, (0, 255, 0), 1, cv2.LINE_AA)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), image)


def save_lidar_dxf_comparison(
    path: str | Path,
    result: OutlineResult,
    dxf_preview_path: str | Path | None = None,
) -> None:
    """Render the cropped dense LiDAR source and complete DXF layers at one scale."""
    cad_points = transform_points(result.detail_points_ref, result.transform_cad_from_ref)
    all_xy = [cad_points[:, :2], np.asarray(result.shell_cad.exterior.coords)]
    for polygon in result.wall_polygons_cad:
        all_xy.append(np.asarray(polygon.exterior.coords))
    xy = np.vstack(all_xy)
    lo = np.min(xy, axis=0) - 0.75
    hi = np.max(xy, axis=0) + 0.75
    extent = hi - lo
    scale_m = max(0.04, float(np.max(extent) / 1500))
    width, height = np.ceil(extent / scale_m).astype(int) + 1

    def pixels(values: np.ndarray) -> np.ndarray:
        out = np.floor((np.asarray(values) - lo) / scale_m).astype(np.int32)
        out[:, 1] = height - 1 - out[:, 1]
        return out

    ij = np.floor((cad_points[:, :2] - lo) / scale_m).astype(np.int64)
    valid = (ij[:, 0] >= 0) & (ij[:, 1] >= 0) & (ij[:, 0] < width) & (ij[:, 1] < height)
    density = np.zeros((height, width), np.float32)
    np.add.at(density, (height - 1 - ij[valid, 1], ij[valid, 0]), 1)
    density = np.log1p(density)
    density = np.clip(density / max(1e-9, float(np.percentile(density[density > 0], 99.5))), 0, 1)
    lidar = np.zeros((height, width, 3), np.uint8)
    lidar[:, :, 0] = (density * 210).astype(np.uint8)
    lidar[:, :, 1] = (density * 225).astype(np.uint8)
    lidar[:, :, 2] = (density * 245).astype(np.uint8)

    dxf = np.full((height, width, 3), (35, 40, 49), np.uint8)
    for line in result.wall_centerlines_cad:
        cv2.polylines(dxf, [pixels(np.asarray(line.coords))], False, (235, 235, 235), 2, cv2.LINE_AA)
    for line in result.doors_cad:
        cv2.polylines(dxf, [pixels(np.asarray(line.coords))], False, (70, 220, 255), 3, cv2.LINE_AA)
    for line in result.windows_cad:
        cv2.polylines(dxf, [pixels(np.asarray(line.coords))], False, (255, 180, 70), 3, cv2.LINE_AA)
    if (
        not result.metrics.get("fallback_shell")
        and result.metrics.get("wall_topology_source") != "vision_prediction_skeleton_graph"
    ):
        cv2.polylines(dxf, [pixels(np.asarray(result.shell_cad.exterior.coords))], True, (255, 210, 70), 2, cv2.LINE_AA)
    for klass, polygon, _ in result.internals_cad:
        color = (70, 220, 255) if klass == "COLUMN" else (80, 90, 255)
        cv2.polylines(dxf, [pixels(np.asarray(polygon.exterior.coords))], True, color, 2, cv2.LINE_AA)

    header = 74
    gutter = 18
    canvas = np.full((height + header, width * 2 + gutter, 3), (35, 40, 49), np.uint8)
    canvas[header:, :width] = lidar
    canvas[header:, width + gutter:] = dxf
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(canvas, f"Dense cropped LiDAR - {len(cad_points):,} points", (18, 31), font, 0.72, (235, 235, 235), 2, cv2.LINE_AA)
    median_error = result.metrics.get("straight_wall_distance_median_m")
    p95_error = result.metrics.get("straight_wall_distance_p95_m")
    connectivity = result.metrics.get("straight_wall_connected_endpoint_fraction")
    stable_coverage = result.metrics.get("raw_wall_structural_evidence_coverage_fraction")
    error_text = "" if median_error is None else f" - error {median_error:.3f} / {p95_error:.3f} m"
    if connectivity is not None:
        error_text += f" - connected {100.0 * connectivity:.1f}%"
    if stable_coverage is not None:
        error_text += f" - raw stable evidence {100.0 * stable_coverage:.1f}%"
    cv2.putText(
        canvas,
        f"Prediction-wall DXF - {len(result.wall_centerlines_cad)} lines{error_text}",
        (width + gutter + 18, 31),
        font,
        0.72,
        (235, 235, 235),
        2,
        cv2.LINE_AA,
    )
    bar_px = int(round(10.0 / scale_m))
    for x0 in (20, width + gutter + 20):
        y0 = height + header - 24
        cv2.line(canvas, (x0, y0), (x0 + bar_px, y0), (245, 245, 245), 4, cv2.LINE_AA)
        cv2.putText(canvas, "10 m", (x0, y0 - 8), font, 0.55, (245, 245, 245), 1, cv2.LINE_AA)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), canvas)
    if dxf_preview_path is not None:
        preview = np.full((height + header, width, 3), (35, 40, 49), np.uint8)
        preview[header:] = dxf
        cv2.putText(
            preview,
            f"Prediction-wall DXF - {len(result.wall_centerlines_cad)} lines{error_text}",
            (18, 31),
            font,
            0.65,
            (235, 235, 235),
            2,
            cv2.LINE_AA,
        )
        target = Path(dxf_preview_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(target), preview)


def save_prediction_dxf_comparison(path: str | Path, result: OutlineResult) -> None:
    """Compare the accepted vision mask with the visible DXF wall network.

    Both panels use the exact source raster coordinate system.  This makes the
    image a direct audit of raster-to-vector conversion rather than another
    point-cloud rendering with a potentially confusing CAD transform.
    """
    prediction = np.where(result.raster > 0, 255, 0).astype(np.uint8)
    height, width = prediction.shape
    left = np.zeros((height, width, 3), np.uint8)
    left[prediction > 0] = (238, 238, 238)
    right = np.full((height, width, 3), (35, 40, 49), np.uint8)

    def pixels(values: np.ndarray) -> np.ndarray:
        return np.rint(
            (np.asarray(values, dtype=float) - result.raster_origin) / result.grid_m - 0.5
        ).astype(np.int32)

    # A dim source-mask underlay exposes both omitted evidence and spurious
    # vector lines.  The bright centre-lines are the actual WALL entities.
    right[prediction > 0] = (52, 54, 57)
    for line in result.wall_centerlines_ref:
        cv2.polylines(right, [pixels(np.asarray(line.coords))], False, (245, 245, 245), 2, cv2.LINE_AA)
    for line in result.doors_ref:
        cv2.polylines(right, [pixels(np.asarray(line.coords))], False, (70, 220, 255), 2, cv2.LINE_AA)

    header = 62
    gutter = 16
    canvas = np.full((height + header, width * 2 + gutter, 3), (35, 40, 49), np.uint8)
    canvas[header:, :width] = left
    canvas[header:, width + gutter:] = right
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(canvas, "Accepted prediction.png", (16, 31), font, 0.68, (238, 238, 238), 2, cv2.LINE_AA)
    cv2.putText(
        canvas,
        f"DXF WALL - direct skeleton graph - {len(result.wall_centerlines_ref)} lines",
        (width + gutter + 16, 31),
        font,
        0.68,
        (238, 238, 238),
        2,
        cv2.LINE_AA,
    )
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), canvas)


def save_registration(path: str | Path, sessions: list[np.ndarray], transforms: list[np.ndarray], grid_m: float = 0.05) -> None:
    transformed = [transform_points(points, transform) for points, transform in zip(sessions, transforms)]
    all_xy = np.vstack([points[:, :2] for points in transformed])
    lo = np.min(all_xy, axis=0) - 1
    hi = np.max(all_xy, axis=0) + 1
    scale = max(grid_m, float(np.max(hi - lo) / 3000))
    width, height = np.ceil((hi - lo) / scale).astype(int) + 1
    image = np.zeros((height, width, 3), np.uint8)
    colors = [(255, 80, 80), (80, 255, 80), (80, 80, 255), (255, 255, 80)]
    for index, points in enumerate(transformed):
        sample = points[:: max(1, len(points) // 300_000)]
        ij = np.floor((sample[:, :2] - lo) / scale).astype(int)
        image[height - 1 - ij[:, 1], ij[:, 0]] = colors[index % len(colors)]
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), image)
