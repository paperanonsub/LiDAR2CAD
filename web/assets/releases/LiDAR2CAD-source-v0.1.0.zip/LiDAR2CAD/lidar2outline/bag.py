from __future__ import annotations

import bz2
import io
import math
import struct
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Iterator

import numpy as np

from .errors import DataQualityError, PipelineError


ROSBAG_MAGIC = b"#ROSBAG V2.0\n"
OP_MSG_DATA = 0x02
OP_BAG_HEADER = 0x03
OP_INDEX_DATA = 0x04
OP_CHUNK = 0x05
OP_CHUNK_INFO = 0x06
OP_CONNECTION = 0x07


def _u32(value: bytes) -> int:
    return struct.unpack("<I", value)[0]


def _u64(value: bytes) -> int:
    return struct.unpack("<Q", value)[0]


def _time(value: bytes) -> float:
    sec, nsec = struct.unpack("<II", value)
    return float(sec) + float(nsec) * 1e-9


def parse_header(data: bytes) -> dict[str, bytes]:
    """Parse the field map used in ROS bag record headers."""
    fields: dict[str, bytes] = {}
    pos = 0
    while pos < len(data):
        if pos + 4 > len(data):
            raise PipelineError("Truncated ROS bag header field length")
        size = struct.unpack_from("<I", data, pos)[0]
        pos += 4
        if size == 0 or pos + size > len(data):
            raise PipelineError("Invalid ROS bag header field")
        field = data[pos : pos + size]
        pos += size
        if b"=" not in field:
            raise PipelineError("ROS bag header field has no '=' separator")
        key, value = field.split(b"=", 1)
        fields[key.decode("ascii")] = value
    return fields


def _read_record(stream: BinaryIO, read_data: bool = True) -> tuple[dict[str, bytes], bytes | tuple[int, int]] | None:
    raw = stream.read(4)
    if not raw:
        return None
    if len(raw) != 4:
        raise PipelineError("Truncated ROS bag record")
    header_len = struct.unpack("<I", raw)[0]
    if header_len > 16 * 1024 * 1024:
        raise PipelineError(f"Unreasonable ROS bag header length: {header_len}")
    header = parse_header(stream.read(header_len))
    raw_len = stream.read(4)
    if len(raw_len) != 4:
        raise PipelineError("Truncated ROS bag data length")
    data_len = struct.unpack("<I", raw_len)[0]
    data_pos = stream.tell()
    if read_data:
        data = stream.read(data_len)
        if len(data) != data_len:
            raise PipelineError("Truncated ROS bag record data")
        return header, data
    stream.seek(data_len, io.SEEK_CUR)
    return header, (data_pos, data_len)


def _iter_records(data: bytes) -> Iterator[tuple[dict[str, bytes], bytes]]:
    stream = io.BytesIO(data)
    while stream.tell() < len(data):
        record = _read_record(stream, read_data=True)
        if record is None:
            break
        header, payload = record
        assert isinstance(payload, bytes)
        yield header, payload


@dataclass(frozen=True)
class Connection:
    conn: int
    topic: str
    msg_type: str
    md5sum: str


@dataclass(frozen=True)
class Chunk:
    data_pos: int
    data_len: int
    compression: str
    uncompressed_size: int


class Cursor:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def take(self, fmt: str):
        size = struct.calcsize(fmt)
        if self.pos + size > len(self.data):
            raise PipelineError("Truncated ROS message")
        values = struct.unpack_from(fmt, self.data, self.pos)
        self.pos += size
        return values[0] if len(values) == 1 else values

    def string(self) -> str:
        size = self.take("<I")
        if self.pos + size > len(self.data):
            raise PipelineError("Truncated ROS string")
        value = self.data[self.pos : self.pos + size]
        self.pos += size
        return value.decode("utf-8", errors="replace")

    def skip(self, count: int) -> None:
        if self.pos + count > len(self.data):
            raise PipelineError("Truncated ROS message array")
        self.pos += count


def _parse_std_header(cur: Cursor) -> dict:
    return {"seq": cur.take("<I"), "stamp": cur.take("<II"), "frame_id": cur.string()}


def parse_imu(data: bytes) -> dict:
    cur = Cursor(data)
    header = _parse_std_header(cur)
    orientation = np.asarray(cur.take("<dddd"), dtype=float)
    cur.skip(9 * 8)
    angular_velocity = np.asarray(cur.take("<ddd"), dtype=float)
    cur.skip(9 * 8)
    linear_acceleration = np.asarray(cur.take("<ddd"), dtype=float)
    return {
        "header": header,
        "orientation_xyzw": orientation,
        "angular_velocity": angular_velocity,
        "linear_acceleration": linear_acceleration,
    }


def parse_pointcloud2_metadata(data: bytes) -> dict:
    cur = Cursor(data)
    header = _parse_std_header(cur)
    height, width, field_count = cur.take("<III")
    fields = []
    for _ in range(field_count):
        fields.append(
            {
                "name": cur.string(),
                "offset": cur.take("<I"),
                "datatype": cur.take("<B"),
                "count": cur.take("<I"),
            }
        )
    is_bigendian = bool(cur.take("<B"))
    point_step, row_step, data_len = cur.take("<III")
    cur.skip(data_len)
    is_dense = bool(cur.take("<B"))
    return {
        "header": header,
        "height": height,
        "width": width,
        "point_count": int(height) * int(width),
        "fields": fields,
        "is_bigendian": is_bigendian,
        "point_step": point_step,
        "row_step": row_step,
        "is_dense": is_dense,
    }


def _decompress(payload: bytes, compression: str, expected: int) -> bytes:
    if compression == "none":
        data = payload
    elif compression == "bz2":
        data = bz2.decompress(payload)
    elif compression == "lz4":
        try:
            import lz4.frame
        except ImportError as exc:
            raise PipelineError("This bag uses LZ4; install lidar2outline[lz4]") from exc
        data = lz4.frame.decompress(payload)
    else:
        raise PipelineError(f"Unsupported ROS bag compression: {compression}")
    if expected and len(data) != expected:
        raise PipelineError(f"Chunk size mismatch: expected {expected}, decoded {len(data)}")
    return data


class RosbagV2:
    """Small dependency-free ROS1 bag index and message sampler."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.connections: dict[int, Connection] = {}
        self.chunks: list[Chunk] = []
        self.counts: dict[int, int] = defaultdict(int)
        self.start_time = math.inf
        self.end_time = -math.inf

    def read_index(self) -> None:
        if not self.path.is_file():
            raise PipelineError(f"Bag not found: {self.path}")
        self.connections.clear()
        self.chunks.clear()
        self.counts.clear()
        self.start_time, self.end_time = math.inf, -math.inf
        with self.path.open("rb") as stream:
            if stream.read(len(ROSBAG_MAGIC)) != ROSBAG_MAGIC:
                raise PipelineError(f"Not a ROS1 bag v2 file: {self.path}")
            while True:
                record = _read_record(stream, read_data=False)
                if record is None:
                    break
                header, location = record
                assert isinstance(location, tuple)
                data_pos, data_len = location
                op = header.get("op", b"\0")[0]
                if op == OP_CONNECTION:
                    stream.seek(data_pos)
                    data = stream.read(data_len)
                    fields = parse_header(data)
                    conn = _u32(header["conn"])
                    self.connections[conn] = Connection(
                        conn=conn,
                        topic=header["topic"].decode("utf-8", errors="replace"),
                        msg_type=fields.get("type", b"").decode("utf-8", errors="replace"),
                        md5sum=fields.get("md5sum", b"").decode("ascii", errors="replace"),
                    )
                elif op == OP_CHUNK:
                    self.chunks.append(
                        Chunk(
                            data_pos=data_pos,
                            data_len=data_len,
                            compression=header.get("compression", b"none").decode("ascii"),
                            uncompressed_size=_u32(header.get("size", b"\0\0\0\0")),
                        )
                    )
                elif op == OP_INDEX_DATA:
                    conn = _u32(header["conn"])
                    count = _u32(header["count"])
                    self.counts[conn] += count
                    if count:
                        stream.seek(data_pos)
                        data = stream.read(data_len)
                        entry_size = data_len // count
                        if entry_size >= 8:
                            for offset in range(0, data_len, entry_size):
                                if offset + 8 <= data_len:
                                    stamp = _time(data[offset : offset + 8])
                                    self.start_time = min(self.start_time, stamp)
                                    self.end_time = max(self.end_time, stamp)
                stream.seek(data_pos + data_len)

    def sample(self, topics: set[str], limit_per_topic: int = 128, max_chunks: int = 64) -> dict[str, list[bytes]]:
        if not self.chunks:
            self.read_index()
        wanted = {conn for conn, item in self.connections.items() if item.topic in topics}
        result: dict[str, list[bytes]] = {topic: [] for topic in topics}
        if not wanted:
            return result
        with self.path.open("rb") as stream:
            for chunk in self.chunks[:max_chunks]:
                stream.seek(chunk.data_pos)
                decoded = _decompress(stream.read(chunk.data_len), chunk.compression, chunk.uncompressed_size)
                for header, data in _iter_records(decoded):
                    if header.get("op", b"\0")[0] != OP_MSG_DATA:
                        continue
                    conn = _u32(header["conn"])
                    if conn in wanted:
                        topic = self.connections[conn].topic
                        if len(result[topic]) < limit_per_topic:
                            result[topic].append(data)
                if all(len(result[topic]) >= limit_per_topic for topic in topics):
                    break
        return result


def _safe_stats(values: np.ndarray) -> dict:
    values = np.asarray(values, dtype=float)
    return {
        "min": float(np.min(values)),
        "median": float(np.median(values)),
        "max": float(np.max(values)),
        "std": float(np.std(values)),
    }


def assess_imu_messages(imu_messages: list[dict]) -> dict | None:
    if not imu_messages:
        return None
    q = np.stack([m["orientation_xyzw"] for m in imu_messages])
    acc = np.stack([m["linear_acceleration"] for m in imu_messages])
    gyro = np.stack([m["angular_velocity"] for m in imu_messages])
    q_norm = np.linalg.norm(q, axis=1)
    acc_norm = np.linalg.norm(acc, axis=1)
    variation = float(max(np.max(np.std(acc, axis=0)), np.max(np.std(gyro, axis=0)), np.max(np.std(q, axis=0))))
    reasons = []
    if not np.all(np.isfinite(q)) or not np.all(np.isfinite(acc)) or not np.all(np.isfinite(gyro)):
        reasons.append("non-finite IMU values")
    if not (0.5 <= float(np.median(q_norm)) <= 1.5):
        reasons.append("orientation quaternion is not normalized")
    if not (5.0 <= float(np.median(acc_norm)) <= 15.0):
        reasons.append("acceleration magnitude is inconsistent with gravity")
    if variation < 1e-7:
        reasons.append("IMU samples are constant/placeholder values")
    return {
        "sample_count": len(imu_messages),
        "frame_ids": sorted({m["header"]["frame_id"] for m in imu_messages}),
        "quaternion_norm": _safe_stats(q_norm),
        "acceleration_norm_mps2": _safe_stats(acc_norm),
        "sample_variation": variation,
        "valid": not reasons,
        "rejection_reasons": reasons,
    }


def inspect_bag(path: str | Path, point_topic: str, imu_topic: str, sample_count: int = 128) -> dict:
    bag = RosbagV2(path)
    bag.read_index()
    samples = bag.sample({point_topic, imu_topic}, sample_count)
    topic_rows = []
    duration = max(0.0, bag.end_time - bag.start_time) if np.isfinite(bag.start_time) else 0.0
    for conn, item in sorted(bag.connections.items()):
        count = int(bag.counts.get(conn, 0))
        topic_rows.append(
            {
                "topic": item.topic,
                "type": item.msg_type,
                "count": count,
                "frequency_hz": count / duration if duration > 0 else 0.0,
            }
        )

    point_messages = [parse_pointcloud2_metadata(data) for data in samples.get(point_topic, [])]
    imu_messages = [parse_imu(data) for data in samples.get(imu_topic, [])]
    point_report = None
    if point_messages:
        first = point_messages[0]
        point_report = {
            "sample_count": len(point_messages),
            "fields": first["fields"],
            "point_step": first["point_step"],
            "point_count": _safe_stats(np.asarray([m["point_count"] for m in point_messages])),
            "frame_ids": sorted({m["header"]["frame_id"] for m in point_messages}),
        }
    imu_report = assess_imu_messages(imu_messages)

    required_fields = {"x", "y", "z", "intensity", "ring", "time"}
    found_fields = {f["name"] for f in point_report["fields"]} if point_report else set()
    failures = []
    by_topic = {row["topic"]: row for row in topic_rows}
    if point_topic not in by_topic:
        failures.append(f"missing point topic {point_topic}")
    elif by_topic[point_topic]["type"] != "sensor_msgs/PointCloud2":
        failures.append(f"{point_topic} is not sensor_msgs/PointCloud2")
    if imu_topic not in by_topic:
        failures.append(f"missing IMU topic {imu_topic}")
    elif by_topic[imu_topic]["type"] != "sensor_msgs/Imu":
        failures.append(f"{imu_topic} is not sensor_msgs/Imu")
    missing_fields = required_fields - found_fields
    if missing_fields:
        failures.append("point cloud missing fields: " + ", ".join(sorted(missing_fields)))
    if imu_report and not imu_report["valid"]:
        failures.extend(imu_report["rejection_reasons"])
    if not point_messages:
        failures.append("could not sample point cloud messages")
    if not imu_messages:
        failures.append("could not sample IMU messages")
    return {
        "path": str(Path(path).resolve()),
        "size_bytes": Path(path).stat().st_size,
        "format": "ROSBAG V2.0",
        "start_time": None if not np.isfinite(bag.start_time) else bag.start_time,
        "end_time": None if not np.isfinite(bag.end_time) else bag.end_time,
        "duration_sec": duration,
        "topics": topic_rows,
        "point_cloud": point_report,
        "imu": imu_report,
        "valid": not failures,
        "failures": failures,
    }


def require_valid_report(report: dict) -> None:
    if not report.get("valid"):
        raise DataQualityError(f"Bag failed quality checks: {report.get('path')}\n- " + "\n- ".join(report["failures"]))
