from __future__ import annotations

import json
import math
import os
import re
import tempfile
import threading
import webbrowser
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import cv2
import numpy as np
from shapely.geometry import LineString, Polygon, mapping
from shapely.validation import make_valid
from skimage.morphology import closing, disk, skeletonize

from .io import read_json


SAFE_ID = re.compile(r"^[A-Za-z0-9_-]+$")


def _atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False
    ) as stream:
        stream.write(payload)
        temporary = Path(stream.name)
    os.replace(temporary, path)


def _deduplicate_vertices(value: Any) -> list[list[float]]:
    if not isinstance(value, (list, tuple)):
        raise ValueError("vertices must be a list")
    vertices: list[list[float]] = []
    for point in value:
        if not isinstance(point, (list, tuple)) or len(point) != 2:
            raise ValueError("each vertex must be [x, y]")
        vertex = [float(point[0]), float(point[1])]
        if not all(math.isfinite(item) for item in vertex):
            raise ValueError("region contains a non-finite coordinate")
        if not vertices or np.linalg.norm(np.asarray(vertex) - np.asarray(vertices[-1])) >= 0.02:
            vertices.append(vertex)
    return vertices


def _normalise_wall_region(value: Any) -> tuple[list[list[float]], Polygon]:
    """Validate a human wall ROI. The clicked polyline is always closed here."""
    vertices = _deduplicate_vertices(value)
    if len(vertices) < 3:
        raise ValueError("墙体区域至少需要三个点")
    if np.linalg.norm(np.asarray(vertices[0]) - np.asarray(vertices[-1])) < 0.02:
        vertices[-1] = vertices[0]
    else:
        vertices.append(vertices[0])
    if len(vertices) > 4001:
        raise ValueError("墙体区域顶点过多")
    polygon = Polygon(vertices)
    if not polygon.is_valid:
        raise ValueError("区域存在自交，请撤销交叉点后重新闭合")
    if polygon.area < 0.02:
        raise ValueError("墙体区域面积过小")
    return [[float(x), float(y)] for x, y in polygon.exterior.coords], polygon


# Backward-compatible symbol. New annotations are regions, not final wall lines.
def _normalise_wall_polyline(value: Any) -> list[list[float]]:
    vertices, _ = _normalise_wall_region(value)
    return vertices


def prepare_wall_label_view(source_dir: str | Path, dataset_id: str) -> dict:
    source_dir = Path(source_dir).resolve()
    evidence_path = source_dir / "semantic_evidence.npz"
    if not evidence_path.is_file():
        raise ValueError(f"Missing V13 semantic evidence: {evidence_path}")
    with np.load(evidence_path) as evidence:
        origin = np.asarray(evidence["origin"], dtype=float)
        grid_m = float(np.asarray(evidence["grid_m"]).reshape(-1)[0])
        point_count = np.asarray(evidence["point_count"], dtype=np.float32)
        height_bins = np.asarray(evidence["height_bin_count"], dtype=np.float32)
        vertical_span = np.asarray(evidence["vertical_span_m"], dtype=np.float32)
    density = np.log1p(point_count)
    positive = density[density > 0]
    density /= max(float(np.quantile(positive, 0.995)) if len(positive) else 1.0, 1e-6)
    density = np.clip(density, 0.0, 1.0)
    persistent = np.clip(vertical_span / 1.5, 0.0, 1.0) * np.clip(height_bins / 8.0, 0.0, 1.0)
    base = np.round(18 + 185 * np.power(density, 0.55)).astype(np.uint8)
    image = np.dstack(
        [
            np.clip(base.astype(float) + 45 * persistent, 0, 255),
            np.clip(base.astype(float) + 28 * persistent, 0, 255),
            base,
        ]
    ).astype(np.uint8)
    image[point_count <= 0] = 0
    image = np.flipud(image)
    view_path = source_dir / "wall_label_full_projection.png"
    metadata_path = source_dir / "wall_label_full_projection.json"
    cv2.imwrite(str(view_path), image)
    metadata = {
        "dataset_id": dataset_id,
        "coordinate_frame": "reference_slam_xy_m",
        "origin_ref": origin.tolist(),
        "grid_m_per_px": grid_m,
        "width_px": int(image.shape[1]),
        "height_px": int(image.shape[0]),
        "y_axis_up": True,
        "source": "clean_interior_unique_xy_z_evidence",
    }
    _atomic_write_json(metadata_path, metadata)
    return {"view_path": str(view_path), "metadata_path": str(metadata_path), "metadata": metadata}


def prepare_wall_region_manifest(output_path: str | Path, dataset_id: str, source_dir: str | Path) -> dict:
    path = Path(output_path).resolve()
    if path.is_file():
        value = read_json(path)
        if value.get("schema_version") == "wall-polylines-v1":
            raise ValueError("这是旧版开放多段线文件；请先迁移为 wall-regions-v1，原文件不会被覆盖")
        value.setdefault("regions", [])
    else:
        value = {"regions": []}
    value.update(
        {
            "schema_version": "wall-regions-v1",
            "dataset_id": dataset_id,
            "coordinate_frame": "reference_slam_xy_m",
            "source_dir": str(Path(source_dir).resolve()),
            "annotation_semantics": "human wall ROI; wall evidence is extracted automatically inside",
        }
    )
    _atomic_write_json(path, value)
    return value


def prepare_wall_polyline_manifest(output_path: str | Path, dataset_id: str, source_dir: str | Path) -> dict:
    return prepare_wall_region_manifest(output_path, dataset_id, source_dir)


def migrate_wall_polylines_to_regions(
    input_path: str | Path,
    output_path: str | Path,
    dataset_id: str | None = None,
    source_dir: str | Path | None = None,
) -> dict:
    """Convert legacy user-drawn boundaries without overwriting the original file."""
    input_path = Path(input_path).resolve()
    output_path = Path(output_path).resolve()
    if input_path == output_path:
        raise ValueError("迁移输出不能覆盖原始多段线文件")
    old = read_json(input_path)
    regions: list[dict] = []
    repaired = 0
    for index, item in enumerate(old.get("polylines", []), start=1):
        vertices = _deduplicate_vertices(item.get("vertices_ref", []))
        if len(vertices) < 3:
            continue
        polygon = Polygon(vertices)
        repair_method = None
        if not polygon.is_valid:
            fixed = make_valid(polygon)
            polygons = [fixed] if isinstance(fixed, Polygon) else [g for g in getattr(fixed, "geoms", []) if isinstance(g, Polygon)]
            if not polygons:
                continue
            polygon = max(polygons, key=lambda value: value.area)
            repair_method = "shapely_make_valid"
            repaired += 1
        if polygon.area < 0.02:
            continue
        regions.append(
            {
                "region_id": f"wall-region-{index:05d}",
                "polygon_ref": [[float(x), float(y)] for x, y in polygon.exterior.coords],
                "area_m2": float(polygon.area),
                "status": "accepted",
                "source": "migrated_human_full_map_boundary",
                "legacy_wall_id": item.get("wall_id"),
                "repair_method": repair_method,
                "created_at": item.get("created_at", datetime.now(timezone.utc).isoformat()),
            }
        )
    value = {
        "schema_version": "wall-regions-v1",
        "dataset_id": dataset_id or old.get("dataset_id", "unknown"),
        "coordinate_frame": "reference_slam_xy_m",
        "source_dir": str(Path(source_dir or old.get("source_dir", ".")).resolve()),
        "annotation_semantics": "human wall ROI; wall evidence is extracted automatically inside",
        "migration": {
            "source": str(input_path),
            "legacy_count": len(old.get("polylines", [])),
            "region_count": len(regions),
            "repaired_count": repaired,
        },
        "regions": regions,
    }
    _atomic_write_json(output_path, value)
    return value


def _region_mask(regions: list[dict], origin: np.ndarray, grid_m: float, shape: tuple[int, int]) -> np.ndarray:
    mask = np.zeros(shape, np.uint8)
    for region in regions:
        if region.get("status", "accepted") != "accepted":
            continue
        vertices = np.asarray(region.get("polygon_ref", []), dtype=float)
        if len(vertices) < 4:
            continue
        pixels = np.round((vertices - origin) / grid_m).astype(np.int32)
        cv2.fillPoly(mask, [pixels], 1)
    return mask.astype(bool)


def _remove_small_components(mask: np.ndarray, minimum_cells: int) -> np.ndarray:
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    result = np.zeros(mask.shape, dtype=bool)
    for component in range(1, count):
        if int(stats[component, cv2.CC_STAT_AREA]) >= minimum_cells:
            result[labels == component] = True
    return result


def _skeleton_paths(mask: np.ndarray, origin: np.ndarray, grid_m: float) -> list[LineString]:
    skeleton = skeletonize(mask > 0)
    coords = {tuple(value) for value in np.argwhere(skeleton)}
    offsets = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    def neighbours(node: tuple[int, int]) -> list[tuple[int, int]]:
        return [(node[0] + dr, node[1] + dc) for dr, dc in offsets if (node[0] + dr, node[1] + dc) in coords]

    terminals = {node for node in coords if len(neighbours(node)) != 2}
    visited: set[frozenset[tuple[int, int]]] = set()
    paths: list[list[tuple[int, int]]] = []

    def walk(start: tuple[int, int], nxt: tuple[int, int]) -> list[tuple[int, int]]:
        result = [start, nxt]
        previous, current = start, nxt
        visited.add(frozenset((previous, current)))
        while current not in terminals:
            options = [node for node in neighbours(current) if node != previous]
            if not options:
                break
            candidate = options[0]
            edge = frozenset((current, candidate))
            if edge in visited:
                break
            visited.add(edge)
            result.append(candidate)
            previous, current = current, candidate
        return result

    for node in terminals or coords:
        for nxt in neighbours(node):
            if frozenset((node, nxt)) not in visited:
                paths.append(walk(node, nxt))
    lines: list[LineString] = []
    for path in paths:
        xy = np.asarray([[origin[0] + col * grid_m, origin[1] + row * grid_m] for row, col in path])
        if len(xy) < 2:
            continue
        line = LineString(xy).simplify(max(0.025, grid_m * 0.75), preserve_topology=False)
        if line.geom_type == "LineString" and line.length >= 0.20:
            lines.append(line)
    return lines


def extract_wall_edges_from_regions(source_dir: str | Path, labels_path: str | Path, output_dir: str | Path) -> dict:
    """Extract persistent wall evidence inside human ROIs; ROI pixels alone are never labels."""
    source_dir = Path(source_dir).resolve()
    labels = read_json(labels_path)
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    with np.load(source_dir / "semantic_evidence.npz") as evidence:
        origin = np.asarray(evidence["origin"], dtype=float)
        grid_m = float(np.asarray(evidence["grid_m"]).reshape(-1)[0])
        point_count = np.asarray(evidence["point_count"], dtype=np.float32)
        height_bins = np.asarray(evidence["height_bin_count"], dtype=np.float32)
        vertical_span = np.asarray(evidence["vertical_span_m"], dtype=np.float32)
        continuity = np.asarray(evidence["vertical_continuity"], dtype=np.float32) if "vertical_continuity" in evidence else np.zeros_like(point_count)
        thin_vote = np.asarray(evidence["thin_vote"], dtype=np.float32) if "thin_vote" in evidence else np.zeros_like(point_count)
        thick_vote = np.asarray(evidence["thick_vote"], dtype=np.float32) if "thick_vote" in evidence else np.zeros_like(point_count)
        structural = np.asarray(evidence["structural_mask"], dtype=bool) if "structural_mask" in evidence else point_count > 0
    roi = _region_mask(labels.get("regions", []), origin, grid_m, point_count.shape)
    nonzero_roi = roi & (point_count > 0)
    density_threshold = max(1.0, float(np.quantile(point_count[nonzero_roi], 0.10))) if np.any(nonzero_roi) else 1.0
    vertical = (vertical_span >= 0.80) & (height_bins >= 4) & (continuity >= 0.25)
    multiscale = np.maximum(thin_vote, thick_vote) >= 0.08
    candidate = roi & structural & vertical & multiscale & (point_count >= density_threshold)
    candidate = closing(candidate, disk(1))
    candidate = _remove_small_components(candidate, max(3, int(round(0.15 / grid_m))))
    paths = _skeleton_paths(candidate, origin, grid_m)
    geojson = {
        "type": "FeatureCollection",
        "properties": {
            "schema_version": "wall-region-evidence-v1",
            "coordinate_frame": "reference_slam_xy_m",
            "note": "human ROIs constrain search; geometry is extracted from persistent point-cloud evidence",
        },
        "features": [
            {
                "type": "Feature",
                "properties": {"edge_id": f"wall-edge-{index:05d}", "source": "roi_pointcloud_skeleton"},
                "geometry": mapping(line),
            }
            for index, line in enumerate(paths, start=1)
        ],
    }
    geojson_path = output_dir / "wall_edges.geojson"
    _atomic_write_json(geojson_path, geojson)
    cv2.imwrite(str(output_dir / "wall_region_mask.png"), np.flipud(roi.astype(np.uint8) * 255))
    cv2.imwrite(str(output_dir / "wall_candidate_mask.png"), np.flipud(candidate.astype(np.uint8) * 255))
    skeleton = skeletonize(candidate).astype(np.uint8)
    cv2.imwrite(str(output_dir / "wall_edges_skeleton.png"), np.flipud(skeleton * 255))
    np.savez_compressed(
        output_dir / "wall_evidence_masks.npz",
        origin=origin,
        grid_m=np.asarray([grid_m], dtype=float),
        roi_mask=roi,
        wall_candidate_mask=candidate,
        edge_skeleton=skeleton,
    )
    base = cv2.imread(str(source_dir / "wall_label_full_projection.png"), cv2.IMREAD_COLOR)
    if base is None:
        prepare_wall_label_view(source_dir, str(labels.get("dataset_id", "unknown")))
        base = cv2.imread(str(source_dir / "wall_label_full_projection.png"), cv2.IMREAD_COLOR)
    overlay = base.copy()
    roi_display = np.flipud(roi)
    candidate_display = np.flipud(candidate)
    tint = np.zeros_like(overlay)
    tint[:, :, 1] = roi_display.astype(np.uint8) * 120
    overlay = cv2.addWeighted(overlay, 1.0, tint, 0.35, 0)
    overlay[candidate_display] = (0, 230, 255)
    for line in paths:
        xy = np.asarray(line.coords)
        pixels = np.column_stack(((xy[:, 0] - origin[0]) / grid_m, point_count.shape[0] - 1 - (xy[:, 1] - origin[1]) / grid_m))
        cv2.polylines(overlay, [np.round(pixels).astype(np.int32)], False, (255, 80, 20), 2, cv2.LINE_AA)
    overlay_path = output_dir / "wall_roi_evidence_edges.png"
    cv2.imwrite(str(overlay_path), overlay)
    report = {
        "schema_version": "wall-region-extraction-v1",
        "dataset_id": labels.get("dataset_id"),
        "accepted_region_count": int(sum(r.get("status", "accepted") == "accepted" for r in labels.get("regions", []))),
        "roi_area_m2": float(np.count_nonzero(roi) * grid_m * grid_m),
        "candidate_area_m2": float(np.count_nonzero(candidate) * grid_m * grid_m),
        "edge_path_count": len(paths),
        "edge_length_m": float(sum(line.length for line in paths)),
        "criteria": {
            "min_vertical_span_m": 0.80,
            "min_height_bins": 4,
            "min_vertical_continuity": 0.25,
            "min_multiscale_vote": 0.08,
            "density_threshold_points": density_threshold,
        },
        "outputs": {
            "region_mask": str((output_dir / "wall_region_mask.png").resolve()),
            "candidate_mask": str((output_dir / "wall_candidate_mask.png").resolve()),
            "edge_skeleton": str((output_dir / "wall_edges_skeleton.png").resolve()),
            "edge_geojson": str(geojson_path.resolve()),
            "evidence_masks": str((output_dir / "wall_evidence_masks.npz").resolve()),
            "overlay": str(overlay_path.resolve()),
        },
    }
    _atomic_write_json(output_dir / "wall_region_extraction_report.json", report)
    return report


def derive_wall_object_labels_from_regions(
    source_dir: str | Path,
    extraction_dir: str | Path,
    semantic_labels_path: str | Path,
    output_path: str | Path,
) -> dict:
    """Transfer reviewed ROI evidence to compatible wall objects without overwriting manual labels."""
    source_dir = Path(source_dir).resolve()
    extraction_dir = Path(extraction_dir).resolve()
    semantic_labels_path = Path(semantic_labels_path).resolve()
    output_path = Path(output_path).resolve()
    graph = read_json(source_dir / "building_object_graph.json")
    manifest = read_json(semantic_labels_path)
    with np.load(extraction_dir / "wall_evidence_masks.npz") as masks:
        origin = np.asarray(masks["origin"], dtype=float)
        grid_m = float(np.asarray(masks["grid_m"]).reshape(-1)[0])
        roi = np.asarray(masks["roi_mask"], dtype=bool)
        evidence = np.asarray(masks["wall_candidate_mask"], dtype=np.uint8)
    # One-pixel tolerance handles discretisation, not missing wall evidence.
    evidence = cv2.dilate(evidence, np.ones((3, 3), np.uint8), iterations=1) > 0
    objects = {
        value.get("object_id"): value
        for key in ("walls", "uncertain")
        for value in graph.get(key, [])
        if value.get("object_id")
    }
    accepted: list[dict] = []
    non_wall: list[dict] = []
    rejected: list[dict] = []
    preserved_manual = 0
    for record in manifest.get("records", []):
        value = objects.get(record.get("object_id"))
        if value is None or value.get("class") not in ("WALL", "UNKNOWN_WALL"):
            continue
        coordinates = np.asarray(value.get("primitive", {}).get("coordinates_ref", []), dtype=float)
        if len(coordinates) < 2:
            rejected.append({"object_id": record.get("object_id"), "reason": "missing_wall_geometry"})
            continue
        line = LineString(coordinates)
        count = max(2, int(math.ceil(line.length / max(grid_m, 0.05))) + 1)
        samples = np.asarray([line.interpolate(distance).coords[0] for distance in np.linspace(0.0, line.length, count)])
        pixels = np.floor((samples - origin) / grid_m).astype(int)
        inside_grid = (
            (pixels[:, 0] >= 0) & (pixels[:, 0] < roi.shape[1])
            & (pixels[:, 1] >= 0) & (pixels[:, 1] < roi.shape[0])
        )
        roi_support = np.zeros(len(samples), dtype=bool)
        evidence_support = np.zeros(len(samples), dtype=bool)
        valid = pixels[inside_grid]
        roi_support[inside_grid] = roi[valid[:, 1], valid[:, 0]]
        evidence_support[inside_grid] = evidence[valid[:, 1], valid[:, 0]]
        roi_fraction = float(np.mean(roi_support))
        evidence_fraction = float(np.mean(evidence_support))
        match = {
            "object_id": record.get("object_id"),
            "length_m": float(line.length),
            "roi_fraction": roi_fraction,
            "wall_evidence_fraction": evidence_fraction,
        }
        record["wall_roi_support"] = {
            "roi_fraction": roi_fraction,
            "wall_evidence_fraction": evidence_fraction,
            "minimum_roi_fraction": 0.80,
            "minimum_evidence_fraction": 0.60,
        }
        if roi_fraction >= 0.80 and evidence_fraction >= 0.60:
            if record.get("label") not in (None, "wall"):
                match["reason"] = "preserved_existing_manual_label"
                preserved_manual += 1
                rejected.append(match)
                continue
            record["label"] = "wall"
            record["label_source"] = "human_wall_roi_plus_pointcloud_edge"
            accepted.append(match)
        elif roi_fraction <= 0.10 and record.get("label") is None:
            # The user declared the full-map wall ROI annotation complete. A
            # wall candidate wholly outside every ROI is therefore a reviewed
            # negative for the binary wall task. It is deliberately called
            # non_wall, not furniture/non_building.
            record["label"] = "non_wall"
            record["label_source"] = "completed_human_wall_roi_complement"
            if "non_wall" not in record.setdefault("allowed_labels", []):
                record["allowed_labels"].append("non_wall")
            match["reason"] = "outside_all_completed_wall_rois"
            non_wall.append(match)
        else:
            match["reason"] = "insufficient_roi_or_wall_evidence"
            rejected.append(match)
    manifest["wall_region_derivation"] = {
        "source_semantic_labels": str(semantic_labels_path),
        "source_extraction": str(extraction_dir / "wall_region_extraction_report.json"),
        "accepted_count": len(accepted),
        "non_wall_count": len(non_wall),
        "preserved_manual_count": preserved_manual,
        "policy": "ROI coverage >=0.80 and extracted wall evidence coverage >=0.60",
    }
    _atomic_write_json(output_path, manifest)
    match_report = {
        **manifest["wall_region_derivation"],
        "accepted": accepted,
        "non_wall": non_wall,
        "rejected": rejected,
        "output_labels": str(output_path),
    }
    _atomic_write_json(extraction_dir / "wall_object_label_matches.json", match_report)
    return match_report


def render_wall_polyline_overlay(source_dir: str | Path, labels_path: str | Path, output_path: str | Path) -> dict:
    """Render either new filled ROIs or legacy open lines for comparison."""
    source_dir = Path(source_dir)
    image = cv2.imread(str(source_dir / "wall_label_full_projection.png"), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("wall-label projection is missing")
    metadata = read_json(source_dir / "wall_label_full_projection.json")
    labels = read_json(labels_path)
    origin = np.asarray(metadata["origin_ref"], dtype=float)
    grid_m = float(metadata["grid_m_per_px"])
    height = int(metadata["height_px"])
    overlay = image.copy()
    items = labels.get("regions", labels.get("polylines", []))
    for item in items:
        key = "polygon_ref" if "polygon_ref" in item else "vertices_ref"
        vertices = np.asarray(item.get(key, []), dtype=float)
        if len(vertices) < 2:
            continue
        pixels = np.column_stack(((vertices[:, 0] - origin[0]) / grid_m, height - 1 - (vertices[:, 1] - origin[1]) / grid_m))
        pixels = np.round(pixels).astype(np.int32)
        if key == "polygon_ref":
            tint = np.zeros_like(image)
            cv2.fillPoly(tint, [pixels], (30, 160, 255))
            overlay = cv2.addWeighted(overlay, 1.0, tint, 0.24, 0)
            cv2.polylines(overlay, [pixels], True, (0, 220, 255), 2, cv2.LINE_AA)
        else:
            cv2.polylines(overlay, [pixels], False, (0, 220, 255), 2, cv2.LINE_AA)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output_path), overlay)
    return {"region_count": len(items), "output": str(output_path.resolve())}


HTML = r"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>整图墙体区域标注</title><style>
:root{color-scheme:dark;--bg:#101318;--panel:#191e26;--line:#303949;--muted:#91a0b6;--accent:#ff4fd8}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#eef3fa;font-family:Inter,"Microsoft YaHei",sans-serif}header{height:66px;padding:11px 18px;background:#141922;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:18px}h1{font-size:19px;margin:0}.meta{font-size:13px;color:var(--muted)}main{display:grid;grid-template-columns:minmax(700px,1fr) 350px;gap:14px;padding:14px;max-width:2100px;margin:auto}.viewer,.controls{background:var(--panel);border:1px solid var(--line);border-radius:11px;overflow:hidden}.viewer{display:flex;justify-content:center;align-items:flex-start;background:#000;min-height:600px}.viewer canvas{display:block;max-width:100%;max-height:calc(100vh - 96px);width:auto;height:auto;background:#000;cursor:crosshair}.controls{height:calc(100vh - 96px);overflow:auto;padding:16px}.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}button{background:#293241;color:white;border:1px solid #48566d;border-radius:7px;padding:9px 11px;cursor:pointer}button.primary{background:#8b176d}button.danger{background:#8f1d35}.status{color:#7dd3fc;min-height:42px;line-height:1.5}.list{display:flex;flex-direction:column;gap:7px;margin-top:10px}.row{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;background:#111720;padding:8px;border-radius:7px}.row small{color:var(--muted)}.help{font-size:13px;line-height:1.7;color:var(--muted);margin-top:16px}@media(max-width:1050px){main{grid-template-columns:1fr}.controls{height:auto}.viewer canvas{max-height:none}}
</style></head><body><header><div><h1 id="title">整图墙体区域标注</h1><div class="meta" id="path"></div></div><div class="meta" id="counter"></div></header><main><section class="viewer"><canvas id="view"></canvas></section><aside class="controls"><div class="toolbar"><button id="newRegion" class="primary">新建墙体区域</button><button id="undoPoint">撤销一点</button><button id="finishRegion">闭合并保存</button><button id="cancelRegion">取消本区</button><button id="undoRegion" class="danger">删除上一区域</button><button id="resetView">重置视图</button></div><div class="status" id="status">点击“新建墙体区域”开始。</div><div class="meta">已保存区域</div><div class="list" id="regionList"></div><div class="help"><b>你只负责框选范围</b><br>沿墙体区域外围依次点击，按 Enter 或“闭合并保存”。程序会自动连接最后一点与第一点。你画的是搜索范围，不是最终墙线。<br><br><b>算法负责提取</b><br>保存后，程序会在框内利用点云竖向连续性、薄/厚切片共同证据和边缘/骨架提取生成墙标签；框内家具不会仅因被圈中而自动变成墙。<br><br><b>操作</b><br>滚轮缩放；按住右键或中键平移；Backspace 撤销一点；Esc 取消当前区域。</div></aside></main><script>
let state=null,image=null,drawing=false,draft=[],zoom=1,panX=0,panY=0,panning=false,lastPan=null;const $=id=>document.getElementById(id);
function canvasPoint(e){const c=$("view"),r=c.getBoundingClientRect();return[(e.clientX-r.left)*c.width/r.width,(e.clientY-r.top)*c.height/r.height]}
function imagePoint(p){return[(p[0]-panX)/zoom,(p[1]-panY)/zoom]}
function refFromImage(p){const m=state.metadata;return[m.origin_ref[0]+p[0]*m.grid_m_per_px,m.origin_ref[1]+(m.height_px-1-p[1])*m.grid_m_per_px]}
function imageFromRef(p){const m=state.metadata;return[(p[0]-m.origin_ref[0])/m.grid_m_per_px,m.height_px-1-(p[1]-m.origin_ref[1])/m.grid_m_per_px]}
function colour(index){const values=["#00e5ff","#ffd54f","#76ff03","#ff6e40","#b388ff","#40c4ff"];return values[index%values.length]}
function drawPolygon(ctx,points,color,draftMode=false){if(points.length<1)return;ctx.save();ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=(draftMode?4:3)/zoom;ctx.setLineDash(draftMode?[8/zoom,5/zoom]:[]);ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);for(let i=1;i<points.length;i++)ctx.lineTo(points[i][0],points[i][1]);if(!draftMode&&points.length>=3)ctx.closePath();if(!draftMode){ctx.globalAlpha=.20;ctx.fill();ctx.globalAlpha=1}ctx.stroke();for(const p of points){ctx.beginPath();ctx.arc(p[0],p[1],4/zoom,0,Math.PI*2);ctx.fill()}ctx.restore()}
function draw(){if(!image||!state)return;const c=$("view"),ctx=c.getContext("2d");ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,c.width,c.height);ctx.setTransform(zoom,0,0,zoom,panX,panY);ctx.drawImage(image,0,0);state.regions.forEach((region,i)=>drawPolygon(ctx,region.polygon_ref.map(imageFromRef),colour(i)));drawPolygon(ctx,draft,"#ff4fd8",true);ctx.setTransform(1,0,0,1,0,0)}
function area(v){let a=0;for(let i=0,j=v.length-1;i<v.length;j=i++)a+=(v[j][0]*v[i][1]-v[i][0]*v[j][1]);return Math.abs(a/2)}
function renderList(){const list=$("regionList");list.innerHTML="";state.regions.slice().reverse().forEach(region=>{const row=document.createElement("div");row.className="row";const text=document.createElement("div");text.innerHTML=`${region.region_id}<br><small>${region.polygon_ref.length-1} 点 · ${area(region.polygon_ref).toFixed(2)} m²</small>`;const button=document.createElement("button");button.textContent="删除";button.className="danger";button.onclick=()=>deleteRegion(region.region_id);row.append(text,button);list.append(row)});$("counter").textContent=`${state.dataset_id} · ${state.regions.length} 个墙体区域`}
async function load(){const response=await fetch("/api/state");state=await response.json();$("title").textContent=`整图墙体区域标注 · ${state.dataset_id}`;$("path").textContent=state.labels_path;image=new Image();image.onload=()=>{const c=$("view");c.width=image.naturalWidth;c.height=image.naturalHeight;draw()};image.src=`/projection.png?${Date.now()}`;renderList()}
async function saveRegion(){if(draft.length<3){$("status").textContent="至少需要三个点。";return}const vertices=draft.map(refFromImage);const response=await fetch("/api/region",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({polygon_ref:vertices})});const value=await response.json();if(!response.ok){$("status").textContent=value.error||"保存失败";return}state.regions=value.regions;draft=[];drawing=false;$("status").textContent=`已闭合并保存 ${value.region.region_id}`;renderList();draw()}
async function deleteRegion(id){const response=await fetch("/api/delete",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({region_id:id})});const value=await response.json();if(response.ok){state.regions=value.regions;renderList();draw()}}
$("newRegion").onclick=()=>{drawing=true;draft=[];$("status").textContent="请沿墙体区域外围依次点击；无需手动画回起点。";draw()};$("undoPoint").onclick=()=>{draft.pop();draw()};$("finishRegion").onclick=saveRegion;$("cancelRegion").onclick=()=>{draft=[];drawing=false;$("status").textContent="已取消本区域。";draw()};$("undoRegion").onclick=()=>{if(state.regions.length)deleteRegion(state.regions[state.regions.length-1].region_id)};$("resetView").onclick=()=>{zoom=1;panX=0;panY=0;draw()};
$("view").oncontextmenu=e=>e.preventDefault();$("view").onmousedown=e=>{if(e.button===1||e.button===2){panning=true;lastPan=canvasPoint(e);e.preventDefault()}};window.onmouseup=()=>{panning=false;lastPan=null};$("view").onmousemove=e=>{if(!panning)return;const p=canvasPoint(e);panX+=p[0]-lastPan[0];panY+=p[1]-lastPan[1];lastPan=p;draw()};$("view").onclick=e=>{if(!drawing||e.button!==0)return;const p=canvasPoint(e),q=imagePoint(p);if(q[0]<0||q[1]<0||q[0]>=state.metadata.width_px||q[1]>=state.metadata.height_px)return;draft.push(q);$("status").textContent=`本区域已添加 ${draft.length} 个点`;draw()};$("view").onwheel=e=>{e.preventDefault();const p=canvasPoint(e),before=imagePoint(p),factor=e.deltaY<0?1.2:1/1.2;zoom=Math.max(.5,Math.min(10,zoom*factor));panX=p[0]-before[0]*zoom;panY=p[1]-before[1]*zoom;draw()};
window.onkeydown=e=>{if(e.key==="Enter"&&drawing){e.preventDefault();saveRegion()}else if(e.key==="Backspace"&&drawing){e.preventDefault();draft.pop();draw()}else if(e.key==="Escape"&&drawing){draft=[];drawing=false;draw()}};load();
</script></body></html>"""


class WallLabelServer(ThreadingHTTPServer):
    def __init__(self, address, labels_path: Path, view_path: Path, metadata: dict):
        super().__init__(address, WallLabelHandler)
        self.labels_path = labels_path
        self.view_path = view_path
        self.metadata = metadata
        self.write_lock = threading.Lock()


class WallLabelHandler(BaseHTTPRequestHandler):
    server: WallLabelServer

    def _json(self, value: Any, status: int = 200) -> None:
        payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/":
            payload = HTML.encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if path == "/projection.png":
            payload = self.server.view_path.read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)
            return
        if path == "/api/state":
            value = read_json(self.server.labels_path)
            self._json({**value, "metadata": self.server.metadata, "labels_path": str(self.server.labels_path)})
            return
        self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        try:
            length = int(self.headers.get("Content-Length", "0"))
            request = json.loads(self.rfile.read(length).decode("utf-8"))
            path = urlparse(self.path).path
            with self.server.write_lock:
                value = read_json(self.server.labels_path)
                if path == "/api/region":
                    vertices, polygon = _normalise_wall_region(request.get("polygon_ref"))
                    next_index = max([int(str(item.get("region_id", "wall-region-0")).split("-")[-1]) for item in value.get("regions", [])], default=0) + 1
                    region = {
                        "region_id": f"wall-region-{next_index:05d}",
                        "polygon_ref": vertices,
                        "area_m2": float(polygon.area),
                        "status": "accepted",
                        "source": "human_full_map_roi",
                        "created_at": datetime.now(timezone.utc).isoformat(),
                    }
                    value.setdefault("regions", []).append(region)
                    _atomic_write_json(self.server.labels_path, value)
                    self._json({"ok": True, "region": region, "regions": value["regions"]})
                    return
                if path == "/api/delete":
                    region_id = str(request.get("region_id", ""))
                    if not SAFE_ID.fullmatch(region_id):
                        raise ValueError("invalid region id")
                    before = len(value.get("regions", []))
                    value["regions"] = [item for item in value.get("regions", []) if item.get("region_id") != region_id]
                    if len(value["regions"]) == before:
                        raise ValueError("unknown region id")
                    _atomic_write_json(self.server.labels_path, value)
                    self._json({"ok": True, "regions": value["regions"]})
                    return
            self.send_error(HTTPStatus.NOT_FOUND)
        except (ValueError, OSError, json.JSONDecodeError) as exc:
            self._json({"error": str(exc)}, 400)

    def log_message(self, format: str, *args: Any) -> None:
        return


def run_semantic_wall_label_ui(
    source_dir: str | Path,
    labels_path: str | Path,
    dataset_id: str,
    host: str = "127.0.0.1",
    port: int = 8770,
    open_browser: bool = True,
) -> None:
    source_dir = Path(source_dir).resolve()
    labels_path = Path(labels_path).resolve()
    report = prepare_wall_label_view(source_dir, dataset_id)
    prepare_wall_region_manifest(labels_path, dataset_id, source_dir)
    server = WallLabelServer((host, int(port)), labels_path, Path(report["view_path"]), report["metadata"])
    url = f"http://{host}:{port}/"
    print(f"Full-map wall ROI UI: {url}")
    print(f"Labels: {labels_path}")
    print(f"Projection: {report['metadata']['width_px']} x {report['metadata']['height_px']} px at {report['metadata']['grid_m_per_px']:.3f} m/px")
    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
