class PipelineError(RuntimeError):
    """An expected, user-actionable pipeline failure."""


class DataQualityError(PipelineError):
    """Input data failed a hard quality gate."""


class ExternalToolError(PipelineError):
    """A required ROS/WSL process failed."""

