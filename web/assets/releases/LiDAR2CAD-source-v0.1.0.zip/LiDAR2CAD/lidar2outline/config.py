from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import re
from typing import Any

import yaml

from .errors import PipelineError


DEFAULTS: dict[str, Any] = {
    "project": {"name": "run", "output_dir": "outputs/run", "level": "0"},
    "runtime": {
        "wsl_distribution": "Ubuntu-20.04",
        "ros_setup": "/opt/ros/noetic/setup.bash",
        "workspace": "~/lidar2outline_ros_ws",
        "playback_rate": 1.0,
    },
    "registration": {
        "grid_m": 0.05,
        "max_points": 50000,
        "overlap_min": 0.35,
        "rmse_max_m": 0.15,
        "wall_direction_max_deg": 5.0,
        "yaw_candidate_peaks": 4,
    },
    "structure": {
        "grid_m": 0.05,
        "height_bin_m": 0.20,
        "min_height_m": 0.25,
        "max_height_m": 2.5,
        "ceiling_margin_m": 0.2,
        "vertical_span_m": 1.2,
        "min_height_bins": 4,
        "min_session_support": 2,
        "max_gap_m": 0.8,
        "snap_angle_deg": 5.0,
        "shell_simplify_m": 0.1,
        "concave_hull_ratio": 0.03,
        "min_internal_area_m2": 0.04,
        "shell_clearance_m": 0.3,
        "column_max_area_m2": 4.0,
        "detail_grid_m": 0.05,
        "detail_min_points_per_cell": 4,
        "projected_detail_min_points_per_cell": 8,
        "detail_min_height_bins": 2,
        "detail_min_component_cells": 4,
        "detail_simplify_m": 0.05,
        "detail_min_wall_area_m2": 0.015,
        "detail_min_wall_perimeter_m": 0.40,
        "detail_scope_margin_m": 0.0,
        "straight_wall_support_distance_m": 0.15,
        "straight_wall_bridge_gap_m": 0.15,
        "straight_wall_min_length_m": 0.75,
        "straight_wall_oblique_min_length_m": 1.50,
        "straight_wall_merge_angle_deg": 1.0,
        "straight_wall_merge_offset_m": 0.25,
        "straight_wall_merge_gap_m": 0.12,
        "straight_wall_junction_tolerance_m": 0.20,
        "ceiling_assist_enabled": True,
        "ceiling_assist_below_m": 0.26,
        "ceiling_assist_above_m": 0.18,
        "ceiling_assist_min_points_per_cell": 4,
        "ceiling_assist_min_component_cells": 4,
        "ceiling_assist_support_distance_m": 0.10,
        "ceiling_assist_bridge_gap_m": 0.20,
        "ceiling_assist_min_length_m": 0.50,
        "ceiling_assist_dedup_angle_deg": 2.0,
        "ceiling_assist_dedup_offset_m": 0.16,
        "ceiling_assist_merge_gap_m": 0.80,
        "ceiling_shell_enabled": True,
        "ceiling_shell_min_points_per_cell": 1,
        "ceiling_shell_max_path_distance_m": 5.0,
        "ceiling_shell_close_gap_m": 0.80,
        "ceiling_shell_simplify_m": 0.40,
        "ceiling_shell_opening_m": 0.50,
        "ceiling_shell_post_simplify_m": 0.20,
        "ceiling_shell_min_trajectory_containment": 0.95,
        "room_gap_close_m": 0.90,
        "min_space_area_m2": 1.0,
        "vision_open_wall_fusion_enabled": True,
        "vision_open_wall_min_length_m": 1.0,
        "vision_open_wall_redundancy_buffer_m": 0.18,
        "vision_open_wall_merge_gap_m": 0.30,
        "vision_open_wall_anchor_tolerance_m": 0.35,
        "vision_open_wall_one_anchor_min_length_m": 1.40,
        "vision_open_wall_unanchored_min_length_m": 4.50,
    },
    "vision_layout": {
        "enabled": False,
        "backend": "lane2structure",
        "seed": 23,
        "patch_size": 256,
        "base_channels": 16,
        "epochs": 14,
        "samples_per_epoch": 192,
        "synthetic_fraction": 0.40,
        "batch_size": 6,
        "inference_batch_size": 6,
        "learning_rate": 0.001,
        "weight_decay": 0.0001,
        "session_min_points_per_cell": 2,
        "session_min_height_bins": 2,
        "target_min_sessions": 2,
        "target_strong_height_bins": 5,
        "target_strong_points_per_cell": 10,
        "target_close_gap_m": 0.35,
        "target_min_component_cells": 8,
        "output_close_gap_m": 0.30,
        "output_min_component_cells": 10,
        "scope_margin_m": 0.30,
        "threshold_min": 0.25,
        "threshold_max": 0.76,
        "threshold_step": 0.05,
        "evidence_distance_m": 0.25,
        "min_pseudo_iou": 0.55,
        "min_evidence_precision": 0.65,
        "min_prediction_ratio": 0.20,
        "max_prediction_ratio": 1.35,
        "direct_vectorization_enabled": False,
        "vector_close_gap_m": 0.80,
        "vector_min_component_cells": 30,
        "vector_simplify_m": 0.12,
        "vector_snap_angle_deg": 8.0,
        "vector_min_line_m": 0.60,
        "vector_oblique_min_line_m": 1.20,
        "vector_short_min_line_m": 0.15,
        "vector_short_min_heat": 0.60,
        "vector_short_min_lower_quartile": 0.40,
        "vector_heat_length_power": 2.0,
        "vector_heatmap_probability_weight": 0.55,
        "vector_heatmap_density_weight": 0.20,
        "vector_heatmap_vertical_weight": 0.15,
        "vector_heatmap_recurrence_weight": 0.10,
        "vector_oblique_reward_enabled": True,
        "vector_oblique_seed_min_m": 1.00,
        "vector_oblique_seed_gap_m": 0.60,
        "vector_oblique_hough_threshold": 12,
        "vector_oblique_axis_exclusion_deg": 8.0,
        "vector_oblique_search_angle_deg": 6.0,
        "vector_oblique_search_angle_step_deg": 1.0,
        "vector_oblique_search_offset_m": 0.30,
        "vector_oblique_search_offset_step_m": 0.10,
        "vector_oblique_support_distance_m": 0.15,
        "vector_oblique_weak_distance_m": 0.25,
        "vector_oblique_weak_min_heat": 0.30,
        "vector_oblique_max_gap_m": 0.60,
        "vector_oblique_candidate_min_m": 1.50,
        "vector_oblique_min_evidence_score": 0.66,
        "vector_oblique_replace_corridor_m": 0.50,
        "vector_oblique_fragment_fraction": 0.55,
        "vector_oblique_remove_fraction": 0.75,
        "vector_oblique_min_fragment_count": 3,
        "vector_oblique_min_straightness_gain": 0.35,
        "vector_oblique_min_reward": 0.79,
        "vector_oblique_evidence_weight": 0.65,
        "vector_oblique_straightness_weight": 0.35,
        "vector_junction_condensation_enabled": True,
        "vector_junction_node_merge_m": 0.08,
        "vector_junction_connector_max_m": 0.85,
        "vector_junction_component_max_m": 1.15,
        "vector_junction_search_radius_m": 0.95,
        "vector_junction_line_fit_m": 0.22,
        "vector_junction_support_distance_m": 0.20,
        "vector_junction_weak_min_heat": 0.35,
        "vector_junction_blob_radius_m": 0.42,
        "vector_junction_max_move_m": 0.60,
        "vector_junction_min_spread_m": 0.12,
        "vector_junction_min_blob_score": 0.32,
        "vector_junction_min_angle_score": 0.80,
        "vector_junction_min_reward": 0.85,
        "vector_junction_straight_sigma_deg": 12.0,
        "vector_junction_right_sigma_deg": 22.0,
        "vector_junction_min_incident_lines": 2,
        "vector_endpoint_cluster_m": 0.22,
        "vector_junction_tolerance_m": 0.35,
        "vector_min_output_lines": 20,
    },
    "height_slices": {
        "enabled": False,
        "architectural_enabled": True,
        # Frozen, non-overlapping evidence grid.  Sliding height windows may
        # reference these voxels but never count them more than once.
        "architectural_xy_grid_m": 0.05,
        "architectural_height_bin_m": 0.10,
        "architectural_vertical_xy_tolerance_m": 0.10,
        "architectural_min_vertical_span_m": 1.20,
        "architectural_min_height_bins": 4,
        "architectural_min_sessions": 2,
        "architectural_low_min_span_m": 0.25,
        "architectural_low_max_span_m": 1.20,
        "architectural_low_start_above_floor_m": 0.35,
        "architectural_low_max_z_min_m": 0.45,
        # Complete-wall reconstruction, association and robust shared-axis fit.
        "architectural_run_angle_deg": 1.0,
        "architectural_run_offset_m": 0.035,
        "architectural_run_gap_m": 0.12,
        "architectural_ridge_hough_votes": 20,
        "architectural_ridge_min_length_m": 0.60,
        "architectural_ridge_max_gap_m": 0.20,
        "architectural_ridge_max_candidates": 300,
        "architectural_association_angle_deg": 5.0,
        "architectural_association_offset_m": 0.25,
        "architectural_association_overlap_m": 0.50,
        "architectural_double_min_separation_m": 0.08,
        "architectural_cross_section_bin_m": 0.025,
        "architectural_observation_scale_m": 0.05,
        "architectural_soft_direction_deg": 2.0,
        "architectural_sample_step_m": 0.10,
        "architectural_support_distance_m": 0.15,
        "architectural_session_coverage_fraction": 0.35,
        "architectural_session_angle_search_deg": 1.0,
        "architectural_session_angle_steps": 5,
        "architectural_session_offset_search_m": 0.10,
        "architectural_session_offset_step_m": 0.02,
        "architectural_local_p95_regression_m": 0.02,
        "architectural_min_wall_length_m": 0.35,
        "architectural_min_structural_coverage": 0.42,
        "architectural_min_point_coverage": 0.80,
        "architectural_min_slice_count": 4,
        "architectural_low_min_length_m": 0.40,
        "architectural_low_min_coverage": 0.55,
        "architectural_low_reliable_coverage": 0.72,
        "architectural_low_node_cluster_m": 0.14,
        "architectural_low_connection_m": 0.20,
        # Simplicity selection and local topology rollback thresholds.
        "architectural_milp_time_limit_s": 120.0,
        "architectural_milp_max_evidence": 1800,
        "architectural_milp_line_penalty": 0.35,
        "architectural_milp_length_penalty": 0.015,
        "architectural_milp_evidence_reward": 0.030,
        "architectural_max_coverage_regression": 0.02,
        "architectural_node_cluster_m": 0.10,
        "architectural_spur_max_length_m": 0.75,
        "architectural_spur_protect_coverage": 0.72,
        "architectural_short_wall_min_slices": 2,
        "architectural_duplicate_offset_m": 0.20,
        "architectural_collinear_gap_max_m": 0.80,
        "architectural_junction_extension_max_m": 0.30,
        "architectural_junction_direct_snap_m": 0.05,
        "architectural_junction_min_angle_deg": 20.0,
        "architectural_junction_min_point_support": 0.85,
        "architectural_gap_min_evidence": 0.60,
        "architectural_target_spur_reduction": 0.60,
        "architectural_target_duplicate_reduction": 0.80,
        "architectural_independent_session_p95_m": 0.05,
        "grid_m": 0.05,
        "floor_margin_m": 0.12,
        "ceiling_margin_m": 0.12,
        "minimum_ceiling_height_m": 2.0,
        "fallback_ceiling_height_m": 3.0,
        "vertical_histogram_bin_m": 0.05,
        "ceiling_hint_search_m": 0.45,
        "horizontal_plane_candidate_half_width_m": 0.14,
        "horizontal_plane_residual_m": 0.04,
        "horizontal_plane_max_tilt_deg": 5.0,
        "horizontal_plane_ransac_iterations": 96,
        "horizontal_plane_ransac_max_points": 30000,
        "horizontal_plane_min_points": 500,
        "horizontal_plane_coverage_grid_m": 0.25,
        "horizontal_plane_min_coverage_cells": 100,
        "volume_xy_grid_m": 0.10,
        "volume_z_grid_m": 0.10,
        "volume_min_vertical_bins": 2,
        "volume_min_points_per_xy_cell": 3,
        "horizontal_residual_guard_m": 0.35,
        "horizontal_residual_min_vertical_bins": 3,
        "horizontal_residual_min_xy_cells": 120,
        "horizontal_residual_density_ratio": 2.5,
        "slice_height_m": 0.50,
        "slice_step_m": 0.30,
        "slice_height_bin_m": 0.10,
        "slice_min_points_per_cell": 2,
        "slice_min_height_bins": 2,
        "slice_strong_points_per_cell": 7,
        "slice_min_component_cells": 6,
        "raster_padding_m": 0.50,
        "calibration_iterations": 4,
        "calibration_angle_tolerance_deg": 5.0,
        "calibration_offset_tolerance_m": 0.25,
        "calibration_interval_gap_m": 0.60,
        "calibration_merge_angle_deg": 3.0,
        "calibration_merge_offset_m": 0.18,
        "calibration_merge_gap_m": 1.00,
        "calibration_same_slice_parallel_guard_m": 0.08,
        "calibration_same_slice_overlap_guard_m": 0.60,
        "calibration_merge_rounds": 5,
        "calibration_em_iterations": 3,
        "calibration_axis_angle_search_deg": 0.75,
        "calibration_axis_angle_step_deg": 0.375,
        "calibration_axis_offset_search_m": 0.10,
        "calibration_axis_offset_step_m": 0.025,
        "calibration_axis_sample_step_m": 0.12,
        "calibration_axis_distance_clip_m": 0.25,
        "calibration_axis_heat_reward_m": 0.015,
        "calibration_endpoint_cluster_m": 0.40,
        "calibration_endpoint_min_slices": 2,
        "calibration_endpoint_evidence_m": 0.10,
        "calibration_junction_extension_m": 0.50,
        "calibration_junction_cluster_m": 0.28,
        "calibration_junction_snap_m": 0.42,
        "calibration_junction_min_angle_deg": 15.0,
        "calibration_junction_min_shared_slices": 2,
        "calibration_junction_max_residual_m": 0.12,
        "calibration_junction_evidence_m": 0.12,
        "calibration_consensus_junction_tolerance_m": 0.03,
        "calibration_max_evidence_p95_regression_m": 0.03,
        "calibration_max_evidence_support_regression": 0.03,
        "calibration_max_reverse_coverage_regression": 0.02,
        "accept_line_to_point_p95_m": 0.10,
        "accept_line_support_fraction": 0.95,
        "consensus_atomic_min_line_m": 0.01,
        "consensus_observed_merge_gap_m": 0.001,
        "consensus_audit_tolerance_m": 0.001,
        "consensus_min_line_m": 0.45,
        "consensus_union_gap_m": 0.25,
        "vector_close_gap_m": 0.30,
        "vector_min_component_cells": 12,
        "vector_simplify_m": 0.10,
        "vector_snap_angle_deg": 7.0,
        "vector_min_line_m": 0.45,
        "vector_oblique_min_line_m": 0.90,
        "vector_short_min_line_m": 0.15,
        "vector_short_min_heat": 0.50,
        "vector_short_min_lower_quartile": 0.30,
        "vector_heat_length_power": 2.0,
        "vector_endpoint_cluster_m": 0.25,
        "vector_junction_tolerance_m": 0.30,
    },
    "deep_layout": {
        "enabled": False,
        "backend": "spatiallm1.1-qwen-0.5b",
        "tile_size_m": 27.0,
        "tile_overlap_m": 7.0,
        "input_voxel_m": 0.035,
        "min_tile_points": 8000,
        "max_tile_points": 220000,
        "model_max_points": 100000,
        "inference_retries": 4,
        "min_predicted_walls": 6,
        "attention_patch_size": 256,
        "max_new_tokens": 2048,
        "seed": 23,
        "deep_wall_min_height_m": 1.5,
        "deep_wall_min_length_m": 0.65,
        "deep_wall_fit_distance_m": 0.25,
        "deep_wall_verify_distance_m": 0.15,
        "deep_wall_min_support_fraction": 0.55,
        "deep_wall_min_support_cells": 12,
        "deep_baseline_min_structural_support_fraction": 0.50,
        "deep_wall_endpoint_extension_m": 0.45,
        "deep_snap_angle_deg": 8.0,
        "deep_merge_angle_deg": 2.0,
        "deep_merge_offset_m": 0.16,
        "deep_merge_gap_m": 0.80,
        "deep_junction_tolerance_m": 0.45,
        "max_median_error_m": 0.10,
        "max_p95_error_m": 0.20,
        "min_support_fraction": 0.80,
        "max_coverage_regression": 0.01,
    },
    "acceptance": {
        "outline_median_m": 0.10,
        "outline_p95_m": 0.20,
        "shell_support_distance_m": 0.15,
        "shell_support_fraction": 0.80,
        "wall_evidence_coverage_fraction": 0.80,
    },
}


def _merge(base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def load_config(path: str | Path) -> dict[str, Any]:
    config_path = Path(path).expanduser().resolve()
    if not config_path.is_file():
        raise PipelineError(f"Configuration not found: {config_path}")

    def load_raw(current: Path, stack: tuple[Path, ...] = ()) -> dict[str, Any]:
        current = current.expanduser().resolve()
        if current in stack:
            chain = " -> ".join(str(value) for value in (*stack, current))
            raise PipelineError(f"Configuration inheritance cycle: {chain}")
        if not current.is_file():
            raise PipelineError(f"Inherited configuration not found: {current}")
        value = yaml.safe_load(current.read_text(encoding="utf-8")) or {}
        parent_values = value.pop("extends", [])
        if isinstance(parent_values, str):
            parent_values = [parent_values]
        inherited: dict[str, Any] = {}
        for parent_value in parent_values:
            parent = Path(parent_value).expanduser()
            if not parent.is_absolute():
                parent = current.parent / parent
            inherited = _merge(inherited, load_raw(parent, (*stack, current)))
        return _merge(inherited, value)

    raw = load_raw(config_path)
    cfg = _merge(DEFAULTS, raw)
    cfg["_config_path"] = str(config_path)
    cfg["_config_dir"] = str(config_path.parent)

    def resolve(value: str) -> str:
        p = Path(value).expanduser()
        return str((config_path.parent / p).resolve()) if not p.is_absolute() else str(p.resolve())

    cfg["project"]["output_dir"] = resolve(cfg["project"]["output_dir"])
    if cfg.get("height_slices", {}).get("source_output_dir"):
        cfg["height_slices"]["source_output_dir"] = resolve(
            cfg["height_slices"]["source_output_dir"]
        )
    if cfg.get("height_slices", {}).get("semantic_model_report"):
        cfg["height_slices"]["semantic_model_report"] = resolve(
            cfg["height_slices"]["semantic_model_report"]
        )
    if cfg.get("height_slices", {}).get("semantic_labels_path"):
        cfg["height_slices"]["semantic_labels_path"] = resolve(
            cfg["height_slices"]["semantic_labels_path"]
        )
    if cfg.get("height_slices", {}).get("semantic_probability_path"):
        cfg["height_slices"]["semantic_probability_path"] = resolve(
            cfg["height_slices"]["semantic_probability_path"]
        )
    if cfg.get("height_slices", {}).get("semantic_comparison_previous_dir"):
        cfg["height_slices"]["semantic_comparison_previous_dir"] = resolve(
            cfg["height_slices"]["semantic_comparison_previous_dir"]
        )
    semantic_v14 = cfg.get("semantic_v14", {})
    for scene in semantic_v14.get("scenes", []):
        for key in (
            "point_cloud",
            "height_summary",
            "wall_regions",
            "object_labels",
            "building_object_graph",
        ):
            if scene.get(key):
                scene[key] = resolve(scene[key])
    for session in cfg.get("inputs", {}).get("sessions", []):
        session["bag"] = resolve(session["bag"])
        if "pcd" in session:
            session["pcd"] = resolve(session["pcd"])
        if "trajectory" in session:
            session["trajectory"] = resolve(session["trajectory"])
    cfg.setdefault("inputs", {})["calibration_bags"] = [
        resolve(p) for p in cfg.get("inputs", {}).get("calibration_bags", [])
    ]
    return cfg


def validate_config(cfg: dict[str, Any], require_bags: bool = True) -> None:
    inputs = cfg.get("inputs", {})
    for key in ("point_topic", "imu_topic"):
        if not inputs.get(key):
            raise PipelineError(f"inputs.{key} is required")
    sessions = inputs.get("sessions", [])
    if require_bags and not sessions:
        raise PipelineError("inputs.sessions must contain at least one session")
    names = [s.get("name") for s in sessions]
    if len(names) != len(set(names)) or any(not n for n in names):
        raise PipelineError("Every session needs a unique non-empty name")
    unsafe = [name for name in names if not re.fullmatch(r"[A-Za-z0-9_.-]+", name)]
    if unsafe:
        raise PipelineError(f"Session names may only contain letters, digits, '.', '_' and '-': {unsafe}")
    if require_bags:
        missing = [s["bag"] for s in sessions if not Path(s["bag"]).is_file()]
        missing += [p for p in inputs.get("calibration_bags", []) if not Path(p).is_file()]
        if missing:
            raise PipelineError("Missing input files:\n" + "\n".join(missing))
