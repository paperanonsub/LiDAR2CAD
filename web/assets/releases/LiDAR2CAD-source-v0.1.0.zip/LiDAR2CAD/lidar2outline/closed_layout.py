from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import cv2
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import polygonize_full, unary_union

from .post_fusion import (
    MorphologyRevectorResult,
    _dominant_line_angles,
    _line_kernel,
    _network_topology,
    _physical_lines,
    _regularize_axes,
    _sample_lines,
)
from .raster_vectorize import vectorize_structure_mask


@dataclass
class ClosedLayoutResult:
    observed_lines: list[LineString]
    inferred_walls: list[dict[str, Any]]
    openings: list[dict[str, Any]]
    regions: list[dict[str, Any]]
    candidates: list[dict[str, Any]]
    morphology_masks: dict[str, np.ndarray]
    morphology_skeletons: dict[str, np.ndarray]
    morphology_vectors: dict[str, list[LineString]]
    input_mask: np.ndarray
    origin: np.ndarray
    grid_m: float
    metrics: dict[str, Any]


def _parts(geometry) -> list[LineString]:
    if geometry is None or geometry.is_empty:
        return []
    if geometry.geom_type in {"LineString", "LinearRing"}:
        return [LineString(geometry.coords)]
    if hasattr(geometry, "geoms"):
        result: list[LineString] = []
        for value in geometry.geoms:
            result.extend(_parts(value))
        return result
    return []


def _raster_frame(
    points: np.ndarray, lines: list[LineString], grid_m: float, padding_m: float
) -> tuple[np.ndarray, tuple[int, int]]:
    line_points = np.vstack([np.asarray(line.coords, dtype=float) for line in lines])
    values = np.vstack([points[:, :2], line_points]) if len(points) else line_points
    lower = np.floor((np.min(values, axis=0) - padding_m) / grid_m) * grid_m
    upper = np.ceil((np.max(values, axis=0) + padding_m) / grid_m) * grid_m
    width, height = np.ceil((upper - lower) / grid_m).astype(int) + 1
    return lower, (int(height), int(width))


def _rasterize(
    lines: list[LineString], origin: np.ndarray, shape: tuple[int, int], grid_m: float
) -> np.ndarray:
    image = np.zeros(shape, dtype=np.uint8)
    for line in lines:
        pixels = np.rint(
            (np.asarray(line.coords, dtype=float) - origin) / grid_m - 0.5
        ).astype(np.int32)
        if len(pixels) >= 2:
            cv2.polylines(image, [pixels], False, 255, 1, cv2.LINE_8)
    return image


def _raster_fraction(
    line: LineString,
    image: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    corridor_m: float = 0.04,
) -> float:
    count = max(2, int(math.ceil(line.length / max(grid_m * 0.5, 0.01))) + 1)
    points = np.asarray(
        [line.interpolate(value, normalized=True).coords[0] for value in np.linspace(0, 1, count)]
    )
    pixels = np.floor((points - origin) / grid_m).astype(int)
    radius = max(0, int(math.ceil(corridor_m / grid_m)))
    supported = 0
    for x, y in pixels:
        x0, x1 = max(0, x - radius), min(image.shape[1], x + radius + 1)
        y0, y1 = max(0, y - radius), min(image.shape[0], y + radius + 1)
        if x0 < x1 and y0 < y1 and np.any(image[y0:y1, x0:x1]):
            supported += 1
    return float(supported / max(len(pixels), 1))


def _point_support(
    line: LineString, tree: cKDTree | None, distance_m: float, step_m: float = 0.05
) -> tuple[float, float | None]:
    if tree is None:
        return 0.0, None
    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    samples = np.asarray(
        [line.interpolate(value, normalized=True).coords[0] for value in np.linspace(0, 1, count)]
    )
    distances, _ = tree.query(samples, k=1)
    return float(np.mean(distances <= distance_m)), float(np.quantile(distances, 0.95))


def _line_support(
    line: LineString, samples: np.ndarray, distance_m: float, step_m: float = 0.05
) -> float:
    if not len(samples):
        return 0.0
    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    query = np.asarray(
        [line.interpolate(value, normalized=True).coords[0] for value in np.linspace(0, 1, count)]
    )
    distances, _ = cKDTree(samples).query(query, k=1)
    return float(np.mean(distances <= distance_m))


def _endpoint_rays(lines: list[LineString]) -> list[dict[str, Any]]:
    noded = unary_union(lines)
    degrees: dict[tuple[int, int], int] = {}
    for line in _parts(noded):
        coordinates = np.asarray(line.coords, dtype=float)
        for index in range(len(coordinates) - 1):
            for point in (coordinates[index], coordinates[index + 1]):
                key = tuple(np.rint(point * 1000.0).astype(int))
                degrees[key] = degrees.get(key, 0) + 1
    rays: list[dict[str, Any]] = []
    for line_index, line in enumerate(lines):
        coordinates = np.asarray(line.coords, dtype=float)
        if len(coordinates) < 2:
            continue
        for endpoint_index, neighbor_index in ((0, 1), (-1, -2)):
            point = coordinates[endpoint_index]
            key = tuple(np.rint(point * 1000.0).astype(int))
            if degrees.get(key, 0) != 1:
                continue
            inward = coordinates[neighbor_index] - point
            length = float(np.linalg.norm(inward))
            if length <= 1e-9:
                continue
            rays.append(
                {
                    "line_index": line_index,
                    "endpoint_index": 0 if endpoint_index == 0 else 1,
                    "endpoint_key": key,
                    "point": point,
                    "inward": inward / length,
                }
            )
    return rays


def _intersection(
    origin: np.ndarray, direction: np.ndarray, line: LineString
) -> tuple[np.ndarray, float, float] | None:
    coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
    target = coordinates[1] - coordinates[0]
    target_length = float(np.linalg.norm(target))
    if target_length <= 1e-9:
        return None
    target /= target_length
    cross = float(direction[0] * target[1] - direction[1] * target[0])
    if abs(cross) <= 1e-9:
        return None
    difference = coordinates[0] - origin
    ray_distance = float(
        (difference[0] * target[1] - difference[1] * target[0]) / cross
    )
    target_distance = float(
        (difference[0] * direction[1] - difference[1] * direction[0]) / cross
    )
    return origin + ray_distance * direction, ray_distance, target_distance


def _candidate_key(line: LineString) -> tuple[tuple[int, int], tuple[int, int]]:
    endpoints = [
        tuple(np.rint(np.asarray(value, dtype=float) * 1000.0).astype(int))
        for value in (line.coords[0], line.coords[-1])
    ]
    endpoints.sort()
    return endpoints[0], endpoints[1]


def _score_candidate(
    line: LineString,
    kind: str,
    endpoint_keys: list[tuple[int, int]],
    point_tree: cKDTree | None,
    thick_samples: np.ndarray,
    masks: dict[str, np.ndarray],
    origin: np.ndarray,
    grid_m: float,
    cfg: dict,
) -> dict[str, Any]:
    distance_m = float(cfg.get("closure_observed_distance_m", 0.10))
    point_fraction, point_p95 = _point_support(line, point_tree, distance_m)
    thick_fraction = _line_support(line, thick_samples, distance_m)
    fractions = {
        name: _raster_fraction(line, image, origin, grid_m)
        for name, image in masks.items()
    }
    morph_fraction = max(fractions.values(), default=0.0)
    maximum_length = float(cfg.get("closure_collinear_gap_m", 1.20))
    score = float(
        0.38 * point_fraction
        + 0.27 * thick_fraction
        + 0.25 * morph_fraction
        + 0.10 * max(0.0, 1.0 - line.length / max(maximum_length, 1e-9))
    )
    minimum_point = float(cfg.get("closure_wall_min_point_fraction", 0.50))
    minimum_thick = float(cfg.get("closure_wall_min_thick_fraction", 0.70))
    # A thick-window line is still derived from the same LiDAR returns and
    # therefore cannot, by itself, turn a doorway into an observed wall.  It
    # may reinforce weaker local points, but some direct evidence is always
    # required at the proposed connector location.
    observed = bool(
        point_fraction >= minimum_point
        or (
            point_fraction
            >= float(cfg.get("closure_wall_min_reinforced_point_fraction", 0.30))
            and thick_fraction >= minimum_thick
        )
    )
    return {
        "line_ref": line,
        "kind": kind,
        "endpoint_keys": endpoint_keys,
        "length_m": float(line.length),
        "point_fraction": point_fraction,
        "point_p95_m": point_p95,
        "thick_fraction": thick_fraction,
        "morphology_fraction": morph_fraction,
        "morphology_by_scale": fractions,
        "score": score,
        "semantic": "inferred_wall" if observed else "virtual_opening",
    }


def _connection_candidates(
    lines: list[LineString],
    clean_points: np.ndarray,
    thick_lines: list[LineString],
    masks: dict[str, np.ndarray],
    origin: np.ndarray,
    grid_m: float,
    cfg: dict,
) -> list[dict[str, Any]]:
    rays = _endpoint_rays(lines)
    point_tree = cKDTree(clean_points[:, :2]) if len(clean_points) else None
    thick_samples = _sample_lines(thick_lines, 0.05)
    collinear_max = float(cfg.get("closure_collinear_gap_m", 1.20))
    corner_max = float(cfg.get("closure_corner_extension_m", 1.00))
    lateral_max = float(cfg.get("closure_collinear_lateral_m", 0.08))
    angle_limit = math.radians(float(cfg.get("closure_collinear_angle_deg", 6.0)))
    candidates: list[dict[str, Any]] = []

    for index, first in enumerate(rays):
        outward = -first["inward"]
        for second in rays[index + 1 :]:
            if first["line_index"] == second["line_index"]:
                continue
            second_outward = -second["inward"]
            angular = math.acos(
                float(np.clip(abs(outward @ second_outward), -1.0, 1.0))
            )
            if angular > angle_limit:
                continue
            difference = second["point"] - first["point"]
            distance = float(np.linalg.norm(difference))
            if distance < float(cfg.get("closure_candidate_min_length_m", 0.03)) or distance > collinear_max:
                continue
            axis = outward if float(outward @ difference) >= 0 else -outward
            along = abs(float(difference @ axis))
            lateral = abs(float(axis[0] * difference[1] - axis[1] * difference[0]))
            if lateral > lateral_max or along < 0.85 * distance:
                continue
            candidates.append(
                _score_candidate(
                    LineString([first["point"], second["point"]]),
                    "collinear_gap",
                    [first["endpoint_key"], second["endpoint_key"]],
                    point_tree,
                    thick_samples,
                    masks,
                    origin,
                    grid_m,
                    cfg,
                )
            )

    minimum_corner_angle = math.radians(
        float(cfg.get("closure_corner_min_angle_deg", 20.0))
    )
    target_slack = float(cfg.get("closure_corner_target_slack_m", 0.10))
    # Two walls can both stop short of their fitted-axis intersection.  An
    # endpoint-to-existing-segment test cannot recover that L corner, because
    # neither current segment reaches the other axis.  Treat the two extension
    # legs as one atomic proposal so the optimizer cannot accept a half-corner.
    for index, first in enumerate(rays):
        first_outward = -first["inward"]
        for second in rays[index + 1 :]:
            if first["line_index"] == second["line_index"]:
                continue
            second_outward = -second["inward"]
            angular = math.acos(
                float(np.clip(abs(first_outward @ second_outward), -1.0, 1.0))
            )
            if angular < minimum_corner_angle:
                continue
            matrix = np.column_stack([first_outward, -second_outward])
            if abs(float(np.linalg.det(matrix))) <= 1e-9:
                continue
            distances = np.linalg.solve(
                matrix, second["point"] - first["point"]
            )
            first_distance, second_distance = map(float, distances)
            minimum_length = float(
                cfg.get("closure_candidate_min_length_m", 0.03)
            )
            if (
                first_distance < minimum_length
                or second_distance < minimum_length
                or first_distance > corner_max
                or second_distance > corner_max
            ):
                continue
            intersection = first["point"] + first_distance * first_outward
            candidates.append(
                _score_candidate(
                    LineString(
                        [first["point"], intersection, second["point"]]
                    ),
                    "corner_pair",
                    [first["endpoint_key"], second["endpoint_key"]],
                    point_tree,
                    thick_samples,
                    masks,
                    origin,
                    grid_m,
                    cfg,
                )
            )
    for ray in rays:
        outward = -ray["inward"]
        for target_index, target in enumerate(lines):
            if target_index == ray["line_index"]:
                continue
            target_coordinates = np.asarray(target.coords, dtype=float)[[0, -1]]
            target_direction = target_coordinates[1] - target_coordinates[0]
            target_length = float(np.linalg.norm(target_direction))
            if target_length <= 1e-9:
                continue
            target_direction /= target_length
            angular = math.acos(
                float(np.clip(abs(outward @ target_direction), -1.0, 1.0))
            )
            if angular < minimum_corner_angle:
                continue
            value = _intersection(ray["point"], outward, target)
            if value is None:
                continue
            point, distance, target_distance = value
            if distance < float(cfg.get("closure_candidate_min_length_m", 0.03)) or distance > corner_max:
                continue
            if target_distance < -target_slack or target_distance > target_length + target_slack:
                continue
            candidates.append(
                _score_candidate(
                    LineString([ray["point"], point]),
                    "axis_intersection",
                    [ray["endpoint_key"]],
                    point_tree,
                    thick_samples,
                    masks,
                    origin,
                    grid_m,
                    cfg,
                )
            )

    unique: dict[tuple[tuple[int, int], tuple[int, int]], dict[str, Any]] = {}
    for candidate in candidates:
        key = _candidate_key(candidate["line_ref"])
        if key not in unique or candidate["score"] > unique[key]["score"]:
            unique[key] = candidate
    minimum_score = float(cfg.get("closure_candidate_min_score", 0.24))
    result = [value for value in unique.values() if value["score"] >= minimum_score]
    result.sort(key=lambda value: (value["score"], -value["length_m"]), reverse=True)
    # Dense thick-window linework can expose many intersections to the same
    # dangling endpoint. Keep a small scored hypothesis set per endpoint so the
    # MILP compares meaningful alternatives instead of thousands of aliases.
    maximum_per_endpoint = int(cfg.get("closure_max_candidates_per_endpoint", 4))
    endpoint_counts: dict[tuple[int, int], int] = {}
    retained = []
    for value in result:
        if any(
            endpoint_counts.get(key, 0) >= maximum_per_endpoint
            for key in value["endpoint_keys"]
        ):
            continue
        retained.append(value)
        for key in value["endpoint_keys"]:
            endpoint_counts[key] = endpoint_counts.get(key, 0) + 1
    result = retained
    for index, value in enumerate(result):
        value["candidate_id"] = f"C{index:04d}"
    return result


def _regularize_polygon(
    polygon: Polygon, angles: list[float], cfg: dict
) -> Polygon:
    tolerance = float(cfg.get("closure_polygon_simplify_m", 0.05))
    simplified = Polygon(polygon.simplify(tolerance, preserve_topology=True).exterior.coords)
    coordinates = np.asarray(simplified.exterior.coords[:-1], dtype=float)
    if len(coordinates) < 3:
        return polygon
    snap_limit = math.radians(float(cfg.get("closure_polygon_snap_angle_deg", 5.0)))
    axes = []
    for index in range(len(coordinates)):
        start = coordinates[index]
        end = coordinates[(index + 1) % len(coordinates)]
        direction = end - start
        length = float(np.linalg.norm(direction))
        if length <= 1e-9:
            return simplified
        angle = math.atan2(direction[1], direction[0]) % math.pi
        if angles:
            selected = min(
                angles,
                key=lambda value: min(abs(value - angle), math.pi - abs(value - angle)),
            )
            difference = min(abs(selected - angle), math.pi - abs(selected - angle))
            if difference <= snap_limit:
                angle = selected
        direction = np.asarray([math.cos(angle), math.sin(angle)], dtype=float)
        normal = np.asarray([-direction[1], direction[0]], dtype=float)
        midpoint = 0.5 * (start + end)
        axes.append((direction, normal, float(midpoint @ normal)))
    vertices = []
    for index in range(len(axes)):
        previous = axes[index - 1]
        current = axes[index]
        matrix = np.vstack([previous[1], current[1]])
        determinant = float(np.linalg.det(matrix))
        if abs(determinant) < math.sin(math.radians(8.0)):
            vertices.append(coordinates[index])
            continue
        vertices.append(
            np.linalg.solve(matrix, np.asarray([previous[2], current[2]], dtype=float))
        )
    fitted = Polygon(vertices)
    if not fitted.is_valid or fitted.area <= 0:
        return simplified
    if fitted.hausdorff_distance(polygon) > float(
        cfg.get("closure_polygon_max_shift_m", 0.10)
    ):
        return simplified
    if abs(fitted.area - polygon.area) / max(polygon.area, 1e-9) > float(
        cfg.get("closure_polygon_max_area_change", 0.08)
    ):
        return simplified
    return fitted


def _supplement_from_thick_slices(
    source_lines: list[LineString], thick_union: list[dict], clean_points: np.ndarray, cfg: dict
) -> tuple[list[LineString], list[dict[str, Any]]]:
    if not thick_union:
        return [], []
    source_samples = _sample_lines(source_lines, 0.05)
    source_tree = cKDTree(source_samples) if len(source_samples) else None
    point_tree = cKDTree(clean_points[:, :2]) if len(clean_points) else None
    minimum_windows = int(cfg.get("closure_thick_min_windows", 2))
    minimum_length = float(cfg.get("closure_thick_min_line_m", 0.20))
    novelty_distance = float(cfg.get("closure_thick_novelty_distance_m", 0.12))
    accepted: list[LineString] = []
    records: list[dict[str, Any]] = []
    for value in thick_union:
        line = value["line_ref"]
        window_count = len(value.get("slice_indices", []))
        if line.length < minimum_length or window_count < minimum_windows:
            continue
        coverage, p95 = _point_support(line, point_tree, 0.10)
        samples = _sample_lines([line], 0.05)
        if source_tree is None:
            novelty = 1.0
        else:
            distances, _ = source_tree.query(samples, k=1)
            novelty = float(np.mean(distances > novelty_distance))
        if coverage < float(cfg.get("closure_thick_min_point_fraction", 0.80)):
            continue
        if novelty < float(cfg.get("closure_thick_min_novel_fraction", 0.20)):
            continue
        accepted.append(line)
        records.append(
            {
                "source": "thick_height_windows",
                "slice_indices": list(value.get("slice_indices", [])),
                "length_m": float(line.length),
                "point_fraction": coverage,
                "point_p95_m": p95,
                "novel_fraction": novelty,
            }
        )
    return accepted, records


def _polygon_candidates(
    observed: list[LineString],
    candidates: list[dict[str, Any]],
    cfg: dict,
    angles: list[float] | None = None,
) -> list[dict[str, Any]]:
    all_geometry = unary_union(
        [*observed, *[value["line_ref"] for value in candidates]]
    )
    polygons, _, _, _ = polygonize_full(_parts(all_geometry))
    observed_union = unary_union(observed)
    observed_buffer = observed_union.buffer(
        float(cfg.get("closure_boundary_support_distance_m", 0.075)),
        cap_style=2,
        join_style=2,
    )
    minimum_area = float(cfg.get("closure_min_region_area_m2", 1.0))
    maximum_area = float(cfg.get("closure_max_region_area_m2", 2000.0))
    minimum_support = float(cfg.get("closure_min_observed_perimeter_fraction", 0.80))
    maximum_inferred = float(cfg.get("closure_max_inferred_perimeter_fraction", 0.20))
    result: list[dict[str, Any]] = []
    for polygon in polygons.geoms:
        polygon = Polygon(polygon.exterior.coords)
        if not polygon.is_valid or polygon.area < minimum_area or polygon.area > maximum_area:
            continue
        polygon = _regularize_polygon(polygon, angles or [], cfg)
        boundary = polygon.boundary
        supported_length = float(boundary.intersection(observed_buffer).length)
        observed_fraction = min(1.0, supported_length / max(boundary.length, 1e-9))
        unsupported_boundary = boundary.difference(observed_buffer)
        inferred_length = float(unsupported_boundary.length)
        inferred_fraction = min(1.0, inferred_length / max(boundary.length, 1e-9))
        if observed_fraction < minimum_support or inferred_fraction > maximum_inferred:
            continue
        # Several alternative rays often lie on the same missing boundary.
        # Requiring every overlapping ray makes an otherwise valid room
        # infeasible because those alternatives compete for one endpoint.
        # Select a small geometric cover of the unsupported boundary instead.
        required: list[int] = []
        required_endpoints: set[tuple[int, int]] = set()
        uncovered = unsupported_boundary
        cover_tolerance = float(
            cfg.get("closure_candidate_boundary_tolerance_m", 0.025)
        )
        while float(uncovered.length) > 0.015:
            best_index = None
            best_coverage = 0.0
            best_utility = -float("inf")
            for index, candidate in enumerate(candidates):
                if index in required:
                    continue
                endpoint_keys = set(candidate.get("endpoint_keys", []))
                if endpoint_keys & required_endpoints:
                    continue
                corridor = candidate["line_ref"].buffer(
                    cover_tolerance, cap_style=2, join_style=2
                )
                coverage = float(uncovered.intersection(corridor).length)
                if coverage <= 0.01:
                    continue
                utility = coverage + 0.02 * float(candidate["score"])
                if utility > best_utility:
                    best_index = index
                    best_coverage = coverage
                    best_utility = utility
            if best_index is None or best_coverage <= 0.01:
                break
            required.append(best_index)
            required_endpoints.update(
                candidates[best_index].get("endpoint_keys", [])
            )
            uncovered = uncovered.difference(
                candidates[best_index]["line_ref"].buffer(
                    cover_tolerance, cap_style=2, join_style=2
                )
            )
        if float(uncovered.length) > float(
            cfg.get("closure_candidate_uncovered_tolerance_m", 0.03)
        ):
            continue
        result.append(
            {
                "polygon_ref": polygon,
                "area_m2": float(polygon.area),
                "perimeter_m": float(boundary.length),
                "observed_perimeter_fraction": observed_fraction,
                "inferred_perimeter_fraction": inferred_fraction,
                "required_candidates": sorted(set(required)),
            }
        )
    result.sort(key=lambda value: value["area_m2"], reverse=True)
    for index, value in enumerate(result):
        value["region_id"] = f"R{index:03d}"
    return result


def _select_regions(
    candidates: list[dict[str, Any]], regions: list[dict[str, Any]], cfg: dict
) -> tuple[list[int], list[int], dict[str, Any]]:
    if not regions:
        return [], [], {"status": "no_valid_regions", "solver_success": False}
    candidate_count = len(candidates)
    region_count = len(regions)
    objective = np.zeros(candidate_count + region_count, dtype=float)
    for index, value in enumerate(candidates):
        objective[index] = float(
            0.35
            + value["length_m"] * (1.25 - min(value["score"], 1.0))
            + (0.35 if value["semantic"] == "virtual_opening" else 0.0)
        )
    for index, value in enumerate(regions):
        area_reward = float(cfg.get("closure_region_area_reward_per_m2", 0.035))
        supported_area_reward = float(
            cfg.get("closure_region_supported_area_reward_per_m2", 0.0)
        )
        objective[candidate_count + index] = float(
            -float(cfg.get("closure_region_base_reward", 0.50))
            - value["area_m2"]
            * (
                area_reward
                + supported_area_reward
                * value["observed_perimeter_fraction"]
            )
        )
    rows: list[int] = []
    columns: list[int] = []
    data: list[float] = []
    lower: list[float] = []
    upper: list[float] = []
    # A selected region requires every connector on its boundary.
    for region_index, region in enumerate(regions):
        y = candidate_count + region_index
        for candidate_index in region["required_candidates"]:
            row = len(lower)
            rows.extend([row, row])
            columns.extend([y, candidate_index])
            data.extend([1.0, -1.0])
            lower.append(-np.inf)
            upper.append(0.0)
    # One dangling endpoint may only be consumed by one connector.
    endpoint_to_candidates: dict[tuple[int, int], list[int]] = {}
    for index, candidate in enumerate(candidates):
        for key in candidate["endpoint_keys"]:
            endpoint_to_candidates.setdefault(key, []).append(index)
    for indices in endpoint_to_candidates.values():
        if len(indices) < 2:
            continue
        row = len(lower)
        for index in indices:
            rows.append(row)
            columns.append(index)
            data.append(1.0)
        lower.append(-np.inf)
        upper.append(1.0)
    matrix = coo_matrix(
        (data, (rows, columns)), shape=(len(lower), len(objective))
    ).tocsr()
    try:
        solution = milp(
            objective,
            integrality=np.ones(len(objective)),
            bounds=Bounds(np.zeros(len(objective)), np.ones(len(objective))),
            constraints=LinearConstraint(
                matrix, np.asarray(lower, dtype=float), np.asarray(upper, dtype=float)
            ),
            options={"time_limit": float(cfg.get("closure_milp_time_limit_s", 120.0))},
        )
    except Exception as exc:  # pragma: no cover - platform solver failures
        solution = None
        error = str(exc)
    else:
        error = None
    if solution is None or solution.x is None:
        selected_regions = list(range(region_count))
        needed = sorted(
            {index for region in regions for index in region["required_candidates"]}
        )
        status = "fallback_all_qualified"
    else:
        selected_regions = [
            index
            for index in range(region_count)
            if solution.x[candidate_count + index] >= 0.5
        ]
        needed = [
            index for index in range(candidate_count) if solution.x[index] >= 0.5
        ]
        status = str(solution.message)
    return needed, selected_regions, {
        "status": status,
        "solver_success": bool(solution is not None and solution.x is not None),
        "objective": None
        if solution is None or solution.fun is None
        else float(solution.fun),
        "error": error,
        "candidate_variable_count": candidate_count,
        "region_variable_count": region_count,
    }


def optimize_closed_layout(
    morphology: MorphologyRevectorResult,
    thick_union: list[dict],
    clean_points: np.ndarray,
    cfg: dict,
    backbone_lines: list[LineString] | None = None,
) -> ClosedLayoutResult:
    """Build a regular, continuous wall graph and explicit closed room polygons."""
    morphology_source = list(morphology.lines)
    explicit_backbone = list(backbone_lines or [])
    # The region optimizer is allowed to consult the morphology and thick-scale
    # networks, but the visible observed wall plan must retain the clearest
    # high-slice geometry.  Previously ``morphology.lines`` served both roles:
    # this silently replaced about a quarter of the good slice-06 wall length
    # and made the final drawing look worse even though more polygons closed.
    source = explicit_backbone if explicit_backbone else morphology_source
    # Thick windows are a second evidence scale, not an instruction to average
    # every atomic line into the high-quality V10 axes. They participate in
    # region/candidate construction; only selected polygon-boundary portions
    # are later promoted to visible observed walls.
    thick_lines = _physical_lines([value["line_ref"] for value in thick_union])
    region_evidence_lines = _physical_lines(
        [
            *source,
            *([] if not explicit_backbone else morphology_source),
            *thick_lines,
        ]
    )
    observed = list(source)
    fit_metrics = {
        "strategy": (
            "protected_high_slice_backbone_with_multiscale_region_evidence"
            if explicit_backbone
            else "protected_morphology_axes_with_selected_thick_boundary_supplement"
        )
    }

    grid_m = float(cfg.get("closure_grid_m", 0.025))
    origin, shape = _raster_frame(
        clean_points,
        region_evidence_lines,
        grid_m,
        float(cfg.get("raster_padding_m", 0.50)),
    )
    input_mask = _rasterize(region_evidence_lines, origin, shape, grid_m)
    angles = _dominant_line_angles(source, cfg)
    if not angles:
        angles = [0.0, math.pi / 2.0]
    masks: dict[str, np.ndarray] = {}
    morphology_skeletons: dict[str, np.ndarray] = {}
    morphology_vectors: dict[str, list[LineString]] = {}
    for length_m in cfg.get("closure_directional_lengths_m", [0.40, 0.80, 1.20]):
        length_m = float(length_m)
        kernel_length = max(3, int(round(length_m / grid_m)) + 1) | 1
        result = input_mask.copy()
        for angle in angles:
            kernel = _line_kernel(kernel_length, angle)
            result = cv2.max(result, cv2.erode(cv2.dilate(input_mask, kernel), kernel))
        # A 5 cm transverse close joins sub-pixel wall-axis offsets without
        # broadening the long directional proposal into nearby parallel walls.
        transverse = max(1, int(round(0.05 / grid_m)))
        transverse_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (2 * transverse + 1, 2 * transverse + 1)
        )
        result = cv2.morphologyEx(result, cv2.MORPH_CLOSE, transverse_kernel)
        scale_name = f"{length_m:.2f}m"
        masks[scale_name] = result
        vector_cfg = dict(cfg)
        vector_cfg.update(
            {
                "vector_close_gap_m": 0.0,
                "vector_min_component_cells": 1,
                "vector_simplify_m": float(
                    cfg.get("closure_revector_simplify_m", 0.05)
                ),
                "vector_snap_angle_deg": float(
                    cfg.get("closure_polygon_snap_angle_deg", 5.0)
                ),
                "vector_min_line_m": float(
                    cfg.get("closure_revector_min_line_m", 0.10)
                ),
                "vector_oblique_min_line_m": float(
                    cfg.get("closure_revector_oblique_min_line_m", 0.20)
                ),
                "vector_short_min_line_m": float(
                    cfg.get("closure_revector_short_min_line_m", 0.05)
                ),
                "vector_short_min_heat": 0.0,
                "vector_short_min_lower_quartile": 0.0,
            }
        )
        revectorized = vectorize_structure_mask(
            result,
            origin,
            grid_m,
            angles[0],
            vector_cfg,
            heatmap=result.astype(np.float32) / 255.0,
        )
        morphology_skeletons[scale_name] = revectorized.skeleton
        morphology_vectors[scale_name] = list(revectorized.lines)

    candidates = _connection_candidates(
        region_evidence_lines,
        clean_points,
        thick_lines,
        masks,
        origin,
        grid_m,
        cfg,
    )
    source_candidates = _connection_candidates(
        source,
        clean_points,
        thick_lines,
        masks,
        origin,
        grid_m,
        cfg,
    )
    combined_candidates: dict[
        tuple[tuple[int, int], tuple[int, int]], dict[str, Any]
    ] = {}
    for value in candidates:
        value["source_network_candidate"] = False
        combined_candidates[_candidate_key(value["line_ref"])] = value
    for value in source_candidates:
        key = _candidate_key(value["line_ref"])
        if key in combined_candidates:
            combined_candidates[key]["source_network_candidate"] = True
        else:
            value["source_network_candidate"] = True
            combined_candidates[key] = value
    candidates = sorted(
        combined_candidates.values(),
        key=lambda value: (value["score"], -value["length_m"]),
        reverse=True,
    )
    for index, value in enumerate(candidates):
        value["candidate_id"] = f"C{index:04d}"
    regions = _polygon_candidates(
        region_evidence_lines, candidates, cfg, angles=angles
    )
    selected_candidates, selected_regions, solver = _select_regions(
        candidates, regions, cfg
    )

    if bool(cfg.get("closure_add_nonregion_continuity", False)):
        # Optional diagnostic mode: add exceptionally strong collinear bridges
        # that do not participate in a region while preserving endpoint choice.
        used_endpoints = {
            key
            for index in selected_candidates
            for key in candidates[index]["endpoint_keys"]
        }
        for index, candidate in enumerate(candidates):
            if index in selected_candidates:
                continue
            if not candidate.get("source_network_candidate", False):
                continue
            if candidate["score"] < float(
                cfg.get("closure_continuity_min_score", 0.70)
            ):
                continue
            if any(key in used_endpoints for key in candidate["endpoint_keys"]):
                continue
            selected_candidates.append(index)
            used_endpoints.update(candidate["endpoint_keys"])

    selected_set = set(selected_candidates)
    # Every connector used by a delivered region must be visible.  Hiding a
    # connector merely because it originated from a thick-window candidate
    # creates a closed polygon layer but leaves the displayed wall network
    # open at precisely the recovered corner.
    visible_selected_set = set(selected_set)
    inferred_walls = [
        value
        for index, value in enumerate(candidates)
        if index in visible_selected_set and value["semantic"] == "inferred_wall"
    ]
    openings = [
        value
        for index, value in enumerate(candidates)
        if index in visible_selected_set and value["semantic"] == "virtual_opening"
    ]
    selected_region_records = [regions[index] for index in selected_regions]
    # Promote only thick-scale portions that actually bound selected regions.
    # This prevents the dense thick union from becoming a second visible copy
    # of every wall while retaining the recovered geometry needed for closure.
    source_area = unary_union(source).buffer(0.075, cap_style=2, join_style=2)
    thick_area = unary_union(thick_lines).buffer(0.075, cap_style=2, join_style=2)
    selected_boundaries = unary_union(
        [value["polygon_ref"].boundary for value in selected_region_records]
    ) if selected_region_records else None
    selected_supplements: list[LineString] = []
    if selected_boundaries is not None and not selected_boundaries.is_empty:
        recovered = selected_boundaries.difference(source_area).intersection(thick_area)
        selected_supplements = [
            line for line in _parts(recovered) if line.length >= 0.05
        ]
        # The closed region itself carries these selected thick-scale boundary
        # portions. Keep the protected source wall layer free of duplicate
        # fragments; the complete thick union remains available in its hidden
        # evidence layer.
        observed = list(source)
    supplement_records = [
        {
            "source": "selected_thick_region_boundary",
            "length_m": float(line.length),
        }
        for line in selected_supplements
    ]
    before = _network_topology(source)
    after = _network_topology(
        [
            *observed,
            *[value["line_ref"] for value in inferred_walls],
            *[value["line_ref"] for value in openings],
        ]
    )
    repairable_keys = {
        key
        for value in candidates
        if value.get("source_network_candidate", False)
        # Keep the continuity benchmark frozen to the original single-leg
        # gap/T candidates.  Pair-corner hypotheses are reported separately;
        # adding more hypotheses must not enlarge the denominator after the
        # fact and make the same repaired network appear worse.
        and value.get("kind") != "corner_pair"
        for key in value.get("endpoint_keys", [])
    }
    repaired_keys = {
        key
        for index in visible_selected_set
        for key in candidates[index].get("endpoint_keys", [])
        if key in repairable_keys
    }
    repairable_endpoints = len(repairable_keys)
    repaired_endpoints = len(repaired_keys)
    point_tree = cKDTree(clean_points[:, :2]) if len(clean_points) else None
    observed_samples = _sample_lines(observed, 0.05)
    if point_tree is None or not len(observed_samples):
        observed_p95 = None
        observed_support = 0.0
    else:
        observed_distances, _ = point_tree.query(observed_samples, k=1)
        observed_p95 = float(np.quantile(observed_distances, 0.95))
        observed_support = float(np.mean(observed_distances <= 0.15))
    metrics = {
        "closed_layout_enabled": True,
        "closed_layout_strategy": "multiscale_height_directional_morphology_polygon_milp",
        "closed_layout_grid_m": grid_m,
        "closed_layout_directional_lengths_m": [
            float(value) for value in cfg.get("closure_directional_lengths_m", [0.4, 0.8, 1.2])
        ],
        "closed_layout_morphology_skeleton_cells_by_scale": {
            name: int(np.count_nonzero(value))
            for name, value in morphology_skeletons.items()
        },
        "closed_layout_morphology_revector_line_count_by_scale": {
            name: len(value) for name, value in morphology_vectors.items()
        },
        "closed_layout_source_line_count": len(source),
        "closed_layout_morphology_source_line_count": len(morphology_source),
        "closed_layout_backbone_source": cfg.get(
            "_closure_backbone_source", "morphology_reextracted"
        ),
        "closed_layout_backbone_slice_index": cfg.get(
            "_closure_backbone_slice_index"
        ),
        "closed_layout_backbone_selection": cfg.get(
            "_closure_backbone_selection", {}
        ),
        "closed_layout_thick_supplement_count": len(selected_supplements),
        "closed_layout_observed_line_count": len(observed),
        "closed_layout_candidate_count": len(candidates),
        "closed_layout_selected_candidate_count": len(selected_set),
        "closed_layout_inferred_wall_count": len(inferred_walls),
        "closed_layout_virtual_opening_count": len(openings),
        "closed_layout_region_count": len(selected_region_records),
        "closed_layout_qualified_region_count": len(regions),
        "closed_layout_qualified_region_area_m2": float(
            sum(value["area_m2"] for value in regions)
        ),
        "closed_layout_qualified_regions": [
            {
                "region_id": value["region_id"],
                "area_m2": float(value["area_m2"]),
                "perimeter_m": float(value["perimeter_m"]),
                "observed_perimeter_fraction": float(
                    value["observed_perimeter_fraction"]
                ),
                "inferred_perimeter_fraction": float(
                    value["inferred_perimeter_fraction"]
                ),
                "required_candidate_count": len(value["required_candidates"]),
                "selected": value in selected_region_records,
            }
            for value in regions
        ],
        "closed_layout_region_area_m2": float(
            sum(value["area_m2"] for value in selected_region_records)
        ),
        "closed_layout_min_observed_perimeter_fraction": (
            None
            if not selected_region_records
            else float(
                min(value["observed_perimeter_fraction"] for value in selected_region_records)
            )
        ),
        "closed_layout_max_inferred_perimeter_fraction": (
            None
            if not selected_region_records
            else float(
                max(value["inferred_perimeter_fraction"] for value in selected_region_records)
            )
        ),
        "closed_layout_topology_before": before,
        "closed_layout_topology_after": after,
        "closed_layout_repairable_endpoint_count": repairable_endpoints,
        "closed_layout_repaired_endpoint_count": repaired_endpoints,
        "closed_layout_repair_fraction": float(
            repaired_endpoints / max(repairable_endpoints, 1)
        ),
        "closed_layout_observed_point_p95_m": observed_p95,
        "closed_layout_observed_15cm_support_fraction": observed_support,
        "closed_layout_selected_corner_pair_count": int(
            sum(
                1
                for index in visible_selected_set
                if candidates[index].get("kind") == "corner_pair"
            )
        ),
        "closed_layout_solver": solver,
        "closed_layout_fit": fit_metrics,
        "closed_layout_thick_supplements": supplement_records,
    }
    return ClosedLayoutResult(
        observed,
        inferred_walls,
        openings,
        selected_region_records,
        candidates,
        masks,
        morphology_skeletons,
        morphology_vectors,
        input_mask,
        origin,
        grid_m,
        metrics,
    )
