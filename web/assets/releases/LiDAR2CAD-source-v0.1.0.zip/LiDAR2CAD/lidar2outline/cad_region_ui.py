"""Small desktop GUI for selecting publication regions from a CAD image.

The selector deliberately treats the source image as read-only.  It stores
pixel coordinates (and optional CAD coordinates when an image extent is
provided) and writes lossless crops plus a review overlay.  This is useful for
choosing representative regions without changing the reconstruction itself.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageTk


@dataclass(frozen=True)
class Region:
    """A selected image rectangle in original-pixel coordinates."""

    x0: int
    y0: int
    x1: int
    y1: int

    def normalized(self, width: int, height: int) -> list[float]:
        return [
            self.x0 / width,
            self.y0 / height,
            self.x1 / width,
            self.y1 / height,
        ]

    def as_list(self) -> list[int]:
        return [self.x0, self.y0, self.x1, self.y1]


def _normalise_box(x0: float, y0: float, x1: float, y1: float, width: int, height: int) -> Region:
    left, right = sorted((int(round(x0)), int(round(x1))))
    top, bottom = sorted((int(round(y0)), int(round(y1))))
    left = max(0, min(width - 1, left))
    right = max(left + 1, min(width, right))
    top = max(0, min(height - 1, top))
    bottom = max(top + 1, min(height, bottom))
    return Region(left, top, right, bottom)


def _square_endpoint(x0: float, y0: float, x1: float, y1: float) -> tuple[float, float]:
    """Make the drag from ``(x0,y0)`` to ``(x1,y1)`` a square drag."""

    dx, dy = x1 - x0, y1 - y0
    side = max(abs(dx), abs(dy))
    return (
        x0 + (side if dx >= 0 else -side),
        y0 + (side if dy >= 0 else -side),
    )


def _cad_box(region: Region, width: int, height: int, extent: tuple[float, float, float, float] | None) -> list[float] | None:
    if extent is None:
        return None
    xmin, xmax, ymin, ymax = extent
    # Image origin is top-left; CAD origin is bottom-left.
    return [
        xmin + (region.x0 / width) * (xmax - xmin),
        ymax - (region.y1 / height) * (ymax - ymin),
        xmin + (region.x1 / width) * (xmax - xmin),
        ymax - (region.y0 / height) * (ymax - ymin),
    ]


def export_regions(
    image_path: str | Path,
    output_dir: str | Path,
    regions: Iterable[Region],
    *,
    extent: tuple[float, float, float, float] | None = None,
) -> dict:
    """Export original-resolution crops, an overlay, and a JSON manifest."""

    source = Path(image_path).resolve()
    destination = Path(output_dir).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    image = Image.open(source).convert("RGB")
    width, height = image.size
    region_list = list(regions)

    overlay = image.copy()
    draw = ImageDraw.Draw(overlay)
    manifest_regions = []
    for index, region in enumerate(region_list, start=1):
        crop = image.crop((region.x0, region.y0, region.x1, region.y1))
        crop_path = destination / f"region_{index:02d}.png"
        crop.save(crop_path, format="PNG")
        draw.rectangle(region.as_list(), outline=(255, 55, 55), width=max(3, round(min(width, height) / 700)))
        draw.text((region.x0 + 6, region.y0 + 6), str(index), fill=(255, 55, 55))
        manifest_regions.append(
            {
                "id": index,
                "pixel_bbox_xyxy": region.as_list(),
                "normalized_bbox_xyxy": region.normalized(width, height),
                "cad_bbox_xyxy": _cad_box(region, width, height, extent),
                "crop": crop_path.name,
            }
        )
    overlay_path = destination / "selection_overlay.png"
    overlay.save(overlay_path, format="PNG")
    manifest = {
        "schema_version": "cad-region-selection-v1",
        "source_image": str(source),
        "image_size_px": [width, height],
        "image_coordinate_system": "origin_top_left_x_right_y_down",
        "cad_extent_xyxy": list(extent) if extent is not None else None,
        "cad_coordinate_note": "When extent is supplied, CAD y is upward and image y is flipped.",
        "regions": manifest_regions,
        "selection_count": len(manifest_regions),
    }
    manifest_path = destination / "regions.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return {**manifest, "manifest": str(manifest_path), "overlay": str(overlay_path)}


def run_cad_region_ui(
    image_path: str | Path | None = None,
    output_dir: str | Path = "cad_region_selection",
    *,
    extent: tuple[float, float, float, float] | None = None,
    max_canvas: tuple[int, int] = (1500, 900),
) -> None:
    """Launch the selector.  Tk is imported here so non-GUI tests stay headless."""

    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("CAD 高清图区域选择")
    root.geometry("1450x950")

    state: dict[str, object] = {
        "source": Path(image_path).resolve() if image_path else None,
        "original": None,
        "display": None,
        "photo": None,
        "scale": 1.0,
        "regions": [],
        "drag_start": None,
        "drag_current": None,
        "drag_item": None,
    }

    def fit_scale(image: Image.Image) -> float:
        max_w, max_h = max_canvas
        return min(max_w / image.width, max_h / image.height, 1.0)

    toolbar = ttk.Frame(root, padding=6)
    toolbar.pack(fill="x")
    canvas_frame = ttk.Frame(root)
    canvas_frame.pack(fill="both", expand=True)
    canvas = tk.Canvas(canvas_frame, background="#202124", cursor="crosshair", highlightthickness=0)
    xbar = ttk.Scrollbar(canvas_frame, orient="horizontal", command=canvas.xview)
    ybar = ttk.Scrollbar(canvas_frame, orient="vertical", command=canvas.yview)
    canvas.configure(xscrollcommand=xbar.set, yscrollcommand=ybar.set)
    canvas.grid(row=0, column=0, sticky="nsew")
    ybar.grid(row=0, column=1, sticky="ns")
    xbar.grid(row=1, column=0, sticky="ew")
    canvas_frame.rowconfigure(0, weight=1)
    canvas_frame.columnconfigure(0, weight=1)
    status = tk.StringVar(value="请打开一张 CAD 高清图，然后拖拽框选区域。")
    ttk.Label(root, textvariable=status, anchor="w", padding=(8, 4)).pack(fill="x")

    def set_status(text: str) -> None:
        status.set(text)

    def redraw() -> None:
        original = state["original"]
        if original is None:
            return
        image: Image.Image = original  # type: ignore[assignment]
        scale = float(state.get("scale") or fit_scale(image))
        scaled = image.resize((max(1, round(image.width * scale)), max(1, round(image.height * scale))), Image.Resampling.LANCZOS)
        state["scale"] = scale
        state["display"] = scaled
        state["photo"] = ImageTk.PhotoImage(scaled)
        canvas.delete("all")
        canvas.create_image(0, 0, image=state["photo"], anchor="nw", tags="image")
        canvas.configure(scrollregion=(0, 0, scaled.width, scaled.height))
        for index, region in enumerate(state["regions"], start=1):  # type: ignore[union-attr]
            x0, y0, x1, y1 = (value * scale for value in region.as_list())
            canvas.create_rectangle(x0, y0, x1, y1, outline="#ff3b30", width=2, tags="region")
            canvas.create_text(x0 + 5, y0 + 5, text=str(index), fill="#ff3b30", anchor="nw", font=("Arial", 14, "bold"), tags="region")

    def open_image() -> None:
        chosen = filedialog.askopenfilename(
            title="选择 CAD 高清图",
            filetypes=[("PNG 图像", "*.png"), ("JPEG 图像", "*.jpg;*.jpeg"), ("所有文件", "*.*")],
        )
        if not chosen:
            return
        try:
            state["source"] = Path(chosen).resolve()
            state["original"] = Image.open(chosen).convert("RGB")
            state["regions"] = []
            state["scale"] = fit_scale(state["original"])  # type: ignore[arg-type]
            redraw()
            image: Image.Image = state["original"]  # type: ignore[assignment]
            set_status(f"已加载 {image.width}×{image.height}；拖拽框选，Enter 也可确认当前框。")
        except Exception as exc:  # pragma: no cover - GUI error dialog
            messagebox.showerror("无法打开图像", str(exc))

    def canvas_point(event: tk.Event) -> tuple[float, float]:
        scale = float(state.get("scale") or 1.0)
        return (canvas.canvasx(event.x) / scale, canvas.canvasy(event.y) / scale)

    def begin(event: tk.Event) -> None:
        if state["original"] is None:
            return
        state["drag_start"] = canvas_point(event)
        state["drag_current"] = state["drag_start"]
        if state["drag_item"] is not None:
            canvas.delete(state["drag_item"])
        x, y = canvas_point(event)
        scale = float(state.get("scale") or 1.0)
        state["drag_item"] = canvas.create_rectangle(x * scale, y * scale, x * scale, y * scale, outline="#ffd60a", width=2, dash=(5, 3))

    def update(event: tk.Event) -> None:
        start = state.get("drag_start")
        if start is None or state["drag_item"] is None:
            return
        x0, y0 = start  # type: ignore[misc]
        x1, y1 = canvas_point(event)
        x1, y1 = _square_endpoint(x0, y0, x1, y1)
        state["drag_current"] = (x1, y1)
        scale = float(state.get("scale") or 1.0)
        canvas.coords(state["drag_item"], x0 * scale, y0 * scale, x1 * scale, y1 * scale)

    def commit(_event: tk.Event | None = None) -> None:
        start = state.get("drag_start")
        if start is None or state["original"] is None:
            return
        current = (
            canvas_point(_event)
            if _event is not None and hasattr(_event, "x")
            else (state.get("drag_current") or start)
        )
        x0, y0 = start  # type: ignore[misc]
        x1, y1 = current
        x1, y1 = _square_endpoint(x0, y0, x1, y1)
        image: Image.Image = state["original"]  # type: ignore[assignment]
        region = _normalise_box(x0, y0, x1, y1, image.width, image.height)
        if region.x1 - region.x0 >= 8 and region.y1 - region.y0 >= 8:
            state["regions"].append(region)  # type: ignore[union-attr]
            set_status(f"已添加区域 {len(state['regions'])}：{region.as_list()}（可继续框选）")
        state["drag_start"] = None
        state["drag_current"] = None
        state["drag_item"] = None
        redraw()

    def undo() -> None:
        regions = state["regions"]  # type: ignore[assignment]
        if regions:
            regions.pop()
            redraw()
            set_status(f"已撤销；当前 {len(regions)} 个区域。")

    def clear() -> None:
        state["regions"] = []
        redraw()
        set_status("已清空区域。")

    def save() -> None:
        source = state["source"]
        image = state["original"]
        regions = state["regions"]
        if source is None or image is None or not regions:
            messagebox.showinfo("尚未选择", "请先打开图像并至少框选一个区域。")
            return
        result = export_regions(source, output_dir, regions, extent=extent)  # type: ignore[arg-type]
        set_status(f"已保存 {len(regions)} 个裁剪区域：{result['manifest']}")
        messagebox.showinfo("保存完成", f"已导出 {len(regions)} 个区域\n{result['manifest']}")

    ttk.Button(toolbar, text="打开图像", command=open_image).pack(side="left")
    ttk.Button(toolbar, text="撤销", command=undo).pack(side="left", padx=(6, 0))
    ttk.Button(toolbar, text="清空", command=clear).pack(side="left", padx=(6, 0))
    ttk.Button(toolbar, text="保存框选区域", command=save).pack(side="left", padx=(6, 0))
    def fit_to_window() -> None:
        image = state.get("original")
        if image is not None:
            state["scale"] = fit_scale(image)  # type: ignore[arg-type]
            redraw()

    def zoom_by(factor: float) -> None:
        image = state.get("original")
        if image is None:
            return
        current = float(state.get("scale") or fit_scale(image))
        state["scale"] = max(0.08, min(8.0, current * factor))
        redraw()

    def zoom_wheel(event: tk.Event) -> str:
        # On Windows Tk exposes Ctrl in event.state as bit 0x0004.
        if event.state & 0x0004:
            zoom_by(1.20 if event.delta > 0 else 1 / 1.20)
            return "break"
        if event.state & 0x0001:
            canvas.xview_scroll(-1 if event.delta > 0 else 1, "units")
        else:
            canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
        return "break"

    def pan_begin(event: tk.Event) -> None:
        canvas.scan_mark(event.x, event.y)

    def pan_move(event: tk.Event) -> None:
        canvas.scan_dragto(event.x, event.y, gain=1)

    ttk.Button(toolbar, text="适应窗口", command=fit_to_window).pack(side="left", padx=(6, 0))
    ttk.Button(toolbar, text="放大", command=lambda: zoom_by(1.25)).pack(side="left", padx=(6, 0))
    ttk.Button(toolbar, text="缩小", command=lambda: zoom_by(1 / 1.25)).pack(side="left", padx=(6, 0))
    ttk.Label(toolbar, text="左键=正方形框选 | 右键拖动=平移 | Ctrl+滚轮=缩放 | 滚轮=滚动").pack(side="left", padx=16)

    canvas.bind("<ButtonPress-1>", begin)
    canvas.bind("<B1-Motion>", update)
    canvas.bind("<ButtonRelease-1>", commit)
    canvas.bind("<ButtonPress-3>", pan_begin)
    canvas.bind("<B3-Motion>", pan_move)
    root.bind("<Return>", commit)
    canvas.bind("<MouseWheel>", zoom_wheel)

    if state["source"] is not None:
        try:
            state["original"] = Image.open(state["source"]).convert("RGB")  # type: ignore[arg-type]
            image: Image.Image = state["original"]  # type: ignore[assignment]
            state["scale"] = fit_scale(image)
            redraw()
            set_status(f"已加载 {image.width}×{image.height}；拖拽框选区域。")
        except Exception as exc:  # pragma: no cover - GUI error dialog
            messagebox.showerror("无法打开图像", str(exc))
    else:
        root.after(100, open_image)
    root.mainloop()
