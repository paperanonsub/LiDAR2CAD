from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .errors import DataQualityError
from .transforms import average_rotations, matrix_json, rotation_angle_deg


@dataclass
class CalibrationEstimate:
    rotation_imu_from_lidar: np.ndarray
    translation_imu_from_lidar: np.ndarray
    # Added to IMU header stamps before LIO-SAM. Positive means publish IMU later.
    imu_stamp_correction_sec: float
    source: str

    def as_dict(self) -> dict:
        transform = np.eye(4)
        transform[:3, :3] = self.rotation_imu_from_lidar
        transform[:3, 3] = self.translation_imu_from_lidar
        return {
            "convention": "T_imu_lidar; p_imu = T_imu_lidar @ p_lidar",
            "T_imu_lidar": matrix_json(transform),
            "rotation": self.rotation_imu_from_lidar.tolist(),
            "translation": self.translation_imu_from_lidar.tolist(),
            "imu_stamp_correction_sec": float(self.imu_stamp_correction_sec),
            "source": self.source,
        }


def seed_estimate(cfg: dict) -> CalibrationEstimate:
    seed = cfg["seed"]
    return CalibrationEstimate(
        np.asarray(seed["rotation"], dtype=float),
        np.asarray(seed["translation"], dtype=float),
        float(seed.get("time_offset_sec", 0.0)),
        "configured_seed",
    )


def parse_li_init_result(path: str | Path) -> CalibrationEstimate:
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    section = text.split("Refinement result:")[-1]
    marker = "Homogeneous Transformation Matrix from LiDAR to IMU:"
    if marker not in section:
        raise DataQualityError(f"LI-Init did not produce a refined transform: {path}")
    after = section.split(marker, 1)[1]
    rows = []
    for line in after.splitlines():
        numbers = re.findall(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", line)
        if len(numbers) == 4:
            rows.append([float(value) for value in numbers])
        if len(rows) == 4:
            break
    matrix = np.asarray(rows, dtype=float)
    if matrix.shape != (4, 4) or not np.all(np.isfinite(matrix)):
        raise DataQualityError(f"Could not parse LI-Init transform: {path}")
    match = re.search(r"Time Lag IMU to LiDAR \(second\)\s*=\s*([-+\d.eE]+)", section)
    if not match:
        raise DataQualityError(f"Could not parse LI-Init time lag: {path}")
    lag_imu_to_lidar = float(match.group(1))
    if abs(lag_imu_to_lidar) > 1.0:
        raise DataQualityError(
            f"LI-Init returned implausible time lag {lag_imu_to_lidar:.6f}s; timestamps/configuration are inconsistent"
        )
    # LI-Init reports LiDAR time minus IMU time. Correct IMU onto LiDAR time by adding it.
    return CalibrationEstimate(matrix[:3, :3], matrix[:3, 3], lag_imu_to_lidar, str(Path(path).resolve()))


def compare_estimates(a: CalibrationEstimate, b: CalibrationEstimate) -> dict:
    return {
        "rotation_deg": rotation_angle_deg(a.rotation_imu_from_lidar, b.rotation_imu_from_lidar),
        "translation_m": float(np.linalg.norm(a.translation_imu_from_lidar - b.translation_imu_from_lidar)),
        "time_ms": abs(a.imu_stamp_correction_sec - b.imu_stamp_correction_sec) * 1000.0,
    }


def estimates_agree(a: CalibrationEstimate, b: CalibrationEstimate, thresholds: dict) -> tuple[bool, dict]:
    difference = compare_estimates(a, b)
    agreed = (
        difference["rotation_deg"] <= float(thresholds["rotation_deg"])
        and difference["translation_m"] <= float(thresholds["translation_m"])
        and difference["time_ms"] <= float(thresholds["time_ms"])
    )
    return agreed, difference


def average_estimates(estimates: list[CalibrationEstimate], source: str = "mean_of_consistent_li_init_runs") -> CalibrationEstimate:
    if not estimates:
        raise ValueError("No calibration estimates")
    return CalibrationEstimate(
        average_rotations([item.rotation_imu_from_lidar for item in estimates]),
        np.mean([item.translation_imu_from_lidar for item in estimates], axis=0),
        float(np.mean([item.imu_stamp_correction_sec for item in estimates])),
        source,
    )


def choose_pilot_candidate(estimates: list[CalibrationEstimate], pilot_metrics: list[dict]) -> tuple[CalibrationEstimate, list[dict]]:
    if len(estimates) != len(pilot_metrics):
        raise ValueError("Calibration candidates and pilot metrics differ in length")
    scored = []
    for estimate, metrics in zip(estimates, pilot_metrics):
        continuity = 1.0 if metrics.get("trajectory_continuous", False) else 0.0
        floor_rmse = float(metrics.get("floor_rmse_m", 1.0))
        wall_thickness = float(metrics.get("wall_thickness_m", 1.0))
        score = continuity * 3.0 - floor_rmse * 10.0 - wall_thickness * 3.0
        scored.append({"source": estimate.source, "score": score, **metrics})
    index = int(np.argmax([row["score"] for row in scored]))
    return estimates[index], scored

