"""Evidence-preserving height-fragment association (R309).

No annotation polygons or baseline CAD are inputs. Voxel row identities refer
to the immutable ExactVoxelEvidence cache, not to repeated window references.
"""
from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from typing import Any

import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString
from shapely.strtree import STRtree
from lidar2outline.semantic_objects import _skeleton_paths
from .v5_evidence import ExactVoxelEvidence, HeightWindow, curve_observation_audit, height_windows


def stable_id(prefix: str, values: Any) -> str:
    return prefix + '-' + hashlib.sha256(repr(values).encode()).hexdigest()[:16]


def reconstruction_windows(exact: ExactVoxelEvidence) -> list[HeightWindow]:
    return (height_windows(exact.floor_m, exact.ceiling_m, .50, .30, 'thin')
            + height_windows(exact.floor_m, exact.ceiling_m, 1.00, .50, 'thick'))


@dataclass
class HeightFragment:
    fragment_id: str
    window_id: str
    z_min_m: float
    z_max_m: float
    line: LineString
    tangent: np.ndarray
    source_rows: np.ndarray


def extract_height_fragments(
    exact: ExactVoxelEvidence, windows: list[HeightWindow], cfg: dict[str, Any],
    *, wall_probability: np.ndarray | None = None, excluded_cells: np.ndarray | None = None,
) -> list[HeightFragment]:
    """Extract *separately* in each window; no cross-height raster union.

    Window candidates need two unique height bins. Optional semantics only
    filters candidates; confidence never creates a voxel or measured support.
    """
    minimum = float(cfg.get('association_fragment_min_length_m', .20))
    tolerance = float(cfg.get('association_fragment_simplify_m', .025))
    tree = cKDTree(exact.centroids[:, :2])
    output: list[HeightFragment] = []
    for window in windows:
        in_window = ((exact.centroids[:, 2] >= window.z_min_m)
                     & (exact.centroids[:, 2] < window.z_max_m))
        rows = np.flatnonzero(in_window)
        cells, counts = np.unique(exact.xy_cell[rows], return_counts=True)
        cells = cells[counts >= int(cfg.get('association_window_min_bins', 2))]
        if wall_probability is not None:
            cells = cells[wall_probability.ravel()[cells] >= float(cfg.get('association_wall_probability_min', .80))]
        if excluded_cells is not None:
            cells = cells[~excluded_cells.ravel()[cells]]
        if not len(cells):
            continue
        # Crop to occupied bounds; global coordinates and cache row IDs remain unchanged.
        rr, cc = np.divmod(cells, exact.shape[1])
        r0, c0 = int(rr.min()) - 1, int(cc.min()) - 1
        mask = np.zeros((int(rr.max()) - r0 + 2, int(cc.max()) - c0 + 2), bool)
        mask[rr - r0, cc - c0] = True
        origin = exact.origin_xy + (np.array([c0, r0]) + .5) * exact.grid_m
        for path in _skeleton_paths(mask, origin, exact.grid_m):
            coordinates = np.asarray(path.simplify(tolerance).coords)
            for a, b in zip(coordinates[:-1], coordinates[1:]):
                length = float(np.linalg.norm(b - a))
                if length < minimum:
                    continue
                tangent = (b - a) / length
                if tuple(tangent) < tuple(-tangent):
                    a, b, tangent = b, a, -tangent
                line = LineString([a, b])
                # Query at <= half a voxel to retain every physical source once.
                samples = np.linspace(a, b, max(2, int(math.ceil(length / .025)) + 1))
                neighbours = tree.query_ball_point(samples, exact.grid_m * .80)
                indices = np.unique(np.concatenate([v for v in neighbours if v])) if any(neighbours) else np.array([], int)
                indices = indices.astype(np.int64)
                indices = indices[in_window[indices]]
                if len(indices) < 4:
                    continue
                offset = exact.centroids[indices, :2] - a
                lateral = np.abs(offset @ np.array([-tangent[1], tangent[0]]))
                along = offset @ tangent
                indices = indices[(lateral <= exact.grid_m * .70) & (along >= -.025) & (along <= length + .025)]
                if len(indices) < 4:
                    continue
                # Fit the physical centroids, not the skeleton pixel centres.
                center = np.mean(exact.centroids[indices, :2], axis=0)
                projected = (exact.centroids[indices, :2] - center) @ tangent
                fitted = LineString([center + projected.min() * tangent, center + projected.max() * tangent])
                if fitted.length < minimum:
                    continue
                identifier = stable_id('HF', (window.window_id, tuple(indices.tolist())))
                output.append(HeightFragment(identifier, window.window_id,
                                             float(exact.centroids[indices, 2].min()),
                                             float(exact.centroids[indices, 2].max()), fitted, tangent, indices))
    return sorted(output, key=lambda f: f.fragment_id)


def _compatible(a: HeightFragment, b: HeightFragment, cfg: dict[str, Any], *, require_overlap: bool) -> bool:
    alignment = abs(float(a.tangent @ b.tangent))
    if alignment < math.cos(math.radians(float(cfg.get('association_direction_tolerance_deg', 10.0)))):
        return False
    height_gap = max(0.0, max(a.z_min_m, b.z_min_m) - min(a.z_max_m, b.z_max_m))
    if require_overlap and height_gap > float(cfg.get('association_max_height_gap_m', 1.0)):
        return False
    pa, pb = np.asarray(a.line.coords), np.asarray(b.line.coords)
    normal = np.array([-a.tangent[1], a.tangent[0]])
    # Symmetric complete-link lateral test prevents chaining across parallel surfaces.
    normal_b = np.array([-b.tangent[1], b.tangent[0]])
    lateral = max(float(np.max(np.abs((pb - pa.mean(axis=0)) @ normal))),
                  float(np.max(np.abs((pa - pb.mean(axis=0)) @ normal_b))))
    if lateral > float(cfg.get('association_lateral_tolerance_m', .035)):
        return False
    along_a, along_b = pa @ a.tangent, pb @ a.tangent
    overlap = min(along_a.max(), along_b.max()) - max(along_a.min(), along_b.min())
    if require_overlap and overlap < min(.15, .30 * min(a.line.length, b.line.length)):
        return False
    return True


def associate_height_fragments(
    fragments: list[HeightFragment], cfg: dict[str, Any],
    *, source_xy: np.ndarray | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Greedy, deterministic association with group-wide cannot-link checks.

    Candidate edges require different windows and overlapping planar extent;
    all members of merged groups must pass the lateral/direction conflict test.
    This is not unrestricted transitive closure of pairwise proximity edges.
    """
    fragments = sorted(fragments, key=lambda f: f.fragment_id)
    parent = list(range(len(fragments)))
    members = {i: [i] for i in parent}
    compatibility_cache: dict[tuple[int, int, bool], bool] = {}
    compatibility_evaluations = 0
    compatibility_cache_hits = 0

    def indexed_compatible(first: int, second: int, *, require_overlap: bool) -> bool:
        """Memoize the expensive Shapely pair check across group merges."""
        nonlocal compatibility_evaluations, compatibility_cache_hits
        if first > second:
            first, second = second, first
        key = (first, second, require_overlap)
        if key in compatibility_cache:
            compatibility_cache_hits += 1
            return compatibility_cache[key]
        compatibility_evaluations += 1
        value = _compatible(fragments[first], fragments[second], cfg, require_overlap=require_overlap)
        compatibility_cache[key] = value
        return value

    def groups_compatible(first_group: list[int], second_group: list[int], seed: tuple[int, int]) -> bool:
        """Exact complete-link check with likely conflicts tested first.

        Successful merges still verify every cross-group pair, preserving the
        previous result.  Memoization prevents rejected edges from repeatedly
        recomputing the same geometric relationships on full scenes.
        """
        probes: list[tuple[int, int]] = [seed]
        for first in (first_group[0], first_group[-1]):
            for second in (second_group[0], second_group[-1]):
                probes.append((first, second))
        seen: set[tuple[int, int]] = set()
        for first, second in probes:
            key = (min(first, second), max(first, second))
            if key in seen:
                continue
            seen.add(key)
            if not indexed_compatible(first, second, require_overlap=False):
                return False
        # Put the smaller group outside so a conflict usually terminates after
        # fewer Python loop iterations; cached pairs cost only a dictionary hit.
        outer, inner = (
            (first_group, second_group)
            if len(first_group) <= len(second_group)
            else (second_group, first_group)
        )
        for first in outer:
            for second in inner:
                key = (min(first, second), max(first, second))
                if key in seen:
                    continue
                if not indexed_compatible(first, second, require_overlap=False):
                    return False
        return True

    def root(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    # Bounding boxes index long fragments; centroid radii alone miss partial overlaps.
    from shapely.strtree import STRtree
    lines = [f.line for f in fragments]
    index = STRtree(lines)
    edges = []
    for i, a in enumerate(fragments):
        for j in index.query(a.line.buffer(float(cfg.get('association_lateral_tolerance_m', .035)))):
            j = int(j)
            if j <= i or a.window_id == fragments[j].window_id:
                continue
            b = fragments[j]
            if indexed_compatible(i, j, require_overlap=True):
                edges.append((a.line.distance(b.line), i, j))
    rejected = 0
    accepted_edges = []
    if bool(cfg.get('explicit_cross_height_association', True)):
        for _, i, j in sorted(edges):
            ri, rj = root(i), root(j)
            if ri == rj:
                continue
            if not groups_compatible(members[ri], members[rj], (i, j)):
                rejected += 1
                continue
            # Union by size bounds tree depth and keeps the member list update
            # linear in the smaller group.
            if len(members[ri]) < len(members[rj]):
                ri, rj = rj, ri
            parent[rj] = ri
            members[ri].extend(members.pop(rj))
            accepted_edges.append([fragments[i].fragment_id, fragments[j].fragment_id])

    # Optional second pass for development experiments.  The strict pass above
    # deliberately uses complete-link constraints and can therefore leave one
    # physical surface split when a single noisy fragment conflicts with a
    # group member.  Reconsideration is based on UNIQUE physical source voxels,
    # not duplicated window observations.  It remains disabled by default so
    # historical A--F runs retain bit-for-bit configuration semantics.
    recheck_enabled = bool(cfg.get('association_group_recheck_enabled', False))
    recheck_candidates = 0
    recheck_accepted_edges: list[list[str]] = []
    if recheck_enabled:
        if source_xy is None:
            raise ValueError('association_group_recheck_enabled requires source_xy')
        source_xy = np.asarray(source_xy, dtype=float)
        if source_xy.ndim != 2 or source_xy.shape[1] != 2:
            raise ValueError('source_xy must have shape (N, 2)')
        if fragments and max((int(np.max(f.source_rows)) for f in fragments if len(f.source_rows)), default=-1) >= len(source_xy):
            raise ValueError('fragment source row is outside source_xy')

        direction_limit = math.cos(math.radians(float(
            cfg.get('association_group_recheck_direction_tolerance_deg',
                    cfg.get('association_direction_tolerance_deg', 10.0)))))
        lateral_limit = float(cfg.get(
            'association_group_recheck_lateral_m',
            cfg.get('association_lateral_tolerance_m', .035)))
        gap_limit = float(cfg.get('association_group_recheck_gap_m', .15))
        p95_limit = float(cfg.get('association_group_recheck_p95_m', .025))
        maximum_limit = float(cfg.get('association_group_recheck_max_m', .055))
        minimum_windows = int(cfg.get('association_group_recheck_min_windows', 2))
        maximum_rounds = int(cfg.get('association_group_recheck_max_rounds', 8))

        def group_summary(indices: list[int]) -> dict[str, Any]:
            rows = np.unique(np.concatenate([fragments[i].source_rows for i in indices])).astype(int)
            points = source_xy[rows]
            if len(points) < 2:
                points = np.vstack([np.asarray(fragments[i].line.coords) for i in indices])
            center = points.mean(axis=0)
            _, _, vh = np.linalg.svd(points - center, full_matrices=False)
            tangent = vh[0]
            along = (points - center) @ tangent
            normal = np.array([-tangent[1], tangent[0]])
            residual = np.abs((points - center) @ normal)
            return {
                'rows': rows, 'points': points, 'center': center, 'tangent': tangent,
                'line': LineString([center + along.min() * tangent,
                                    center + along.max() * tangent]),
                'windows': {fragments[i].window_id for i in indices},
                'p95': float(np.percentile(residual, 95)),
                'maximum': float(residual.max(initial=0.0)),
            }

        def review(first: list[int], second: list[int]) -> tuple[bool, float]:
            a, b = group_summary(first), group_summary(second)
            if abs(float(a['tangent'] @ b['tangent'])) < direction_limit:
                return False, math.inf
            if len(a['windows'] | b['windows']) < minimum_windows:
                return False, math.inf
            # Reject nearby parallel walls before the joint residual can average
            # their offsets into an apparently plausible centre line.
            normal = np.array([-a['tangent'][1], a['tangent'][0]])
            lateral = abs(float((b['center'] - a['center']) @ normal))
            if lateral > lateral_limit:
                return False, math.inf
            points = np.vstack([a['points'], b['points']])
            center = points.mean(axis=0)
            _, _, vh = np.linalg.svd(points - center, full_matrices=False)
            tangent = vh[0]
            normal = np.array([-tangent[1], tangent[0]])
            residual = np.abs((points - center) @ normal)
            p95 = float(np.percentile(residual, 95))
            maximum = float(residual.max(initial=0.0))
            if p95 > p95_limit or maximum > maximum_limit:
                return False, math.inf
            first_along = (a['points'] - center) @ tangent
            second_along = (b['points'] - center) @ tangent
            gap = max(0.0, max(float(first_along.min()), float(second_along.min()))
                      - min(float(first_along.max()), float(second_along.max())))
            if gap > gap_limit:
                return False, math.inf
            return True, p95 + gap + lateral

        for _ in range(maximum_rounds):
            roots = sorted(members, key=lambda value: fragments[members[value][0]].fragment_id)
            if len(roots) < 2:
                break
            summaries = {value: group_summary(members[value]) for value in roots}
            from shapely.strtree import STRtree
            group_lines = [summaries[value]['line'] for value in roots]
            group_index = STRtree(group_lines)
            proposed: list[tuple[float, int, int]] = []
            for position, first_root in enumerate(roots):
                search = group_lines[position].buffer(max(gap_limit, lateral_limit))
                for other_position in group_index.query(search):
                    other_position = int(other_position)
                    if other_position <= position:
                        continue
                    second_root = roots[other_position]
                    recheck_candidates += 1
                    valid, score = review(members[first_root], members[second_root])
                    if valid:
                        proposed.append((score, first_root, second_root))
            changed = False
            for _, first_root, second_root in sorted(proposed):
                first_root, second_root = root(first_root), root(second_root)
                if first_root == second_root or first_root not in members or second_root not in members:
                    continue
                valid, _ = review(members[first_root], members[second_root])
                if not valid:
                    continue
                first_id = fragments[members[first_root][0]].fragment_id
                second_id = fragments[members[second_root][0]].fragment_id
                if len(members[first_root]) < len(members[second_root]):
                    first_root, second_root = second_root, first_root
                parent[second_root] = first_root
                members[first_root].extend(members.pop(second_root))
                recheck_accepted_edges.append([first_id, second_id])
                changed = True
            if not changed:
                break
    objects = []
    for indices in sorted(members.values(), key=lambda v: fragments[v[0]].fragment_id):
        group = [fragments[i] for i in indices]
        rows = np.unique(np.concatenate([f.source_rows for f in group]))
        # Endpoint fit weighted by physical extent; unique sources are used downstream.
        coordinates = np.vstack([np.asarray(f.line.coords) for f in group])
        center = coordinates.mean(axis=0)
        _, _, vh = np.linalg.svd(coordinates - center, full_matrices=False)
        tangent = vh[0]
        along = (coordinates - center) @ tangent
        line = LineString([center + along.min() * tangent, center + along.max() * tangent])
        identifier = stable_id('XH', sorted(f.fragment_id for f in group))
        objects.append({
            'wall_id': identifier, 'association_object_ids': [identifier],
            'physical_wall_id': identifier, 'line': line, 'geometry_kind': 'line',
            'status': 'inferred_semantic_object', 'source': 'explicit_height_fragment_association',
            'source_voxel_rows': rows.tolist(),
            'source_windows': sorted(set(f.window_id for f in group)),
            'fragment_ids': [f.fragment_id for f in group],
            'provenance': {'kind': 'cross_height_association' if len(group) > 1 else 'surface_extraction',
                           'fragment_ids': [f.fragment_id for f in group]},
        })
    return objects, {'fragment_count': len(fragments), 'object_count': len(objects),
                     'association_candidate_count': len(edges), 'accepted_edges': accepted_edges,
                     'group_conflicts_rejected': rejected,
                     'compatibility_evaluations': compatibility_evaluations,
                     'compatibility_cache_hits': compatibility_cache_hits,
                     'compatibility_cache_size': len(compatibility_cache),
                     'group_recheck_enabled': recheck_enabled,
                     'group_recheck_candidate_count': recheck_candidates,
                     'group_recheck_accepted_edges': recheck_accepted_edges,
                     'group_recheck_accepted_count': len(recheck_accepted_edges),
                     'unique_source_voxel_count': len(set(r for o in objects for r in o['source_voxel_rows']))}


class ObjectEvidenceIndex:
    """Immutable source ownership from Module B, never expanded by connections."""

    def __init__(self, exact: ExactVoxelEvidence, objects: list[dict[str, Any]]):
        self.exact = exact
        self.tree = cKDTree(exact.centroids[:, :2])
        self.owner = np.full(len(exact.centroids), -1, np.int32)
        self.tangents = np.zeros((len(exact.centroids), 2), np.float32)
        self.ids = [str(o['wall_id']) for o in objects]
        self.by_id = {value: i for i, value in enumerate(self.ids)}
        self.lines = [o['line'] for o in objects]
        # Full-scene reconstructions can contain tens of thousands of wall
        # objects.  Query a spatial index before applying the exact legacy
        # distance/angle/overlap tests below; scanning every wall for every
        # connection candidate makes this stage quadratic without changing
        # which objects can possibly be compatible.
        self.line_tree = STRtree(self.lines) if self.lines else None
        self.rows: list[np.ndarray] = []
        for i, obj in enumerate(objects):
            rows = np.asarray(obj.get('source_voxel_rows', []), dtype=np.int64)
            self.rows.append(rows)
            conflict = (self.owner[rows] >= 0) & (self.owner[rows] != i)
            previous_conflict = self.owner[rows] == -2
            self.owner[rows] = np.where(conflict | previous_conflict, -2, i)
            delta = np.asarray(obj['line'].coords[-1]) - np.asarray(obj['line'].coords[0])
            self.tangents[rows] = delta / max(np.linalg.norm(delta), 1e-12)
        self._mask = np.zeros(len(exact.centroids), bool)

    def audit(
        self,
        line: LineString,
        allowed: list[str] | None = None,
        *,
        row_mask: np.ndarray | None = None,
        enforce_direction: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        mask = None
        if row_mask is not None:
            mask = np.asarray(row_mask, dtype=bool)
            if mask.shape != self.owner.shape:
                raise ValueError('row_mask must have one entry per unique voxel')
        elif allowed is not None:
            self._mask.fill(False)
            for identifier in allowed:
                if identifier in self.by_id:
                    i = self.by_id[identifier]
                    rows = self.rows[i]
                    self._mask[rows] = self.owner[rows] == i
            mask = self._mask
        return curve_observation_audit(line, self.exact, tree=self.tree, row_mask=mask,
                                       row_tangents=self.tangents if enforce_direction else None,
                                       **kwargs)

    def ownership_masks(
        self,
        line: LineString,
        allowed: list[str],
        cfg: dict[str, Any],
    ) -> dict[str, Any]:
        """Separate certain host, uncertain-compatible and certain foreign rows.

        Compatibility is evaluated from object geometry only.  It never changes
        the immutable owner array and therefore cannot turn a connection into a
        measured object.  A compatible non-host object is an explicit identity
        hypothesis, not proof that both program objects are one physical wall.
        """
        allowed_indices = {self.by_id[value] for value in allowed if value in self.by_id}
        coordinates = np.asarray(line.coords, dtype=float)
        delta = np.diff(coordinates, axis=0)
        lengths = np.linalg.norm(delta, axis=1)
        directions = delta[lengths > 1e-9] / lengths[lengths > 1e-9, None]
        angle = float(cfg.get('object_hypothesis_direction_tolerance_deg',
                              cfg.get('association_direction_tolerance_deg', 10.0)))
        cosine = math.cos(math.radians(angle))
        lateral = float(cfg.get('object_hypothesis_lateral_tolerance_m',
                                cfg.get('association_lateral_tolerance_m', .035)))
        minimum_overlap = float(cfg.get('object_hypothesis_min_overlap_m', .05))
        compatible_indices: set[int] = set()
        if len(directions):
            corridor = line.buffer(lateral + 1e-9, cap_style=2, join_style=2)
            nearby = (
                np.asarray(
                    self.line_tree.query(line.buffer(lateral + 1e-9)),
                    dtype=np.int64,
                )
                if self.line_tree is not None
                else np.empty(0, dtype=np.int64)
            )
            for index in sorted(map(int, nearby)):
                object_line = self.lines[index]
                if index in allowed_indices or object_line.distance(line) > lateral + 1e-9:
                    continue
                object_delta = np.asarray(object_line.coords[-1], float) - np.asarray(object_line.coords[0], float)
                object_length = float(np.linalg.norm(object_delta))
                if object_length <= 1e-9:
                    continue
                object_direction = object_delta / object_length
                if float(np.max(np.abs(directions @ object_direction))) < cosine:
                    continue
                proximal_length = float(object_line.intersection(corridor).length)
                required = min(minimum_overlap, .25 * object_length, .25 * float(line.length))
                if proximal_length + 1e-9 >= required:
                    compatible_indices.add(index)

        host = np.isin(self.owner, list(allowed_indices)) if allowed_indices else np.zeros_like(self.owner, bool)
        compatible = (np.isin(self.owner, list(compatible_indices))
                      if compatible_indices else np.zeros_like(self.owner, bool))
        ambiguous = self.owner == -2
        unassigned = self.owner == -1
        confirmed_foreign = (self.owner >= 0) & ~host & ~compatible
        return {
            'host': host,
            'compatible_hypothesis': compatible,
            'ambiguous': ambiguous,
            'unassigned': unassigned,
            'confirmed_foreign': confirmed_foreign,
            'uncertain': compatible | ambiguous,
            'soft_admissible': host | compatible | ambiguous,
            'compatible_object_ids': sorted(self.ids[index] for index in compatible_indices),
        }


def _fraction(audit: dict[str, Any], interior: bool = False) -> float:
    values = np.asarray(audit['supported'], bool)
    if interior and len(values) > 2:
        values = values[1:-1]
    return float(values.mean()) if len(values) else 0.0


def _weighted_fraction(
    host_audit: dict[str, Any],
    soft_audit: dict[str, Any],
    uncertain_weight: float,
    *,
    interior: bool = False,
) -> float:
    host = np.asarray(host_audit['supported'], bool)
    soft = np.asarray(soft_audit['supported'], bool)
    if host.shape != soft.shape:
        raise ValueError('ownership audits must share one sampling grid')
    values = host.astype(float) + float(uncertain_weight) * (soft & ~host)
    if interior and len(values) > 2:
        values = values[1:-1]
    return float(values.mean()) if len(values) else 0.0


def longest_missing_run(audit: dict[str, Any], length: float) -> float:
    positions = np.asarray(audit['sample_arclength_m'], float)
    supported = np.asarray(audit['supported'], bool)
    bounds = np.r_[0.0, (positions[:-1] + positions[1:]) / 2, length]
    longest = run = 0.0
    for i, valid in enumerate(supported):
        run = 0.0 if valid else run + float(bounds[i + 1] - bounds[i])
        longest = max(longest, run)
    return longest


def enrich_connection_evidence(candidates: list[dict[str, Any]], walls: list[dict[str, Any]],
                               index: ObjectEvidenceIndex, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    by_id = {str(w['wall_id']): w for w in walls}
    output = []
    for source in candidates:
        c = dict(source)
        host_ids = [str(v[0]) for v in c.get('endpoint_keys', [])]
        # T attachments have one free endpoint; explicitly retain the receiving host too.
        if c.get('host_wall_id') is not None:
            host_ids.append(str(c['host_wall_id']))
        allowed = sorted({oid for h in host_ids for oid in by_id.get(h, {}).get('association_object_ids', [h])})
        ownership = index.ownership_masks(c['line'], allowed, cfg)
        strict = index.audit(c['line'], row_mask=ownership['host'], include_sources=True)
        relaxed = index.audit(c['line'], row_mask=ownership['host'], min_height_bins=2,
                              min_vertical_span_m=.10, include_sources=True)
        soft_strict = index.audit(c['line'], row_mask=ownership['soft_admissible'], include_sources=True)
        soft_relaxed = index.audit(c['line'], row_mask=ownership['soft_admissible'], min_height_bins=2,
                                   min_vertical_span_m=.10, include_sources=True)
        compatible = index.audit(c['line'], row_mask=ownership['compatible_hypothesis'],
                                 min_height_bins=2, min_vertical_span_m=.10)
        ambiguous = index.audit(c['line'], row_mask=ownership['ambiguous'],
                                min_height_bins=2, min_vertical_span_m=.10)
        uncertain = index.audit(c['line'], row_mask=ownership['uncertain'],
                                min_height_bins=2, min_vertical_span_m=.10)
        unassigned = index.audit(c['line'], row_mask=ownership['unassigned'], enforce_direction=False,
                                 min_height_bins=2, min_vertical_span_m=.10)
        confirmed_foreign = index.audit(c['line'], row_mask=ownership['confirmed_foreign'],
                                        min_height_bins=2, min_vertical_span_m=.10)
        geometric = index.audit(c['line'], None, min_height_bins=2, min_vertical_span_m=.10)
        mode = str(cfg.get('object_ownership_mode', 'hard'))
        if mode not in {'hard', 'multi_hypothesis'}:
            raise ValueError(f'unsupported object_ownership_mode: {mode}')
        uncertainty_weight = float(cfg.get('object_uncertain_support_weight', .50))
        if not 0.0 <= uncertainty_weight <= 1.0:
            raise ValueError('object_uncertain_support_weight must be in [0, 1]')
        effective_strict = (_weighted_fraction(strict, soft_strict, uncertainty_weight, interior=True)
                            if mode == 'multi_hypothesis' else _fraction(strict, True))
        effective_strict_full = (_weighted_fraction(strict, soft_strict, uncertainty_weight)
                                 if mode == 'multi_hypothesis' else _fraction(strict))
        effective_relaxed = (_weighted_fraction(relaxed, soft_relaxed, uncertainty_weight, interior=True)
                             if mode == 'multi_hypothesis' else _fraction(relaxed, True))
        support_audit = soft_relaxed if mode == 'multi_hypothesis' else relaxed
        support_fraction = _fraction(support_audit, True)
        support_mask = np.asarray(support_audit['supported'], bool)
        foreign_mask = np.asarray(confirmed_foreign['supported'], bool)
        raw_foreign = float(foreign_mask.mean()) if len(foreign_mask) else 0.0
        foreign = float(np.mean(foreign_mask & ~support_mask)) if len(foreign_mask) else 0.0
        matched = np.asarray([v is not None for v in support_audit['nearest_distance_m']])
        blind = longest_missing_run(support_audit, c['line'].length)
        # A distinct, bounded inference branch: no fabricated measured support.
        continuation_score = (.50 * c.get('orientation_score', 0.0)
                              + .35 * c.get('attachment_support_score', 0.0)
                              + .15 * max(0.0, 1 - c['line'].length / .30))
        continuation = bool(cfg.get('short_gap_continuation_enabled', True)
                            and len(set(host_ids)) == 2 and c.get('kind') == 'collinear'
                            and c['line'].length <= float(cfg.get('object_continuation_max_gap_m', .20))
                            and c.get('orientation_score', 0) >= .95
                            and c.get('attachment_support_score', 0) >= .80
                            and foreign <= float(cfg.get('object_foreign_support_max', .15))
                            and continuation_score >= float(cfg.get('object_continuation_score_min', .80)))
        evidence_gate = (support_fraction >= float(cfg.get('object_support_min', .70))
                         and effective_relaxed >= float(cfg.get('object_weighted_support_min', .35))
                         and foreign <= float(cfg.get('object_foreign_support_max', .15))
                         and support_audit['p95_m'] is not None and support_audit['p95_m'] <= .05)
        c.update({
            'host_wall_ids': sorted(set(host_ids)), 'association_object_ids': allowed,
            'identity_evidence_mode': mode,
            'compatible_hypothesis_object_ids': ownership['compatible_object_ids'],
            'geometric_support_fraction': _fraction(geometric, True),
            'host_support_fraction': _fraction(relaxed, True),
            'compatible_support_fraction': _fraction(compatible, True),
            'ambiguous_support_fraction': _fraction(ambiguous, True),
            'unassigned_support_fraction': _fraction(unassigned, True),
            'uncertain_support_fraction': _fraction(uncertain, True),
            'object_support_fraction': effective_relaxed,
            'soft_support_fraction': _fraction(soft_relaxed, True),
            'foreign_support_fraction': foreign,
            'raw_foreign_support_fraction': raw_foreign,
            'object_matched_fraction': float(matched.mean()), 'object_p95_m': support_audit['p95_m'],
            'object_strict_support_fraction': _fraction(strict, True),
            'soft_strict_support_fraction': _fraction(soft_strict, True),
            'object_longest_unsupported_m': blind,
            'object_evidence_eligible': bool(evidence_gate),
            'continuation_eligible': continuation, 'continuation_score': float(continuation_score),
            'provenance': {'kind': 'direction_search_connection' if 'direction' in c.get('source', '')
                           else 'endpoint_connection', 'host_object_ids': allowed},
            'object_source_voxel_rows': sorted(set(r for rows in support_audit['source_voxel_rows'] for r in rows)),
        })
        if bool(cfg.get('object_consistent_gate', True)):
            c['legacy_geometric_score'] = c['score']
            c['strict_support_fraction'] = effective_strict
            c['strict_full_support_fraction'] = effective_strict_full
            # Selection coverage and identity confidence are separate quantities:
            # an uncertain sample still covers an interval, but contributes only
            # ``uncertainty_weight`` to the score above.
            c['relaxed_support_fraction'] = (
                support_fraction if mode == 'multi_hypothesis' else effective_relaxed
            )
            c['relaxed_p95_m'] = support_audit['p95_m']
            # Replace the two evidence terms; retain exactly the original geometric terms.
            weights = np.array([cfg.get('topology_score_strict_weight', .45),
                                cfg.get('topology_score_relaxed_weight', .20),
                                cfg.get('topology_score_orientation_weight', .20),
                                cfg.get('topology_score_length_weight', .15)], float)
            if np.any(weights < 0) or weights.sum() <= 0:
                raise ValueError('invalid topology score weights')
            weights /= weights.sum()
            c['score'] = float(c['score'] + weights[0] * (effective_strict - source['strict_support_fraction'])
                               + weights[1] * (effective_relaxed - source['relaxed_support_fraction']))
            # Only certain host support can create a directly observed status.
            # Compatible or ambiguous ownership remains an inferred hypothesis.
            if not (_fraction(strict) >= .95 and strict['p95_m'] is not None and strict['p95_m'] <= .10):
                c['status'] = 'inferred_gap'
            p95 = support_audit['p95_m']
            align = max(0.0, 1 - p95 / .10) if p95 is not None else 0.0
            c['path_membership_score'] = min(c.get('path_membership_score', 0.0),
                                             .40 * align + .30 * c.get('orientation_score', 0.0)
                                             + .20 * c.get('attachment_support_score', 0.0)
                                             + .10 * c.get('object_relation_score', 0.0))
            c['open_risk_score'] = float(np.clip(.65 * blind / max(c['line'].length, 1e-9) + .35 * (1 - align), 0, 1))
        output.append(c)
    return output


def annotate_dual_evidence(records: list[dict[str, Any]], index: ObjectEvidenceIndex,
                           windows: list[HeightWindow]) -> list[dict[str, Any]]:
    """Recompute after noding; provenance never implies direct observation."""
    output = []
    for source in records:
        r = dict(source)
        r.setdefault('wall_id', str(r.get('connection_id', 'unidentified')))
        allowed = r.get('association_object_ids', [str(r['wall_id'])])
        audit = index.audit(r['line'], allowed, include_sources=True)
        r.setdefault('provenance', {'kind': r.get('source', 'surface_extraction')})
        positions = np.asarray(audit['sample_arclength_m'])
        bounds = np.r_[0.0, (positions[:-1] + positions[1:]) / 2, r['line'].length]
        records_local = []
        for i, sources in enumerate(audit['source_voxel_rows']):
            strong = bool(audit['supported'][i])
            strength = 'strong' if strong else ('weak' if sources else 'absent')
            state = 'observed' if sources else ('inferred' if r.get('connection_id') else 'unknown')
            records_local.append({'s_start_m': float(bounds[i]), 's_end_m': float(bounds[i+1]),
                                  'state': state, 'evidence_strength': strength,
                                  'height_bin_count': audit['height_bin_count'][i],
                                  'vertical_span_m': audit['vertical_span_m'][i],
                                  'match_distance_m': audit['nearest_distance_m'][i],
                                  'geometric_consistency': audit['geometric_consistency'][i],
                                  'source_voxel_rows': sources})
        r['support_intervals'] = records_local
        r['observed_support_fraction'] = _fraction(audit)
        r['matched_support_fraction'] = float(audit['matched_fraction'])
        r['status'] = 'observed' if all(audit['supported']) else ('inferred_gap' if r.get('connection_id') else 'mixed_evidence')
        # Window evidence is a subset of the same source rows. Full-height validity
        # is stored independently and can never create a window match.
        per_window = {}
        for window in windows:
            entries = []
            for interval in records_local:
                rows = np.asarray(interval['source_voxel_rows'], int)
                rows = rows[(index.exact.centroids[rows, 2] >= window.z_min_m)
                            & (index.exact.centroids[rows, 2] < window.z_max_m)]
                bins = np.unique(index.exact.z_bin[rows])
                entries.append({'s_start_m': interval['s_start_m'], 's_end_m': interval['s_end_m'],
                                'state': 'observed' if len(rows) else ('inferred' if r.get('connection_id') else 'unknown'),
                                'evidence_strength': 'weak' if len(rows) else 'absent',
                                'height_bin_count': len(bins),
                                'vertical_span_m': float((bins[-1] - bins[0] + 1) * index.exact.z_bin_m) if len(bins) else 0.0,
                                'match_distance_m': float(np.min(np.linalg.norm(index.exact.centroids[rows, :2]
                                    - np.asarray(r['line'].interpolate((interval['s_start_m'] + interval['s_end_m']) / 2).coords[0]), axis=1))) if len(rows) else None,
                                'geometric_consistency': interval['geometric_consistency'] if len(rows) else 0.0,
                                'source_voxel_rows': rows.tolist(),
                                'full_height_valid': interval['evidence_strength'] == 'strong'})
            per_window[window.window_id] = entries
        r['window_evidence'] = per_window
        r['source_voxel_rows'] = sorted(set(v for a in records_local for v in a['source_voxel_rows']))
        output.append(r)
    return output
