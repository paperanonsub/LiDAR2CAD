"""Design-assisted post-processing for a native LiDAR2CAD R309 object graph.

The module deliberately does not consume the archived V6 ``fusion_cache.json``.
Every design correspondence and every added connection is regenerated from the
specified R309 object graph, design drawing, frozen registration and evidence
cache.  Design-only geometry is exported on a reference layer and is excluded
from measured reconstruction length.

Example
-------
python -m parking_pipeline.design_assisted_r309 \
  --object-graph TII/results/independent_validation/r309_semantic_continuity_icpar/run/building_object_graph.json \
  --geometry-geojson TII/results/independent_validation/ablation_matrix_icpar_full/runs/icpar_F/architectural_plan.geojson \
  --semantic-geojson TII/results/independent_validation/r309_semantic_continuity_icpar/run/architectural_plan.geojson \
  --evidence TII/data/semantic_cache/exact_voxels.npz \
  --semantic-cache TII/data/semantic_cache/probabilities_raster.npz \
  --design-architecture outputs/parking/design_fusion/icpar_r309_aligned/artifacts/design_arch.json \
  --alignment outputs/parking/design_fusion/icpar_r309_aligned/artifacts/arch_alignment.json \
  --output TII/results/independent_validation/design_assisted_r309_icpar
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import shutil
from time import perf_counter
from typing import Any, Iterable

import ezdxf
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial import cKDTree
from shapely import affinity
from shapely.geometry import LineString, Point, mapping
from shapely.strtree import STRtree


SCHEMA_VERSION = "design-assisted-r309-v1"


def _read_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _line(record: dict[str, Any]) -> LineString:
    return LineString(record["coordinates"])


def _angle_difference(first: LineString, second: LineString) -> float:
    def angle(line: LineString) -> float:
        coordinates = np.asarray(line.coords, dtype=float)
        delta = coordinates[-1] - coordinates[0]
        return math.atan2(float(delta[1]), float(delta[0])) % math.pi

    difference = abs(angle(first) - angle(second))
    return min(difference, math.pi - difference) * 180.0 / math.pi


def _sample_line(line: LineString, step_m: float) -> np.ndarray:
    if line.length <= 1e-12:
        return np.asarray(line.coords[:1], dtype=float)
    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    return np.asarray([line.interpolate(value, normalized=True).coords[0]
                       for value in np.linspace(0.0, 1.0, count)], dtype=float)


def load_global_design(design_path: Path, alignment_path: Path) -> dict[str, Any]:
    """Apply only the frozen global similarity transform to the design CAD."""
    design = _read_json(design_path)
    alignment = _read_json(alignment_path)
    source_transform = np.asarray(design["transform_2d_mm_to_lidar_m"], dtype=float)
    linear = np.asarray(alignment["transform"]["linear_2x2"], dtype=float)
    translation = np.asarray(alignment["transform"]["translation_m"], dtype=float)

    def convert(points: Iterable[Iterable[float]]) -> np.ndarray:
        values = np.asarray(list(points), dtype=float)[:, :2]
        initial = values @ source_transform[:2, :2].T + source_transform[:2, 2]
        return initial @ linear.T + translation

    wall_polylines: list[dict[str, Any]] = []
    wall_segments: list[dict[str, Any]] = []
    for wall_index, wall in enumerate(design["walls"]):
        points = convert(wall["pts"])
        wall_id = f"DW-{wall_index:05d}"
        wall_polylines.append({"design_wall_id": wall_id, "layer": wall.get("layer", ""),
                               "closed": bool(wall.get("closed", False)),
                               "coordinates": points.tolist()})
        for segment_index, (start, end) in enumerate(zip(points[:-1], points[1:])):
            line = LineString([start, end])
            if line.length <= 1e-6:
                continue
            wall_segments.append({"design_wall_id": wall_id,
                                  "design_segment_id": f"{wall_id}-S{segment_index:04d}",
                                  "layer": wall.get("layer", ""), "line": line})

    openings = []
    for opening_index, opening in enumerate(design.get("openings", [])):
        points = convert(opening["pts"])
        if len(points) >= 2:
            openings.append({"design_opening_id": f"DO-{opening_index:05d}",
                             "line": LineString(points)})
    columns = []
    for column_index, column in enumerate(design.get("columns", [])):
        center = convert([column["centre_mm"]])[0]
        columns.append({"design_column_id": f"DC-{column_index:05d}",
                        "coordinates": center.tolist(), "layer": column.get("layer", "")})
    return {"wall_polylines": wall_polylines, "wall_segments": wall_segments,
            "openings": openings, "columns": columns,
            "registration": {"mode": "global_similarity_frozen",
                             "source_transform_2d_mm_to_lidar_m": source_transform.tolist(),
                             "linear_2x2": linear.tolist(), "translation_m": translation.tolist()}}


def apply_design_intervention(design: dict[str, Any], *, drop_fraction: float,
                              perturb_x_m: float, perturb_y_m: float,
                              seed: int) -> dict[str, Any]:
    """Apply deterministic development-only stale-prior diagnostics."""
    if not 0.0 <= drop_fraction < 1.0:
        raise ValueError("design drop fraction must be in [0, 1)")
    wall_ids = sorted({value["design_wall_id"] for value in design["wall_segments"]})
    dropped: set[str] = set()
    for wall_id in wall_ids:
        digest = hashlib.sha256(f"{seed}:{wall_id}".encode()).digest()
        uniform = int.from_bytes(digest[:8], "big") / float(2**64)
        if uniform < drop_fraction:
            dropped.add(wall_id)

    result = dict(design)
    result["wall_polylines"] = [dict(value) for value in design["wall_polylines"]
                                if value["design_wall_id"] not in dropped]
    result["wall_segments"] = [dict(value) for value in design["wall_segments"]
                               if value["design_wall_id"] not in dropped]
    result["openings"] = [dict(value) for value in design["openings"]]
    result["columns"] = [dict(value) for value in design["columns"]]
    if perturb_x_m or perturb_y_m:
        for value in result["wall_segments"]:
            value["line"] = affinity.translate(value["line"], xoff=perturb_x_m, yoff=perturb_y_m)
        for value in result["wall_polylines"]:
            coordinates = np.asarray(value["coordinates"], dtype=float)
            coordinates += np.asarray([perturb_x_m, perturb_y_m])
            value["coordinates"] = coordinates.tolist()
        for value in result["openings"]:
            value["line"] = affinity.translate(value["line"], xoff=perturb_x_m, yoff=perturb_y_m)
        for value in result["columns"]:
            coordinates = np.asarray(value["coordinates"], dtype=float)
            value["coordinates"] = (coordinates + np.asarray([perturb_x_m, perturb_y_m])).tolist()
    result["registration"] = dict(design["registration"])
    result["registration"]["development_robustness_intervention"] = {
        "drop_fraction_requested": drop_fraction,
        "dropped_wall_count": len(dropped),
        "input_wall_count": len(wall_ids),
        "perturbation_m": [perturb_x_m, perturb_y_m],
        "seed": seed,
        "not_for_main_evaluation": bool(drop_fraction or perturb_x_m or perturb_y_m),
    }
    return result


def match_walls_to_design(
    walls: list[dict[str, Any]],
    design_segments: list[dict[str, Any]],
    *,
    maximum_distance_m: float,
    maximum_direction_difference_deg: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Attach a design identity without replacing the R309 physical wall ID."""
    geometries = [value["line"] for value in design_segments]
    tree = STRtree(geometries)
    enriched: list[dict[str, Any]] = []
    matches: list[dict[str, Any]] = []
    for wall in walls:
        line = _line(wall)
        candidates = tree.query(line.buffer(maximum_distance_m))
        best: tuple[float, float, int] | None = None
        samples = [Point(value) for value in _sample_line(line, max(0.10, line.length / 4.0))]
        for raw_index in candidates:
            index = int(raw_index)
            design_line = geometries[index]
            direction = _angle_difference(line, design_line)
            if direction > maximum_direction_difference_deg:
                continue
            distances = [point.distance(design_line) for point in samples]
            score = float(np.mean(distances))
            maximum = float(np.max(distances))
            if maximum > maximum_distance_m:
                continue
            key = (score, direction, index)
            if best is None or key < best:
                best = key
        record = dict(wall)
        if best is None:
            record["design_correspondence"] = {
                "matched": False, "design_support": "none",
                "reason": "no_parallel_design_segment_within_threshold",
            }
        else:
            mean_distance, direction, index = best
            design = design_segments[index]
            support = "strict" if mean_distance <= 0.30 else "proximity"
            record["design_correspondence"] = {
                "matched": True, "design_support": support,
                "design_wall_id": design["design_wall_id"],
                "design_segment_id": design["design_segment_id"],
                "mean_distance_m": mean_distance,
                "direction_difference_deg": direction,
            }
            matches.append({"wall_id": wall.get("wall_id"),
                            **record["design_correspondence"],
                            "wall_length_m": float(line.length)})
        enriched.append(record)
    return enriched, matches


def _inner_endpoint(record: dict[str, Any], design_line: LineString, high: bool) -> tuple[np.ndarray, float]:
    coordinates = np.asarray(record["coordinates"], dtype=float)
    projected = np.asarray([design_line.project(Point(value)) for value in (coordinates[0], coordinates[-1])])
    index = int(np.argmax(projected) if high else np.argmin(projected))
    return coordinates[[0, -1][index]], float(projected[index])


def generate_identity_candidates(
    walls: list[dict[str, Any]],
    design_segments: list[dict[str, Any]],
    *,
    minimum_gap_m: float,
    maximum_gap_m: float,
    maximum_direction_difference_deg: float,
) -> list[dict[str, Any]]:
    """Join adjacent R309 intervals assigned to exactly one design segment."""
    design_by_id = {value["design_segment_id"]: value for value in design_segments}
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for wall in walls:
        match = wall.get("design_correspondence", {})
        if match.get("matched"):
            groups[str(match["design_segment_id"])].append(wall)

    result: list[dict[str, Any]] = []
    for segment_id, records in groups.items():
        design = design_by_id[segment_id]
        design_line = design["line"]
        intervals = []
        for record in records:
            low_point, low = _inner_endpoint(record, design_line, False)
            high_point, high = _inner_endpoint(record, design_line, True)
            intervals.append({"low": low, "high": high, "low_point": low_point,
                              "high_point": high_point, "low_wall": record, "high_wall": record})
        intervals.sort(key=lambda value: (value["low"], value["high"]))
        if not intervals:
            continue
        merged = [intervals[0]]
        for value in intervals[1:]:
            current = merged[-1]
            if value["low"] <= current["high"] + minimum_gap_m:
                if value["high"] > current["high"]:
                    current["high"] = value["high"]
                    current["high_point"] = value["high_point"]
                    current["high_wall"] = value["high_wall"]
            else:
                merged.append(value)
        for first, second in zip(merged[:-1], merged[1:]):
            start = np.asarray(first["high_point"], dtype=float)
            end = np.asarray(second["low_point"], dtype=float)
            line = LineString([start, end])
            if not minimum_gap_m <= line.length <= maximum_gap_m:
                continue
            if _angle_difference(line, design_line) > maximum_direction_difference_deg:
                continue
            left = first["high_wall"]
            right = second["low_wall"]
            candidate_id = "DCON-" + hashlib.sha1(
                f"{segment_id}:{left.get('wall_id')}:{right.get('wall_id')}".encode()
            ).hexdigest()[:14]
            result.append({
                "connection_id": candidate_id, "wall_id": candidate_id,
                "physical_wall_id": candidate_id, "coordinates": list(map(list, line.coords)),
                "source": "design_identity_candidate", "status": "unknown",
                "design_support": "matched_same_design_segment",
                "design_wall_id": design["design_wall_id"],
                "design_segment_id": segment_id,
                "host_wall_ids": [left.get("wall_id"), right.get("wall_id")],
                "host_physical_wall_ids": [left.get("physical_wall_id"), right.get("physical_wall_id")],
                "host_observed_support_fraction": [float(left.get("observed_support_fraction", 0.0)),
                                                     float(right.get("observed_support_fraction", 0.0))],
                "length_m": float(line.length),
            })
    return result


def generate_proximity_candidates(
    walls: list[dict[str, Any]],
    *,
    minimum_gap_m: float,
    maximum_gap_m: float,
    maximum_direction_difference_deg: float,
) -> list[dict[str, Any]]:
    """Ablation pool: endpoint proximity without a shared design identity."""
    endpoints: list[dict[str, Any]] = []
    for wall in walls:
        if not wall.get("design_correspondence", {}).get("matched"):
            continue
        line = _line(wall)
        coordinates = np.asarray(line.coords, dtype=float)
        for endpoint_index, point in enumerate((coordinates[0], coordinates[-1])):
            endpoints.append({"point": point, "endpoint_index": endpoint_index,
                              "wall": wall, "line": line})
    if not endpoints:
        return []
    coordinates = np.asarray([value["point"] for value in endpoints])
    tree = cKDTree(coordinates)
    pairs = tree.query_pairs(maximum_gap_m, output_type="ndarray")
    result: list[dict[str, Any]] = []
    used: set[tuple[str, int]] = set()
    scored = []
    for first_index, second_index in pairs:
        first, second = endpoints[int(first_index)], endpoints[int(second_index)]
        first_id, second_id = first["wall"].get("wall_id"), second["wall"].get("wall_id")
        if first_id == second_id:
            continue
        connector = LineString([first["point"], second["point"]])
        if connector.length < minimum_gap_m:
            continue
        direction = min(_angle_difference(connector, first["line"]),
                        _angle_difference(connector, second["line"]))
        if direction > maximum_direction_difference_deg:
            continue
        scored.append((float(connector.length), direction, int(first_index), int(second_index)))
    for length, direction, first_index, second_index in sorted(scored):
        first, second = endpoints[first_index], endpoints[second_index]
        keys = [(str(first["wall"].get("wall_id")), int(first["endpoint_index"])),
                (str(second["wall"].get("wall_id")), int(second["endpoint_index"]))]
        if any(key in used for key in keys):
            continue
        used.update(keys)
        candidate_id = "PCON-" + hashlib.sha1(repr(keys).encode()).hexdigest()[:14]
        result.append({
            "connection_id": candidate_id, "wall_id": candidate_id,
            "physical_wall_id": candidate_id,
            "coordinates": [first["point"].tolist(), second["point"].tolist()],
            "source": "design_proximity_candidate_without_identity", "status": "unknown",
            "design_support": "near_design_without_shared_identity",
            "design_wall_id": None, "design_segment_id": None,
            "host_wall_ids": [value["wall"].get("wall_id") for value in (first, second)],
            "host_physical_wall_ids": [value["wall"].get("physical_wall_id") for value in (first, second)],
            "host_observed_support_fraction": [float(value["wall"].get("observed_support_fraction", 0.0))
                                                 for value in (first, second)],
            "length_m": length, "direction_difference_deg": direction,
        })
    return result


class EvidenceSampler:
    def __init__(self, evidence_path: Path, semantic_path: Path) -> None:
        with np.load(evidence_path) as values:
            self.origin = np.asarray(values["origin_xy"], dtype=float)
            self.grid_m = float(values["grid_m"])
            self.shape = tuple(int(value) for value in values["shape"])
            self.xy_cell = np.asarray(values["xy_cell"], dtype=np.int64)
        with np.load(semantic_path) as values:
            self.wall_probability = np.asarray(values["wall_probability"], dtype=np.float32)
            self.vehicle_probability = np.asarray(values["vehicle_probability"], dtype=np.float32)
            self.agreement_probability = np.asarray(values.get("agreement_probability",
                                                                np.ones(self.shape)), dtype=np.float32)
            self.voxel_probability = np.asarray(values.get("voxel_probability", np.empty((0, 3))),
                                                dtype=np.float32)
        if self.wall_probability.shape != self.shape or self.vehicle_probability.shape != self.shape:
            raise ValueError("semantic raster and exact evidence grid do not match")

    def sample(self, line: LineString, step_m: float = 0.05) -> dict[str, Any]:
        points = _sample_line(line, step_m)
        pixels = np.floor((points - self.origin) / self.grid_m).astype(np.int64)
        valid = ((pixels[:, 0] >= 0) & (pixels[:, 0] < self.shape[1])
                 & (pixels[:, 1] >= 0) & (pixels[:, 1] < self.shape[0]))
        if not np.any(valid):
            return {"sample_count": int(len(points)), "valid_sample_count": 0,
                    "direct_wall_support_fraction": 0.0, "weak_wall_support_fraction": 0.0,
                    "vehicle_occlusion_fraction": 0.0, "semantic_agreement_fraction": 0.0,
                    "source_voxel_rows": []}
        pixels = pixels[valid]
        rows, columns = pixels[:, 1], pixels[:, 0]
        wall = self.wall_probability[rows, columns]
        vehicle = self.vehicle_probability[rows, columns]
        agreement = self.agreement_probability[rows, columns]
        cells = np.unique(rows * self.shape[1] + columns)
        source_rows: list[int] = []
        if len(self.voxel_probability):
            starts = np.searchsorted(self.xy_cell, cells, side="left")
            ends = np.searchsorted(self.xy_cell, cells, side="right")
            for start, end in zip(starts, ends):
                if end <= start:
                    continue
                local = np.arange(start, end, dtype=np.int64)
                probability = self.voxel_probability[local]
                keep = ((probability[:, 0] >= 0.50)
                        & (probability[:, 0] >= probability[:, 1])
                        & (probability[:, 0] >= probability[:, 2]))
                source_rows.extend(int(value) for value in local[keep])
        return {
            "sample_count": int(len(points)), "valid_sample_count": int(np.count_nonzero(valid)),
            "direct_wall_support_fraction": float(np.mean((wall >= 0.80) & (wall >= vehicle))),
            "weak_wall_support_fraction": float(np.mean((wall >= 0.50) & (wall >= vehicle))),
            "vehicle_occlusion_fraction": float(np.mean(vehicle >= 0.50)),
            "semantic_agreement_fraction": float(np.mean(agreement >= 2.0 / 3.0)),
            "source_voxel_rows": sorted(set(source_rows)),
        }


def classify_candidates(
    candidates: list[dict[str, Any]],
    sampler: EvidenceSampler,
    openings: list[dict[str, Any]],
    *,
    apply_evidence_gate: bool,
    direct_support_minimum: float,
    weak_support_minimum: float,
    vehicle_fraction_minimum: float,
    context_support_minimum: float,
    context_only_maximum_gap_m: float,
    opening_buffer_m: float,
) -> list[dict[str, Any]]:
    opening_lines = [value["line"] for value in openings]
    opening_tree = STRtree(opening_lines) if opening_lines else None
    result: list[dict[str, Any]] = []
    for candidate in candidates:
        record = dict(candidate)
        line = _line(record)
        audit = sampler.sample(line)
        context = min(record.get("host_observed_support_fraction", [0.0, 0.0]))
        opening_ids: list[str] = []
        if opening_tree is not None:
            for raw_index in opening_tree.query(line.buffer(opening_buffer_m)):
                index = int(raw_index)
                if line.distance(opening_lines[index]) <= opening_buffer_m:
                    opening_ids.append(openings[index]["design_opening_id"])
        record["field_evidence"] = {**audit, "endpoint_context_support": float(context),
                                    "near_design_opening_ids": opening_ids}
        if opening_ids:
            state, strength, decision = "unknown", "absent", "rejected_design_opening_conflict"
        elif not apply_evidence_gate:
            state, strength, decision = "inferred", "absent", "accepted_without_new_evidence_gate"
        elif audit["direct_wall_support_fraction"] >= direct_support_minimum:
            state, strength, decision = "observed", "strong", "accepted_direct_wall_evidence"
        elif (audit["weak_wall_support_fraction"] >= weak_support_minimum
              and context >= context_support_minimum):
            state, strength, decision = "inferred", "weak", "accepted_weak_wall_and_endpoint_context"
        elif (audit["vehicle_occlusion_fraction"] >= vehicle_fraction_minimum
              and context >= context_support_minimum):
            state, strength, decision = "inferred", "absent", "accepted_vehicle_occlusion_and_endpoint_context"
        elif (line.length <= context_only_maximum_gap_m
              and context >= max(0.80, context_support_minimum)):
            state, strength, decision = "inferred", "absent", "accepted_short_gap_endpoint_context"
        else:
            state, strength, decision = "unknown", "absent", "design_only_reference"
        record.update({"status": state, "evidence_strength": strength,
                       "decision": decision, "selected": decision.startswith("accepted"),
                       "reference_only": decision == "design_only_reference",
                       "source_voxel_rows": audit["source_voxel_rows"]})
        result.append(record)
    return result


def _measured_candidates(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [record for record in records if record.get("selected") and not record.get("reference_only")]


def _reference_candidates(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [record for record in records if record.get("reference_only")]


def topology_proxy(records: list[dict[str, Any]], snap_m: float = 0.05) -> dict[str, Any]:
    """Deterministic endpoint graph diagnostic; not an accuracy metric."""
    if not records:
        return {"line_count": 0, "line_length_m": 0.0, "component_count": 0,
                "dangling_endpoint_count": 0, "snap_m": snap_m}
    endpoints = []
    for record in records:
        coordinates = np.asarray(record["coordinates"], dtype=float)
        endpoints.extend([coordinates[0], coordinates[-1]])
    points = np.asarray(endpoints)
    spatial_parent = np.arange(len(points), dtype=np.int64)

    def spatial_find(index: int) -> int:
        while spatial_parent[index] != index:
            spatial_parent[index] = spatial_parent[spatial_parent[index]]
            index = int(spatial_parent[index])
        return index

    def spatial_union(first: int, second: int) -> None:
        left, right = spatial_find(first), spatial_find(second)
        if left != right:
            spatial_parent[right] = left

    for first, second in cKDTree(points).query_pairs(snap_m):
        spatial_union(int(first), int(second))
    spatial_roots = [spatial_find(index) for index in range(len(points))]
    root_to_node = {root: index for index, root in enumerate(sorted(set(spatial_roots)))}
    endpoint_nodes = [root_to_node[root] for root in spatial_roots]
    graph_parent = np.arange(len(root_to_node), dtype=np.int64)

    def graph_find(index: int) -> int:
        while graph_parent[index] != index:
            graph_parent[index] = graph_parent[graph_parent[index]]
            index = int(graph_parent[index])
        return index

    def graph_union(first: int, second: int) -> None:
        left, right = graph_find(first), graph_find(second)
        if left != right:
            graph_parent[right] = left

    degree = Counter()
    for line_index in range(len(records)):
        first, second = endpoint_nodes[2 * line_index], endpoint_nodes[2 * line_index + 1]
        degree[first] += 1
        degree[second] += 1
        graph_union(first, second)
    components = {graph_find(index) for index in range(len(root_to_node))}
    return {"line_count": len(records),
            "line_length_m": float(sum(_line(record).length for record in records)),
            "component_count": len(components),
            "dangling_endpoint_count": int(sum(value == 1 for value in degree.values())),
            "snap_m": snap_m}


def _sampled_point_distances(source: list[LineString], target: list[LineString],
                             step_m: float = 0.10) -> tuple[np.ndarray, float]:
    if not source or not target:
        return np.empty(0, dtype=float), 0.0
    source_points = np.vstack([_sample_line(line, step_m) for line in source])
    # Densifying the target at half the source step bounds the point-sampling
    # approximation while making all five tolerance checks one vector query.
    target_points = np.vstack([_sample_line(line, step_m / 2.0) for line in target])
    distances = cKDTree(target_points).query(source_points, workers=-1)[0]
    return np.asarray(distances, dtype=float), float(len(source_points) * step_m)


def design_conformance(records: list[dict[str, Any]], design_segments: list[dict[str, Any]]) -> dict[str, Any]:
    output_lines = [_line(record) for record in records]
    design_lines = [record["line"] for record in design_segments]
    values: dict[str, Any] = {"interpretation": "design conformance, not field-truth accuracy"}
    output_distances, output_sampled = _sampled_point_distances(output_lines, design_lines)
    design_distances, design_sampled = _sampled_point_distances(design_lines, output_lines)
    for tolerance in (0.05, 0.10, 0.15, 0.30, 0.50):
        key = str(tolerance).replace(".", "p")
        values[f"output_length_fraction_within_{key}m_of_design"] = (
            float(np.mean(output_distances <= tolerance)) if len(output_distances) else 0.0)
        values[f"design_length_fraction_within_{key}m_of_output"] = (
            float(np.mean(design_distances <= tolerance)) if len(design_distances) else 0.0)
        values["output_sampled_length_m"] = output_sampled
        values["design_sampled_length_m"] = design_sampled
    return values


def write_variant_geojson(path: Path, base: list[dict[str, Any]], additions: list[dict[str, Any]],
                          references: list[dict[str, Any]], metadata: dict[str, Any]) -> None:
    def properties(record: dict[str, Any]) -> dict[str, Any]:
        # Source-row arrays and interval-level audit belong in the immutable R309
        # object graph / candidate_audit. Repeating them in every comparison
        # variant makes an otherwise small interchange file approach 1 GB.
        keys = (
            "wall_id", "connection_id", "physical_wall_id", "status", "source",
            "observed_support_fraction", "matched_support_fraction",
            "design_correspondence", "design_support", "design_wall_id",
            "design_segment_id", "host_wall_ids", "host_physical_wall_ids",
            "host_observed_support_fraction", "length_m", "evidence_strength",
            "decision", "selected", "reference_only", "field_evidence",
        )
        value = {key: record[key] for key in keys if key in record}
        field = value.get("field_evidence")
        if isinstance(field, dict):
            value["field_evidence"] = {key: item for key, item in field.items()
                                       if key != "source_voxel_rows"}
        value["audit_reference"] = ("candidate_audit.json" if record.get("connection_id")
                                    else "source R309 building_object_graph.json")
        return value

    features = []
    for record in base:
        feature_properties = properties(record)
        feature_properties["class"] = "WALL" if record.get("status") == "observed" else "INFERRED_WALL"
        features.append({"type": "Feature", "geometry": mapping(_line(record)),
                         "properties": feature_properties})
    for record in additions:
        feature_properties = properties(record)
        feature_properties["class"] = "DESIGN_ASSISTED_WALL"
        features.append({"type": "Feature", "geometry": mapping(_line(record)),
                         "properties": feature_properties})
    for record in references:
        feature_properties = properties(record)
        feature_properties["class"] = "DESIGN_REFERENCE_ONLY"
        features.append({"type": "Feature", "geometry": mapping(_line(record)),
                         "properties": feature_properties})
    _write_json(path, {"type": "FeatureCollection", "schema_version": SCHEMA_VERSION,
                       "local_coordinate_system": {"units": "metre", "frame": "R309_CAD"},
                       "metadata": metadata, "features": features})


def write_variant_dxf(path: Path, base: list[dict[str, Any]], additions: list[dict[str, Any]],
                      references: list[dict[str, Any]], design_segments: list[dict[str, Any]] | None = None) -> None:
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6
    for name, color, off in (("WALL_OBSERVED", 7, False), ("WALL_INFERRED", 30, False),
                             ("DESIGN_ASSISTED_OBSERVED", 3, False),
                             ("DESIGN_ASSISTED_INFERRED", 5, False),
                             ("DESIGN_REFERENCE_ONLY", 8, True)):
        layer = document.layers.add(name, color=color)
        if off:
            layer.off()
    model = document.modelspace()
    for record in base:
        layer = "WALL_OBSERVED" if record.get("status") == "observed" else "WALL_INFERRED"
        model.add_lwpolyline(record["coordinates"], dxfattribs={"layer": layer})
    for record in additions:
        layer = "DESIGN_ASSISTED_OBSERVED" if record.get("status") == "observed" else "DESIGN_ASSISTED_INFERRED"
        model.add_lwpolyline(record["coordinates"], dxfattribs={"layer": layer})
    for record in references:
        model.add_lwpolyline(record["coordinates"], dxfattribs={"layer": "DESIGN_REFERENCE_ONLY"})
    if design_segments:
        for record in design_segments:
            model.add_lwpolyline(list(record["line"].coords), dxfattribs={"layer": "DESIGN_REFERENCE_ONLY"})
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def render_comparison(path: Path, base: list[dict[str, Any]], design_segments: list[dict[str, Any]],
                      proximity: list[dict[str, Any]], full: list[dict[str, Any]]) -> None:
    base_lines = [_line(record) for record in base]
    design_lines = [record["line"] for record in design_segments]
    panels = [("R309 semantic", []), ("Semantic + design proximity", proximity),
              ("Full design identity + evidence", full)]
    figure, axes = plt.subplots(1, 3, figsize=(18, 6), constrained_layout=True)
    for axis, (title, additions) in zip(axes, panels):
        for line in design_lines:
            xy = np.asarray(line.coords)
            axis.plot(xy[:, 0], xy[:, 1], color="#b8b8b8", linewidth=0.25, alpha=0.45)
        for line in base_lines:
            xy = np.asarray(line.coords)
            axis.plot(xy[:, 0], xy[:, 1], color="#235789", linewidth=0.45, alpha=0.8)
        for record in additions:
            xy = np.asarray(record["coordinates"])
            color = "#d62828" if record.get("status") == "observed" else "#f77f00"
            axis.plot(xy[:, 0], xy[:, 1], color=color, linewidth=1.0, alpha=0.95)
        axis.set_title(title)
        axis.set_aspect("equal", adjustable="box")
        axis.axis("off")
    figure.savefig(path, dpi=220)
    plt.close(figure)


def _load_geojson_lines(path: Path) -> list[dict[str, Any]]:
    document = _read_json(path)
    result = []
    for index, feature in enumerate(document.get("features", [])):
        if feature.get("geometry", {}).get("type") not in {"LineString", "MultiLineString"}:
            continue
        properties = dict(feature.get("properties", {}))
        coordinates = feature["geometry"]["coordinates"]
        if feature["geometry"]["type"] == "LineString":
            result.append({**properties, "wall_id": properties.get("wall_id", f"GEO-{index:06d}"),
                           "coordinates": coordinates})
        else:
            for part_index, part in enumerate(coordinates):
                result.append({**properties, "wall_id": properties.get("wall_id", f"GEO-{index:06d}-{part_index}"),
                               "coordinates": part})
    return result


def run(args: argparse.Namespace) -> dict[str, Any]:
    started = perf_counter()
    paths = {name: Path(getattr(args, name)).resolve() for name in
             ("object_graph", "geometry_geojson", "semantic_geojson", "evidence",
              "semantic_cache", "design_architecture", "alignment")}
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    for name, path in paths.items():
        if not path.exists():
            raise FileNotFoundError(f"{name}: {path}")

    graph = _read_json(paths["object_graph"])
    if graph.get("algorithm") != "LiDAR2CAD-R309":
        raise ValueError("object graph is not a LiDAR2CAD-R309 graph")
    declared = graph.get("evidence_reference", {}).get("cache_sha256")
    actual = _sha256(paths["evidence"])
    if declared and declared != actual:
        raise ValueError("R309 object graph and evidence cache fingerprints differ")

    timings: dict[str, float] = {}
    phase = perf_counter()
    design = load_global_design(paths["design_architecture"], paths["alignment"])
    design = apply_design_intervention(
        design,
        drop_fraction=args.design_drop_fraction,
        perturb_x_m=args.design_perturb_x_m,
        perturb_y_m=args.design_perturb_y_m,
        seed=args.design_intervention_seed,
    )
    timings["design_parse_and_global_transform"] = perf_counter() - phase

    phase = perf_counter()
    walls, matches = match_walls_to_design(
        list(graph["walls"]), design["wall_segments"],
        maximum_distance_m=args.match_distance_m,
        maximum_direction_difference_deg=args.direction_tolerance_deg,
    )
    timings["design_identity_association"] = perf_counter() - phase

    phase = perf_counter()
    identity_candidates = generate_identity_candidates(
        walls, design["wall_segments"], minimum_gap_m=args.gap_min_m,
        maximum_gap_m=args.gap_max_m,
        maximum_direction_difference_deg=args.direction_tolerance_deg,
    )
    proximity_candidates = generate_proximity_candidates(
        walls, minimum_gap_m=args.gap_min_m, maximum_gap_m=args.gap_max_m,
        maximum_direction_difference_deg=args.direction_tolerance_deg,
    )
    timings["candidate_regeneration"] = perf_counter() - phase

    phase = perf_counter()
    sampler = EvidenceSampler(paths["evidence"], paths["semantic_cache"])
    full_audit = classify_candidates(
        identity_candidates, sampler, design["openings"], apply_evidence_gate=True,
        direct_support_minimum=args.direct_support_min,
        weak_support_minimum=args.weak_support_min,
        vehicle_fraction_minimum=args.vehicle_fraction_min,
        context_support_minimum=args.context_support_min,
        context_only_maximum_gap_m=args.context_only_max_gap_m,
        opening_buffer_m=args.opening_buffer_m,
    )
    proximity_audit = classify_candidates(
        proximity_candidates, sampler, design["openings"], apply_evidence_gate=True,
        direct_support_minimum=args.direct_support_min,
        weak_support_minimum=args.weak_support_min,
        vehicle_fraction_minimum=args.vehicle_fraction_min,
        context_support_minimum=args.context_support_min,
        context_only_maximum_gap_m=args.context_only_max_gap_m,
        opening_buffer_m=args.opening_buffer_m,
    )
    no_evidence_audit = classify_candidates(
        identity_candidates, sampler, design["openings"], apply_evidence_gate=False,
        direct_support_minimum=args.direct_support_min,
        weak_support_minimum=args.weak_support_min,
        vehicle_fraction_minimum=args.vehicle_fraction_min,
        context_support_minimum=args.context_support_min,
        context_only_maximum_gap_m=args.context_only_max_gap_m,
        opening_buffer_m=args.opening_buffer_m,
    )
    timings["field_evidence_and_opening_gate"] = perf_counter() - phase

    measured_full = _measured_candidates(full_audit)
    reference_full = _reference_candidates(full_audit)
    measured_proximity = _measured_candidates(proximity_audit)
    measured_no_evidence = _measured_candidates(no_evidence_audit)
    baseline = walls

    metadata = {"schema_version": SCHEMA_VERSION, "registration": design["registration"],
                "evidence_cache_sha256": actual, "object_graph_sha256": _sha256(paths["object_graph"]),
                "reference_only_excluded_from_measured_length": True}
    phase = perf_counter()
    variants = output / "variants"
    variants.mkdir(exist_ok=True)
    write_variant_geojson(variants / "r309_semantic_design_annotated.geojson", baseline, [], [], metadata)
    write_variant_dxf(variants / "r309_semantic_design_annotated.dxf", baseline, [], [])
    write_variant_geojson(variants / "semantic_plus_design_proximity.geojson", baseline,
                          measured_proximity, [], metadata)
    write_variant_dxf(variants / "semantic_plus_design_proximity.dxf", baseline, measured_proximity, [])
    write_variant_geojson(variants / "full_design_assisted.geojson", baseline, measured_full,
                          reference_full, metadata)
    write_variant_dxf(variants / "full_design_assisted.dxf", baseline, measured_full, reference_full)
    write_variant_geojson(variants / "ablation_no_design_identity.geojson", baseline,
                          measured_proximity, [], metadata)
    write_variant_dxf(variants / "ablation_no_design_identity.dxf", baseline, measured_proximity, [])
    write_variant_geojson(variants / "ablation_no_new_evidence_gate.geojson", baseline,
                          measured_no_evidence, [], metadata)
    write_variant_dxf(variants / "ablation_no_new_evidence_gate.dxf", baseline, measured_no_evidence, [])
    design_references = [{"wall_id": value["design_segment_id"],
                          "coordinates": list(map(list, value["line"].coords)),
                          "status": "unknown", "source": "design_cad_direct_reference",
                          "reference_only": True, "design_support": "design_only"}
                         for value in design["wall_segments"]]
    write_variant_geojson(variants / "design_direct_reference.geojson", [], [], design_references, metadata)
    write_variant_dxf(variants / "design_direct_reference.dxf", [], [], design_references)
    _write_json(output / "design_correspondences.json", {"schema_version": SCHEMA_VERSION,
                                                           "matches": matches})
    _write_json(output / "candidate_audit.json", {"schema_version": SCHEMA_VERSION,
                                                    "full_identity_candidates": full_audit,
                                                    "no_identity_candidates": proximity_audit,
                                                    "no_evidence_gate_candidates": no_evidence_audit})
    timings["layered_export"] = perf_counter() - phase

    phase = perf_counter()
    geometry_records = _load_geojson_lines(paths["geometry_geojson"])
    semantic_records = _load_geojson_lines(paths["semantic_geojson"])
    evaluated = {
        "r309_geometry": geometry_records,
        "r309_semantic": semantic_records,
        "semantic_plus_design_proximity": baseline + measured_proximity,
        "full_design_assisted": baseline + measured_full,
        "ablation_no_design_identity": baseline + measured_proximity,
        "ablation_no_new_evidence_gate": baseline + measured_no_evidence,
    }
    metrics: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "accuracy_status": "pending_manual_region_truth",
        "warning": ("These are design-conformance and topology diagnostics. They are not "
                    "precision/recall against field truth."),
        "design_reference": {
            "wall_segment_count": len(design["wall_segments"]),
            "wall_length_m": float(sum(value["line"].length for value in design["wall_segments"])),
            "opening_count": len(design["openings"]), "column_count": len(design["columns"]),
        },
        "r309_design_match": {
            "wall_count": len(baseline), "matched_wall_count": len(matches),
            "matched_wall_fraction": float(len(matches) / len(baseline)) if baseline else 0.0,
            "matched_wall_length_m": float(sum(value["wall_length_m"] for value in matches)),
            "strict_0p30m_wall_length_m": float(sum(value["wall_length_m"] for value in matches
                                                     if value["mean_distance_m"] <= 0.30)),
        },
        "candidate_summary": {
            "identity_candidate_count": len(full_audit),
            "identity_candidate_length_m": float(sum(value["length_m"] for value in full_audit)),
            "full_selected_count": len(measured_full),
            "full_selected_length_m": float(sum(value["length_m"] for value in measured_full)),
            "full_reference_only_count": len(reference_full),
            "full_reference_only_length_m": float(sum(value["length_m"] for value in reference_full)),
            "full_decisions": dict(Counter(value["decision"] for value in full_audit)),
            "proximity_candidate_count": len(proximity_audit),
            "proximity_selected_count": len(measured_proximity),
            "no_evidence_gate_selected_count": len(measured_no_evidence),
        },
        "variants": {},
    }
    for name, records in evaluated.items():
        metrics["variants"][name] = {"topology_proxy": topology_proxy(records),
                                     "design_conformance": design_conformance(records,
                                                                               design["wall_segments"])}
    timings["diagnostic_metrics"] = perf_counter() - phase

    phase = perf_counter()
    render_comparison(output / "figure_design_assisted_comparison.png", baseline,
                      design["wall_segments"], measured_proximity, measured_full)
    timings["figure_export"] = perf_counter() - phase
    timings["total"] = perf_counter() - started
    metrics["runtime_seconds"] = timings
    _write_json(output / "metrics.json", metrics)

    source_map = {name: {"path": str(path), "sha256": _sha256(path)} for name, path in paths.items()}
    manifest = {"schema_version": SCHEMA_VERSION, "created_by": __name__,
                "source_map": source_map, "parameters": vars(args),
                "registration": design["registration"],
                "cache_policy": "R309 candidates regenerated; archived V6 fusion_cache.json not read",
                "outputs": {"metrics": str(output / "metrics.json"),
                            "candidate_audit": str(output / "candidate_audit.json"),
                            "correspondences": str(output / "design_correspondences.json"),
                            "comparison_figure": str(output / "figure_design_assisted_comparison.png")}}
    _write_json(output / "manifest.json", manifest)
    shutil.copy2(paths["alignment"], output / "frozen_global_alignment.json")
    return metrics


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--object-graph", required=True)
    parser.add_argument("--geometry-geojson", required=True)
    parser.add_argument("--semantic-geojson", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--semantic-cache", required=True)
    parser.add_argument("--design-architecture", required=True)
    parser.add_argument("--alignment", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--match-distance-m", type=float, default=0.50)
    parser.add_argument("--direction-tolerance-deg", type=float, default=12.0)
    parser.add_argument("--gap-min-m", type=float, default=0.15)
    parser.add_argument("--gap-max-m", type=float, default=3.00)
    parser.add_argument("--direct-support-min", type=float, default=0.60)
    parser.add_argument("--weak-support-min", type=float, default=0.45)
    parser.add_argument("--vehicle-fraction-min", type=float, default=0.30)
    parser.add_argument("--context-support-min", type=float, default=0.60)
    parser.add_argument("--context-only-max-gap-m", type=float, default=1.00)
    parser.add_argument("--opening-buffer-m", type=float, default=0.20)
    parser.add_argument("--design-drop-fraction", type=float, default=0.0,
                        help="Development-only deterministic deletion of design wall objects.")
    parser.add_argument("--design-perturb-x-m", type=float, default=0.0,
                        help="Development-only design X shift after the frozen transform.")
    parser.add_argument("--design-perturb-y-m", type=float, default=0.0,
                        help="Development-only design Y shift after the frozen transform.")
    parser.add_argument("--design-intervention-seed", type=int, default=309)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    metrics = run(args)
    print(json.dumps({"output": str(Path(args.output).resolve()),
                      "accuracy_status": metrics["accuracy_status"],
                      "candidate_summary": metrics["candidate_summary"],
                      "runtime_seconds": metrics["runtime_seconds"]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
