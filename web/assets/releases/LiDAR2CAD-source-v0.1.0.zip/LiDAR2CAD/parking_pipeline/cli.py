from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

from lidar2outline.scenario_cli import ScenarioProfile, run_profile


# The paper artifact keeps code and configs as siblings under ``TII``.
ROOT = Path(__file__).resolve().parents[2]


def profile_for(dataset: str) -> ScenarioProfile:
    stems = {
        "b01": "quzhou_b01",
        "b02": "quzhou_b02",
    }
    stem = stems[dataset]
    return ScenarioProfile(
        program="parking2cad",
        description=f"Underground-parking LiDAR to CAD pipeline ({dataset.upper()} profile)",
        scene_type="underground_parking",
        default_config=ROOT / "configs" / "parking" / f"{stem}_v13.yaml",
        default_output=ROOT / "outputs" / "parking" / stem / "v13" / "height_slices",
        default_reuse_from=ROOT / "outputs" / "parking" / stem / "v12" / "height_slices",
    )


def main(argv: Sequence[str] | None = None) -> int:
    raw = list(argv) if argv is not None else None
    selector = argparse.ArgumentParser(add_help=False)
    selector.add_argument("--dataset", choices=("b01", "b02"), default="b02")
    selected, remaining = selector.parse_known_args(raw)
    return run_profile(profile_for(selected.dataset), remaining)
