from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable

import cv2
import numpy as np
from scipy.spatial import cKDTree
from scipy.ndimage import distance_transform_edt
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import linemerge, polygonize, substring, unary_union
from shapely.strtree import STRtree

from lidar2outline.config import load_config
from lidar2outline.io import read_json, write_json

from .conservative_fusion import _column_records, _region_records, _wall_records
from .structure_v4 import (
    _virtual_opening_candidates,
    audit_written_outputs,
    optimise_closed_regions,
    update_shared_nodes,
    write_architectural_dxf,
    write_closed_layout_dxf,
    write_structure_geojson,
)
from .structure_v5 import _adapter, _independent_metrics, _render_v5_plan
from .v5_evidence import curve_observation_audit, load_exact_evidence
from .evidence_association import (ObjectEvidenceIndex, annotate_dual_evidence,
    enrich_connection_evidence, extract_height_fragments, associate_height_fragments,
    reconstruction_windows)


ALGORITHM = "parking_structure_v6_topology"


def _iter_lines(geometry: Any) -> Iterable[LineString]:
    if geometry.is_empty:
        return
    if geometry.geom_type == "LineString":
        yield geometry
        return
    for child in getattr(geometry, "geoms", []):
        yield from _iter_lines(child)


def _endpoint_tangent(line: LineString, endpoint: int) -> np.ndarray:
    coordinates = np.asarray(line.coords, dtype=float)
    if endpoint == 0:
        delta = coordinates[0] - coordinates[1]
    else:
        delta = coordinates[-1] - coordinates[-2]
    return delta / max(float(np.linalg.norm(delta)), 1e-12)


def _axis_intersection(
    first_point: np.ndarray,
    first_direction: np.ndarray,
    second_point: np.ndarray,
    second_direction: np.ndarray,
) -> tuple[np.ndarray, float, float] | None:
    matrix = np.column_stack([first_direction, -second_direction])
    if abs(float(np.linalg.det(matrix))) < 1e-6:
        return None
    distance = np.linalg.solve(matrix, second_point - first_point)
    point = first_point + float(distance[0]) * first_direction
    return point, float(distance[0]), float(distance[1])


def _angle_error(first: np.ndarray, second: np.ndarray) -> float:
    return float(math.acos(np.clip(abs(float(first @ second)), -1.0, 1.0)))


def _line_signature(line: LineString) -> tuple[tuple[float, float], ...]:
    values = [tuple(np.round(value, 4)) for value in line.coords]
    reverse = list(reversed(values))
    return tuple(min(values, reverse))


def _stable_identifier(prefix: str, values: Iterable[str]) -> str:
    payload = "|".join(sorted(set(str(value) for value in values)))
    digest = hashlib.sha1(payload.encode("utf-8")).hexdigest()[:14]
    return f"{prefix}-{digest}"


def _root_wall_id(record: dict[str, Any], by_id: dict[str, dict[str, Any]]) -> str:
    current = str(record.get("wall_id", "unknown"))
    seen: set[str] = set()
    while current not in seen:
        seen.add(current)
        parent = by_id.get(current, {}).get("parent_wall_id")
        if parent is None or str(parent) not in by_id:
            return str(parent) if parent is not None else current
        current = str(parent)
    return current


def _support_intervals_from_audit(line: LineString, audit: dict[str, Any]) -> list[dict[str, Any]]:
    """Compress 5 cm evidence states into arclength attributes, not wall objects."""

    positions = np.asarray(audit.get("sample_arclength_m", []), dtype=float)
    supported = np.asarray(audit.get("supported", []), dtype=bool)
    nearest = audit.get("nearest_distance_m", [])
    if len(positions) == 0:
        return []
    matched = np.asarray([value is not None for value in nearest], dtype=bool)
    states = np.where(supported, "observed", np.where(matched, "insufficient_vertical_support", "unknown"))
    boundaries = np.r_[0, np.flatnonzero(states[1:] != states[:-1]) + 1, len(states)]
    intervals: list[dict[str, Any]] = []
    for start, stop in zip(boundaries[:-1], boundaries[1:]):
        left = float(positions[start])
        right = float(positions[stop - 1])
        if stop < len(positions):
            right = 0.5 * (right + float(positions[stop]))
        if start > 0:
            left = 0.5 * (left + float(positions[start - 1]))
        intervals.append(
            {
                "s_start_m": max(0.0, left),
                "s_end_m": min(float(line.length), right),
                "state": str(states[start]),
                "sample_count": int(stop - start),
            }
        )
    return intervals


def annotate_wall_support_intervals(
    records: list[dict[str, Any]], exact: Any
) -> list[dict[str, Any]]:
    """Re-audit final node-adjusted geometry against the immutable 3-D evidence."""

    tree = cKDTree(exact.centroids[:, :2])
    output: list[dict[str, Any]] = []
    for source in records:
        record = dict(source)
        audit = curve_observation_audit(record["line"], exact, tree=tree)
        record["support_intervals"] = _support_intervals_from_audit(record["line"], audit)
        record["observed_support_fraction"] = float(audit["supported_fraction"])
        record["matched_support_fraction"] = float(audit["matched_fraction"])
        output.append(record)
    return output


def normalise_wall_objects(
    walls: list[dict[str, Any]], cfg: dict[str, Any]
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Node and merge physical wall evidence while dropping legacy gap soup."""

    minimum = float(cfg.get("topology_min_wall_length_m", 0.15))
    accepted = [
        value
        for value in walls
        if value.get("status") == "observed"
        or value.get("status") == "inferred_semantic_object"
    ]
    observed_lines = [
        value["line"] for value in accepted if value.get("status") == "observed"
    ]
    observed_union = unary_union(observed_lines) if observed_lines else LineString()
    raw_lines = [value["line"] for value in accepted]
    if not raw_lines:
        return [], {
            "input_physical_wall_count": 0,
            "legacy_connector_count_removed": len(walls),
            "normalised_wall_count": 0,
        }
    noded = unary_union(raw_lines)
    merged = linemerge(noded) if noded.geom_type != "LineString" else noded
    unique: dict[tuple[tuple[float, float], ...], LineString] = {}
    for line in _iter_lines(merged):
        if line.length >= minimum:
            unique.setdefault(_line_signature(line), line)
    by_id = {str(value.get("wall_id")): value for value in accepted}
    source_tree = STRtree(raw_lines)
    source_geometry_index = {id(value): index for index, value in enumerate(raw_lines)}
    records: list[dict[str, Any]] = []
    for line in sorted(unique.values(), key=lambda value: -value.length):
        queried = source_tree.query(line.buffer(0.015, cap_style=2))
        if len(queried) and np.issubdtype(np.asarray(queried).dtype, np.integer):
            candidate_indices = [int(value) for value in queried]
        else:
            candidate_indices = [source_geometry_index[id(value)] for value in queried]
        source_indices = [
            index
            for index in candidate_indices
            if line.intersection(raw_lines[index].buffer(0.012, cap_style=2)).length > 1e-4
        ]
        source_ids = [str(accepted[index].get("wall_id")) for index in source_indices]
        root_ids = [_root_wall_id(accepted[index], by_id) for index in source_indices]
        physical_wall_id = _stable_identifier("PW", root_ids or [repr(_line_signature(line))])
        segment_id = _stable_identifier(
            "WS", [physical_wall_id, repr(_line_signature(line))]
        )
        observed_overlap = (
            line.intersection(observed_union.buffer(0.012, cap_style=2)).length
            / max(line.length, 1e-9)
            if not observed_union.is_empty
            else 0.0
        )
        is_observed = observed_overlap >= 0.95
        records.append(
            {
                "wall_id": segment_id,
                "physical_wall_id": physical_wall_id,
                "source_wall_ids": sorted(set(source_ids)),
                "source_root_wall_ids": sorted(set(root_ids)),
                "line": line,
                "geometry_kind": "line" if len(line.coords) == 2 else "polyline",
                "status": "observed" if is_observed else "inferred_semantic_object",
                "source": (
                    "v6_noded_strict_observation"
                    if is_observed
                    else "v6_noded_human_wall_object"
                ),
                "strict_observed_overlap_fraction": float(observed_overlap),
                **({"association_object_ids": sorted({oid for index in source_indices
                    for oid in accepted[index].get("association_object_ids", [])}),
                    "provenance": {"kind": "noded_associated_surface", "parent_object_ids": source_ids}}
                   if any("association_object_ids" in accepted[index] for index in source_indices) else {}),
            }
        )
    old_connectors = [
        value
        for value in walls
        if value.get("status") not in {"observed", "inferred_semantic_object"}
    ]
    return records, {
        "input_physical_wall_count": len(accepted),
        "input_physical_wall_length_m": float(sum(value["line"].length for value in accepted)),
        "legacy_connector_count_removed": len(old_connectors),
        "legacy_connector_length_removed_m": float(
            sum(value["line"].length for value in old_connectors)
        ),
        "normalised_wall_count": len(records),
        "normalised_physical_wall_count": len(
            {value["physical_wall_id"] for value in records}
        ),
        "normalised_wall_length_m": float(sum(value["line"].length for value in records)),
    }


def _candidate_audit(line: LineString, exact: Any, tree: cKDTree) -> dict[str, Any]:
    strict = curve_observation_audit(line, exact, tree=tree)
    relaxed = curve_observation_audit(
        line,
        exact,
        tree=tree,
        min_height_bins=2,
        min_vertical_span_m=0.10,
    )
    def interior_fraction(audit: dict[str, Any]) -> float:
        supported = np.asarray(audit["supported"], dtype=bool)
        # Connector endpoints lie on already accepted wall objects.  Exclude
        # only those two samples so half-cell ownership at the join does not
        # turn a fully observed gap into an inferred one; every interior 5 cm
        # interval must still support itself.
        interior = supported[1:-1] if len(supported) > 2 else supported
        return float(np.mean(interior)) if len(interior) else 0.0

    def longest_unsupported_run_m(audit: dict[str, Any]) -> float:
        supported = np.asarray(audit["supported"], dtype=bool)
        positions = np.asarray(audit.get("sample_arclength_m", []), dtype=float)
        if not len(supported) or len(positions) != len(supported):
            return float(line.length)
        longest = 0.0
        start: int | None = None
        for index, value in enumerate(supported):
            if not value and start is None:
                start = index
            if value and start is not None:
                longest = max(longest, float(positions[index - 1] - positions[start]))
                start = None
        if start is not None:
            longest = max(longest, float(positions[-1] - positions[start]))
        step = float(np.median(np.diff(positions))) if len(positions) > 1 else float(line.length)
        return min(float(line.length), longest + max(0.0, step))

    return {
        "strict_support_fraction": interior_fraction(strict),
        "strict_full_support_fraction": float(strict["supported_fraction"]),
        "strict_p95_m": strict["p95_m"],
        "relaxed_support_fraction": interior_fraction(relaxed),
        "relaxed_p95_m": relaxed["p95_m"],
        "longest_relaxed_unsupported_run_m": longest_unsupported_run_m(relaxed),
        "strict_supported": strict["supported"],
    }


def _local_relaxed_support(
    line: LineString,
    position_m: float,
    exact: Any,
    tree: cKDTree,
    half_window_m: float = 0.25,
) -> float:
    """Audit the already accepted wall immediately around an attachment."""

    start = max(0.0, float(position_m) - half_window_m)
    stop = min(float(line.length), float(position_m) + half_window_m)
    if stop - start < 0.05:
        return 0.0
    local = substring(line, start, stop)
    if not isinstance(local, LineString) or local.length < 0.05:
        return 0.0
    audit = curve_observation_audit(
        local,
        exact,
        tree=tree,
        min_height_bins=2,
        min_vertical_span_m=0.10,
    )
    return float(audit["supported_fraction"])


def _candidate_record(
    *,
    kind: str,
    geometry: LineString,
    endpoint_keys: list[list[Any]],
    exact: Any,
    tree: cKDTree,
    orientation_score: float,
    maximum_length: float,
    identifier: int,
    cfg: dict[str, Any],
    attachment_support_score: float = 0.0,
    object_relation_score: float = 0.0,
) -> dict[str, Any]:
    audit = _candidate_audit(geometry, exact, tree)
    length_score = max(0.0, 1.0 - geometry.length / max(maximum_length, 1e-6))
    weights = np.asarray(
        [
            float(cfg.get("topology_score_strict_weight", 0.45)),
            float(cfg.get("topology_score_relaxed_weight", 0.20)),
            float(cfg.get("topology_score_orientation_weight", 0.20)),
            float(cfg.get("topology_score_length_weight", 0.15)),
        ],
        dtype=float,
    )
    if np.any(weights < 0.0) or float(weights.sum()) <= 0.0:
        raise ValueError("Topology score weights must be non-negative and have positive sum")
    weights /= weights.sum()
    score = float(
        weights
        @ np.asarray(
            [
                audit["strict_support_fraction"],
                audit["relaxed_support_fraction"],
                orientation_score,
                length_score,
            ],
            dtype=float,
        )
    )
    observed = bool(
        audit["strict_full_support_fraction"] >= 0.95
        and audit["strict_p95_m"] is not None
        and audit["strict_p95_m"] <= 0.10
    )
    relaxed_p95 = audit.get("relaxed_p95_m")
    surface_alignment_score = (
        max(0.0, 1.0 - float(relaxed_p95) / 0.10)
        if relaxed_p95 is not None
        else 0.0
    )
    path_membership_score = float(
        0.40 * surface_alignment_score
        + 0.30 * float(orientation_score)
        + 0.20 * float(attachment_support_score)
        + 0.10 * float(object_relation_score)
    )
    unsupported_fraction = min(
        1.0,
        float(audit["longest_relaxed_unsupported_run_m"]) / max(float(geometry.length), 1e-9),
    )
    open_risk_score = float(
        np.clip(
            0.65 * unsupported_fraction + 0.35 * (1.0 - surface_alignment_score),
            0.0,
            1.0,
        )
    )
    connection_id = _stable_identifier(
        "CON",
        [kind, repr(_line_signature(geometry)), repr(sorted(endpoint_keys))],
    )
    return {
        "connection_id": connection_id,
        "wall_id": connection_id,
        "physical_wall_id": connection_id,
        "line": geometry,
        "geometry_kind": "line" if len(geometry.coords) == 2 else "polyline",
        "status": "observed" if observed else "inferred_gap",
        "source": (
            "v6_3d_recovered_gap" if observed else "v6_directional_topology_candidate"
        ),
        "kind": kind,
        "endpoint_keys": endpoint_keys,
        "score": float(score),
        "orientation_score": float(orientation_score),
        "attachment_support_score": float(attachment_support_score),
        "object_relation_score": float(object_relation_score),
        "surface_alignment_score": surface_alignment_score,
        "path_membership_score": path_membership_score,
        "open_risk_score": open_risk_score,
        **audit,
    }


def generate_connection_candidates(
    walls: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    exact: Any,
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    maximum_gap = float(cfg.get("topology_collinear_gap_max_m", 1.20))
    maximum_corner = float(cfg.get("topology_corner_extension_max_m", 1.00))
    maximum_t = float(cfg.get("topology_t_extension_max_m", 0.60))
    endpoint_angle = math.radians(float(cfg.get("topology_endpoint_angle_deg", 30.0)))
    parallel_angle = math.radians(float(cfg.get("topology_parallel_angle_deg", 10.0)))
    minimum = float(cfg.get("topology_min_connector_m", 0.025))
    base_union = unary_union([value["line"] for value in walls])
    column_union = unary_union([value["polygon"] for value in columns]) if columns else Polygon()
    tree = cKDTree(exact.centroids[:, :2])

    endpoints: list[tuple[str, int, np.ndarray, np.ndarray, int]] = []
    for wall_index, wall in enumerate(walls):
        line = wall["line"]
        coordinates = np.asarray(line.coords, dtype=float)
        endpoints.extend(
            [
                (str(wall["wall_id"]), 0, coordinates[0], _endpoint_tangent(line, 0), wall_index),
                (str(wall["wall_id"]), 1, coordinates[-1], _endpoint_tangent(line, 1), wall_index),
            ]
        )
    endpoint_xy = np.asarray([value[2] for value in endpoints], dtype=float)
    endpoint_support: dict[tuple[str, int], float] = {}
    for wall_id, endpoint, _, _, wall_index in endpoints:
        line = walls[wall_index]["line"]
        position = 0.0 if endpoint == 0 else float(line.length)
        endpoint_support[(wall_id, endpoint)] = _local_relaxed_support(
            line, position, exact, tree
        )

    def wall_relation(first_index: int, second_index: int) -> float:
        first_wall = walls[first_index]
        second_wall = walls[second_index]
        first_physical = first_wall.get("physical_wall_id")
        second_physical = second_wall.get("physical_wall_id")
        if first_physical is not None and first_physical == second_physical:
            return 1.0
        first_roots = set(first_wall.get("source_root_wall_ids", []))
        second_roots = set(second_wall.get("source_root_wall_ids", []))
        if first_roots and second_roots:
            return float(len(first_roots & second_roots) / len(first_roots | second_roots))
        return 0.0
    pairs = sorted(cKDTree(endpoint_xy).query_pairs(maximum_gap)) if len(endpoint_xy) else []
    candidates: list[dict[str, Any]] = []
    signatures: set[tuple[tuple[float, float], ...]] = set()

    def append_candidate(
        kind: str,
        geometry: LineString,
        keys: list[list[Any]],
        orientation_score: float,
        maximum_length: float,
        attachment_support_score: float = 0.0,
        object_relation_score: float = 0.0,
    ) -> None:
        if geometry.length < minimum or geometry.length > maximum_length + 1e-9:
            return
        signature = _line_signature(geometry)
        if signature in signatures:
            return
        # Touching at the proposed endpoints is intended.  Crossing a column
        # footprint or a third wall in the connector interior is not.
        interior = geometry.interpolate(0.5, normalized=True)
        if not column_union.is_empty and column_union.buffer(0.03).contains(interior):
            return
        shortened = geometry.interpolate(0.02), geometry.interpolate(max(0.02, geometry.length - 0.02))
        if geometry.length > 0.05:
            core = LineString([shortened[0], shortened[1]])
            if core.crosses(base_union):
                return
        signatures.add(signature)
        candidates.append(
            _candidate_record(
                kind=kind,
                geometry=geometry,
                endpoint_keys=keys,
                exact=exact,
                tree=tree,
                orientation_score=orientation_score,
                maximum_length=maximum_length,
                identifier=len(candidates),
                cfg=cfg,
                attachment_support_score=attachment_support_score,
                object_relation_score=object_relation_score,
            )
        )

    for first_index, second_index in pairs:
        first = endpoints[first_index]
        second = endpoints[second_index]
        if first[0] == second[0]:
            continue
        delta = second[2] - first[2]
        distance = float(np.linalg.norm(delta))
        if not minimum <= distance <= maximum_gap:
            continue
        direction = delta / distance
        first_faces = float(first[3] @ direction)
        second_faces = float(second[3] @ -direction)
        continuation_error = _angle_error(first[3], -second[3])
        if (
            first_faces >= math.cos(endpoint_angle)
            and second_faces >= math.cos(endpoint_angle)
            and continuation_error <= parallel_angle
        ):
            orientation = max(
                0.0,
                min(first_faces, second_faces)
                * (1.0 - continuation_error / max(parallel_angle, 1e-9)),
            )
            append_candidate(
                "collinear",
                LineString([first[2], second[2]]),
                [[first[0], first[1]], [second[0], second[1]]],
                orientation,
                maximum_gap,
                min(
                    endpoint_support.get((first[0], first[1]), 0.0),
                    endpoint_support.get((second[0], second[1]), 0.0),
                ),
                wall_relation(first[4], second[4]),
            )
            continue
        angle = math.acos(np.clip(abs(float(first[3] @ second[3])), -1.0, 1.0))
        if not math.radians(15.0) <= angle <= math.radians(165.0):
            continue
        intersection = _axis_intersection(first[2], first[3], second[2], second[3])
        if intersection is None:
            continue
        point, first_distance, second_distance = intersection
        if (
            first_distance < -0.02
            or second_distance < -0.02
            or max(first_distance, second_distance) > maximum_corner
        ):
            continue
        geometry = LineString([first[2], point, second[2]])
        right_angle_score = math.exp(-((angle - math.pi / 2.0) / math.radians(35.0)) ** 2)
        append_candidate(
            "corner",
            geometry,
            [[first[0], first[1]], [second[0], second[1]]],
            right_angle_score,
            maximum_corner * 2.0,
            min(
                endpoint_support.get((first[0], first[1]), 0.0),
                endpoint_support.get((second[0], second[1]), 0.0),
            ),
            wall_relation(first[4], second[4]),
        )

    # Endpoint-to-host candidates recover T junctions.  Samples locate a host;
    # exact projection supplies the node coordinate.
    sample_xy: list[np.ndarray] = []
    sample_wall: list[int] = []
    for wall_index, wall in enumerate(walls):
        line = wall["line"]
        count = max(2, int(math.ceil(line.length / 0.10)) + 1)
        for position in np.linspace(0.0, line.length, count):
            sample_xy.append(np.asarray(line.interpolate(float(position)).coords[0]))
            sample_wall.append(wall_index)
    sample_values = np.asarray(sample_xy, dtype=float)
    sample_tree = cKDTree(sample_values) if len(sample_values) else None
    for endpoint in endpoints:
        if sample_tree is None:
            break
        nearby = sample_tree.query_ball_point(endpoint[2], maximum_t)
        host_indices = sorted({sample_wall[index] for index in nearby})
        best: tuple[float, LineString, list[list[Any]], float, float, float] | None = None
        for host_index in host_indices:
            if host_index == endpoint[4]:
                continue
            host = walls[host_index]
            host_line = host["line"]
            position = float(host_line.project(Point(endpoint[2])))
            if position <= 0.10 or position >= host_line.length - 0.10:
                continue
            target = np.asarray(host_line.interpolate(position).coords[0], dtype=float)
            delta = target - endpoint[2]
            distance = float(np.linalg.norm(delta))
            if not minimum <= distance <= maximum_t:
                continue
            direction = delta / distance
            facing = float(endpoint[3] @ direction)
            if facing < math.cos(endpoint_angle):
                continue
            epsilon = min(0.05, position, host_line.length - position)
            before = np.asarray(host_line.interpolate(position - epsilon).coords[0])
            after = np.asarray(host_line.interpolate(position + epsilon).coords[0])
            host_direction = (after - before) / max(float(np.linalg.norm(after - before)), 1e-12)
            angle = math.acos(np.clip(abs(float(direction @ host_direction)), -1.0, 1.0))
            if not math.radians(15.0) <= angle <= math.radians(165.0):
                continue
            orientation = facing * math.exp(-((angle - math.pi / 2.0) / math.radians(40.0)) ** 2)
            attachment_support = min(
                endpoint_support.get((endpoint[0], endpoint[1]), 0.0),
                _local_relaxed_support(host_line, position, exact, tree),
            )
            item = (
                distance,
                LineString([endpoint[2], target]),
                [[endpoint[0], endpoint[1]]],
                orientation,
                attachment_support,
                wall_relation(endpoint[4], host_index),
            )
            if best is None or item[0] < best[0]:
                best = item
        if best is not None:
            previous_count = len(candidates)
            append_candidate(
                "t_junction", best[1], best[2], best[3], maximum_t, best[4], best[5]
            )
            if len(candidates) > previous_count:
                target = Point(best[1].coords[-1])
                receiving = min((w for w in walls if str(w['wall_id']) != str(best[2][0][0])),
                                key=lambda w: w['line'].distance(target), default=None)
                if receiving is not None:
                    candidates[-1]['host_wall_id'] = str(receiving['wall_id'])

    # Limit combinatorics without coupling the limit to generation order.
    per_endpoint = int(cfg.get("topology_candidates_per_endpoint", 4))
    by_endpoint: dict[tuple[str, int], list[dict[str, Any]]] = {}
    for candidate in candidates:
        for value in candidate["endpoint_keys"]:
            by_endpoint.setdefault(tuple(value), []).append(candidate)
    retained_ids = {
        id(candidate)
        for values in by_endpoint.values()
        for candidate in sorted(values, key=lambda value: value["score"], reverse=True)[:per_endpoint]
    }
    retained = [value for value in candidates if id(value) in retained_ids]
    return sorted(retained, key=lambda value: value["score"], reverse=True), {
        "raw_candidate_count": len(candidates),
        "retained_candidate_count": len(retained),
        "candidate_kind_counts": {
            kind: sum(value["kind"] == kind for value in retained)
            for kind in ("collinear", "corner", "t_junction")
        },
    }


def generate_supplemental_endpoint_candidates(
    walls: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    exact: Any,
    cfg: dict[str, Any],
    existing: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Generate a controlled second pool for endpoints missed by the base search.

    The second pass only widens the collinear distance bound; it reuses the
    ordinary direction, obstruction and evidence feature computation.  Its
    records subsequently pass through the same evidence enrichment and global
    conflict selector as the base candidates.
    """
    enabled = bool(cfg.get("supplemental_endpoint_candidates_enabled", False))
    if not enabled:
        return [], {
            "enabled": False,
            "reason": "configuration_disabled",
            "candidate_count": 0,
        }
    factor = float(cfg.get("supplemental_endpoint_gap_factor", 2.0))
    if factor <= 1.0:
        raise ValueError("supplemental_endpoint_gap_factor must be greater than 1")
    per_endpoint = int(cfg.get("supplemental_candidates_per_endpoint", 2))
    if per_endpoint < 1:
        raise ValueError("supplemental_candidates_per_endpoint must be positive")

    base_gap = float(cfg.get("topology_collinear_gap_max_m", 1.20))
    expanded = dict(cfg)
    expanded["topology_collinear_gap_max_m"] = base_gap * factor
    expanded["topology_candidates_per_endpoint"] = max(
        int(cfg.get("topology_candidates_per_endpoint", 4)) + per_endpoint + 8,
        int(cfg.get("topology_candidates_per_endpoint", 4)),
    )
    expanded_pool, expanded_report = generate_connection_candidates(
        walls, columns, exact, expanded
    )
    existing_ids = {str(value["connection_id"]) for value in existing}
    covered = {
        tuple(key)
        for value in existing
        for key in value.get("endpoint_keys", [])
    }
    eligible: list[dict[str, Any]] = []
    for candidate in expanded_pool:
        keys = [tuple(value) for value in candidate.get("endpoint_keys", [])]
        if str(candidate["connection_id"]) in existing_ids:
            continue
        if candidate.get("kind") != "collinear":
            continue
        if not any(key not in covered for key in keys):
            continue
        record = dict(candidate)
        record["source"] = "v6_supplemental_endpoint_candidate"
        record["generation_stage"] = "supplemental_unconnected_endpoint"
        record["supplemental_gap_factor"] = factor
        record["provenance"] = {
            "kind": "supplemental_endpoint_search",
            "base_collinear_gap_m": base_gap,
            "expanded_collinear_gap_m": base_gap * factor,
        }
        eligible.append(record)

    by_endpoint: dict[tuple[Any, ...], list[dict[str, Any]]] = {}
    for candidate in eligible:
        for value in candidate.get("endpoint_keys", []):
            key = tuple(value)
            if key not in covered:
                by_endpoint.setdefault(key, []).append(candidate)
    retained_ids = {
        id(candidate)
        for values in by_endpoint.values()
        for candidate in sorted(
            values,
            key=lambda value: (-float(value.get("score", 0.0)), str(value["connection_id"])),
        )[:per_endpoint]
    }
    retained = [value for value in eligible if id(value) in retained_ids]
    retained.sort(key=lambda value: (-float(value.get("score", 0.0)), str(value["connection_id"])))
    return retained, {
        "enabled": True,
        "base_collinear_gap_m": base_gap,
        "expanded_collinear_gap_m": base_gap * factor,
        "uncovered_endpoint_count": len(by_endpoint),
        "expanded_raw_candidate_count": expanded_report["raw_candidate_count"],
        "eligible_candidate_count": len(eligible),
        "candidate_count": len(retained),
        "candidates_per_endpoint": per_endpoint,
    }


def _xy_to_grid_cell(point: np.ndarray, exact: Any) -> tuple[int, int]:
    column, row = np.floor(
        (np.asarray(point, dtype=float) - np.asarray(exact.origin_xy, dtype=float))
        / float(exact.grid_m)
    ).astype(int)
    return int(row), int(column)


def _grid_cell_center(row: int, column: int, exact: Any) -> np.ndarray:
    return np.asarray(exact.origin_xy, dtype=float) + (
        np.asarray([column, row], dtype=float) + 0.5
    ) * float(exact.grid_m)


def _heading_index(direction: np.ndarray, headings: np.ndarray) -> int:
    value = np.asarray(direction, dtype=float)
    value /= max(float(np.linalg.norm(value)), 1e-12)
    return int(np.argmax(headings @ value))


def _directional_trace(
    *,
    start_xy: np.ndarray,
    start_tangent: np.ndarray,
    start_key: tuple[str, int],
    endpoint_tree: cKDTree,
    endpoints: list[tuple[str, int, np.ndarray, np.ndarray, int]],
    evidence_distance_m: np.ndarray,
    exact: Any,
    cfg: dict[str, Any],
) -> list[tuple[int | None, LineString, float, float]]:
    """Trace a small direction-state beam through immutable 3-D evidence.

    This is deliberately not morphology: every step is scored against the
    original structural XY cells.  The state retains heading, so a supported
    wall can turn while lateral jumps and oscillations remain expensive.
    """

    grid = float(exact.grid_m)
    maximum_length = float(cfg.get("topology_directional_trace_max_m", 2.40))
    target_radius = float(cfg.get("topology_directional_trace_target_radius_m", 0.12))
    beam_width = int(cfg.get("topology_directional_trace_beam_width", 18))
    minimum_steps = int(cfg.get("topology_directional_trace_min_steps", 3))
    maximum_steps = max(minimum_steps, int(math.ceil(maximum_length / grid)))
    evidence_radius = float(cfg.get("topology_directional_trace_evidence_radius_m", 0.10))
    minimum_evidence = float(
        cfg.get("topology_directional_trace_min_evidence_fraction", 0.55)
    )
    turn_weight = float(cfg.get("topology_directional_trace_turn_weight", 0.18))
    lateral_weight = float(cfg.get("topology_directional_trace_lateral_weight", 4.0))
    target_cosine = math.cos(
        math.radians(float(cfg.get("topology_directional_trace_target_angle_deg", 50.0)))
    )
    simplify_tolerance = float(
        cfg.get("topology_directional_trace_simplify_tolerance_m", 0.055)
    )
    maximum_hits = int(cfg.get("topology_directional_trace_candidates_per_endpoint", 2))
    extension_enabled = bool(
        cfg.get("topology_directional_trace_emit_supported_extension", True)
    )
    extension_minimum_length = float(
        cfg.get("topology_directional_trace_extension_min_m", 0.40)
    )
    extension_minimum_evidence = float(
        cfg.get("topology_directional_trace_extension_min_evidence_fraction", 0.90)
    )

    angles = np.arange(8, dtype=float) * (math.pi / 4.0)
    headings = np.column_stack([np.cos(angles), np.sin(angles)])
    moves = np.rint(headings).astype(int)
    start_row, start_column = _xy_to_grid_cell(start_xy, exact)
    height, width = evidence_distance_m.shape
    if not (0 <= start_row < height and 0 <= start_column < width):
        return []
    start_heading = _heading_index(start_tangent, headings)
    # cost, row, column, heading, evidence hits, path cells
    beam: list[tuple[float, int, int, int, int, tuple[tuple[int, int], ...]]] = [
        (0.0, start_row, start_column, start_heading, 1, ((start_row, start_column),))
    ]
    best_state: dict[tuple[int, int, int], float] = {
        (start_row, start_column, start_heading): 0.0
    }
    hits: dict[int, tuple[float, LineString, float, float]] = {}
    best_extension: tuple[float, LineString, float, float] | None = None

    for step_index in range(1, maximum_steps + 1):
        proposals: list[
            tuple[float, int, int, int, int, tuple[tuple[int, int], ...]]
        ] = []
        for cost, row, column, heading, evidence_hits, path in beam:
            for heading_delta in (-2, -1, 0, 1, 2):
                next_heading = (heading + heading_delta) % 8
                dx, dy = moves[next_heading]
                next_row = row + int(dy)
                next_column = column + int(dx)
                if not (0 <= next_row < height and 0 <= next_column < width):
                    continue
                if (next_row, next_column) in path[-8:]:
                    continue
                distance = float(evidence_distance_m[next_row, next_column])
                step_length = grid * math.hypot(float(dx), float(dy))
                lateral_penalty = lateral_weight * min(distance / max(evidence_radius, 1e-9), 3.0)
                turn_penalty = turn_weight * abs(heading_delta)
                next_cost = cost + step_length * (1.0 + lateral_penalty + turn_penalty)
                state = (next_row, next_column, next_heading)
                if next_cost >= best_state.get(state, math.inf) - 1e-12:
                    continue
                best_state[state] = next_cost
                next_hits = evidence_hits + int(distance <= evidence_radius)
                next_path = path + ((next_row, next_column),)
                proposals.append(
                    (
                        next_cost,
                        next_row,
                        next_column,
                        next_heading,
                        next_hits,
                        next_path,
                    )
                )

                travelled = step_index * grid
                extension_evidence = float(next_hits / len(next_path))
                if (
                    extension_enabled
                    and travelled >= extension_minimum_length
                    and extension_evidence >= extension_minimum_evidence
                ):
                    extension_coordinates = [start_xy]
                    extension_coordinates.extend(
                        _grid_cell_center(path_row, path_column, exact)
                        for path_row, path_column in next_path[1:]
                    )
                    extension = LineString(extension_coordinates).simplify(
                        simplify_tolerance, preserve_topology=False
                    )
                    if isinstance(extension, LineString) and extension.length >= extension_minimum_length:
                        extension_values = np.asarray(extension.coords, dtype=float)
                        forward_progress = float(
                            (extension_values[-1] - extension_values[0]) @ start_tangent
                        )
                        if forward_progress < 0.25 * extension.length:
                            continue
                        initial_direction = extension_values[1] - extension_values[0]
                        initial_direction /= max(float(np.linalg.norm(initial_direction)), 1e-12)
                        initial_alignment = max(0.0, float(initial_direction @ start_tangent))
                        normalised_cost = next_cost / max(travelled, grid)
                        quality = float(
                            extension.length
                            * extension_evidence
                            * initial_alignment
                            / max(normalised_cost, 1e-6)
                        )
                        if best_extension is None or quality > best_extension[0]:
                            best_extension = (
                                quality,
                                extension,
                                extension_evidence,
                                initial_alignment,
                            )

                if step_index < minimum_steps:
                    continue
                current_xy = _grid_cell_center(next_row, next_column, exact)
                for target_index in endpoint_tree.query_ball_point(current_xy, target_radius):
                    target = endpoints[target_index]
                    target_key = (target[0], target[1])
                    if target_key == start_key or target[0] == start_key[0]:
                        continue
                    if float(np.linalg.norm(current_xy - target[2])) > target_radius:
                        continue
                    arrival = headings[next_heading]
                    if float(arrival @ -target[3]) < target_cosine:
                        continue
                    evidence_fraction = float(next_hits / len(next_path))
                    if evidence_fraction < minimum_evidence:
                        continue
                    coordinates = [start_xy]
                    coordinates.extend(
                        _grid_cell_center(path_row, path_column, exact)
                        for path_row, path_column in next_path[1:]
                    )
                    coordinates.append(target[2])
                    route = LineString(coordinates).simplify(
                        simplify_tolerance, preserve_topology=False
                    )
                    if not isinstance(route, LineString) or route.length <= 0.05:
                        continue
                    if route.length > maximum_length + grid:
                        continue
                    route_coordinates = np.asarray(route.coords, dtype=float)
                    first_direction = route_coordinates[1] - route_coordinates[0]
                    last_direction = route_coordinates[-1] - route_coordinates[-2]
                    first_direction /= max(float(np.linalg.norm(first_direction)), 1e-12)
                    last_direction /= max(float(np.linalg.norm(last_direction)), 1e-12)
                    endpoint_orientation = min(
                        float(first_direction @ start_tangent),
                        float(last_direction @ -target[3]),
                    )
                    if endpoint_orientation < target_cosine:
                        continue
                    quality = float(
                        evidence_fraction
                        * endpoint_orientation
                        / max(1.0, route.length / max(np.linalg.norm(target[2] - start_xy), grid))
                    )
                    previous = hits.get(target_index)
                    item = (target_index, route, evidence_fraction, endpoint_orientation)
                    if previous is None or quality > previous[0]:
                        hits[target_index] = (quality, route, evidence_fraction, endpoint_orientation)

        if not proposals:
            break
        if len(hits) >= maximum_hits:
            break
        # Beam rank is length-normalised so an evidence-following state is not
        # discarded merely because it has travelled farther along the wall.
        proposals.sort(key=lambda value: value[0] / max(len(value[5]) - 1, 1))
        beam = proposals[:beam_width]

    result: list[tuple[int | None, LineString, float, float]] = [
        (target_index, value[1], value[2], value[3])
        for target_index, value in sorted(hits.items(), key=lambda item: item[1][0], reverse=True)
    ]
    if best_extension is not None:
        result.append(
            (None, best_extension[1], best_extension[2], best_extension[3])
        )
    return result


def generate_directional_trace_candidates(
    walls: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    exact: Any,
    cfg: dict[str, Any],
    existing_candidates: list[dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Generate evidence-following wall continuations before graph selection."""

    if not bool(cfg.get("topology_directional_trace_enabled", False)):
        return [], {"enabled": False, "candidate_count": 0}
    if not walls:
        return [], {"enabled": True, "candidate_count": 0, "reason": "no_wall_endpoints"}
    endpoints: list[tuple[str, int, np.ndarray, np.ndarray, int]] = []
    for wall_index, wall in enumerate(walls):
        coordinates = np.asarray(wall["line"].coords, dtype=float)
        endpoints.extend(
            [
                (str(wall["wall_id"]), 0, coordinates[0], _endpoint_tangent(wall["line"], 0), wall_index),
                (str(wall["wall_id"]), 1, coordinates[-1], _endpoint_tangent(wall["line"], 1), wall_index),
            ]
        )
    endpoint_xy = np.asarray([value[2] for value in endpoints], dtype=float)
    endpoint_tree = cKDTree(endpoint_xy)
    trace_minimum_bins = int(cfg.get("topology_directional_trace_min_height_bins", 4))
    trace_minimum_span = float(
        cfg.get("topology_directional_trace_min_vertical_span_m", 0.40)
    )
    all_span = (
        exact.all_z_max_bin - exact.all_z_min_bin + 1
    ) * float(exact.z_bin_m)
    trace_cells = exact.all_xy_cell[
        (exact.all_bin_count >= trace_minimum_bins)
        & (all_span + 1e-9 >= trace_minimum_span)
    ]
    trace_mask = np.zeros(exact.shape, dtype=bool)
    trace_mask.flat[trace_cells] = True
    wall_probability = cfg.get("_topology_wall_probability")
    semantic_agreement = cfg.get("_topology_semantic_agreement")
    semantic_threshold = float(
        cfg.get("topology_directional_trace_wall_probability_min", 0.80)
    )
    semantic_agreement_min = float(
        cfg.get("topology_directional_trace_semantic_agreement_min", 2.0 / 3.0)
    )
    if wall_probability is not None:
        semantic_mask = np.asarray(wall_probability, dtype=float) >= semantic_threshold
        if semantic_agreement is not None:
            semantic_mask &= (
                np.asarray(semantic_agreement, dtype=float) >= semantic_agreement_min
            )
        trace_mask &= semantic_mask
    evidence_distance = distance_transform_edt(~trace_mask) * float(exact.grid_m)
    column_union = unary_union([value["polygon"] for value in columns]) if columns else Polygon()
    base_union = unary_union([value["line"] for value in walls])
    exact_tree = cKDTree(exact.centroids[:, :2])
    maximum_starts = int(cfg.get("topology_directional_trace_max_starts", 0))
    per_endpoint = int(cfg.get("topology_directional_trace_candidates_per_endpoint", 2))
    existing_signatures = {
        _line_signature(value["line"]) for value in (existing_candidates or [])
    }
    covered_endpoint_keys: set[tuple[str, int]] = set()
    if bool(cfg.get("topology_directional_trace_skip_existing_qualified", True)):
        minimum_existing_path = float(
            cfg.get("topology_directional_trace_existing_path_score_min", 0.55)
        )
        minimum_existing_support = float(
            cfg.get("topology_directional_trace_existing_support_min", 0.85)
        )
        for candidate in existing_candidates or []:
            if (
                float(candidate.get("path_membership_score", 0.0)) >= minimum_existing_path
                and float(candidate.get("relaxed_support_fraction", 0.0))
                >= minimum_existing_support
            ):
                covered_endpoint_keys.update(
                    tuple(value) for value in candidate.get("endpoint_keys", [])
                )
    output: list[dict[str, Any]] = []
    pair_signatures: set[tuple[tuple[str, int], tuple[str, int]]] = set()
    rejection: dict[str, int] = {}

    def reject(reason: str) -> None:
        rejection[reason] = rejection.get(reason, 0) + 1

    maximum_length = float(cfg.get("topology_directional_trace_max_m", 2.40))
    extension_enabled = bool(
        cfg.get("topology_directional_trace_emit_supported_extension", True)
    )
    extension_seed_radius = float(
        cfg.get("topology_directional_trace_evidence_radius_m", 0.10)
    )
    start_target_cosine = math.cos(
        math.radians(float(cfg.get("topology_directional_trace_prefilter_angle_deg", 78.0)))
    )
    start_indices: list[int] = []
    prefilter_target_count = 0
    for index, endpoint in enumerate(endpoints):
        if (endpoint[0], endpoint[1]) in covered_endpoint_keys:
            continue
        compatible = False
        for target_index in endpoint_tree.query_ball_point(endpoint[2], maximum_length):
            if target_index == index:
                continue
            target = endpoints[target_index]
            if target[0] == endpoint[0]:
                continue
            delta = target[2] - endpoint[2]
            distance = float(np.linalg.norm(delta))
            if distance < 0.12:
                continue
            chord = delta / distance
            if (
                float(endpoint[3] @ chord) >= start_target_cosine
                and float(target[3] @ -chord) >= start_target_cosine
            ):
                compatible = True
                prefilter_target_count += 1
                break
        if not compatible and extension_enabled:
            heading_angles = np.arange(8, dtype=float) * (math.pi / 4.0)
            heading_vectors = np.column_stack(
                [np.cos(heading_angles), np.sin(heading_angles)]
            )
            heading = _heading_index(endpoint[3], heading_vectors)
            seed_hits = 0
            for seed_step in range(1, 5):
                probe = endpoint[2] + heading_vectors[heading] * (
                    seed_step * float(exact.grid_m)
                )
                probe_row, probe_column = _xy_to_grid_cell(probe, exact)
                if (
                    0 <= probe_row < evidence_distance.shape[0]
                    and 0 <= probe_column < evidence_distance.shape[1]
                    and evidence_distance[probe_row, probe_column] <= extension_seed_radius
                ):
                    seed_hits += 1
            compatible = seed_hits >= 3
        if compatible:
            start_indices.append(index)
    if maximum_starts > 0:
        start_indices = start_indices[:maximum_starts]
    for start_index in start_indices:
        start = endpoints[start_index]
        traces = _directional_trace(
            start_xy=start[2],
            start_tangent=start[3],
            start_key=(start[0], start[1]),
            endpoint_tree=endpoint_tree,
            endpoints=endpoints,
            evidence_distance_m=evidence_distance,
            exact=exact,
            cfg=cfg,
        )
        accepted_for_endpoint = 0
        for target_index, geometry, route_support, endpoint_orientation in traces:
            target = endpoints[target_index] if target_index is not None else None
            pair = (
                tuple(sorted(((start[0], start[1]), (target[0], target[1]))))
                if target is not None
                else None
            )
            if pair is not None and pair in pair_signatures:
                continue
            signature = _line_signature(geometry)
            if signature in existing_signatures:
                continue
            if not column_union.is_empty and geometry.intersects(column_union.buffer(0.03)):
                reject("column_conflict")
                continue
            core = (
                substring(geometry, 0.03, geometry.length - 0.03)
                if geometry.length > 0.08
                else geometry
            )
            if isinstance(core, LineString) and core.crosses(base_union):
                reject("wall_crossing")
                continue
            start_support = _local_relaxed_support(
                walls[start[4]]["line"],
                0.0 if start[1] == 0 else walls[start[4]]["line"].length,
                exact,
                exact_tree,
            )
            attachment_support = (
                min(
                    start_support,
                    _local_relaxed_support(
                        walls[target[4]]["line"],
                        0.0 if target[1] == 0 else walls[target[4]]["line"].length,
                        exact,
                        exact_tree,
                    ),
                )
                if target is not None
                else start_support
            )
            record = _candidate_record(
                kind=("directional_trace" if target is not None else "supported_extension"),
                geometry=geometry,
                endpoint_keys=(
                    [[start[0], start[1]], [target[0], target[1]]]
                    if target is not None
                    else [[start[0], start[1]]]
                ),
                exact=exact,
                tree=exact_tree,
                orientation_score=max(0.0, endpoint_orientation),
                maximum_length=float(cfg.get("topology_directional_trace_max_m", 2.40)),
                identifier=len(output),
                cfg=cfg,
                attachment_support_score=attachment_support,
                object_relation_score=0.0,
            )
            record["source"] = "v7_direction_state_trace"
            record["route_evidence_fraction"] = route_support
            record["path_membership_score"] = max(
                float(record.get("path_membership_score", 0.0)),
                float(0.55 * route_support + 0.30 * endpoint_orientation + 0.15 * attachment_support),
            )
            if pair is not None:
                pair_signatures.add(pair)
            existing_signatures.add(signature)
            output.append(record)
            accepted_for_endpoint += 1
            if accepted_for_endpoint >= per_endpoint:
                break
    return sorted(output, key=lambda value: value["path_membership_score"], reverse=True), {
        "enabled": True,
        "start_endpoint_count": len(start_indices),
        "prefilter_compatible_target_count": prefilter_target_count,
        "skipped_existing_qualified_endpoint_count": len(covered_endpoint_keys),
        "candidate_count": len(output),
        "trace_evidence_cell_count": int(np.count_nonzero(trace_mask)),
        "trace_evidence_definition": (
            f"vertical_bins>={trace_minimum_bins},span>={trace_minimum_span:.2f}m"
            + (f",wall_probability>={semantic_threshold:.2f}" if wall_probability is not None else "")
        ),
        "rejection_reasons": rejection,
    }


def assign_persistent_wall_chain_ids(
    walls: list[dict[str, Any]], connections: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Attach stable physical-chain IDs without erasing observation states."""

    parent = {str(value["wall_id"]): str(value["wall_id"]) for value in walls}

    def find(value: str) -> str:
        parent.setdefault(value, value)
        while parent[value] != value:
            parent[value] = parent[parent[value]]
            value = parent[value]
        return value

    def union(first: str, second: str) -> None:
        first_root, second_root = find(first), find(second)
        if first_root != second_root:
            parent[max(first_root, second_root)] = min(first_root, second_root)

    for connection in connections:
        attached = [str(value[0]) for value in connection.get("endpoint_keys", [])]
        if len(attached) == 2:
            union(attached[0], attached[1])
    members: dict[str, list[str]] = {}
    for wall_id in parent:
        members.setdefault(find(wall_id), []).append(wall_id)
    chain_ids = {
        member: _stable_identifier("CHAIN", values)
        for values in members.values()
        for member in values
    }
    result: list[dict[str, Any]] = []
    for source in walls:
        record = dict(source)
        record["wall_chain_id"] = chain_ids[str(record["wall_id"])]
        result.append(record)
    for source in connections:
        record = dict(source)
        attached = [str(value[0]) for value in record.get("endpoint_keys", [])]
        record["wall_chain_id"] = (
            chain_ids.get(attached[0], str(record.get("connection_id")))
            if attached
            else str(record.get("connection_id"))
        )
        result.append(record)
    return result, {
        "chain_count": len(set(chain_ids.values())),
        "multi_fragment_chain_count": sum(len(values) > 1 for values in members.values()),
        "connected_fragment_count": sum(len(values) for values in members.values() if len(values) > 1),
    }


def recover_legacy_connector_candidates(
    walls: list[dict[str, Any]],
    legacy_walls: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    exact: Any,
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Re-score old connectors as proposals in the rebuilt wall graph.

    V5's connector geometry contains useful hypotheses, but its labels are not
    trusted.  Both ends must attach to the rebuilt physical wall network and
    point into the gap before the proposal can compete with a new V6 path.
    """

    maximum = float(cfg.get("topology_legacy_connector_max_m", 1.20))
    attach = float(cfg.get("topology_legacy_attachment_m", 0.12))
    endpoint_angle = math.radians(float(cfg.get("topology_legacy_endpoint_angle_deg", 45.0)))
    endpoints: list[tuple[str, int, np.ndarray, np.ndarray, int]] = []
    for wall_index, wall in enumerate(walls):
        line = wall["line"]
        coordinates = np.asarray(line.coords, dtype=float)
        endpoints.extend(
            [
                (str(wall["wall_id"]), 0, coordinates[0], _endpoint_tangent(line, 0), wall_index),
                (str(wall["wall_id"]), 1, coordinates[-1], _endpoint_tangent(line, 1), wall_index),
            ]
        )
    if not endpoints:
        return [], {"legacy_candidate_count": 0}
    endpoint_xy = np.asarray([value[2] for value in endpoints])
    endpoint_tree = cKDTree(endpoint_xy)
    host_samples: list[np.ndarray] = []
    host_sample_index: list[int] = []
    for wall_index, wall in enumerate(walls):
        line = wall["line"]
        count = max(2, int(math.ceil(line.length / 0.10)) + 1)
        for position in np.linspace(0.0, line.length, count):
            host_samples.append(np.asarray(line.interpolate(float(position)).coords[0]))
            host_sample_index.append(wall_index)
    host_tree = cKDTree(np.asarray(host_samples)) if host_samples else None
    exact_tree = cKDTree(exact.centroids[:, :2])
    base_union = unary_union([value["line"] for value in walls])
    column_union = unary_union([value["polygon"] for value in columns]) if columns else Polygon()
    output: list[dict[str, Any]] = []
    signatures: set[tuple[tuple[float, float], ...]] = set()
    rejection: dict[str, int] = {}

    def reject(reason: str) -> None:
        rejection[reason] = rejection.get(reason, 0) + 1

    for source in legacy_walls:
        if source.get("status") not in {"inferred_gap", "observed_recovery"}:
            continue
        source_line = source["line"]
        if not 0.02 <= source_line.length <= maximum:
            reject("length")
            continue
        source_coordinates = np.asarray(source_line.coords, dtype=float)
        matched: list[dict[str, Any]] = []
        valid = True
        for point in (source_coordinates[0], source_coordinates[-1]):
            distance, index = endpoint_tree.query(point)
            if float(distance) <= attach:
                endpoint = endpoints[int(index)]
                matched.append(
                    {
                        "kind": "endpoint",
                        "wall_id": endpoint[0],
                        "endpoint": endpoint[1],
                        "point": endpoint[2],
                        "tangent": endpoint[3],
                        "wall_index": endpoint[4],
                    }
                )
                continue
            if host_tree is None:
                valid = False
                break
            host_distance, sample_index = host_tree.query(point)
            if float(host_distance) > attach:
                valid = False
                break
            wall_index = host_sample_index[int(sample_index)]
            host = walls[wall_index]
            host_line = host["line"]
            position = float(host_line.project(Point(point)))
            if position <= 0.10 or position >= host_line.length - 0.10:
                valid = False
                break
            projected = np.asarray(host_line.interpolate(position).coords[0])
            epsilon = min(0.05, position, host_line.length - position)
            before = np.asarray(host_line.interpolate(position - epsilon).coords[0])
            after = np.asarray(host_line.interpolate(position + epsilon).coords[0])
            tangent = (after - before) / max(float(np.linalg.norm(after - before)), 1e-12)
            matched.append(
                {
                    "kind": "host",
                    "wall_id": str(host["wall_id"]),
                    "endpoint": None,
                    "point": projected,
                    "tangent": tangent,
                    "wall_index": wall_index,
                }
            )
        if (
            not valid
            or matched[0]["wall_id"] == matched[1]["wall_id"]
            or all(value["kind"] == "host" for value in matched)
        ):
            reject("attachment")
            continue
        start, stop = matched
        snapped = source_coordinates.copy()
        snapped[0] = start["point"]
        snapped[-1] = stop["point"]
        geometry = LineString(snapped)
        if geometry.length > maximum or geometry.length < 0.02:
            reject("snapped_length")
            continue
        start_direction = np.asarray(geometry.coords[1]) - np.asarray(geometry.coords[0])
        stop_direction = np.asarray(geometry.coords[-2]) - np.asarray(geometry.coords[-1])
        start_direction /= max(float(np.linalg.norm(start_direction)), 1e-12)
        stop_direction /= max(float(np.linalg.norm(stop_direction)), 1e-12)
        orientation_values: list[float] = []
        direction_valid = True
        for attachment, direction in ((start, start_direction), (stop, stop_direction)):
            if attachment["kind"] == "endpoint":
                facing = float(attachment["tangent"] @ direction)
                if facing < math.cos(endpoint_angle):
                    direction_valid = False
                    break
                orientation_values.append(facing)
            else:
                # A host-interior attachment is a T node.  A nearly parallel
                # hit merely overlaps an existing wall and is not a closure.
                angle = math.acos(
                    np.clip(abs(float(attachment["tangent"] @ direction)), -1.0, 1.0)
                )
                if not math.radians(15.0) <= angle <= math.radians(165.0):
                    direction_valid = False
                    break
                orientation_values.append(
                    math.exp(-((angle - math.pi / 2.0) / math.radians(40.0)) ** 2)
                )
        if not direction_valid:
            reject("direction")
            continue
        midpoint = geometry.interpolate(0.5, normalized=True)
        if not column_union.is_empty and column_union.buffer(0.03).contains(midpoint):
            reject("column_conflict")
            continue
        if geometry.length > 0.05:
            core = LineString(
                [geometry.interpolate(0.02), geometry.interpolate(geometry.length - 0.02)]
            )
            if core.crosses(base_union):
                reject("wall_crossing")
                continue
        signature = _line_signature(geometry)
        if signature in signatures:
            reject("duplicate")
            continue
        signatures.add(signature)
        if all(value["kind"] == "endpoint" for value in matched):
            direction_change = _angle_error(start_direction, -stop_direction)
            orientation = min(orientation_values) * math.exp(
                -(direction_change / math.radians(35.0)) ** 2
            )
            kind = "legacy_reaudited"
        else:
            orientation = min(orientation_values)
            kind = "legacy_t_reaudited"
        endpoint_keys = [
            [value["wall_id"], value["endpoint"]]
            for value in matched
            if value["kind"] == "endpoint"
        ]
        attachment_support_values = []
        for attachment in matched:
            attachment_line = walls[attachment["wall_index"]]["line"]
            attachment_position = float(
                attachment_line.project(Point(attachment["point"]))
            )
            attachment_support_values.append(
                _local_relaxed_support(
                    attachment_line, attachment_position, exact, exact_tree
                )
            )
        first_wall = walls[start["wall_index"]]
        second_wall = walls[stop["wall_index"]]
        first_physical = first_wall.get("physical_wall_id")
        second_physical = second_wall.get("physical_wall_id")
        relation = float(
            first_physical is not None and first_physical == second_physical
        )
        if relation == 0.0:
            first_roots = set(first_wall.get("source_root_wall_ids", []))
            second_roots = set(second_wall.get("source_root_wall_ids", []))
            if first_roots and second_roots:
                relation = float(
                    len(first_roots & second_roots) / len(first_roots | second_roots)
                )
        record = _candidate_record(
            kind=kind,
            geometry=geometry,
            endpoint_keys=endpoint_keys,
            exact=exact,
            tree=exact_tree,
            orientation_score=max(0.0, orientation),
            maximum_length=maximum,
            identifier=len(output),
            cfg=cfg,
            attachment_support_score=min(attachment_support_values, default=0.0),
            object_relation_score=relation,
        )
        # The stable ID created from geometry and attached wall IDs remains
        # unchanged when candidate ordering changes between ablations.
        record["source"] = "v5_connector_reaudited_against_rebuilt_wall_graph"
        record["legacy_wall_id"] = source.get("wall_id")
        output.append(record)
    return sorted(output, key=lambda value: value["score"], reverse=True), {
        "legacy_input_connector_count": sum(
            value.get("status") in {"inferred_gap", "observed_recovery"}
            for value in legacy_walls
        ),
        "legacy_candidate_count": len(output),
        "legacy_rejection_reasons": rejection,
    }


def select_continuity_connections(
    candidates: list[dict[str, Any]], cfg: dict[str, Any]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    observed_threshold = float(cfg.get("topology_observed_score_min", 0.72))
    inferred_threshold = float(cfg.get("topology_inferred_score_min", 0.48))
    inferred_support = float(cfg.get("topology_inferred_relaxed_support_min", 0.35))
    inferred_strict_support = float(
        cfg.get("topology_inferred_strict_support_min", 0.0)
    )
    inferred_orientation = float(cfg.get("topology_inferred_orientation_min", 0.0))
    path_gate_enabled = bool(cfg.get("topology_surface_path_gate_enabled", False))
    path_score_min = float(cfg.get("topology_surface_path_score_min", 0.30))
    path_relaxed_support = float(
        cfg.get("topology_surface_path_relaxed_support_min", 0.95)
    )
    path_p95_max = float(cfg.get("topology_surface_path_p95_max_m", 0.05))
    path_attachment_min = float(
        cfg.get("topology_surface_path_attachment_support_min", 0.80)
    )
    path_orientation_min = float(
        cfg.get("topology_surface_path_orientation_min", 0.15)
    )
    path_open_risk_max = float(cfg.get("topology_surface_path_open_risk_max", 0.45))
    enforce_conflicts = bool(cfg.get("topology_enforce_endpoint_conflicts", True))
    fixed_budget_ranking = bool(cfg.get("topology_fixed_budget_ranking", False))
    rank_mode = str(cfg.get("topology_selection_rank_mode", "evidence_score"))
    prefer_two_ended = bool(cfg.get("topology_selection_prefer_two_ended", False))
    trace_residual_only = bool(cfg.get("topology_selection_trace_residual_only", False))
    budget_value = cfg.get("topology_connection_budget")
    budget = int(budget_value) if budget_value is not None else None
    used: set[tuple[str, int]] = set()
    observed: list[dict[str, Any]] = []
    inferred: list[dict[str, Any]] = []

    def standard_inferred(candidate: dict[str, Any]) -> bool:
        return bool(
            candidate["score"] >= inferred_threshold
            and candidate["relaxed_support_fraction"] >= inferred_support
            and candidate["strict_support_fraction"] >= inferred_strict_support
            and candidate["orientation_score"] >= inferred_orientation
        )

    def surface_path_inferred(candidate: dict[str, Any]) -> bool:
        p95 = candidate.get("relaxed_p95_m")
        return bool(
            path_gate_enabled
            and p95 is not None
            and float(p95) <= path_p95_max
            and float(candidate.get("path_membership_score", 0.0)) >= path_score_min
            and float(candidate.get("relaxed_support_fraction", 0.0)) >= path_relaxed_support
            and float(candidate.get("attachment_support_score", 0.0)) >= path_attachment_min
            and float(candidate.get("orientation_score", 0.0)) >= path_orientation_min
            and float(candidate.get("open_risk_score", 1.0)) <= path_open_risk_max
        )

    def inferred_eligible(candidate: dict[str, Any]) -> bool:
        ordinary = standard_inferred(candidate) or surface_path_inferred(candidate)
        if bool(cfg.get('object_consistent_gate', False)):
            return bool((ordinary and candidate.get('object_evidence_eligible', False))
                        or candidate.get('continuation_eligible', False))
        return ordinary

    def observed_eligible(candidate: dict[str, Any]) -> bool:
        return bool(candidate['status'] == 'observed' and candidate['score'] >= observed_threshold
                    and (not cfg.get('object_consistent_gate', False)
                         or candidate.get('object_evidence_eligible', False)))

    eligible_endpoints = {
        tuple(value)
        for candidate in candidates
        if fixed_budget_ranking or (
            observed_eligible(candidate)
        )
        or inferred_eligible(candidate)
        for value in candidate["endpoint_keys"]
    }
    ordered_candidates = candidates
    if not fixed_budget_ranking and rank_mode == "surface_path":
        ordered_candidates = sorted(
            candidates,
            key=lambda candidate: (
                (
                    candidate.get("source") != "v7_direction_state_trace"
                    if trace_residual_only
                    else True
                ),
                candidate.get("status") == "observed",
                (
                    len(candidate.get("endpoint_keys", [])) >= 2
                    if prefer_two_ended
                    else True
                ),
                surface_path_inferred(candidate),
                float(candidate.get("path_membership_score", 0.0)),
                float(candidate.get("score", 0.0)),
            ),
            reverse=True,
        )
    for candidate in ordered_candidates:
        if cfg.get('object_consistent_gate', False) and not (observed_eligible(candidate) or inferred_eligible(candidate)):
            continue
        if cfg.get('topology_enforce_connection_crossings', False) and any(
            candidate['line'].crosses(value['line']) or candidate['line'].overlaps(value['line'])
            for value in observed + inferred
        ):
            continue
        keys = [tuple(value) for value in candidate["endpoint_keys"]]
        if enforce_conflicts and any(value in used for value in keys):
            continue
        if fixed_budget_ranking:
            (observed if candidate["status"] == "observed" else inferred).append(candidate)
        elif observed_eligible(candidate):
            observed.append(candidate)
        elif inferred_eligible(candidate):
            item = dict(candidate)
            item["selection_gate"] = (
                "bounded_object_continuation" if candidate.get('continuation_eligible', False)
                and not candidate.get('object_evidence_eligible', False) else
                "surface_path" if surface_path_inferred(candidate) and not standard_inferred(candidate)
                else "standard_evidence"
            )
            inferred.append(item)
        else:
            continue
        used.update(keys)
        if budget is not None and len(observed) + len(inferred) >= budget:
            break
    repaired = eligible_endpoints & used
    return observed, inferred, {
        "frozen_eligible_endpoint_count": len(eligible_endpoints),
        "repaired_eligible_endpoint_count": len(repaired),
        "repair_rate": (
            float(len(repaired) / len(eligible_endpoints)) if eligible_endpoints else None
        ),
        "selected_observed_connection_count": len(observed),
        "selected_inferred_connection_count": len(inferred),
        "endpoint_conflict_constraint_enabled": enforce_conflicts,
        "fixed_budget_ranking_enabled": fixed_budget_ranking,
        "selection_rank_mode": rank_mode,
        "prefer_two_ended_connections": prefer_two_ended,
        "directional_trace_used_as_residual": trace_residual_only,
        "connection_budget": budget,
        "object_consistent_gate_enabled": bool(cfg.get('object_consistent_gate', False)),
        "object_gate_rejected_count": sum(not c.get('object_evidence_eligible', False)
             and not c.get('continuation_eligible', False) for c in candidates) if cfg.get('object_consistent_gate', False) else 0,
        "quality_gate": {
            "observed_score_min": observed_threshold,
            "inferred_score_min": inferred_threshold,
            "inferred_relaxed_support_min": inferred_support,
            "inferred_strict_support_min": inferred_strict_support,
            "inferred_orientation_min": inferred_orientation,
            "surface_path_gate_enabled": path_gate_enabled,
            "surface_path_score_min": path_score_min,
            "surface_path_relaxed_support_min": path_relaxed_support,
            "surface_path_p95_max_m": path_p95_max,
            "surface_path_attachment_support_min": path_attachment_min,
            "surface_path_orientation_min": path_orientation_min,
            "surface_path_open_risk_max": path_open_risk_max,
        },
    }


def topology_statistics(records: list[dict[str, Any]]) -> dict[str, Any]:
    lines = [value["line"] for value in records if value["line"].length > 1e-6]
    if not lines:
        return {"edge_count": 0, "node_count": 0, "dangling_node_count": 0}
    noded = unary_union(lines)
    edges = list(_iter_lines(noded))
    degree: dict[tuple[int, int], int] = {}
    for line in edges:
        coordinates = np.asarray(line.coords, dtype=float)
        for point in (coordinates[0], coordinates[-1]):
            key = tuple(np.rint(point / 0.001).astype(int))
            degree[key] = degree.get(key, 0) + 1
    return {
        "edge_count": len(edges),
        "node_count": len(degree),
        "dangling_node_count": sum(value == 1 for value in degree.values()),
        "junction_node_count": sum(value >= 3 for value in degree.values()),
        "connected_node_fraction": float(
            sum(value >= 2 for value in degree.values()) / max(len(degree), 1)
        ),
    }


def _records_to_document(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {key: value for key, value in record.items() if key != "line"}
        | {"coordinates": np.asarray(record["line"].coords).tolist()}
        for record in records
    ]


def _regions_union(
    baseline: list[dict[str, Any]], recovered: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for source_name, values in (("v5_preserved", baseline), ("v6_recovered", recovered)):
        for value in values:
            polygon = value["polygon"]
            if any(polygon.symmetric_difference(item["polygon"]).area <= 0.01 for item in result):
                continue
            record = dict(value)
            record["region_id"] = f"V6-REG-{len(result):05d}"
            record["source"] = source_name
            result.append(record)
    return result


def _write_v5_v6_comparison(
    path: Path, baseline_image: Path, v6_image: Path
) -> None:
    baseline = cv2.imread(str(baseline_image), cv2.IMREAD_COLOR)
    current = cv2.imread(str(v6_image), cv2.IMREAD_COLOR)
    if baseline is None or current is None:
        return
    height = min(baseline.shape[0], current.shape[0])
    if baseline.shape[0] != height:
        scale = height / baseline.shape[0]
        baseline = cv2.resize(baseline, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    if current.shape[0] != height:
        scale = height / current.shape[0]
        current = cv2.resize(current, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    cv2.putText(
        baseline, "V5 CONSERVATIVE", (18, 60), cv2.FONT_HERSHEY_SIMPLEX,
        1.0, (255, 255, 255), 2, cv2.LINE_AA,
    )
    cv2.putText(
        current, "V6 TOPOLOGY", (18, 60), cv2.FONT_HERSHEY_SIMPLEX,
        1.0, (255, 255, 255), 2, cv2.LINE_AA,
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(path), np.hstack([baseline, current])):
        raise OSError(f"Could not write comparison image: {path}")


def run_topology_v6(config_path: str | Path) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    config = load_config(config_path)
    cfg = config["parking_structure"]
    algorithm_name = str(cfg.get("algorithm_version", ALGORITHM))
    display_name = str(cfg.get("algorithm_display_name", "V6 TOPOLOGY"))
    output = Path(config["project"]["output_dir"]).resolve()
    output.mkdir(parents=True, exist_ok=True)

    def resolved(key: str) -> Path:
        value = Path(str(cfg[key])).expanduser()
        return value.resolve() if value.is_absolute() else (config_path.parent / value).resolve()

    baseline_path = resolved("topology_baseline_graph")
    evidence_path = resolved("topology_evidence_cache")
    transforms_path = resolved("topology_transforms")
    baseline_document = read_json(baseline_path)
    walls = _wall_records(baseline_document)
    columns = _column_records(baseline_document)
    baseline_regions = _region_records(baseline_document)
    exact = load_exact_evidence(evidence_path)
    transform = np.asarray(read_json(transforms_path)["T_cad_reference_slam"], dtype=float)

    runtime_cfg = dict(cfg)
    semantic_value = cfg.get("topology_semantic_probability_cache")
    if semantic_value:
        semantic_path = Path(str(semantic_value)).expanduser()
        if not semantic_path.is_absolute():
            semantic_path = (config_path.parent / semantic_path).resolve()
        if not semantic_path.exists():
            raise FileNotFoundError(
                f"topology semantic probability cache does not exist: {semantic_path}"
            )
        with np.load(semantic_path) as semantic_values:
            wall_probability = np.asarray(
                semantic_values["wall_probability"], dtype=np.float32
            )
            if wall_probability.shape != exact.shape:
                raise ValueError("topology semantic raster/evidence shape mismatch")
            runtime_cfg["_topology_wall_probability"] = wall_probability
            if "agreement_probability" in semantic_values.files:
                runtime_cfg["_topology_semantic_agreement"] = np.asarray(
                    semantic_values["agreement_probability"], dtype=np.float32
                )

    normalised, normalise_metrics = normalise_wall_objects(walls, runtime_cfg)
    topology_before = topology_statistics(normalised)
    candidates, candidate_metrics = generate_connection_candidates(
        normalised, columns, exact, runtime_cfg
    )
    trace_candidates, trace_candidate_metrics = generate_directional_trace_candidates(
        normalised, columns, exact, runtime_cfg, candidates
    )
    candidate_signatures = {_line_signature(value["line"]) for value in candidates}
    candidates.extend(
        value
        for value in trace_candidates
        if _line_signature(value["line"]) not in candidate_signatures
    )
    legacy_candidates, legacy_candidate_metrics = recover_legacy_connector_candidates(
        normalised, walls, columns, exact, runtime_cfg
    )
    # New geometry wins exact duplicates; otherwise both sources compete under
    # the same non-competing endpoint rule.
    signatures = {_line_signature(value["line"]) for value in candidates}
    candidates.extend(
        value
        for value in legacy_candidates
        if _line_signature(value["line"]) not in signatures
    )
    candidates.sort(key=lambda value: value["score"], reverse=True)
    observed_connections, inferred_connections, selection_metrics = (
        select_continuity_connections(candidates, runtime_cfg)
    )
    base_for_closure = normalised + observed_connections
    selected_connection_ids = {
        value["connection_id"] for value in observed_connections + inferred_connections
    }
    closure_pool_limit = int(cfg.get("topology_closure_candidate_limit", 1200))
    closure_pool = list(inferred_connections)
    for candidate in candidates:
        if candidate["connection_id"] in selected_connection_ids:
            continue
        if candidate["score"] < float(cfg.get("topology_closure_score_min", 0.30)):
            continue
        closure_pool.append(candidate)
        if len(closure_pool) >= closure_pool_limit:
            break
    virtual = _virtual_opening_candidates(
        base_for_closure,
        observed_connections + inferred_connections,
        cfg,
    )
    recovered_regions, closure_edges, closure_metrics = optimise_closed_regions(
        base_for_closure,
        closure_pool,
        virtual,
        cfg,
    )
    regions = _regions_union(baseline_regions, recovered_regions)
    closure_inferred = [
        value
        for value in closure_edges
        if value.get("status") == "inferred_gap"
        and value.get("connection_id") not in selected_connection_ids
    ]
    openings = [value for value in closure_edges if value.get("status") == "virtual_opening"]
    inferred_connections.extend(closure_inferred)

    final_records, wall_chain_metrics = assign_persistent_wall_chain_ids(
        normalised, observed_connections + inferred_connections
    )
    # Resolve exact L/T nodes after candidate selection.  A one millimetre pass
    # cannot pull a reliable axis; it only writes shared topology and splits a
    # straight host at an exact T projection.
    stable_cfg = dict(cfg)
    stable_cfg["wall_junction_tolerance_m"] = 0.001
    final_records, nodes, node_metrics = update_shared_nodes(final_records, stable_cfg)
    # Node operations may split or shorten records.  Recompute arclength state
    # intervals on the landed geometry so children never inherit a parent's
    # full support range.  These intervals remain attributes of the same
    # physical wall and do not create new topology objects.
    final_records = annotate_wall_support_intervals(final_records, exact)
    observed = [value for value in final_records if value.get("status") == "observed"]
    inferred = [value for value in final_records if value.get("status") != "observed"]
    topology_after = topology_statistics(final_records)

    write_architectural_dxf(
        output / "architectural_plan.dxf", observed, inferred, columns, []
    )
    write_closed_layout_dxf(output / "closed_layout.dxf", regions, closure_edges)
    write_structure_geojson(
        output / "architectural_plan.geojson",
        observed,
        inferred,
        columns,
        [],
        regions,
        nodes,
        transform,
    )
    graph_document = {
        "algorithm": algorithm_name,
        "walls": _records_to_document(observed + inferred),
        "columns": [
            {key: value for key, value in record.items() if key not in {"polygon", "center", "cross_height_consensus_center"}}
            | {
                "center": np.asarray(record["center"]).tolist(),
                "coordinates": np.asarray(record["polygon"].exterior.coords).tolist(),
                "cross_height_consensus_center": (
                    np.asarray(record["cross_height_consensus_center"]).tolist()
                    if record.get("cross_height_consensus_center") is not None
                    else None
                ),
            }
            for record in columns
        ],
        "nodes": nodes,
        "regions": [
            {key: value for key, value in record.items() if key != "polygon"}
            | {"coordinates": np.asarray(record["polygon"].exterior.coords).tolist()}
            for record in regions
        ],
        "virtual_openings": _records_to_document(openings),
    }
    write_json(output / "building_object_graph.json", graph_document)
    evidence = _adapter(exact, exact.raw_mask, exact.raw_mask, {})
    _render_v5_plan(
        output / "architectural_plan.png",
        evidence,
        observed,
        inferred,
        columns,
        openings,
        f"ICPAR {display_name} - {len(normalised)} WALL OBJECTS - {len(observed_connections) + len(inferred_connections)} CONNECTIONS",
    )
    _render_v5_plan(
        output / "closed_layout.png",
        evidence,
        observed,
        inferred,
        columns,
        openings,
        f"ICPAR {display_name} CLOSED LAYOUT - {len(regions)} REGIONS - BLUE=VIRTUAL OPENING",
    )
    comparison_path = output / "v5_v6_topology_comparison.png"
    _write_v5_v6_comparison(
        comparison_path,
        baseline_path.parent / "architectural_plan.png",
        output / "architectural_plan.png",
    )

    baseline_physical = [
        value
        for value in walls
        if value.get("status") in {"observed", "inferred_semantic_object"}
    ]
    final_union = unary_union([value["line"] for value in final_records])
    baseline_samples = np.vstack(
        [
            np.asarray(
                [
                    value["line"].interpolate(position).coords[0]
                    for position in np.linspace(
                        0.0,
                        value["line"].length,
                        max(2, int(math.ceil(value["line"].length / 0.10)) + 1),
                    )
                ]
            )
            for value in baseline_physical
            if value["line"].length > 1e-6
        ]
    )
    retained_fraction = float(
        np.mean([final_union.distance(Point(value)) <= 0.01 for value in baseline_samples])
    )
    observed_connection_metrics = _independent_metrics(observed_connections, exact)
    disk = audit_written_outputs(output)
    acceptance = {
        "baseline_physical_structure_retained_ge_98pct": retained_fraction >= 0.98,
        # This is endpoint coverage in the fixed candidate graph.  It is a
        # useful continuity diagnostic, but it is not a correctness label and
        # must not be described as a human-verified repair rate.
        "candidate_endpoint_coverage_ge_90pct": (
            selection_metrics["repair_rate"] is not None
            and selection_metrics["repair_rate"] >= 0.90
        ),
        "observed_connection_support_ge_95pct": (
            not observed_connections
            or observed_connection_metrics["supported_fraction_10cm"] >= 0.95
        ),
        "observed_connection_p95_le_10cm": (
            not observed_connections
            or (
                observed_connection_metrics["line_to_surface_p95_m"] is not None
                and observed_connection_metrics["line_to_surface_p95_m"] <= 0.10
            )
        ),
        "dangling_nodes_reduced": (
            topology_after["dangling_node_count"] < topology_before["dangling_node_count"]
        ),
        "closed_regions_present": len(regions) > 0,
        "landed_dxf_valid": bool(
            disk["architectural_xdata_count"] == disk["architectural_entity_count"]
            and disk["closed_polylines_self_intersection_count"] == 0
        ),
    }
    if bool(cfg.get("topology_require_independent_opening_audit", False)):
        acceptance["independent_opening_audit_passed"] = bool(
            cfg.get("topology_independent_opening_audit_passed", False)
        )
    report = {
        "algorithm": algorithm_name,
        "recommended": bool(all(acceptance.values())),
        "recommendations": {
            "architectural_wall_plan": bool(all(acceptance.values())),
            "closed_layout": bool(len(regions) > len(baseline_regions)),
            "closed_layout_reason": (
                "new qualified regions recovered"
                if len(regions) > len(baseline_regions)
                else "no new region met the 80 percent measured-boundary gate"
            ),
        },
        "acceptance": acceptance,
        "inputs": {
            "baseline_graph": str(baseline_path),
            "evidence": str(evidence_path),
            "transforms": str(transforms_path),
        },
        "normalisation": normalise_metrics,
        "candidate_generation": candidate_metrics,
        "directional_trace_generation": trace_candidate_metrics,
        "legacy_candidate_recovery": legacy_candidate_metrics,
        "persistent_wall_chains": wall_chain_metrics,
        "connection_selection": selection_metrics,
        "topology_before": topology_before,
        "topology_after": topology_after,
        "baseline_physical_structure_retained_fraction_1cm": retained_fraction,
        "observed_connection_metrics": observed_connection_metrics,
        "closure": closure_metrics | {
            "baseline_region_count": len(baseline_regions),
            "new_region_count": len(regions) - len(baseline_regions),
            "final_region_count": len(regions),
            "virtual_opening_count": len(openings),
        },
        "node_pass": node_metrics,
        "disk_audit": disk,
        "comparison_png": str(comparison_path),
        "interpretation": (
            f"{display_name} rebuilds topology from immutable 3-D evidence and persistent "
            "wall chains; legacy gap connectors are not accepted as final geometry."
        ),
    }
    write_json(output / "structure_report.json", report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Rebuild parking-wall topology and closed spaces")
    parser.add_argument("--config", required=True)
    args = parser.parse_args(argv)
    report = run_topology_v6(args.config)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
