"""GT-free, point-supported wall-face recovery upstream of the joint solver.

Proposals are search corridors, never observations. All accepted coordinates are
fitted to immutable voxel centroids. Height support is pooled in longitudinal
bins, avoiding R309's two-heights-in-one-5cm-pixel skeleton prerequisite.
"""
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path

import ezdxf
import numpy as np
from scipy.spatial import cKDTree
from scipy.signal import find_peaks
from shapely.geometry import LineString, Polygon, Point
from shapely.strtree import STRtree

from .joint_reconstruction_v3 import DEFAULT_CONFIG, digest, unit, make_scene

CONFIG = {**DEFAULT_CONFIG, "schema": "lidar2cad-joint-config/v3", "max_iterations": 12, "design_feedback": True,
    "recovery_search_m": .50, "observation_search_m": .12,
    "recovery_lateral_m": .04, "recovery_bin_m": .25,
    "recovery_min_length_m": .50, "recovery_min_points": 8,
    "recovery_min_height_span_m": .45, "recovery_height_bins": 3,
    "recovery_wall_probability_min": .35, "recovery_min_bin_coverage": .65,
    "recovery_min_vertical_coverage": .50, "recovery_max_p95_m": .04,
    "recovery_direction_deg": 8., "duplicate_face_distance_m": .035,
    "column_buffer_m": .04, "opening_recovery_buffer_m": .08}


class RecoveryEvidence:
    def __init__(self, points, probabilities, config):
        self.points, self.probabilities, self.cfg = points, probabilities, config
        self.eligible = ((probabilities[:, 0] >= config["recovery_wall_probability_min"])
                         & (probabilities[:, 0] >= probabilities[:, 1])
                         & (probabilities[:, 0] >= probabilities[:, 2]))
        self.rows = np.flatnonzero(self.eligible)
        self.tree = cKDTree(points[self.rows, :2])

    def corridor(self, coords, width):
        a, b = np.asarray(coords, float)[[0, -1]]
        length = np.linalg.norm(b-a)
        if length < 1e-6:
            return np.array([], int)
        samples = np.linspace(a, b, max(2, int(np.ceil(length / .4))+1))
        groups = self.tree.query_ball_point(samples, np.hypot(width, .2)+.01)
        local = np.unique([i for g in groups for i in g]).astype(int)
        rows = self.rows[local]
        v = (b-a)/length
        delta = self.points[rows, :2]-a
        keep = ((delta@v >= -.05) & (delta@v <= length+.05)
                & (np.abs(delta@np.array([-v[1], v[0]])) <= width))
        return rows[keep]

    def measure(self, coords, rows=None):
        cfg = self.cfg
        coords = np.asarray(coords, float)
        v = unit(coords); n = np.array([-v[1], v[0]])
        length = np.linalg.norm(coords[-1]-coords[0])
        if rows is None:
            rows = self.corridor(coords, cfg["recovery_lateral_m"])
        delta = self.points[rows, :2]-coords[0]
        along, residual = delta@v, np.abs(delta@n)
        keep = (along >= -.025) & (along <= length+.025) & (residual <= cfg["recovery_lateral_m"])
        rows, along, residual = rows[keep], along[keep], residual[keep]
        nb = max(1, int(np.ceil(length/cfg["recovery_bin_m"])))
        bins = np.minimum(nb-1, np.maximum(0, (along/cfg["recovery_bin_m"]).astype(int)))
        occupied, vertical = [], []
        for i in range(nb):
            z = self.points[rows[bins == i], 2]
            occupied.append(len(z) > 0)
            vertical.append(len(z) >= cfg["recovery_height_bins"] and
                            len(np.unique(np.floor(z/.1))) >= cfg["recovery_height_bins"] and
                            np.ptp(z) >= cfg["recovery_min_height_span_m"])
        z = self.points[rows, 2]
        stats = {"source_voxel_rows": rows.tolist(), "unique_voxel_count": len(rows),
                 "height_span_m": float(np.ptp(z)) if len(z) else 0.,
                 "occupied_fraction": float(np.mean(occupied)),
                 "vertical_fraction": float(np.mean(vertical)),
                 "p95_residual_m": float(np.quantile(residual, .95)) if len(rows) else None,
                 "mean_wall_probability": float(self.probabilities[rows, 0].mean()) if len(rows) else 0.,
                 "mean_vehicle_probability": float(self.probabilities[rows, 2].mean()) if len(rows) else 0.,
                 "height_bins": len(np.unique(np.floor(z/.1))),
                 "evidence_kind": "unique_raw_voxels_local_vertical_plane"}
        reason = "supported"
        for failed, name in [
            (length < cfg["recovery_min_length_m"]-1e-8, "short_structure"),
            (len(rows) < cfg["recovery_min_points"], "insufficient_wall_voxels"),
            (stats["height_span_m"] < cfg["recovery_min_height_span_m"], "insufficient_height_span"),
            (stats["occupied_fraction"] < cfg["recovery_min_bin_coverage"], "fragmented_support"),
            (stats["vertical_fraction"] < cfg["recovery_min_vertical_coverage"], "insufficient_cross_height_support")]:
            if failed:
                reason = name
                break
        return reason, stats

    def recover(self, proposal):
        cfg = self.cfg
        coords = np.asarray(proposal["coordinates"], float)
        width = cfg["recovery_search_m"] if proposal["source_kind"] == "design" else cfg["observation_search_m"]
        rows = self.corridor(coords, width)
        v = unit(coords); n = np.array([-v[1], v[0]])
        offset = (self.points[rows, :2]-coords[0])@n
        # Separate lateral modes before fitting; opposing faces never share a fit.
        fits = []
        # Detect density modes once. Greedy removal in v2 turned the shoulders
        # of a single noisy surface into new parallel planes on later passes.
        edges = np.arange(-width-.04, width+.06, .02)
        counts, edges = np.histogram(offset, edges)
        density = np.convolve(counts, [.25, .5, .25], mode="same")
        peaks, _ = find_peaks(density)
        centers = (edges[peaks]+edges[peaks+1])/2
        if not len(centers): return [], len(rows)
        assignment = np.argmin(np.abs(offset[:, None]-centers), axis=1) if len(rows) else np.array([], int)
        for mode, center in enumerate(centers):
            member = (assignment == mode) & (np.abs(offset-center) <= cfg["recovery_lateral_m"])
            candidates = rows[member]
            if len(candidates) < cfg["recovery_min_points"]:
                continue
            along = (self.points[candidates, :2]-coords[0])@v
            order = np.argsort(along)
            # A support-free longitudinal interval is never filled by a prior.
            groups = np.split(order, np.flatnonzero(np.diff(along[order]) > cfg["recovery_bin_m"])+1)
            for group in groups:
                selected = candidates[group]
                if len(selected) < cfg["recovery_min_points"]:
                    continue
                xy = self.points[selected, :2]
                origin = np.median(xy, axis=0)
                _, _, vt = np.linalg.svd(xy-origin, full_matrices=False)
                tangent = vt[0]
                if tangent@v < 0: tangent = -tangent
                if abs(tangent@v) < np.cos(np.deg2rad(cfg["recovery_direction_deg"])):
                    continue
                normal = np.array([-tangent[1], tangent[0]])
                residual = np.abs((xy-origin)@normal)
                selected = selected[residual <= cfg["recovery_lateral_m"]]
                if len(selected) < cfg["recovery_min_points"]: continue
                xy = self.points[selected, :2]
                origin = np.median(xy, axis=0)
                along_fit = (xy-origin)@tangent
                fitted = [origin+along_fit.min()*tangent, origin+along_fit.max()*tangent]
                reason, support = self.measure(fitted, selected)
                if reason == "supported": fits.append((np.asarray(fitted).tolist(), support))
        return fits, len(rows)


def load_proposals(geojson_path, fusion_path, design):
    proposals = []
    data = json.loads(Path(geojson_path).read_text(encoding="utf-8"))
    for i, f in enumerate(data["features"]):
        if f["geometry"]["type"] != "LineString" or f.get("properties", {}).get("class") != "WALL": continue
        p = f.get("properties", {})
        xy = f["geometry"]["coordinates"]
        for j, (a, b) in enumerate(zip(xy[:-1], xy[1:])):
            if np.linalg.norm(np.asarray(b)[:2]-np.asarray(a)[:2]) < .1: continue
            proposals.append({"proposal_id": f"V6:{p.get('wall_id', i)}:{j}", "source_kind": "v6",
                              "source_properties": p, "coordinates": [a[:2], b[:2]]})
    doc = ezdxf.readfile(fusion_path)
    layers = {"LIDAR_WALL_ON_DESIGN_WALL", "LIDAR_WALL_RECOVERED", "LIDAR_WALL_OBSERVED", "DESIGN_WALL_CONFIRMED"}
    for e in doc.modelspace():
        if e.dxf.layer not in layers: continue
        if e.dxftype() == "LWPOLYLINE": xy = list(e.get_points("xy"))
        elif e.dxftype() == "LINE": xy = [list(e.dxf.start)[:2], list(e.dxf.end)[:2]]
        else: continue
        for j, (a,b) in enumerate(zip(xy[:-1], xy[1:])):
            if np.linalg.norm(np.asarray(b)-a) < .1: continue
            proposals.append({"proposal_id": f"FUSION:{e.dxf.handle}:{j}", "source_kind": "fusion",
                              "source_properties": {"dxf_handle": e.dxf.handle, "layer": e.dxf.layer},
                              "coordinates": [list(a), list(b)]})
    for d in design["wall_segments"]:
        proposals.append({"proposal_id": d["design_segment_id"], "source_kind": "design",
                          "coordinates": list(map(list, d["line"].coords))})
    return proposals


def prepare_scene(walls, columns, design, proposals, evidence, cfg, progress=print):
    """Revalidate R309 and recover missing observed faces, preserving all decisions."""
    scene = make_scene([], columns, design, cfg)
    audits, accepted, rejected, lineage = [], [], [], []
    original = [w for w in walls if w.get("status") != "inferred_gap"]
    scene["initial_r309_walls"] = [{"object_id": w["wall_id"], "coordinates": w["coordinates"]} for w in original]
    column_shapes = [Polygon(c["coordinates"]).buffer(cfg["column_buffer_m"]) for c in columns]
    column_tree = STRtree(column_shapes)
    opening_shapes = [d["line"].buffer(cfg["opening_recovery_buffer_m"]) for d in design["openings"]]
    opening_tree = STRtree(opening_shapes)
    # Index accepted faces incrementally in fixed batches, retaining recent additions.
    indexed, tree = 0, STRtree([])
    def insert(coords, support, proposal, parent_id=None):
        nonlocal indexed, tree
        line = LineString(coords)
        for shapes, spatial in [(column_shapes, column_tree), (opening_shapes, opening_tree)]:
            for idx in spatial.query(line, predicate="intersects"):
                line = line.difference(shapes[int(idx)])
        if len(accepted)-indexed >= 128:
            tree = STRtree([LineString(w["coordinates"]) for w in accepted]); indexed = len(accepted)
        neighbors = [int(i) for i in tree.query(line.buffer(.08))] + list(range(indexed, len(accepted)))
        for i in neighbors:
            prior = accepted[i]
            if abs(unit(coords)@unit(prior["coordinates"])) < np.cos(np.deg2rad(6)): continue
            line = line.difference(LineString(prior["coordinates"]).buffer(cfg["duplicate_face_distance_m"], cap_style=2))
        parts = [line] if line.geom_type == "LineString" else list(getattr(line, "geoms", []))
        ids = []
        for part in parts:
            if part.geom_type != "LineString" or part.length < cfg["recovery_min_length_m"]: continue
            xy = list(map(list, part.coords))
            reason, stats = evidence.measure(xy)
            if reason != "supported": continue
            oid = parent_id if parent_id and len(parts) == 1 else "REC-"+digest([proposal["proposal_id"], xy])[:18]
            w = {"wall_id": oid, "coordinates": xy, "source_voxel_rows": stats["source_voxel_rows"],
                 "status": "raw_voxel_revalidated", "source": proposal["source_kind"],
                 "observed_support_fraction": stats["occupied_fraction"]}
            accepted.append(w); ids.append(oid)
            lineage.append({"object_id": oid, "source_kind": proposal["source_kind"],
                            "proposal_id": proposal["proposal_id"], "proposal_geometry": proposal["coordinates"],
                            "proposal_properties": proposal.get("source_properties", {}), "support": stats,
                            "coordinates": xy, "parent_r309_id": parent_id})
        return ids
    for w in original:
        reason, support = evidence.measure(w["coordinates"])
        proposal = {"proposal_id": w["wall_id"], "source_kind": "r309", "coordinates": w["coordinates"]}
        ids = insert(w["coordinates"], support, proposal, w["wall_id"]) if reason == "supported" else []
        if not ids: rejected.append(w["wall_id"])
        audits.append({**proposal, "decision": "accepted" if ids else (reason if reason != "supported" else "opening_column_or_duplicate"),
                       "output_object_ids": ids, "support": support})
    progress(f"upstream R309: retained {len(accepted)} faces from {len(original)} observed records", flush=True)
    for i, proposal in enumerate(proposals):
        fits, nrows = evidence.recover(proposal)
        ids = []
        for coords, support in fits: ids += insert(coords, support, proposal)
        audits.append({**proposal, "search_wall_voxels": nrows, "validated_fit_count": len(fits),
                       "output_object_ids": ids, "decision": "accepted" if ids else
                       ("opening_column_or_duplicate" if fits else "insufficient_plane_or_cross_height_evidence")})
        if i % 1000 == 0: progress(f"recovery proposals {i}/{len(proposals)}; accepted faces {len(accepted)}", flush=True)
    recovered = make_scene(accepted, [], design, cfg)
    scene["objects"].update(recovered["objects"])
    for row in lineage:
        obj = scene["objects"][row["object_id"]]
        obj["geometry_provenance"] = [{"kind": "raw_voxel_revalidated_face", **{k:v for k,v in row.items() if k != "support"}}]
        obj["support_evidence"].update(row["support"])
        obj["source_lidar_object_ids"] = [row["parent_r309_id"]] if row["parent_r309_id"] else []
        obj["source_geometry_proposal_ids"] = [row["proposal_id"]]
    scene["upstream_recovery"] = {"original_r309_observed_count": len(original),
        "suppressed_r309_count": len(rejected), "accepted_by_source": dict(Counter(r["source_kind"] for r in lineage)),
        "accepted_length_by_source_m": {s: sum(LineString(r["coordinates"]).length for r in lineage if r["source_kind"] == s)
                                        for s in ["r309", "v6", "fusion", "design"]},
        "rejected_r309_object_ids": rejected, "GT_read": False}
    return scene, audits, lineage
