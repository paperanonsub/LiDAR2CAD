"""Evidence-constrained design-assisted structural reconstruction.

The implementation keeps the LiDAR object graph as the measured substrate.
Design geometry supplies correspondence and connection hypotheses, while
three-dimensional source voxels determine interval observation state.  Every
ablation uses one common candidate pool and one conflict selector.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import shutil
import sys
from time import perf_counter
from typing import Any, Iterable

import ezdxf
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Point, Polygon, mapping
from shapely.ops import substring, unary_union
from shapely.strtree import STRtree

from .design_assisted_r309 import (
    _angle_difference,
    _line,
    _load_geojson_lines,
    _read_json,
    _sha256,
    apply_design_intervention,
    load_global_design,
    match_walls_to_design,
)


SCHEMA_VERSION = "lidar2cad-design-assisted-evidence-v2"


def _write_json(path: Path, value: Any) -> None:
    """Stream large audit documents instead of materialising one JSON string."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def _json_value(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    return value


def _line_angle(line: LineString) -> float:
    coordinates = np.asarray(line.coords, dtype=float)
    delta = coordinates[-1, :2] - coordinates[0, :2]
    return math.atan2(float(delta[1]), float(delta[0])) % math.pi


def _angular_difference_deg(first: float, second: float) -> float:
    difference = abs(first - second) % math.pi
    return math.degrees(min(difference, math.pi - difference))


def _sample_positions(line: LineString, step_m: float) -> tuple[np.ndarray, np.ndarray]:
    if line.length <= 1e-12:
        return np.asarray([line.coords[0][:2]], dtype=float), np.asarray([0.0])
    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    positions = np.linspace(0.0, line.length, count)
    points = np.asarray([line.interpolate(value).coords[0][:2] for value in positions])
    return points, positions


def _linear_parts(geometry: Any) -> list[LineString]:
    if isinstance(geometry, LineString):
        return [geometry] if geometry.length > 1e-9 else []
    result: list[LineString] = []
    for part in getattr(geometry, "geoms", []):
        result.extend(_linear_parts(part))
    return result


def _state_at(record: dict[str, Any], position_m: float) -> tuple[str, str, list[int]]:
    intervals = record.get("evidence_intervals", record.get("support_intervals", []))
    for interval in intervals:
        start = float(interval.get("s_start_m", 0.0))
        stop = float(interval.get("s_end_m", start))
        if start - 1e-9 <= position_m <= stop + 1e-9:
            return (
                str(interval.get("state", "unknown")),
                str(interval.get("evidence_strength", "absent")),
                [int(value) for value in interval.get("source_voxel_rows", [])],
            )
    status = str(record.get("status", "unknown"))
    if status == "mixed_evidence":
        status = "unknown"
    if status not in {"observed", "inferred", "unknown"}:
        status = "inferred" if "infer" in status else "unknown"
    return status, str(record.get("evidence_strength", "absent")), []


def _column_polygons(columns: list[dict[str, Any]]) -> list[Polygon]:
    result: list[Polygon] = []
    for column in columns:
        coordinates = column.get("coordinates", column.get("polygon", []))
        try:
            polygon = Polygon(np.asarray(coordinates, dtype=float)[:, :2])
        except (TypeError, ValueError, IndexError):
            continue
        if not polygon.is_empty and polygon.area > 1e-8:
            result.append(polygon)
    return result


def build_common_candidate_pool(
    walls: list[dict[str, Any]],
    *,
    minimum_gap_m: float,
    maximum_gap_m: float,
    maximum_direction_difference_deg: float,
    maximum_design_distance_m: float,
    candidates_per_endpoint: int,
) -> list[dict[str, Any]]:
    """Generate a fixed pool without occupying endpoints during generation."""
    endpoints: list[dict[str, Any]] = []
    for wall in walls:
        correspondence = wall.get("design_correspondence", {})
        if not correspondence.get("matched"):
            continue
        line = _line(wall)
        coordinates = np.asarray(line.coords, dtype=float)[:, :2]
        for endpoint in (0, 1):
            point = coordinates[0 if endpoint == 0 else -1]
            endpoints.append(
                {
                    "point": point,
                    "endpoint": endpoint,
                    "wall": wall,
                    "line": line,
                    "angle": _line_angle(line),
                }
            )
    if not endpoints:
        return []
    endpoint_xy = np.asarray([value["point"] for value in endpoints])
    pairs = cKDTree(endpoint_xy).query_pairs(maximum_gap_m, output_type="ndarray")
    candidates: list[dict[str, Any]] = []
    for first_index, second_index in pairs:
        first = endpoints[int(first_index)]
        second = endpoints[int(second_index)]
        first_wall = first["wall"]
        second_wall = second["wall"]
        if first_wall.get("wall_id") == second_wall.get("wall_id"):
            continue
        connector = LineString([first["point"], second["point"]])
        if not minimum_gap_m <= connector.length <= maximum_gap_m:
            continue
        connector_angle = _line_angle(connector)
        first_direction = _angular_difference_deg(connector_angle, float(first["angle"]))
        second_direction = _angular_difference_deg(connector_angle, float(second["angle"]))
        # Both ends must be directionally compatible.  Using min() here would
        # allow a connector aligned with only one host.
        if max(first_direction, second_direction) > maximum_direction_difference_deg:
            continue
        first_match = first_wall["design_correspondence"]
        second_match = second_wall["design_correspondence"]
        first_surface = str(first_match.get("design_segment_id"))
        second_surface = str(second_match.get("design_segment_id"))
        same_surface = first_surface == second_surface
        design_distance = max(
            float(first_match.get("mean_distance_m", math.inf)),
            float(second_match.get("mean_distance_m", math.inf)),
        )
        if design_distance > maximum_design_distance_m:
            continue
        endpoint_keys = [
            [str(first_wall.get("wall_id")), int(first["endpoint"])],
            [str(second_wall.get("wall_id")), int(second["endpoint"])],
        ]
        signature = json.dumps(sorted(endpoint_keys), separators=(",", ":"))
        connection_id = "DESIGN-CONNECTION-" + hashlib.sha1(signature.encode()).hexdigest()[:16]
        candidates.append(
            {
                "connection_id": connection_id,
                "wall_id": connection_id,
                "coordinates": np.asarray(connector.coords)[:, :2].tolist(),
                "length_m": float(connector.length),
                "endpoint_keys": endpoint_keys,
                "host_wall_ids": [str(first_wall.get("wall_id")), str(second_wall.get("wall_id"))],
                "host_physical_wall_ids": [
                    first_wall.get("physical_wall_id"),
                    second_wall.get("physical_wall_id"),
                ],
                "host_observed_support_fraction": [
                    float(first_wall.get("observed_support_fraction", 0.0)),
                    float(second_wall.get("observed_support_fraction", 0.0)),
                ],
                "host_direction_difference_deg": [first_direction, second_direction],
                "same_design_surface": same_surface,
                "design_surface_ids": [first_surface, second_surface],
                "design_wall_ids": [
                    first_match.get("design_wall_id"),
                    second_match.get("design_wall_id"),
                ],
                "design_distance_m": design_distance,
                "design_support": "shared_surface" if same_surface else "spatial_proximity",
                "source": "design_assisted_candidate",
            }
        )
    candidates.sort(
        key=lambda value: (
            not value["same_design_surface"],
            max(value["host_direction_difference_deg"]),
            value["length_m"],
            value["connection_id"],
        )
    )
    # This is a shared resource bound, not endpoint selection: an endpoint can
    # retain several alternatives and remains free until evidence is audited.
    retained: list[dict[str, Any]] = []
    counts: Counter[tuple[str, int]] = Counter()
    for candidate in candidates:
        keys = [tuple(value) for value in candidate["endpoint_keys"]]
        if any(counts[key] >= candidates_per_endpoint for key in keys):
            continue
        retained.append(candidate)
        for key in keys:
            counts[key] += 1
    return retained


@dataclass
class EvidenceIndex:
    origin: np.ndarray
    grid_m: float
    shape: tuple[int, int]
    xy_cell: np.ndarray
    z_bin: np.ndarray
    centroids: np.ndarray
    wall_probability: np.ndarray
    column_probability: np.ndarray
    vehicle_probability: np.ndarray
    wall_probability_raster: np.ndarray
    vehicle_probability_raster: np.ndarray
    row_wall_code: np.ndarray
    row_surface_code: np.ndarray
    wall_id_to_code: dict[str, int]
    surface_id_to_code: dict[str, int]
    owned_rows: np.ndarray
    owned_tree: cKDTree

    @classmethod
    def load(
        cls,
        evidence_path: Path,
        semantic_path: Path,
        walls: list[dict[str, Any]],
    ) -> "EvidenceIndex":
        with np.load(evidence_path, allow_pickle=False) as values:
            origin = np.asarray(values["origin_xy"], dtype=float)
            grid_m = float(values["grid_m"])
            shape = tuple(int(value) for value in values["shape"])
            xy_cell = np.asarray(values["xy_cell"], dtype=np.int64)
            z_bin = np.asarray(values["z_bin"], dtype=np.int16)
            centroids = np.asarray(values["centroids"], dtype=np.float32)
        with np.load(semantic_path, allow_pickle=False) as values:
            voxel_probability = np.asarray(values["voxel_probability"], dtype=np.float32)
            wall_probability_raster = np.asarray(values["wall_probability"], dtype=np.float32)
            vehicle_probability_raster = np.asarray(values["vehicle_probability"], dtype=np.float32)
        if len(voxel_probability) != len(centroids):
            raise ValueError("semantic voxel rows and exact evidence rows differ")
        row_limit = len(centroids)
        wall_ids = sorted({str(wall.get("wall_id")) for wall in walls})
        surface_ids = sorted(
            {
                str(wall.get("design_correspondence", {}).get("design_segment_id"))
                for wall in walls
                if wall.get("design_correspondence", {}).get("design_segment_id") is not None
            }
        )
        wall_id_to_code = {value: index for index, value in enumerate(wall_ids)}
        surface_id_to_code = {value: index for index, value in enumerate(surface_ids)}
        row_wall_code = np.full(row_limit, -1, dtype=np.int32)
        row_surface_code = np.full(row_limit, -1, dtype=np.int32)
        for wall in walls:
            wall_id = str(wall.get("wall_id"))
            surface = wall.get("design_correspondence", {}).get("design_segment_id")
            rows = np.asarray(wall.get("source_voxel_rows", []), dtype=np.int64)
            rows = rows[(rows >= 0) & (rows < row_limit)]
            if not len(rows):
                continue
            wall_code = wall_id_to_code[wall_id]
            previous = row_wall_code[rows]
            row_wall_code[rows[previous == -1]] = wall_code
            row_wall_code[rows[(previous >= 0) & (previous != wall_code)]] = -2
            if surface is not None:
                surface_code = surface_id_to_code[str(surface)]
                previous = row_surface_code[rows]
                row_surface_code[rows[previous == -1]] = surface_code
                row_surface_code[rows[(previous >= 0) & (previous != surface_code)]] = -2
        wall_probability = voxel_probability[:, 0]
        column_probability = voxel_probability[:, 1]
        vehicle_probability = voxel_probability[:, 2]
        owned_mask = (
            ((row_wall_code >= 0) | (row_surface_code >= 0))
            & (wall_probability >= 0.50)
            & (wall_probability >= column_probability)
            & (wall_probability >= vehicle_probability)
        )
        owned_rows = np.flatnonzero(owned_mask).astype(np.int64)
        if not len(owned_rows):
            raise ValueError("no attributed wall-semantic voxels available")
        return cls(
            origin=origin,
            grid_m=grid_m,
            shape=shape,
            xy_cell=xy_cell,
            z_bin=z_bin,
            centroids=centroids,
            wall_probability=wall_probability,
            column_probability=column_probability,
            vehicle_probability=vehicle_probability,
            wall_probability_raster=wall_probability_raster,
            vehicle_probability_raster=vehicle_probability_raster,
            row_wall_code=row_wall_code,
            row_surface_code=row_surface_code,
            wall_id_to_code=wall_id_to_code,
            surface_id_to_code=surface_id_to_code,
            owned_rows=owned_rows,
            owned_tree=cKDTree(centroids[owned_rows, :2]),
        )

    def audit_candidate(
        self,
        candidate: dict[str, Any],
        *,
        sample_step_m: float,
        support_radius_m: float,
    ) -> dict[str, Any]:
        line = _line(candidate)
        points, positions = _sample_positions(line, sample_step_m)
        host_codes = {
            self.wall_id_to_code[value]
            for value in map(str, candidate.get("host_wall_ids", []))
            if value in self.wall_id_to_code
        }
        shared_surface_code = None
        if candidate.get("same_design_surface"):
            shared_surface_code = self.surface_id_to_code.get(str(candidate["design_surface_ids"][0]))
        samples: list[dict[str, Any]] = []
        vehicle_dominant = 0
        incompatible = 0
        neighbours = self.owned_tree.query_ball_point(points, support_radius_m)
        for point, position, local_neighbours in zip(points, positions, neighbours):
            rows = self.owned_rows[np.asarray(local_neighbours, dtype=np.int64)]
            if len(rows):
                wall_compatible = np.isin(self.row_wall_code[rows], list(host_codes))
                surface_compatible = (
                    self.row_surface_code[rows] == shared_surface_code
                    if shared_surface_code is not None else np.zeros(len(rows), dtype=bool)
                )
                mask = wall_compatible | surface_compatible
                compatible = rows[mask].astype(int).tolist()
                foreign = rows[~mask].astype(int).tolist()
            else:
                compatible, foreign = [], []
            pixel = np.floor((point - self.origin) / self.grid_m).astype(np.int64)
            if (
                0 <= pixel[0] < self.shape[1]
                and 0 <= pixel[1] < self.shape[0]
                and self.vehicle_probability_raster[pixel[1], pixel[0]] >= 0.50
                and self.vehicle_probability_raster[pixel[1], pixel[0]]
                > self.wall_probability_raster[pixel[1], pixel[0]]
            ):
                vehicle_dominant += 1
            if foreign:
                incompatible += 1
            strong_rows = [row for row in compatible if self.wall_probability[row] >= 0.80]
            weak_rows = [row for row in compatible if self.wall_probability[row] >= 0.50]
            strong_bins = len(set(int(self.z_bin[row]) for row in strong_rows))
            weak_bins = len(set(int(self.z_bin[row]) for row in weak_rows))
            if strong_bins >= 3:
                state, strength, source_rows = "observed", "strong", strong_rows
            elif weak_bins >= 2:
                state, strength, source_rows = "observed", "weak", weak_rows
            else:
                state, strength, source_rows = "unknown", "absent", []
            samples.append(
                {
                    "position_m": float(position),
                    "state": state,
                    "evidence_strength": strength,
                    "source_voxel_rows": sorted(set(map(int, source_rows))),
                    "compatible_row_count": len(compatible),
                    "foreign_row_count": len(foreign),
                }
            )
        intervals: list[dict[str, Any]] = []
        for index, sample in enumerate(samples):
            start = 0.0 if index == 0 else 0.5 * (positions[index - 1] + positions[index])
            stop = line.length if index == len(samples) - 1 else 0.5 * (positions[index] + positions[index + 1])
            key = (sample["state"], sample["evidence_strength"])
            if intervals and (intervals[-1]["state"], intervals[-1]["evidence_strength"]) == key:
                intervals[-1]["s_end_m"] = float(stop)
                intervals[-1]["source_voxel_rows"] = sorted(
                    set(intervals[-1]["source_voxel_rows"]) | set(sample["source_voxel_rows"])
                )
            else:
                intervals.append(
                    {
                        "s_start_m": float(start),
                        "s_end_m": float(stop),
                        "state": sample["state"],
                        "evidence_strength": sample["evidence_strength"],
                        "source_voxel_rows": sample["source_voxel_rows"],
                    }
                )
        observed_length = sum(
            interval["s_end_m"] - interval["s_start_m"]
            for interval in intervals
            if interval["state"] == "observed"
        )
        count = max(1, len(samples))
        return {
            "evidence_intervals": intervals,
            "observed_length_m": float(observed_length),
            "observed_fraction": float(observed_length / line.length) if line.length else 0.0,
            "strong_sample_fraction": sum(value["evidence_strength"] == "strong" for value in samples) / count,
            "weak_sample_fraction": sum(value["evidence_strength"] == "weak" for value in samples) / count,
            "incompatible_sample_fraction": incompatible / count,
            "vehicle_dominant_sample_fraction": vehicle_dominant / count,
            "source_voxel_rows": sorted(
                {row for interval in intervals for row in interval["source_voxel_rows"]}
            ),
            "source_attribution_required": True,
            "vehicle_probability_is_diagnostic_only": True,
        }


def audit_static_conflicts(
    candidates: list[dict[str, Any]],
    walls: list[dict[str, Any]],
    openings: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    *,
    opening_buffer_m: float,
    wall_crossing_tolerance_m: float,
) -> None:
    wall_lines = [_line(value) for value in walls]
    wall_tree = STRtree(wall_lines)
    wall_ids = [str(value.get("wall_id")) for value in walls]
    opening_lines = [value["line"] for value in openings]
    opening_tree = STRtree(opening_lines) if opening_lines else None
    column_polygons = _column_polygons(columns)
    column_tree = STRtree(column_polygons) if column_polygons else None
    for candidate in candidates:
        line = _line(candidate)
        host_ids = set(map(str, candidate["host_wall_ids"]))
        conflicts: list[str] = []
        opening_ids: list[str] = []
        if opening_tree is not None:
            for raw_index in opening_tree.query(line.buffer(opening_buffer_m)):
                index = int(raw_index)
                if line.distance(opening_lines[index]) <= opening_buffer_m:
                    opening_ids.append(str(openings[index]["design_opening_id"]))
        if opening_ids:
            conflicts.append("design_opening")
        for raw_index in wall_tree.query(line.buffer(wall_crossing_tolerance_m)):
            index = int(raw_index)
            if wall_ids[index] in host_ids:
                continue
            other = wall_lines[index]
            intersection = line.intersection(other)
            if intersection.is_empty:
                continue
            if line.overlaps(other) or line.crosses(other):
                conflicts.append("existing_wall_crossing")
                break
            for point in [value for value in getattr(intersection, "geoms", [intersection]) if isinstance(value, Point)]:
                if min(point.distance(Point(line.coords[0])), point.distance(Point(line.coords[-1]))) > wall_crossing_tolerance_m:
                    conflicts.append("existing_wall_interior_attachment")
                    break
            if conflicts and conflicts[-1].startswith("existing_wall"):
                break
        if column_tree is not None:
            for raw_index in column_tree.query(line):
                if line.crosses(column_polygons[int(raw_index)]) or line.within(column_polygons[int(raw_index)]):
                    conflicts.append("column_crossing")
                    break
        candidate["static_conflicts"] = sorted(set(conflicts))
        candidate["near_design_opening_ids"] = opening_ids


def _eligible_decision(
    candidate: dict[str, Any],
    *,
    use_design_identity: bool,
    use_field_evidence: bool,
    minimum_observed_fraction: float,
    minimum_endpoint_context: float,
    maximum_incompatible_fraction: float,
) -> tuple[bool, str, str]:
    if candidate.get("static_conflicts"):
        return False, "unknown", "rejected_static_conflict"
    if use_design_identity and not candidate.get("same_design_surface"):
        return False, "unknown", "rejected_design_surface_identity"
    evidence = candidate["field_evidence"]
    observed = float(evidence["observed_fraction"])
    incompatible = float(evidence["incompatible_sample_fraction"])
    context = min(map(float, candidate.get("host_observed_support_fraction", [0.0, 0.0])))
    if not use_field_evidence:
        return True, "inferred", "accepted_without_field_evidence_constraint"
    if observed >= minimum_observed_fraction and incompatible <= maximum_incompatible_fraction:
        return True, "observed" if observed >= 0.95 else "inferred", "accepted_attributed_3d_evidence"
    if (
        use_design_identity
        and context >= minimum_endpoint_context
        and incompatible <= maximum_incompatible_fraction
    ):
        return True, "inferred", "accepted_design_continuation_with_observed_hosts"
    return False, "unknown", "rejected_insufficient_attributed_evidence"


def select_candidates(
    candidates: list[dict[str, Any]],
    *,
    use_design_identity: bool,
    use_field_evidence: bool,
    minimum_observed_fraction: float,
    minimum_endpoint_context: float,
    maximum_incompatible_fraction: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    audited: list[dict[str, Any]] = []
    for source in candidates:
        candidate = deepcopy(source)
        eligible, state, reason = _eligible_decision(
            candidate,
            use_design_identity=use_design_identity,
            use_field_evidence=use_field_evidence,
            minimum_observed_fraction=minimum_observed_fraction,
            minimum_endpoint_context=minimum_endpoint_context,
            maximum_incompatible_fraction=maximum_incompatible_fraction,
        )
        candidate.update(
            {
                "eligible_before_conflict_selection": eligible,
                "provisional_state": state,
                "decision": reason,
                "selected": False,
            }
        )
        audited.append(candidate)
    ordered = sorted(
        [value for value in audited if value["eligible_before_conflict_selection"]],
        key=lambda value: (
            value["provisional_state"] != "observed",
            -float(value["field_evidence"]["observed_fraction"]),
            not value["same_design_surface"],
            value["length_m"],
            value["connection_id"],
        ),
    )
    used_endpoints: set[tuple[str, int]] = set()
    selected: list[dict[str, Any]] = []
    for candidate in ordered:
        keys = [tuple(value) for value in candidate["endpoint_keys"]]
        if any(key in used_endpoints for key in keys):
            candidate["decision"] = "rejected_endpoint_conflict"
            continue
        line = _line(candidate)
        if any(line.crosses(_line(value)) or line.overlaps(_line(value)) for value in selected):
            candidate["decision"] = "rejected_connection_crossing"
            continue
        candidate["selected"] = True
        candidate["status"] = candidate["provisional_state"]
        intervals = deepcopy(candidate["field_evidence"]["evidence_intervals"])
        for interval in intervals:
            if interval["state"] == "unknown":
                interval["state"] = "inferred" if candidate["status"] == "inferred" else "unknown"
        candidate["evidence_intervals"] = intervals
        candidate["support_intervals"] = deepcopy(intervals)
        candidate["source_voxel_rows"] = list(candidate["field_evidence"]["source_voxel_rows"])
        candidate["physical_wall_id"] = (
            candidate["host_physical_wall_ids"][0]
            if len(set(map(str, candidate["host_physical_wall_ids"]))) == 1
            else candidate["connection_id"]
        )
        selected.append(candidate)
        used_endpoints.update(keys)
    return selected, audited


def node_final_network(
    base_walls: list[dict[str, Any]], selected: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Assign shared endpoint nodes without turning evidence intervals into objects.

    The input object graph has already been noded.  Added hypotheses connect
    two existing endpoints, and the conflict audit rejects wall-interior and
    connection crossings.  Re-unioning the whole 13k-edge scene for every
    ablation is therefore redundant and can create unnecessary numerical
    fragments; incremental noding is both exact for this candidate model and
    preserves the original evidence intervals.
    """
    edges: list[dict[str, Any]] = []
    for source in base_walls + selected:
        edge = dict(source)
        edge["coordinates"] = np.asarray(_line(source).coords, dtype=float)[:, :2].tolist()
        edge["source_wall_id"] = source.get("wall_id")
        edge["source"] = (
            "accepted_design_connection" if source.get("selected")
            else source.get("source", "lidar_wall")
        )
        edge["node_ids"] = []
        edges.append(edge)
    nodes: dict[tuple[int, int], dict[str, Any]] = {}
    for edge in edges:
        for endpoint, coordinate in enumerate((edge["coordinates"][0], edge["coordinates"][-1])):
            key = (round(float(coordinate[0]) / 0.001), round(float(coordinate[1]) / 0.001))
            node = nodes.setdefault(
                key,
                {
                    "node_id": f"NODE-{len(nodes):06d}",
                    "coordinates": [float(coordinate[0]), float(coordinate[1])],
                    "incident_wall_ids": [],
                },
            )
            node["incident_wall_ids"].append(edge["wall_id"])
            edge["node_ids"].append(node["node_id"])
    for node in nodes.values():
        node["degree"] = len(node["incident_wall_ids"])
    return edges, list(nodes.values())


def network_diagnostics(
    records: list[dict[str, Any]], *, union_length_m: float | None = None,
    duplicate_length_m: float | None = None,
) -> dict[str, Any]:
    lines = [_line(value) for value in records]
    total_input = float(sum(line.length for line in lines))
    if union_length_m is None or duplicate_length_m is None:
        unique: dict[tuple[tuple[float, float], ...], float] = {}
        for line in lines:
            coordinates = tuple(tuple(map(float, np.round(value[:2], 6))) for value in line.coords)
            signature = min(coordinates, tuple(reversed(coordinates)))
            unique.setdefault(signature, float(line.length))
        unique_length = float(sum(unique.values()))
        union_length_m = unique_length
        duplicate_length_m = max(0.0, total_input - unique_length)
    state_lengths: Counter[str] = Counter()
    for record, line in zip(records, lines):
        state_lengths[str(record.get("status", "unknown"))] += float(line.length)
    nodes: Counter[tuple[float, float]] = Counter()
    for line in lines:
        nodes[tuple(np.round(line.coords[0][:2], 3))] += 1
        nodes[tuple(np.round(line.coords[-1][:2], 3))] += 1
    return {
        "input_line_count": len(lines),
        "input_length_m": total_input,
        "unique_geometry_length_m": union_length_m,
        "exact_duplicate_length_m": duplicate_length_m,
        "noded_edge_count": len(lines),
        "dangling_node_count": sum(value == 1 for value in nodes.values()),
        "state_input_length_m": dict(state_lengths),
    }


def exact_design_conformance(
    records: list[dict[str, Any]], design_segments: list[dict[str, Any]]
) -> dict[str, Any]:
    def signature(line: LineString) -> tuple[tuple[float, float], ...]:
        coordinates = tuple(tuple(map(float, np.round(value[:2], 6))) for value in line.coords)
        reverse = tuple(reversed(coordinates))
        return min(coordinates, reverse)

    def unique_lines(lines: list[LineString]) -> tuple[list[LineString], float]:
        unique: dict[tuple[tuple[float, float], ...], LineString] = {}
        for line in lines:
            unique.setdefault(signature(line), line)
        input_length = float(sum(line.length for line in lines))
        unique_length = float(sum(line.length for line in unique.values()))
        return list(unique.values()), max(0.0, input_length - unique_length)

    def covered_length(source: list[LineString], target: list[LineString], tolerance: float) -> float:
        if not source or not target:
            return 0.0
        tree = STRtree(target)
        total = 0.0
        for line in source:
            indices = [
                int(value)
                for value in tree.query(line.buffer(tolerance).envelope)
                if line.distance(target[int(value)]) <= tolerance
            ]
            if not indices:
                continue
            local_cover = unary_union(
                [target[index].buffer(tolerance, cap_style=2, join_style=2) for index in indices]
            )
            total += float(line.intersection(local_cover).length)
        return total

    output_input_lines = [_line(value) for value in records]
    design_input_lines = [value["line"] for value in design_segments]
    output_lines, output_duplicate = unique_lines(output_input_lines)
    design_lines, design_duplicate = unique_lines(design_input_lines)
    output_length = float(sum(value.length for value in output_lines))
    design_length = float(sum(value.length for value in design_lines))
    result: dict[str, Any] = {
        "interpretation": "design correspondence diagnostic; not field-truth accuracy",
        "coverage_measure": "length intersection against locally buffered indexed target lines",
        "output_unique_length_m": output_length,
        "design_unique_length_m": design_length,
        "output_exact_duplicate_length_m": output_duplicate,
        "design_exact_duplicate_length_m": design_duplicate,
    }
    for tolerance in (0.05, 0.10, 0.15):
        output_supported = covered_length(output_lines, design_lines, tolerance)
        design_covered = covered_length(design_lines, output_lines, tolerance)
        result[f"{tolerance:.2f}"] = {
            "output_supported_length_m": output_supported,
            "output_supported_fraction": output_supported / output_length if output_length else None,
            "design_covered_length_m": design_covered,
            "design_covered_fraction": design_covered / design_length if design_length else None,
        }
    return result


def _feature_collection(records: list[dict[str, Any]], metadata: dict[str, Any]) -> dict[str, Any]:
    features = []
    for record in records:
        compact_keys = (
            "wall_id",
            "physical_wall_id",
            "status",
            "evidence_strength",
            "source",
            "source_wall_id",
            "design_support",
            "observed_support_fraction",
            "host_wall_ids",
            "node_ids",
        )
        properties = {
            key: _json_value(record[key])
            for key in compact_keys
            if record.get(key) is not None
        }
        features.append(
            {
                "type": "Feature",
                "geometry": mapping(_line(record)),
                "properties": properties,
            }
        )
    return {"type": "FeatureCollection", "metadata": _json_value(metadata), "features": features}


def _write_dxf(path: Path, records: list[dict[str, Any]], design_segments: list[dict[str, Any]]) -> None:
    document = ezdxf.new("R2018")
    for name, color, linetype in (
        ("OBSERVED_WALL", 5, "CONTINUOUS"),
        ("INFERRED_WALL", 30, "DASHED"),
        ("UNKNOWN_WALL", 8, "DOTTED"),
        ("DESIGN_REFERENCE", 4, "DASHDOT"),
    ):
        if name not in document.layers:
            document.layers.add(name, color=color, linetype=linetype)
    model = document.modelspace()
    for record in records:
        line = _line(record)
        intervals = record.get("evidence_intervals", record.get("support_intervals", []))
        if intervals:
            for interval in intervals:
                start = float(np.clip(interval.get("s_start_m", 0.0), 0.0, line.length))
                stop = float(np.clip(interval.get("s_end_m", line.length), 0.0, line.length))
                if stop - start <= 1e-9:
                    continue
                part = substring(line, start, stop)
                if not isinstance(part, LineString) or part.length <= 1e-9:
                    continue
                state = str(interval.get("state", "unknown")).upper()
                layer = f"{state}_WALL" if state in {"OBSERVED", "INFERRED", "UNKNOWN"} else "UNKNOWN_WALL"
                model.add_lwpolyline(list(part.coords), dxfattribs={"layer": layer})
        else:
            state = str(record.get("status", "unknown")).upper()
            layer = f"{state}_WALL" if state in {"OBSERVED", "INFERRED", "UNKNOWN"} else "UNKNOWN_WALL"
            model.add_lwpolyline(record["coordinates"], dxfattribs={"layer": layer})
    for segment in design_segments:
        model.add_lwpolyline(list(segment["line"].coords), dxfattribs={"layer": "DESIGN_REFERENCE"})
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def _copy_base_artifacts(base_run: Path, run: Path) -> None:
    for name in ("height_fragment_graph.json", "associated_wall_objects.json"):
        source = base_run / name
        if source.exists():
            shutil.copy2(source, run / name)
    fragment = run / "height_fragment_graph.json"
    if not fragment.exists():
        _write_json(fragment, {"schema": SCHEMA_VERSION, "fragments": []})


def _support_interval_summary(record: dict[str, Any]) -> dict[str, Any]:
    intervals = record.get("support_intervals", [])
    lengths: Counter[str] = Counter()
    strengths: Counter[str] = Counter()
    for interval in intervals:
        length = max(
            0.0,
            float(interval.get("s_end_m", 0.0)) - float(interval.get("s_start_m", 0.0)),
        )
        lengths[str(interval.get("state", "unknown"))] += length
        strengths[str(interval.get("evidence_strength", "absent"))] += length
    return {
        "interval_count": len(intervals),
        "state_length_m": dict(lengths),
        "strength_length_m": dict(strengths),
    }


def _compact_base_walls(
    walls: list[dict[str, Any]], *, source_path: str, source_sha256: str
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for wall in walls:
        result.append(
            {
                "wall_id": wall.get("wall_id"),
                "physical_wall_id": wall.get("physical_wall_id"),
                "coordinates": wall.get("coordinates"),
                "status": wall.get("status", "unknown"),
                "source": wall.get("source", "lidar_wall"),
                "observed_support_fraction": wall.get("observed_support_fraction"),
                "design_correspondence": wall.get("design_correspondence"),
                "support_interval_summary": _support_interval_summary(wall),
                "support_intervals_reference": {
                    "source_object_graph": source_path,
                    "source_object_graph_sha256": source_sha256,
                    "source_wall_id": wall.get("wall_id"),
                },
            }
        )
    return result


def _compact_candidate_decision(candidate: dict[str, Any]) -> dict[str, Any]:
    evidence = candidate.get("field_evidence", {})
    return {
        key: _json_value(candidate.get(key))
        for key in (
            "connection_id",
            "wall_id",
            "coordinates",
            "length_m",
            "endpoint_keys",
            "host_wall_ids",
            "same_design_surface",
            "design_surface_ids",
            "design_support",
            "static_conflicts",
            "near_design_opening_ids",
            "eligible_before_conflict_selection",
            "provisional_state",
            "decision",
            "selected",
        )
    } | {
        "field_evidence_summary": {
            key: _json_value(evidence.get(key))
            for key in (
                "observed_length_m",
                "observed_fraction",
                "strong_sample_fraction",
                "weak_sample_fraction",
                "incompatible_sample_fraction",
                "vehicle_dominant_sample_fraction",
                "source_attribution_required",
                "vehicle_probability_is_diagnostic_only",
            )
        }
    }


def _compact_selected_connection(candidate: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "connection_id",
        "wall_id",
        "physical_wall_id",
        "coordinates",
        "length_m",
        "status",
        "evidence_strength",
        "source",
        "source_voxel_rows",
        "evidence_intervals",
        "support_intervals",
        "design_support",
        "design_surface_ids",
        "host_wall_ids",
        "host_physical_wall_ids",
        "endpoint_keys",
        "decision",
        "selected",
    )
    return {key: deepcopy(candidate.get(key)) for key in keys if candidate.get(key) is not None}


def write_variant(
    run: Path,
    *,
    name: str,
    base_graph: dict[str, Any],
    base_walls: list[dict[str, Any]],
    selected: list[dict[str, Any]],
    audited: list[dict[str, Any]],
    design_segments: list[dict[str, Any]],
    metadata: dict[str, Any],
    base_run: Path,
) -> dict[str, Any]:
    run.mkdir(parents=True, exist_ok=True)
    object_graph_input = metadata["inputs"]["object_graph"]
    compact_base = _compact_base_walls(
        base_walls,
        source_path=str(object_graph_input["path"]),
        source_sha256=str(object_graph_input["sha256"]),
    )
    selected_graph = [_compact_selected_connection(value) for value in selected]
    noded_walls, nodes = node_final_network(compact_base, selected_graph)
    graph = {
        "algorithm": "LiDAR2CAD design-assisted evidence-constrained reconstruction",
        "schema_version": SCHEMA_VERSION,
        "variant": name,
        "evidence_reference": deepcopy(base_graph.get("evidence_reference", {})),
        "source_graph_reference": object_graph_input,
        "walls": noded_walls,
        "accepted_connection_ids": [value["connection_id"] for value in selected],
        "nodes": nodes,
        "columns": deepcopy(base_graph.get("columns", [])),
        "uncertain_columns": deepcopy(base_graph.get("uncertain_columns", [])),
        "design_reference": {
            "included_in_reconstruction_metrics": False,
            "segment_count": len(design_segments),
        },
        "run_metadata": _json_value(metadata),
    }
    _write_json(run / "building_object_graph.json", graph)
    _write_json(
        run / "candidate_audit.json",
        {
            "schema_version": SCHEMA_VERSION,
            "variant": name,
            "common_candidate_pool_reference": "../../common_candidate_pool.json",
            "candidates": [_compact_candidate_decision(value) for value in audited],
            "selected_connection_ids": [value["connection_id"] for value in selected],
        },
    )
    _write_json(run / "architectural_plan.geojson", _feature_collection(noded_walls, metadata))
    # DXF receives full base intervals so display layers retain the original
    # evidence segmentation.  The JSON graph stores a hashed reference rather
    # than copying the 0.86 GB source graph into every ablation.
    _write_dxf(run / "architectural_plan.dxf", base_walls + selected, design_segments)
    _copy_base_artifacts(base_run, run)
    return {
        "selected_count": len(selected),
        "selected_length_m": float(sum(_line(value).length for value in selected)),
        "decisions": dict(Counter(value["decision"] for value in audited)),
        "network": network_diagnostics(noded_walls),
        "design_conformance": {"status": "optional_diagnostic_not_run_by_default"},
    }


def _direct_design_records(design_segments: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "wall_id": str(value["design_segment_id"]),
            "physical_wall_id": str(value["design_wall_id"]),
            "coordinates": np.asarray(value["line"].coords)[:, :2].tolist(),
            "status": "inferred",
            "evidence_strength": "absent",
            "source_voxel_rows": [],
            "source": "design_direct_baseline",
            "design_support": "design_only",
        }
        for value in design_segments
    ]


def _write_direct_design_variant(
    run: Path,
    records: list[dict[str, Any]],
    base_graph: dict[str, Any],
    design_segments: list[dict[str, Any]],
    metadata: dict[str, Any],
    base_run: Path,
) -> dict[str, Any]:
    run.mkdir(parents=True, exist_ok=True)
    graph = {
        "algorithm": "Direct design baseline",
        "schema_version": SCHEMA_VERSION,
        "variant": "design_direct_baseline",
        "evidence_reference": deepcopy(base_graph.get("evidence_reference", {})),
        "walls": records,
        "nodes": [],
        "columns": [],
        "run_metadata": _json_value(metadata),
    }
    _write_json(run / "building_object_graph.json", graph)
    _write_json(run / "candidate_audit.json", {"schema_version": SCHEMA_VERSION, "candidates": []})
    _write_json(run / "architectural_plan.geojson", _feature_collection(records, metadata))
    _write_dxf(run / "architectural_plan.dxf", records, [])
    _copy_base_artifacts(base_run, run)
    return {
        "selected_count": len(records),
        "selected_length_m": float(sum(_line(value).length for value in records)),
        "network": network_diagnostics(records),
        "design_conformance": {"status": "optional_diagnostic_not_run_by_default"},
        "field_accuracy_status": "pending_complete_region_reference",
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    started = perf_counter()
    paths = {
        name: Path(getattr(args, name)).resolve()
        for name in (
            "object_graph",
            "geometry_geojson",
            "semantic_geojson",
            "evidence",
            "semantic_cache",
            "design_architecture",
            "alignment",
        )
    }
    for name, path in paths.items():
        if not path.is_file():
            raise FileNotFoundError(f"{name}: {path}")
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    base_run = paths["object_graph"].parent
    graph = _read_json(paths["object_graph"])
    expected = graph.get("evidence_reference", {}).get("cache_sha256")
    evidence_sha = _sha256(paths["evidence"])
    if expected and str(expected).lower() != evidence_sha.lower():
        raise ValueError("object graph and exact evidence fingerprints differ")

    timings: dict[str, float] = {}
    phase = perf_counter()
    design = load_global_design(paths["design_architecture"], paths["alignment"])
    design = apply_design_intervention(
        design,
        drop_fraction=float(args.design_drop_fraction),
        perturb_x_m=float(args.design_perturb_x_m),
        perturb_y_m=float(args.design_perturb_y_m),
        seed=int(args.design_intervention_seed),
    )
    base_walls, matches = match_walls_to_design(
        list(graph["walls"]),
        design["wall_segments"],
        maximum_distance_m=float(args.match_distance_m),
        maximum_direction_difference_deg=float(args.direction_tolerance_deg),
    )
    timings["design_correspondence"] = perf_counter() - phase

    phase = perf_counter()
    candidates = build_common_candidate_pool(
        base_walls,
        minimum_gap_m=float(args.gap_min_m),
        maximum_gap_m=float(args.gap_max_m),
        maximum_direction_difference_deg=float(args.direction_tolerance_deg),
        maximum_design_distance_m=float(args.match_distance_m),
        candidates_per_endpoint=int(args.candidates_per_endpoint),
    )
    evidence_index = EvidenceIndex.load(paths["evidence"], paths["semantic_cache"], base_walls)
    for candidate in candidates:
        candidate["field_evidence"] = evidence_index.audit_candidate(
            candidate,
            sample_step_m=float(args.evidence_step_m),
            support_radius_m=float(args.evidence_radius_m),
        )
    audit_static_conflicts(
        candidates,
        base_walls,
        design["openings"],
        list(graph.get("columns", [])),
        opening_buffer_m=float(args.opening_buffer_m),
        wall_crossing_tolerance_m=float(args.wall_crossing_tolerance_m),
    )
    timings["common_candidate_and_evidence_audit"] = perf_counter() - phase

    variants = {
        "proximity_without_evidence": (False, False),
        "proximity_with_evidence": (False, True),
        "identity_without_evidence": (True, False),
        "complete_method": (True, True),
    }
    source_map = {
        name: {"path": str(path), "sha256": _sha256(path)} for name, path in paths.items()
    }
    metadata = {
        "schema_version": SCHEMA_VERSION,
        "implementation": {
            "module": __name__,
            "path": str(Path(__file__).resolve()),
            "sha256": _sha256(Path(__file__).resolve()),
            "python": sys.version,
        },
        "inputs": source_map,
        "registration": design["registration"],
        "parameters": _json_value(vars(args)),
        "design_reference_excluded_from_reconstruction_metrics": True,
    }
    summaries: dict[str, Any] = {}
    phase = perf_counter()
    variant_root = output / "variants"
    for name, (use_identity, use_evidence) in variants.items():
        selected, audited = select_candidates(
            candidates,
            use_design_identity=use_identity,
            use_field_evidence=use_evidence,
            minimum_observed_fraction=float(args.minimum_observed_fraction),
            minimum_endpoint_context=float(args.minimum_endpoint_context),
            maximum_incompatible_fraction=float(args.maximum_incompatible_fraction),
        )
        summaries[name] = write_variant(
            variant_root / name,
            name=name,
            base_graph=graph,
            base_walls=base_walls,
            selected=selected,
            audited=audited,
            design_segments=design["wall_segments"],
            metadata={**metadata, "factors": {"design_identity": use_identity, "field_evidence": use_evidence}},
            base_run=base_run,
        )
    direct_records = _direct_design_records(design["wall_segments"])
    summaries["design_direct_baseline"] = _write_direct_design_variant(
        variant_root / "design_direct_baseline",
        direct_records,
        graph,
        design["wall_segments"],
        metadata,
        base_run,
    )
    timings["selection_noding_and_export"] = perf_counter() - phase

    geometry_records = _load_geojson_lines(paths["geometry_geojson"])
    semantic_records = _load_geojson_lines(paths["semantic_geojson"])
    summaries["lidar_geometry_baseline"] = {
        "network": network_diagnostics(geometry_records),
        "design_conformance": {"status": "optional_diagnostic_not_run_by_default"},
    }
    summaries["lidar_semantic_baseline"] = {
        "network": network_diagnostics(semantic_records),
        "design_conformance": {"status": "optional_diagnostic_not_run_by_default"},
    }
    timings["total"] = perf_counter() - started
    truth_files = sorted((Path(args.region_truth_package) / "truth").glob("*.json")) if args.region_truth_package else []
    complete_truth = 0
    for path in truth_files:
        try:
            complete_truth += _read_json(path).get("annotation", {}).get("status") == "complete"
        except (OSError, json.JSONDecodeError):
            continue
    metrics = {
        "schema_version": SCHEMA_VERSION,
        "field_accuracy_status": "available" if complete_truth else "pending_complete_region_reference",
        "complete_region_reference_count": int(complete_truth),
        "candidate_pool": {
            "count": len(candidates),
            "same_design_surface_count": sum(value["same_design_surface"] for value in candidates),
            "static_conflict_count": sum(bool(value.get("static_conflicts")) for value in candidates),
            "directly_observed_candidate_count": sum(value["field_evidence"]["observed_fraction"] > 0 for value in candidates),
            "vehicle_probability_used_for_acceptance": False,
        },
        "design_correspondence": {
            "lidar_wall_count": len(base_walls),
            "matched_wall_count": len(matches),
            "matched_wall_length_m": float(sum(value["wall_length_m"] for value in matches)),
        },
        "variants": summaries,
        "runtime_seconds": timings,
        "interpretation_limits": [
            "design conformance is not field-truth accuracy",
            "field precision and recall remain pending until region references are complete",
            "vehicle probability is reported only as interference context and never accepts a wall",
        ],
    }
    _write_json(output / "metrics.json", metrics)
    _write_json(
        output / "common_candidate_pool.json",
        {"schema_version": SCHEMA_VERSION, "candidates": candidates},
    )
    manifest = {
        **metadata,
        "outputs": {
            "metrics": str(output / "metrics.json"),
            "common_candidate_pool": str(output / "common_candidate_pool.json"),
            "variants": {name: str((variant_root / name).resolve()) for name in summaries if (variant_root / name).exists()},
        },
        "runtime_seconds": timings,
        "cache_policy": "all design candidates and evidence classifications regenerated for this run",
    }
    _write_json(output / "manifest.json", manifest)
    _write_json(output / "design_correspondences.json", {"schema_version": SCHEMA_VERSION, "matches": matches})
    return metrics


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--object-graph", required=True)
    parser.add_argument("--geometry-geojson", required=True)
    parser.add_argument("--semantic-geojson", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--semantic-cache", required=True)
    parser.add_argument("--design-architecture", required=True)
    parser.add_argument("--alignment", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--region-truth-package")
    parser.add_argument("--match-distance-m", type=float, default=0.50)
    parser.add_argument("--direction-tolerance-deg", type=float, default=12.0)
    parser.add_argument("--gap-min-m", type=float, default=0.15)
    parser.add_argument("--gap-max-m", type=float, default=3.00)
    parser.add_argument("--candidates-per-endpoint", type=int, default=4)
    parser.add_argument("--evidence-step-m", type=float, default=0.05)
    parser.add_argument("--evidence-radius-m", type=float, default=0.08)
    parser.add_argument("--minimum-observed-fraction", type=float, default=0.35)
    parser.add_argument("--minimum-endpoint-context", type=float, default=0.60)
    parser.add_argument("--maximum-incompatible-fraction", type=float, default=0.20)
    parser.add_argument("--opening-buffer-m", type=float, default=0.20)
    parser.add_argument("--wall-crossing-tolerance-m", type=float, default=0.05)
    parser.add_argument("--design-drop-fraction", type=float, default=0.0)
    parser.add_argument("--design-perturb-x-m", type=float, default=0.0)
    parser.add_argument("--design-perturb-y-m", type=float, default=0.0)
    parser.add_argument("--design-intervention-seed", type=int, default=309)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    metrics = run(args)
    print(
        json.dumps(
            {
                "field_accuracy_status": metrics["field_accuracy_status"],
                "candidate_pool": metrics["candidate_pool"],
                "runtime_seconds": metrics["runtime_seconds"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
