"""GT-free, local-support-bounded assembly of a frozen joint reconstruction.

An observed patch must not clone/rotate an entire design wall. Each original
design interval has exactly one selected reference track. Competing physical
observations remain separate; discarded alternative *extrapolations* are kept
in the audit. This module does not certify topology or infer free space.
"""
from copy import deepcopy
from hashlib import sha256
import json

import numpy as np
from shapely.geometry import LineString, Point
from shapely.ops import substring, unary_union
from shapely.strtree import STRtree


CONFIG = {
    'schema': 'local-support-assembly/v1',
    'same_face_distance_m': .04,
    'same_face_angle_deg': 3.,
    'maximum_local_design_shift_m': .075,
    'minimum_host_multiheight_coverage': .45,
    'minimum_piece_m': .15,
    'track_direction_tolerance_deg': 12.,
    'supports_must_overlap_original_design': True,
    'extrapolate_beyond_observed_intervals': False,
    'select_track_by': 'nearest_original_then_support_then_stable_id',
    'gap_visibility_without_registered_rays': 'unknown',
}


def parts(g, minimum=0.):
    if g.is_empty:
        return []
    if g.geom_type == 'LineString':
        return [g] if g.length > max(minimum, 1e-10) else []
    return [p for child in getattr(g, 'geoms', []) for p in parts(child, minimum)]


def unit(line):
    xy = np.asarray(line.coords)
    v = xy[-1] - xy[0]
    return v / max(np.linalg.norm(v), 1e-12)


def record(line, source, source_ids, design_ids=()):
    xy = [list(p) for p in line.coords]
    payload = [xy, source, sorted(source_ids), sorted(design_ids)]
    return {'id': sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:20],
            'coordinates': xy, 'source': source, 'source_ids': sorted(source_ids),
            'design_ids': sorted(design_ids),
            'existence': 'undecided' if source.startswith('design') else 'present',
            'visibility': 'seen_object_level' if source == 'observed' else 'unknown'}


def _track_patches(design, objects, cfg):
    original = LineString(design['original_geometry'])
    a = np.asarray(original.coords[0]); v = unit(original)
    patches, rejected = [], []
    for track in design.get('validated_faces', []):
        line = LineString(track['coordinates']); t = unit(line)
        alignment = float(t @ v)
        if abs(alignment) < np.cos(np.deg2rad(cfg['track_direction_tolerance_deg'])):
            rejected.append({'face_id': track['face_id'], 'reason': 'direction_incompatible'})
            continue
        c = np.asarray(line.coords[0])
        for oid in track.get('source_lidar_object_ids', []):
            host = objects.get(oid)
            if not host or host['kind'] != 'WALL_FACE_TRACE':
                continue
            support = host.get('support_evidence', {})
            strength = float(support.get('multiheight_coverage', support.get('vertical_fraction', 0.)))
            if strength < cfg['minimum_host_multiheight_coverage']:
                continue
            projected = (np.asarray(host['current_geometry']) - a) @ v
            lo, hi = max(0., float(projected.min())), min(original.length, float(projected.max()))
            if hi - lo < cfg['minimum_piece_m']:
                continue
            # Intersect the track with the normals at original interval ends.
            xy = [c + ((s - (c-a)@v) / alignment) * t for s in (lo, hi)]
            shifts = [np.linalg.norm(p-(a+s*v)) for p, s in zip(xy, (lo, hi))]
            if max(shifts) > cfg['maximum_local_design_shift_m'] + 1e-10:
                rejected.append({'face_id': track['face_id'], 'source_id': oid,
                                 'reason': 'local_displacement_limit', 'max_shift_m': float(max(shifts))})
                continue
            patches.append({'lo': lo, 'hi': hi, 'face_id': track['face_id'], 'source_id': oid,
                            'strength': strength, 'shift': float(max(shifts)), 'c': c, 't': t,
                            'alignment': alignment})
    return patches, rejected


def local_design_pieces(design_id, design, objects, cfg=None, update=True):
    cfg = cfg or CONFIG
    original = LineString(design['original_geometry'])
    a = np.asarray(original.coords[0]); v = unit(original)
    patches, rejected = _track_patches(design, objects, cfg) if update else ([], [])
    cuts = sorted({0., original.length, *(p[k] for p in patches for k in ('lo', 'hi'))})
    intervals = []
    for lo, hi in zip(cuts, cuts[1:]):
        if hi-lo < 1e-10:
            continue
        midpoint = (lo+hi)/2
        available = [p for p in patches if p['lo'] <= midpoint <= p['hi']]
        chosen = min(available, key=lambda p: (p['shift'], -p['strength'], p['face_id'], p['source_id'])) if available else None
        key = chosen['face_id'] if chosen else None
        if intervals and intervals[-1]['key'] == key:
            intervals[-1]['hi'] = hi
            if chosen:
                intervals[-1]['sources'].add(chosen['source_id'])
        else:
            intervals.append({'lo': lo, 'hi': hi, 'key': key, 'track': chosen,
                              'sources': {chosen['source_id']} if chosen else set()})
    records, changed_length = [], 0.
    for interval in intervals:
        lo, hi, p = interval['lo'], interval['hi'], interval['track']
        if p:
            xy = [p['c'] + ((s-(p['c']-a)@v)/p['alignment'])*p['t'] for s in (lo, hi)]
            line = LineString(xy); source = 'design_locally_adjusted'
            changed_length += hi-lo
        else:
            line = substring(original, lo, hi); source = 'design_original'
        records.append(record(line, source, list(interval['sources']), [design_id]))
    return records, {'design_id': design_id, 'length_m': original.length,
                     'updated_original_interval_m': changed_length,
                     'accepted_patch_count': len(patches), 'rejected_patches': rejected}


def canonicalize(records, cfg=None):
    """One geometry per near-collinear overlap, preserving competing evidence.

    Observations precede conditional inferences and design. Different faces
    beyond 4 cm and nonparallel crossings are never collapsed. Exact duplicates
    use unoriented geometry; all contributor links remain in the audit.
    """
    cfg = cfg or CONFIG
    priority = {'observed': 0, 'inferred': 1, 'design_locally_adjusted': 2, 'design_original': 3}
    ordered = sorted(records, key=lambda r: (priority[r['source']], -LineString(r['coordinates']).length, r['id']))
    # Query the complete static set, but only subtract already accepted pieces.
    original_lines = [LineString(r['coordinates']) for r in ordered]
    tree = STRtree(original_lines)
    accepted_by_index = {}; kept = []; links = []
    for i, (r, line) in enumerate(zip(ordered, original_lines)):
        remaining = line
        contributors = []
        for j in sorted(map(int, tree.query(line.buffer(cfg['same_face_distance_m'])))):
            if j not in accepted_by_index:
                continue
            for other, rid in accepted_by_index[j]:
                if abs(unit(line) @ unit(other)) < np.cos(np.deg2rad(cfg['same_face_angle_deg'])):
                    continue
                before = remaining.length
                remaining = remaining.difference(other.buffer(cfg['same_face_distance_m'], cap_style=2))
                if before - remaining.length > 1e-9:
                    contributors.append(rid)
        pieces = parts(remaining)  # Do not erase genuine short remnants.
        accepted_by_index[i] = []
        for piece in pieces:
            out = record(piece, r['source'], r['source_ids'], r['design_ids'])
            out['parent_piece_id'] = r['id']
            kept.append(out); accepted_by_index[i].append((piece, out['id']))
        if contributors:
            links.append({'input_piece_id': r['id'], 'represented_by': sorted(set(contributors)),
                          'input_source_ids': r['source_ids'], 'input_design_ids': r['design_ids'],
                          'removed_overlap_length_m': line.length - sum(p.length for p in pieces)})
    return kept, links


def assemble(scene, excluded_design_groups=(), site=None, update=True, normalize=True, cfg=None):
    cfg = deepcopy(cfg or CONFIG)
    records = []; track_audit = []
    for oid, obj in sorted(scene['objects'].items()):
        if obj['kind'] in {'WALL_FACE_TRACE', 'INFERRED_WALL_FACE', 'PRIOR_INFERRED_WALL_FACE'}:
            source = 'observed' if obj['kind'] == 'WALL_FACE_TRACE' else 'inferred'
            records.append(record(LineString(obj['current_geometry']), source, [oid], obj.get('matched_design_entity_ids', [])))
    seen = set()
    for did, design in sorted(scene['design_entities'].items()):
        original = LineString(design['original_geometry'])
        if design['design_wall_id'] in excluded_design_groups or (site is not None and not original.intersects(site)):
            continue
        key = LineString(np.round(original.coords, 6)).normalize().wkb
        if key in seen:
            # Source geometry duplicates must not multiply reference intervals.
            continue
        seen.add(key)
        pieces, audit = local_design_pieces(did, design, scene['objects'], cfg, update)
        records.extend(pieces); track_audit.append(audit)
    before = sum(LineString(r['coordinates']).length for r in records)
    records, links = canonicalize(records, cfg) if normalize else (records, [])
    return {'schema': 'local-support-assembly-output/v1', 'config': cfg,
            'update_design': update, 'canonicalization': normalize,
            'walls': [r['coordinates'] for r in records], 'wall_records': records,
            'relations': deepcopy(scene['relations']),
            'relation_policy': 'Frozen explicit candidates retained; no claim of site verification or improved topology.',
            'track_audit': track_audit, 'overlap_provenance': links,
            'summary': {'input_length_m': before,
                        'output_length_m': sum(LineString(r['coordinates']).length for r in records),
                        'updated_original_interval_m': sum(a['updated_original_interval_m'] for a in track_audit),
                        'updated_entities': sum(a['updated_original_interval_m'] > 0 for a in track_audit),
                        'GT_used_for_inference': False}}
