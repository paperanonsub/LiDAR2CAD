from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import ezdxf
import numpy as np
from shapely.geometry import LineString, mapping

from lidar2outline.config import load_config
from lidar2outline.height_slices import _vectorize_slice
from lidar2outline.io import read_json, read_point_cloud, write_json
from lidar2outline.transforms import transform_points


def persistent_vertical_mask(
    points: np.ndarray,
    grid_m: float,
    z_bin_m: float,
    min_height_bins: int,
    min_vertical_span_m: float,
    max_start_height_m: float,
    min_top_height_m: float,
    padding_m: float = 0.5,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict]:
    """Project only cells with persistent low-to-high vertical evidence."""

    values = np.asarray(points, dtype=np.float64)
    finite = values[np.all(np.isfinite(values), axis=1)]
    if not len(finite):
        raise ValueError("Point cloud has no finite points")
    origin = np.floor((finite[:, :2].min(axis=0) - padding_m) / grid_m) * grid_m
    maximum = np.ceil((finite[:, :2].max(axis=0) + padding_m) / grid_m) * grid_m
    shape_xy = np.maximum(1, np.ceil((maximum - origin) / grid_m).astype(int) + 1)
    width, height = int(shape_xy[0]), int(shape_xy[1])
    ij = np.floor((finite[:, :2] - origin) / grid_m).astype(np.int64)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < width)
        & (ij[:, 1] < height)
    )
    finite, ij = finite[valid], ij[valid]
    z_origin = float(np.floor(finite[:, 2].min() / z_bin_m) * z_bin_m)
    z_bins = np.floor((finite[:, 2] - z_origin) / z_bin_m).astype(np.int64)
    z_count = int(z_bins.max()) + 2
    flat = ij[:, 1] * width + ij[:, 0]
    keys = np.unique(flat * z_count + z_bins)
    cells = keys // z_count
    bins = keys % z_count
    unique_cells, starts, counts = np.unique(cells, return_index=True, return_counts=True)
    minimum_bins = bins[starts]
    maximum_bins = bins[starts + counts - 1]
    minimum_z = z_origin + minimum_bins * z_bin_m
    maximum_z = z_origin + (maximum_bins + 1) * z_bin_m
    keep = (
        (counts >= int(min_height_bins))
        & ((maximum_z - minimum_z) >= float(min_vertical_span_m))
        & (minimum_z <= float(max_start_height_m))
        & (maximum_z >= float(min_top_height_m))
    )
    mask = np.zeros((height, width), dtype=np.uint8)
    vertical = np.zeros((height, width), dtype=np.uint8)
    cy = unique_cells // width
    cx = unique_cells % width
    vertical[cy, cx] = np.minimum(counts, 255).astype(np.uint8)
    selected = unique_cells[keep]
    mask[selected // width, selected % width] = 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    component_count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    cleaned = np.zeros_like(mask)
    for component in range(1, component_count):
        if int(stats[component, cv2.CC_STAT_AREA]) >= 4:
            cleaned[labels == component] = 255
    heat = np.clip(vertical.astype(np.float32) / max(float(min_height_bins * 1.5), 1.0), 0.0, 1.0)
    metrics = {
        "input_point_count": int(len(values)),
        "finite_point_count": int(len(finite)),
        "grid_m": float(grid_m),
        "z_bin_m": float(z_bin_m),
        "raster_shape": [height, width],
        "occupied_xy_cell_count": int(len(unique_cells)),
        "persistent_cell_count": int(np.count_nonzero(cleaned)),
        "min_height_bins": int(min_height_bins),
        "min_vertical_span_m": float(min_vertical_span_m),
        "max_start_height_m": float(max_start_height_m),
        "min_top_height_m": float(min_top_height_m),
    }
    return cleaned, heat, origin, metrics


def _write_dxf(path: Path, lines: list[LineString]) -> None:
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6
    document.layers.add("PERSISTENT_STRUCTURE", color=7)
    modelspace = document.modelspace()
    for line in lines:
        coordinates = [(float(x), float(y)) for x, y in line.coords]
        if len(coordinates) == 2:
            modelspace.add_line(coordinates[0], coordinates[1], dxfattribs={"layer": "PERSISTENT_STRUCTURE"})
        else:
            modelspace.add_lwpolyline(coordinates, dxfattribs={"layer": "PERSISTENT_STRUCTURE"})
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def _write_preview(path: Path, mask: np.ndarray, lines: list[LineString], origin: np.ndarray, grid_m: float) -> None:
    base = np.zeros((*mask.shape, 3), dtype=np.uint8)
    base[mask > 0] = (92, 92, 92)
    for line in lines:
        pixels = np.rint((np.asarray(line.coords) - origin) / grid_m).astype(np.int32)
        cv2.polylines(base, [pixels.reshape(-1, 1, 2)], False, (255, 235, 210), 1, cv2.LINE_AA)
    # ``flipud`` is a negative-stride view; OpenCV drawing requires a
    # contiguous writable buffer.
    image = np.flipud(base).copy()
    cv2.putText(
        image,
        f"PERSISTENT HEIGHT STRUCTURE - {len(lines)} lines - grid {grid_m:.2f} m",
        (18, 36),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )
    if not cv2.imwrite(str(path), image):
        raise OSError(f"Could not write preview image: {path}")


def run_persistent_preview(
    config_path: str | Path,
    point_cloud_path: str | Path,
    transforms_path: str | Path,
    output_dir: str | Path,
) -> dict:
    cfg = load_config(config_path)
    if cfg.get("project", {}).get("scene_type") != "underground_parking":
        raise ValueError("Persistent parking preview requires an underground_parking config")
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    points_ref = read_point_cloud(point_cloud_path)
    transforms = read_json(transforms_path)
    transform = np.asarray(transforms["T_cad_reference_slam"], dtype=float)
    points_cad = transform_points(points_ref, transform)
    height_cfg = cfg.get("height_slices", {})
    grid_m = float(height_cfg.get("persistent_preview_grid_m", 0.10))
    mask, heat, origin, metrics = persistent_vertical_mask(
        points_cad,
        grid_m=grid_m,
        z_bin_m=float(height_cfg.get("persistent_preview_z_bin_m", 0.10)),
        min_height_bins=int(height_cfg.get("persistent_preview_min_height_bins", 7)),
        min_vertical_span_m=float(height_cfg.get("persistent_preview_min_span_m", 1.0)),
        max_start_height_m=float(height_cfg.get("persistent_preview_max_start_m", 0.80)),
        min_top_height_m=float(height_cfg.get("persistent_preview_min_top_m", 1.80)),
    )
    vector_cfg = dict(cfg.get("vision_layout", {}))
    vector_cfg.update(
        {key: value for key, value in height_cfg.items() if key.startswith("vector_")}
    )
    vector_cfg.setdefault("vector_tile_size_m", 45.0)
    vector_cfg.setdefault("vector_tile_overlap_m", 3.0)
    vector_cfg.setdefault("vector_tile_min_pixels", 8)
    lines = _vectorize_slice(mask, heat, origin, grid_m, 0.0, vector_cfg)
    metrics["line_count"] = int(len(lines))
    metrics["total_line_length_m"] = float(sum(line.length for line in lines))
    _write_dxf(output / "persistent_structure.dxf", lines)
    _write_preview(output / "persistent_structure.png", mask, lines, origin, grid_m)
    cv2.imwrite(str(output / "persistent_mask.png"), np.flipud(mask))
    write_json(
        output / "persistent_structure.geojson",
        {
            "type": "FeatureCollection",
            "local_coordinate_system": {"units": "metre", "frame": "CAD"},
            "features": [
                {
                    "type": "Feature",
                    "geometry": mapping(line),
                    "properties": {"class": "PERSISTENT_STRUCTURE", "observed": True},
                }
                for line in lines
            ],
        },
    )
    write_json(output / "persistent_preview_report.json", metrics)
    return metrics


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Fast persistent-height parking structure preview")
    parser.add_argument("--config", required=True)
    parser.add_argument("--pcd", required=True)
    parser.add_argument("--transforms", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    report = run_persistent_preview(args.config, args.pcd, args.transforms, args.output)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
