from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import cv2
import numpy as np
from scipy.optimize import least_squares
from sklearn.cluster import AgglomerativeClustering
from shapely.geometry import Point, Polygon


@dataclass(frozen=True)
class ColumnTemplate:
    template_id: str
    width_m: float
    length_m: float
    dimension_mad_m: float
    source_count: int


def _rectangle_coordinates(center: np.ndarray, angle: float, width: float, length: float) -> np.ndarray:
    local = np.asarray(
        [
            [-length / 2, -width / 2],
            [length / 2, -width / 2],
            [length / 2, width / 2],
            [-length / 2, width / 2],
        ],
        dtype=float,
    )
    rotation = np.asarray(
        [[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]],
        dtype=float,
    )
    return local @ rotation.T + center


def _rectangle_frame(points: np.ndarray, center: np.ndarray, angle: float) -> np.ndarray:
    rotation = np.asarray(
        [[math.cos(angle), math.sin(angle)], [-math.sin(angle), math.cos(angle)]],
        dtype=float,
    )
    return (points - center) @ rotation.T


def _boundary_residual(parameters: np.ndarray, points: np.ndarray, template: tuple[float, float] | None) -> np.ndarray:
    cx, cy, angle = parameters[:3]
    if template is None:
        width, length = parameters[3:5]
    else:
        width, length = template
    local = _rectangle_frame(points, np.asarray([cx, cy]), angle)
    # Distance to the four finite boundary segments, not to four infinite
    # supporting lines.  The old minimum-of-line-distances objective admitted
    # a degenerate 15 cm-wide rectangle for a single long strip and could then
    # report spurious adjacent faces.
    half_length = length / 2
    half_width = width / 2
    ax = np.abs(local[:, 0])
    ay = np.abs(local[:, 1])
    outside_x = np.maximum(ax - half_length, 0.0)
    outside_y = np.maximum(ay - half_width, 0.0)
    outside = np.hypot(outside_x, outside_y)
    inside = np.minimum(half_length - ax, half_width - ay)
    is_inside = (ax <= half_length) & (ay <= half_width)
    return np.where(is_inside, inside, outside)


def _face_audit(
    points: np.ndarray,
    center: np.ndarray,
    angle: float,
    width: float,
    length: float,
    distance_m: float,
) -> list[dict[str, Any]]:
    local = _rectangle_frame(points, center, angle)
    distances = np.column_stack(
        [
            np.abs(local[:, 1] + width / 2),
            np.abs(local[:, 0] - length / 2),
            np.abs(local[:, 1] - width / 2),
            np.abs(local[:, 0] + length / 2),
        ]
    )
    assignments = np.argmin(distances, axis=1)
    result: list[dict[str, Any]] = []
    spans = (length, width, length, width)
    along_values = (local[:, 0], local[:, 1], local[:, 0], local[:, 1])
    for face in range(4):
        # A return supports a face only when it projects onto the finite face
        # interior.  Corner points remain assigned to one nearest face and can
        # no longer prove two unobserved sides of an L-shaped object.
        inside_span = np.abs(along_values[face]) <= spans[face] / 2 + distance_m
        selected = (
            (assignments == face)
            & (distances[:, face] <= distance_m)
            & inside_span
        )
        along = along_values[face][selected]
        if len(along):
            bins = np.unique(np.floor((along + spans[face] / 2) / 0.05).astype(int))
            coverage = min(1.0, len(bins) * 0.05 / max(spans[face], 1e-6))
            p95 = float(np.quantile(distances[selected, face], 0.95))
        else:
            coverage = 0.0
            p95 = None
        result.append(
            {
                "face_index": face,
                "point_count": int(np.count_nonzero(selected)),
                "coverage": float(coverage),
                "p95_m": p95,
                "supported": bool(np.count_nonzero(selected) >= 5 and coverage >= 0.55 and p95 is not None and p95 <= distance_m),
            }
        )
    return result


def fit_column_instance(
    points_xy: np.ndarray,
    height_bins: np.ndarray,
    *,
    template: ColumnTemplate | None = None,
    min_size_m: float = 0.15,
    max_size_m: float = 1.80,
    face_distance_m: float = 0.075,
) -> dict[str, Any]:
    """Fit a rectangle to column surface points, never to their filled area."""

    points = np.asarray(points_xy, dtype=float)
    if len(points) < 12:
        raise ValueError("column instance needs at least 12 surface points")
    # PCA points along the diagonal of a two-face L observation and biases the
    # centre.  The oriented envelope recovers the two physical edge directions
    # and is only an optimiser initialisation; final dimensions still minimise
    # distances to the actual finite boundary segments.
    oriented_envelope = cv2.minAreaRect(points.astype(np.float32))
    box = cv2.boxPoints(oriented_envelope).astype(float)
    edges = np.roll(box, -1, axis=0) - box
    edge_lengths = np.linalg.norm(edges, axis=1)
    longest_edge = edges[int(np.argmax(edge_lengths))]
    center0 = np.mean(box, axis=0)
    angle0 = float(math.atan2(longest_edge[1], longest_edge[0]))
    length0 = float(np.max(edge_lengths))
    width0 = float(np.min(edge_lengths))
    length0 = max(length0, min_size_m)
    width0 = max(width0, min_size_m)
    if width0 > length0:
        width0, length0 = length0, width0
        angle0 += math.pi / 2
    width0 = float(np.clip(width0, min_size_m, max_size_m))
    length0 = float(np.clip(length0, min_size_m, max_size_m))
    if template is None:
        x0 = np.asarray([center0[0], center0[1], angle0, width0, length0])
        lower = [points[:, 0].min() - max_size_m, points[:, 1].min() - max_size_m, angle0 - math.pi / 2, min_size_m, min_size_m]
        upper = [points[:, 0].max() + max_size_m, points[:, 1].max() + max_size_m, angle0 + math.pi / 2, max_size_m, max_size_m]
        result = least_squares(
            _boundary_residual, x0, args=(points, None), bounds=(lower, upper), loss="huber", f_scale=0.03, max_nfev=250
        )
        center = result.x[:2]
        angle = float(result.x[2])
        width, length = float(result.x[3]), float(result.x[4])
    else:
        x0 = np.asarray([center0[0], center0[1], angle0])
        result = least_squares(
            _boundary_residual,
            x0,
            args=(points, (template.width_m, template.length_m)),
            bounds=([points[:, 0].min() - template.length_m, points[:, 1].min() - template.length_m, angle0 - math.pi / 2],
                    [points[:, 0].max() + template.length_m, points[:, 1].max() + template.length_m, angle0 + math.pi / 2]),
            loss="huber",
            f_scale=0.03,
            max_nfev=250,
        )
        center = result.x[:2]
        angle = float(result.x[2])
        width, length = template.width_m, template.length_m
    if width > length:
        width, length = length, width
        angle += math.pi / 2
    coordinates = _rectangle_coordinates(center, angle, width, length)
    audit = _face_audit(points, center, angle, width, length, face_distance_m)
    observed_faces = [value["face_index"] for value in audit if value["supported"]]
    unique_height_bins = int(len(np.unique(np.asarray(height_bins, dtype=int))))
    residual = _boundary_residual(
        np.asarray([center[0], center[1], angle, width, length]), points, None
    )
    residual_p95 = float(np.quantile(residual, 0.95))
    surface_inlier_fraction = float(np.mean(residual <= face_distance_m))
    inlier_residual = residual[residual <= face_distance_m]
    robust_residual_p95 = (
        float(np.quantile(inlier_residual, 0.95)) if len(inlier_residual) else None
    )
    # Human polygons are deliberately loose search regions.  Reliability is
    # determined by three independently supported finite faces plus a robust
    # majority of boundary inliers; unrelated vertical returns inside the ROI
    # remain auditable outliers and must not veto an otherwise complete column.
    surface_fit_ok = surface_inlier_fraction >= 0.70
    identifiable = (
        len(observed_faces) >= 3
        and unique_height_bins >= 6
        and surface_fit_ok
    )
    if (
        template is not None
        and len(observed_faces) >= 2
        and unique_height_bins >= 6
        and surface_fit_ok
    ):
        status = "template_completed"
    elif identifiable:
        status = "reliable"
    else:
        status = "uncertain"
    return {
        "center": np.asarray(center, dtype=float),
        "angle_rad": float(angle % math.pi),
        "width_m": float(width),
        "length_m": float(length),
        "polygon": Polygon(coordinates),
        "observed_edge_indices": observed_faces,
        "edge_support": audit,
        "height_bin_count": unique_height_bins,
        "residual_p95_m": residual_p95,
        "robust_residual_p95_m": robust_residual_p95,
        "surface_inlier_fraction": surface_inlier_fraction,
        "identifiable_without_template": bool(identifiable),
        "status": status,
        "template_id": template.template_id if template is not None else None,
        "cross_section_model": "rectangle",
    }


def fit_circular_column_instance(
    points_xy: np.ndarray,
    height_bins: np.ndarray,
    *,
    min_diameter_m: float = 0.15,
    max_diameter_m: float = 1.80,
    surface_distance_m: float = 0.075,
) -> dict[str, Any]:
    """Fit a circular column surface and audit angular rather than filled support."""

    points = np.asarray(points_xy, dtype=float)
    if len(points) < 12:
        raise ValueError("circular column instance needs at least 12 surface points")
    center0 = np.median(points, axis=0)
    radius0 = float(np.median(np.linalg.norm(points - center0, axis=1)))
    radius0 = float(np.clip(radius0, min_diameter_m / 2, max_diameter_m / 2))

    def residual(parameters: np.ndarray) -> np.ndarray:
        center = parameters[:2]
        radius = parameters[2]
        return np.linalg.norm(points - center, axis=1) - radius

    result = least_squares(
        residual,
        np.asarray([center0[0], center0[1], radius0]),
        bounds=(
            [points[:, 0].min() - max_diameter_m, points[:, 1].min() - max_diameter_m, min_diameter_m / 2],
            [points[:, 0].max() + max_diameter_m, points[:, 1].max() + max_diameter_m, max_diameter_m / 2],
        ),
        loss="huber",
        f_scale=0.03,
        max_nfev=250,
    )
    center = result.x[:2]
    radius = float(result.x[2])
    absolute = np.abs(residual(result.x))
    supported = absolute <= surface_distance_m
    angles = np.mod(np.arctan2(points[:, 1] - center[1], points[:, 0] - center[0]), 2 * math.pi)
    angular_bins = np.unique(np.floor(angles[supported] / (2 * math.pi) * 24).astype(int))
    angular_coverage = float(len(angular_bins) / 24.0)
    unique_height_bins = int(len(np.unique(np.asarray(height_bins, dtype=int))))
    p95 = float(np.quantile(absolute, 0.95))
    surface_inlier_fraction = float(np.mean(supported))
    inlier_residual = absolute[supported]
    robust_residual_p95 = (
        float(np.quantile(inlier_residual, 0.95)) if len(inlier_residual) else None
    )
    identifiable = bool(
        np.count_nonzero(supported) >= 12
        and angular_coverage >= 0.50
        and unique_height_bins >= 6
        and surface_inlier_fraction >= 0.70
    )
    return {
        "center": np.asarray(center, dtype=float),
        "angle_rad": 0.0,
        "width_m": float(2 * radius),
        "length_m": float(2 * radius),
        "diameter_m": float(2 * radius),
        "polygon": Point(float(center[0]), float(center[1])).buffer(radius, quad_segs=32),
        "observed_edge_indices": sorted(int(value) for value in angular_bins.tolist()),
        "edge_support": {
            "angular_bin_count": int(len(angular_bins)),
            "angular_coverage": angular_coverage,
            "surface_point_count": int(np.count_nonzero(supported)),
        },
        "height_bin_count": unique_height_bins,
        "residual_p95_m": p95,
        "robust_residual_p95_m": robust_residual_p95,
        "surface_inlier_fraction": surface_inlier_fraction,
        "identifiable_without_template": identifiable,
        "status": "reliable" if identifiable else "uncertain",
        "template_id": None,
        "cross_section_model": "circle",
    }


def fit_best_column_instance(
    points_xy: np.ndarray,
    height_bins: np.ndarray,
    *,
    min_size_m: float = 0.15,
    max_size_m: float = 1.80,
    surface_distance_m: float = 0.075,
) -> dict[str, Any]:
    """Choose rectangle/square or circle using audited surface evidence."""

    rectangle = fit_column_instance(
        points_xy,
        height_bins,
        min_size_m=min_size_m,
        max_size_m=max_size_m,
        face_distance_m=surface_distance_m,
    )
    circle = fit_circular_column_instance(
        points_xy,
        height_bins,
        min_diameter_m=min_size_m,
        max_diameter_m=max_size_m,
        surface_distance_m=surface_distance_m,
    )
    reliable = [value for value in (rectangle, circle) if value["status"] == "reliable"]
    if not reliable:
        return min((rectangle, circle), key=lambda value: value["residual_p95_m"])
    if len(reliable) == 1:
        return reliable[0]
    # A circle must explain the boundary materially better because a rectangle
    # is the simpler CAD primitive for near-square columns.
    circle_score = float(circle.get("robust_residual_p95_m") or circle["residual_p95_m"])
    rectangle_score = float(
        rectangle.get("robust_residual_p95_m") or rectangle["residual_p95_m"]
    )
    if circle_score + 0.008 < rectangle_score:
        return circle
    return rectangle


def fit_column_across_height_windows(
    points_xy: np.ndarray,
    height_bins: np.ndarray,
    windows: list[tuple[str, str, int, int]],
    *,
    template: ColumnTemplate | None = None,
    min_size_m: float = 0.15,
    max_size_m: float = 1.80,
    surface_distance_m: float = 0.075,
    minimum_window_points: int = 12,
    maximum_center_deviation_m: float = 0.20,
    maximum_dimension_deviation_m: float = 0.25,
) -> dict[str, Any]:
    """Associate per-projection column observations and fit one 3-D instance.

    Thin and thick windows are overlapping *views*, not independent samples.
    Each view first estimates a cross-section.  Inconsistent views are removed,
    then their original voxel rows are unioned before the final fit, so a voxel
    can influence the column only once.  The final centre comes from the joint
    boundary model rather than the visible-point centroid.
    """

    points = np.asarray(points_xy, dtype=float)
    bins = np.asarray(height_bins, dtype=int)
    if len(points) != len(bins):
        raise ValueError("column points/height bins length mismatch")
    if len(points) < minimum_window_points:
        raise ValueError("column instance needs more surface observations")
    observations: list[dict[str, Any]] = []
    selections: list[np.ndarray] = []
    for window_id, scale, lower, upper in windows:
        selected = (bins >= int(lower)) & (bins < int(upper))
        if np.count_nonzero(selected) < minimum_window_points:
            continue
        try:
            if template is None:
                fitted = fit_best_column_instance(
                    points[selected],
                    bins[selected],
                    min_size_m=min_size_m,
                    max_size_m=max_size_m,
                    surface_distance_m=surface_distance_m,
                )
            else:
                fitted = fit_column_instance(
                    points[selected],
                    bins[selected],
                    template=template,
                    min_size_m=min_size_m,
                    max_size_m=max_size_m,
                    face_distance_m=surface_distance_m,
                )
        except ValueError:
            continue
        center = np.asarray(fitted["center"], dtype=float)
        observations.append(
            {
                "window_id": str(window_id),
                "scale": str(scale),
                "center": center,
                "angle_rad": float(fitted["angle_rad"]),
                "width_m": float(fitted["width_m"]),
                "length_m": float(fitted["length_m"]),
                "cross_section_model": str(fitted["cross_section_model"]),
                "surface_inlier_fraction": float(fitted["surface_inlier_fraction"]),
                "robust_residual_p95_m": fitted.get("robust_residual_p95_m"),
                "height_bins": np.unique(bins[selected]),
            }
        )
        selections.append(selected)
    if not observations:
        if template is None:
            final = fit_best_column_instance(
                points,
                bins,
                min_size_m=min_size_m,
                max_size_m=max_size_m,
                surface_distance_m=surface_distance_m,
            )
        else:
            final = fit_column_instance(
                points,
                bins,
                template=template,
                min_size_m=min_size_m,
                max_size_m=max_size_m,
                face_distance_m=surface_distance_m,
            )
        final["height_window_observations"] = []
        final["cross_height_observation_count"] = 0
        final["cross_height_center_spread_m"] = None
        final["cross_height_fusion"] = "all_unique_voxels_no_valid_window_fit"
        return final

    centers = np.asarray([value["center"] for value in observations])
    dimensions = np.asarray(
        [[value["width_m"], value["length_m"]] for value in observations]
    )
    median_center = np.median(centers, axis=0)
    median_dimensions = np.median(dimensions, axis=0)
    center_error = np.linalg.norm(centers - median_center, axis=1)
    dimension_error = np.linalg.norm(dimensions - median_dimensions, axis=1)
    model_names = [value["cross_section_model"] for value in observations]
    model = max(set(model_names), key=model_names.count)
    accepted = (
        (center_error <= maximum_center_deviation_m)
        & (dimension_error <= maximum_dimension_deviation_m)
        & np.asarray([value == model for value in model_names])
    )
    # With one or two windows, a robust median cannot identify an outlier.
    # Keep the best residual view instead of discarding the whole object.
    if not np.any(accepted):
        residuals = np.asarray(
            [
                float(value["robust_residual_p95_m"])
                if value["robust_residual_p95_m"] is not None
                else float("inf")
                for value in observations
            ]
        )
        accepted[int(np.argmin(residuals))] = True
    selected_rows = np.zeros(len(points), dtype=bool)
    for keep, selected in zip(accepted, selections):
        if keep:
            selected_rows |= selected
    if np.count_nonzero(selected_rows) < minimum_window_points:
        selected_rows[:] = True

    if template is None:
        final = fit_best_column_instance(
            points[selected_rows],
            bins[selected_rows],
            min_size_m=min_size_m,
            max_size_m=max_size_m,
            surface_distance_m=surface_distance_m,
        )
    else:
        final = fit_column_instance(
            points[selected_rows],
            bins[selected_rows],
            template=template,
            min_size_m=min_size_m,
            max_size_m=max_size_m,
            face_distance_m=surface_distance_m,
        )

    # Give each physical height bin total weight one even though it appears in
    # several overlapping projections.  This centre is diagnostic; the DXF
    # centre remains the joint finite-boundary optimum above.
    accepted_indices = np.flatnonzero(accepted)
    bin_multiplicity: dict[int, int] = {}
    for index in accepted_indices:
        for value in observations[index]["height_bins"]:
            key = int(value)
            bin_multiplicity[key] = bin_multiplicity.get(key, 0) + 1
    weights = []
    for index in accepted_indices:
        values = observations[index]["height_bins"]
        weights.append(
            float(sum(1.0 / bin_multiplicity[int(value)] for value in values))
        )
    accepted_centers = centers[accepted]
    consensus = np.average(accepted_centers, axis=0, weights=np.asarray(weights))
    spread = float(np.max(np.linalg.norm(accepted_centers - consensus, axis=1)))
    final["cross_height_consensus_center"] = consensus
    final["cross_height_center_spread_m"] = spread
    final["cross_height_observation_count"] = int(np.count_nonzero(accepted))
    final["cross_height_rejected_observation_count"] = int(
        len(observations) - np.count_nonzero(accepted)
    )
    final["cross_height_fusion"] = (
        "per_projection_fit_then_unique_voxel_joint_boundary_optimisation"
    )
    final["height_window_observations"] = [
        {
            "window_id": value["window_id"],
            "scale": value["scale"],
            "center": value["center"].tolist(),
            "angle_rad": value["angle_rad"],
            "width_m": value["width_m"],
            "length_m": value["length_m"],
            "cross_section_model": value["cross_section_model"],
            "surface_inlier_fraction": value["surface_inlier_fraction"],
            "robust_residual_p95_m": value["robust_residual_p95_m"],
            "accepted": bool(keep),
            "unique_height_bins": [int(item) for item in value["height_bins"]],
        }
        for value, keep in zip(observations, accepted)
    ]
    return final


def learn_column_templates(
    fitted: list[dict[str, Any]],
    *,
    minimum_group_size: int = 3,
    dimension_tolerance_m: float = 0.12,
) -> list[ColumnTemplate]:
    reliable = [
        value
        for value in fitted
        if value.get("identifiable_without_template")
        and value.get("cross_section_model", "rectangle") == "rectangle"
    ]
    if len(reliable) < minimum_group_size:
        return []
    dimensions = np.asarray([[value["width_m"], value["length_m"]] for value in reliable], dtype=float)
    labels = AgglomerativeClustering(
        n_clusters=None,
        distance_threshold=dimension_tolerance_m,
        linkage="complete",
        metric="euclidean",
    ).fit_predict(dimensions)
    templates: list[ColumnTemplate] = []
    for label in sorted(set(labels.tolist())):
        group = dimensions[labels == label]
        if len(group) < minimum_group_size:
            continue
        median = np.median(group, axis=0)
        mad = float(np.median(np.abs(group - median)))
        templates.append(
            ColumnTemplate(
                template_id=f"CT-{len(templates):03d}",
                width_m=float(median[0]),
                length_m=float(median[1]),
                dimension_mad_m=mad,
                source_count=int(len(group)),
            )
        )
    return templates


def compatible_template(
    observation: dict[str, Any], templates: list[ColumnTemplate]
) -> ColumnTemplate | None:
    if not templates:
        return None
    observed_width = float(observation["width_m"])
    observed_length = float(observation["length_m"])
    candidates = []
    for template in templates:
        distance = math.hypot(
            template.width_m - observed_width,
            template.length_m - observed_length,
        )
        tolerance = max(0.05, 2.0 * template.dimension_mad_m, 0.10 * template.length_m)
        if distance <= tolerance:
            candidates.append((distance, template))
    if len(candidates) != 1:
        return None
    return candidates[0][1]
