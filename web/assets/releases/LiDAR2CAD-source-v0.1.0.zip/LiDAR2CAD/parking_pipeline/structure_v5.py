from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

import cv2
import ezdxf
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Polygon, mapping

from lidar2outline.config import load_config
from lidar2outline.io import read_json, read_point_cloud, write_json
from lidar2outline.semantic_objects import _skeleton_paths, fit_curve_primitive

from .semantic_annotation import _normalise_polygon
from .projection_objects import (
    classify_height_projections,
    trace_projection_wall_objects,
    write_projection_semantic_products,
)
from .structure import _sample_line
from .structure_v4 import (
    VoxelEvidence,
    _connection_candidates,
    _proposal_mask,
    _read_v3_features,
    _record_line,
    _virtual_opening_candidates,
    audit_written_outputs,
    extract_wall_objects,
    optimise_closed_regions,
    render_plan,
    select_non_competing_connections,
    split_connections_by_observation,
    update_shared_nodes,
    write_architectural_dxf,
    write_closed_layout_dxf,
    write_structure_geojson,
)
from .v5_evidence import (
    ExactVoxelEvidence,
    build_exact_voxel_evidence,
    curve_observation_audit,
    height_windows,
    load_exact_evidence,
    multiscale_fusion,
    save_exact_evidence,
    vertical_run_mask,
    window_occupancy,
)
from .v5_objects import (
    compatible_template,
    fit_best_column_instance,
    fit_column_across_height_windows,
    fit_column_instance,
    learn_column_templates,
)


def _transform_points(points: np.ndarray, transform: np.ndarray) -> np.ndarray:
    values = np.ones((len(points), 4), dtype=np.float64)
    values[:, :3] = np.asarray(points[:, :3], dtype=np.float64)
    return (values @ transform.T)[:, :3]


def _fingerprint(paths: list[Path], cfg: dict[str, Any]) -> str:
    digest = hashlib.sha256(b"parking_structure_v5_exact_evidence_2")
    for path in paths:
        stat = path.stat()
        digest.update(str(path.resolve()).encode("utf-8"))
        digest.update(str(stat.st_size).encode("ascii"))
        digest.update(str(stat.st_mtime_ns).encode("ascii"))
    selected = {
        key: value
        for key, value in cfg.items()
        if key.startswith(("evidence_", "surface_", "raster_", "thin_", "thick_"))
    }
    digest.update(json.dumps(selected, sort_keys=True, default=str).encode("utf-8"))
    return digest.hexdigest()


def _adapter(
    exact: ExactVoxelEvidence,
    observed_mask: np.ndarray,
    proposal_mask: np.ndarray,
    cfg: dict[str, Any],
) -> VoxelEvidence:
    cells = np.flatnonzero(observed_mask).astype(np.int64)
    positions = np.searchsorted(exact.all_xy_cell, cells)
    valid = (positions < len(exact.all_xy_cell))
    valid[valid] &= exact.all_xy_cell[positions[valid]] == cells[valid]
    cells = cells[valid]
    positions = positions[valid]
    first_rows = []
    for rows in exact.voxel_rows_for_xy(cells):
        first_rows.append(int(rows[0]) if len(rows) else 0)
    z_min_bin = exact.all_z_min_bin[positions]
    z_max_bin = exact.all_z_max_bin[positions]
    bin_count = exact.all_bin_count[positions]
    z_min = exact.floor_m + z_min_bin.astype(float) * exact.z_bin_m
    z_max = exact.floor_m + (z_max_bin.astype(float) + 1) * exact.z_bin_m
    return VoxelEvidence(
        origin=exact.origin_xy,
        shape=exact.shape,
        grid_m=exact.grid_m,
        z_bin_m=exact.z_bin_m,
        global_floor_m=exact.floor_m,
        global_ceiling_m=exact.ceiling_m,
        raw_mask=observed_mask,
        proposal_mask=proposal_mask,
        morphology_added_mask=proposal_mask & ~observed_mask,
        cell_linear=cells,
        cell_z_min_m=z_min,
        cell_z_max_m=z_max,
        cell_height_bin_count=bin_count,
        cell_vertical_span_m=(z_max_bin - z_min_bin + 1).astype(float) * exact.z_bin_m,
        cell_first_point_index=exact.first_point_index[np.asarray(first_rows, dtype=np.int64)],
        local_surfaces=[],
        source_metrics={
            "unique_xyz_voxel_count": int(len(exact.xy_cell)),
            "candidate_xy_cell_count": int(len(cells)),
            "vertical_support_xy_m": exact.grid_m,
            "support_is_exact_per_xy_cell": True,
            "global_floor_m": exact.floor_m,
            "global_ceiling_m": exact.ceiling_m,
        },
    )


def _load_semantic_rasters(path: Path | None, shape: tuple[int, int]) -> dict[str, np.ndarray] | None:
    if path is None or not path.exists():
        return None
    with np.load(path) as values:
        required = {"wall_probability", "column_probability", "vehicle_probability"}
        # Read old caches only to provide an explicit migration path; newly
        # generated V5 caches use vehicle_probability.
        if "vehicle_probability" not in values.files and "non_architectural_probability" in values.files:
            result = {
                "wall_probability": np.asarray(values["wall_probability"], dtype=np.float32),
                "column_probability": np.asarray(values["column_probability"], dtype=np.float32),
                "vehicle_probability": np.asarray(values["non_architectural_probability"], dtype=np.float32),
            }
            required = set()
        else:
            result = {}
        missing = required - set(values.files)
        if missing:
            raise ValueError(f"semantic probability cache is missing {sorted(missing)}")
        result.update({key: np.asarray(values[key], dtype=np.float32) for key in required})
        result["agreement_probability"] = (
            np.asarray(values["agreement_probability"], dtype=np.float32)
            if "agreement_probability" in values.files
            else np.ones(shape, dtype=np.float32)
        )
        if "voxel_probability" in values.files:
            result["voxel_probability"] = np.asarray(
                values["voxel_probability"], dtype=np.float32
            )
        if "voxel_agreement" in values.files:
            result["voxel_agreement"] = np.asarray(
                values["voxel_agreement"], dtype=bool
            )
    for key, value in result.items():
        if key.startswith("voxel_"):
            continue
        if value.shape != shape:
            raise ValueError(f"{key} has shape {value.shape}, expected {shape}")
    return result


def _tracking_seed_lines(mask: np.ndarray, exact: ExactVoxelEvidence, cfg: dict[str, Any]) -> list[LineString]:
    lines: list[LineString] = []
    for path in _skeleton_paths(mask.astype(bool), exact.origin_xy + 0.5 * exact.grid_m, exact.grid_m):
        if path.length < float(cfg.get("wall_candidate_min_length_m", 0.20)):
            continue
        primitive = fit_curve_primitive(path, cfg)
        fitted = LineString(primitive.get("coordinates_ref", list(path.coords)))
        if fitted.length >= float(cfg.get("wall_candidate_min_length_m", 0.20)):
            lines.append(fitted)
    return lines


def _line_corridor(
    lines: list[LineString], exact: ExactVoxelEvidence, radius_m: float
) -> np.ndarray:
    mask = np.zeros(exact.shape, dtype=np.uint8)
    thickness = max(1, int(math.ceil(2.0 * radius_m / exact.grid_m)))
    for line in lines:
        coordinates = np.asarray(line.coords, dtype=float)
        pixels = np.rint((coordinates - exact.origin_xy) / exact.grid_m - 0.5).astype(np.int32)
        if len(pixels) >= 2:
            cv2.polylines(mask, [pixels.reshape(-1, 1, 2)], False, 1, thickness)
    return mask.astype(bool)


def _annotation_objects(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.exists():
        return []
    document = read_json(path)
    if document.get("schema_version") != "parking-object-regions-v1":
        raise ValueError("ICPAR annotation manifest has an unsupported schema")
    return [value for value in document.get("objects", []) if value.get("status", "accepted") == "accepted"]


def _prepare_reconstruction_annotation_inputs(
    objects: list[dict[str, Any]],
    wall_supervision: np.ndarray | None,
    column_supervision: np.ndarray | None,
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], np.ndarray | None, np.ndarray | None, bool]:
    """Separate direct ROI guidance from labels retained for semantic training.

    The default preserves the historical V5 behavior.  When disabled, wall and
    column annotations remain available to the annotation/training workflows,
    but do not directly seed geometric reconstruction or override projection
    classifications.  Classifier probabilities may still be used by the
    configured semantic candidate gates.
    """

    enabled = bool(cfg.get("manual_wall_column_rois_for_reconstruction", True))
    if enabled:
        return objects, wall_supervision, column_supervision, True
    reconstruction_objects = [
        item
        for item in objects
        if str(item.get("semantic", "")) not in {"wall", "column"}
    ]
    return reconstruction_objects, None, None, False


def _annotation_block_mask(objects: list[dict[str, Any]], exact: ExactVoxelEvidence) -> np.ndarray:
    blocked = np.zeros(exact.shape, dtype=bool)
    occupied = np.zeros(exact.shape, dtype=np.uint8)
    occupied.ravel()[np.unique(exact.xy_cell)] = 1
    persistent = vertical_run_mask(exact, min_bins=10, min_span_m=1.0)
    for item in objects:
        semantic = "vehicle" if item.get("semantic") == "non_architectural" else item.get("semantic")
        if semantic not in {"vehicle", "other", "opening", "scan_boundary"}:
            continue
        region = _annotation_polygon_mask(item, exact)
        if semantic in {"opening", "scan_boundary"}:
            blocked |= region
            continue
        # A human ROI is a search region, not a filled object mask.  Block
        # only actually occupied, non-wall-persistent evidence near the marked
        # vehicle/other returns; do not erase a wall seen behind a loose box.
        evidence = region & occupied.astype(bool) & ~persistent
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        blocked |= cv2.dilate(evidence.astype(np.uint8), kernel).astype(bool) & region
    return blocked


def _annotation_polygon_mask(item: dict[str, Any], exact: ExactVoxelEvidence) -> np.ndarray:
    vertices, _ = _normalise_polygon(item.get("polygon_ref"))
    coordinates = np.asarray(vertices, dtype=float)
    pixels = np.rint((coordinates - exact.origin_xy) / exact.grid_m - 0.5).astype(np.int32)
    mask = np.zeros(exact.shape, np.uint8)
    if len(pixels) >= 3:
        cv2.fillPoly(mask, [pixels.reshape(-1, 1, 2)], 1)
    return mask.astype(bool)


def _annotation_region_mask(
    objects: list[dict[str, Any]], exact: ExactVoxelEvidence, semantics: set[str]
) -> np.ndarray:
    result = np.zeros(exact.shape, dtype=bool)
    for item in objects:
        semantic = "vehicle" if item.get("semantic") == "non_architectural" else str(item.get("semantic"))
        if semantic in semantics:
            result |= _annotation_polygon_mask(item, exact)
    return result


def _column_points(
    item: dict[str, Any],
    exact: ExactVoxelEvidence,
    persistent_voxels: np.ndarray,
    column_supervision: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    # The hand polygon is a search region, never a filled column footprint.
    # Restrict it to cells with their own continuous vertical support before
    # estimating a cross-section, so a nearby car roof or isolated wall return
    # cannot dominate a broad ROI.
    region = _annotation_polygon_mask(item, exact)
    surface = persistent_voxels if column_supervision is None else column_supervision
    selected = region.ravel()[exact.xy_cell] & surface
    return exact.centroids[selected, :2].astype(float), exact.z_bin[selected].astype(int)


def _fit_annotated_columns(
    objects: list[dict[str, Any]],
    exact: ExactVoxelEvidence,
    cfg: dict[str, Any],
    column_supervision: np.ndarray | None = None,
    height_window_values: list[Any] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    initial: list[tuple[dict[str, Any], np.ndarray, np.ndarray, dict[str, Any]]] = []
    uncertain: list[dict[str, Any]] = []
    persistent_voxels = np.isin(exact.xy_cell, exact.structural_xy_cell)
    window_bins = [
        (
            value.window_id,
            value.scale,
            int(
                math.floor(
                    (value.z_min_m - exact.floor_m) / exact.z_bin_m + 1e-9
                )
            ),
            int(
                math.ceil(
                    (value.z_max_m - exact.floor_m) / exact.z_bin_m - 1e-9
                )
            ),
        )
        for value in (height_window_values or [])
    ]
    for item in objects:
        if item.get("semantic") != "column":
            continue
        points, bins = _column_points(
            item,
            exact,
            persistent_voxels,
            column_supervision=column_supervision,
        )
        try:
            if height_window_values:
                fit = fit_column_across_height_windows(
                    points,
                    bins,
                    window_bins,
                    min_size_m=float(cfg.get("column_min_size_m", 0.15)),
                    max_size_m=float(cfg.get("column_max_size_m", 1.80)),
                    surface_distance_m=float(
                        cfg.get("column_face_support_distance_m", 0.075)
                    ),
                    maximum_center_deviation_m=float(
                        cfg.get("column_window_max_center_deviation_m", 0.20)
                    ),
                    maximum_dimension_deviation_m=float(
                        cfg.get("column_window_max_dimension_deviation_m", 0.25)
                    ),
                )
            else:
                fit = fit_best_column_instance(
                    points,
                    bins,
                    min_size_m=float(cfg.get("column_min_size_m", 0.15)),
                    max_size_m=float(cfg.get("column_max_size_m", 1.80)),
                    surface_distance_m=float(
                        cfg.get("column_face_support_distance_m", 0.075)
                    ),
                )
            initial.append((item, points, bins, fit))
        except ValueError as exc:
            _, polygon = _normalise_polygon(item.get("polygon_ref"))
            uncertain.append(
                {
                    "column_id": item["object_id"],
                    "polygon": polygon,
                    "status": "uncertain",
                    "source": "human_roi_insufficient_surface",
                    "reason": str(exc),
                }
            )
    templates = learn_column_templates(
        [value[3] for value in initial],
        minimum_group_size=int(cfg.get("column_template_min_group_size", 3)),
        dimension_tolerance_m=float(cfg.get("column_template_dimension_tolerance_m", 0.12)),
    )
    reliable: list[dict[str, Any]] = []
    for item, points, bins, fit in initial:
        final = fit
        if fit["status"] == "uncertain":
            template = compatible_template(fit, templates)
            if template is not None:
                if height_window_values:
                    final = fit_column_across_height_windows(
                        points,
                        bins,
                        window_bins,
                        template=template,
                        min_size_m=float(cfg.get("column_min_size_m", 0.15)),
                        max_size_m=float(cfg.get("column_max_size_m", 1.80)),
                        surface_distance_m=float(
                            cfg.get("column_face_support_distance_m", 0.075)
                        ),
                    )
                else:
                    final = fit_column_instance(points, bins, template=template)
        record = {
            **final,
            "column_id": item["object_id"],
            "source": "human_column_roi_plus_exact_3d_surface",
            "semantic": "column",
        }
        if final["status"] in {"reliable", "template_completed"}:
            reliable.append(record)
        else:
            uncertain.append(record)
    return reliable, uncertain, [template.__dict__ for template in templates]


def _auto_column_candidates(
    exact: ExactVoxelEvidence,
    walls: list[dict[str, Any]],
    cfg: dict[str, Any],
    semantic_column_probability: np.ndarray | None = None,
    height_window_values: list[Any] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """Detect compact, floor-to-ceiling column instances without manual ROIs."""

    span_m = exact.ceiling_m - exact.floor_m
    minimum_bins = int(cfg.get("auto_column_min_height_bins", 12))
    minimum_span = float(cfg.get("auto_column_min_vertical_span_m", 1.20))
    maximum_start = float(cfg.get("auto_column_max_start_m", 0.40))
    minimum_top = float(cfg.get("auto_column_min_top_m", max(1.50, span_m - 0.35)))
    eligible = (
        (exact.all_bin_count >= minimum_bins)
        & ((exact.all_z_max_bin - exact.all_z_min_bin + 1) * exact.z_bin_m >= minimum_span)
        & (exact.all_z_min_bin * exact.z_bin_m <= maximum_start)
        & ((exact.all_z_max_bin + 1) * exact.z_bin_m >= minimum_top)
    )
    mask = np.zeros(exact.shape, np.uint8)
    mask.ravel()[exact.all_xy_cell[eligible]] = 1
    association_close_m = float(cfg.get("auto_column_association_close_m", 0.45))
    association_kernel_px = max(3, int(round(association_close_m / exact.grid_m)))
    if association_kernel_px % 2 == 0:
        association_kernel_px += 1
    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (association_kernel_px, association_kernel_px)
        ),
    )
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    voxel_component = labels.ravel()[exact.xy_cell]
    initial: list[dict[str, Any]] = []
    rejected_reasons: dict[str, int] = {}
    minimum_size = float(
        cfg.get("auto_column_min_size_m", cfg.get("column_min_size_m", 0.15))
    )
    maximum_size = float(cfg.get("column_max_size_m", 1.80))
    wall_lines = [_record_line(value) for value in walls]
    window_bins = [
        (
            value.window_id,
            value.scale,
            int(math.floor((value.z_min_m - exact.floor_m) / exact.z_bin_m + 1e-9)),
            int(math.ceil((value.z_max_m - exact.floor_m) / exact.z_bin_m - 1e-9)),
        )
        for value in (height_window_values or [])
    ]

    def reject(reason: str) -> None:
        rejected_reasons[reason] = rejected_reasons.get(reason, 0) + 1

    for component_id in range(1, count):
        x, y, width_px, height_px, area_px = stats[component_id]
        width_m = width_px * exact.grid_m
        height_m = height_px * exact.grid_m
        if min(width_m, height_m) < minimum_size * 0.65:
            reject("too_narrow")
            continue
        if max(width_m, height_m) > maximum_size * 1.35:
            reject("not_compact")
            continue
        if area_px < int(cfg.get("auto_column_min_xy_cells", 10)):
            reject("too_few_xy_cells")
            continue
        selected = voxel_component == component_id
        if np.count_nonzero(selected) < int(cfg.get("auto_column_min_voxels", 30)):
            reject("too_few_voxels")
            continue
        points = exact.centroids[selected, :2].astype(float)
        bins = exact.z_bin[selected].astype(int)
        try:
            if window_bins:
                fit = fit_column_across_height_windows(
                    points,
                    bins,
                    window_bins,
                    min_size_m=minimum_size,
                    max_size_m=maximum_size,
                    surface_distance_m=float(
                        cfg.get("column_face_support_distance_m", 0.075)
                    ),
                )
            else:
                fit = fit_best_column_instance(
                    points,
                    bins,
                    min_size_m=minimum_size,
                    max_size_m=maximum_size,
                    surface_distance_m=float(
                        cfg.get("column_face_support_distance_m", 0.075)
                    ),
                )
        except ValueError:
            reject("fit_failed")
            continue

        # The same cross-section must remain in place over independent height
        # ranges.  Medians are used only as a stability check, not as the final
        # centre estimate (which comes from the surface model).
        unique_bins = np.unique(bins)
        groups = [value for value in np.array_split(unique_bins, 3) if len(value)]
        centers = []
        for group in groups:
            member = np.isin(bins, group)
            if np.count_nonzero(member) >= 6:
                centers.append(np.median(points[member], axis=0))
        if len(centers) < 2:
            reject("insufficient_height_groups")
            continue
        centers_array = np.asarray(centers)
        stability = float(np.max(np.linalg.norm(centers_array - np.median(centers_array, axis=0), axis=1)))
        fit["cross_height_center_spread_m"] = stability
        if stability > float(cfg.get("auto_column_max_center_spread_m", 0.20)):
            fit["status"] = "uncertain"
            fit["reason"] = "cross_height_center_shift"

        wall_distance = min((line.distance(fit["polygon"]) for line in wall_lines), default=float("inf"))
        fit["nearest_wall_distance_m"] = float(wall_distance)
        component_pixels = labels == component_id
        if semantic_column_probability is not None:
            semantic_values = semantic_column_probability[component_pixels]
            fit["semantic_column_probability_max"] = float(
                np.max(semantic_values) if len(semantic_values) else 0.0
            )
            fit["semantic_column_probability_mean"] = float(
                np.mean(semantic_values) if len(semantic_values) else 0.0
            )
        if wall_distance <= float(cfg.get("auto_column_wall_conflict_m", 0.08)):
            fit["status"] = "uncertain"
            fit["reason"] = "wall_corner_conflict"
        fit["column_id"] = f"AUTO-COL-{len(initial):04d}"
        fit["source"] = (
            "semantic_seed_plus_exact_3d_cross_height_instance"
            if semantic_column_probability is not None
            and fit.get("semantic_column_probability_max", 0.0)
            >= float(cfg.get("semantic_confidence", 0.80))
            else "exact_3d_cross_height_geometric_instance"
        )
        fit["semantic"] = "column"
        fit["_points_xy"] = points
        fit["_height_bins"] = bins
        initial.append(fit)

    templates = learn_column_templates(
        initial,
        minimum_group_size=int(cfg.get("column_template_min_group_size", 3)),
        dimension_tolerance_m=float(cfg.get("column_template_dimension_tolerance_m", 0.12)),
    )
    completed: list[dict[str, Any]] = []
    for value in initial:
        final = value
        if (
            value.get("status") == "uncertain"
            and value.get("cross_section_model") == "rectangle"
            and value.get("reason") not in {"cross_height_center_shift", "wall_corner_conflict"}
        ):
            template = compatible_template(value, templates)
            if template is not None:
                refit = fit_column_instance(
                    value["_points_xy"],
                    value["_height_bins"],
                    template=template,
                    min_size_m=minimum_size,
                    max_size_m=maximum_size,
                    face_distance_m=float(cfg.get("column_face_support_distance_m", 0.075)),
                )
                if refit.get("status") == "template_completed":
                    final = {
                        **refit,
                        "column_id": value["column_id"],
                        "source": "exact_3d_surface_plus_unique_size_template",
                        "semantic": "column",
                        "cross_height_center_spread_m": value["cross_height_center_spread_m"],
                        "nearest_wall_distance_m": value["nearest_wall_distance_m"],
                    }
        final.pop("_points_xy", None)
        final.pop("_height_bins", None)
        completed.append(final)
    initial = completed
    reliable = [
        value for value in initial if value.get("status") in {"reliable", "template_completed"}
    ]
    uncertain = [value for value in initial if value.get("status") not in {"reliable", "template_completed"}]
    metrics = {
        "connected_component_count": int(max(0, count - 1)),
        "fitted_candidate_count": len(initial),
        "reliable_count": len(reliable),
        "uncertain_count": len(uncertain),
        "rectangle_count": int(sum(value.get("cross_section_model") == "rectangle" for value in reliable)),
        "circle_count": int(sum(value.get("cross_section_model") == "circle" for value in reliable)),
        "association_close_m": association_close_m,
        "minimum_cross_section_m": minimum_size,
        "semantic_probability_used": semantic_column_probability is not None,
        "rejected_reasons": rejected_reasons,
        "centre_definition": "joint surface model; never visible-point centroid",
    }
    return reliable, uncertain, [value.__dict__ for value in templates], metrics


def _independent_metrics(records: list[dict[str, Any]], exact: ExactVoxelEvidence) -> dict[str, Any]:
    tree = cKDTree(exact.centroids[:, :2])
    audits = [
        curve_observation_audit(_record_line(record), exact, tree=tree)
        for record in records
    ]
    support_values: list[bool] = []
    matched_distances: list[float] = []
    sample_count = 0
    matched_count = 0
    for audit in audits:
        support_values.extend(bool(value) for value in audit["supported"])
        sample_count += int(audit["sample_count"])
        matched_count += int(audit.get("matched_count", 0))
        matched_distances.extend(
            float(value)
            for value in audit.get("nearest_distance_m", [])
            if value is not None
        )
    return {
        "validator": "raw_3d_voxel_own_arclength_interval",
        "line_count": len(records),
        "total_length_m": float(sum(_record_line(value).length for value in records)),
        "supported_fraction_10cm": float(np.mean(support_values)) if support_values else 0.0,
        # This is an XY distance within the configured 10 cm candidate search,
        # not a complete 3-D wall-plane residual.  It is reported only over
        # matched samples and accompanied by the unmatched fraction below.
        "matched_xy_distance_p95_m": (
            float(np.quantile(matched_distances, 0.95)) if matched_distances else None
        ),
        "line_to_surface_p95_m": (
            float(np.quantile(matched_distances, 0.95)) if matched_distances else None
        ),
        "sample_count": sample_count,
        "matched_sample_count": matched_count,
        "unmatched_sample_count": sample_count - matched_count,
        "matched_sample_fraction": (
            float(matched_count / sample_count) if sample_count else 0.0
        ),
        "audit_count": len(audits),
    }


def _revalidate_wall_records(
    records: list[dict[str, Any]],
    exact: ExactVoxelEvidence,
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """Split candidates by strict, per-arclength 3-D vertical support."""

    observed: list[dict[str, Any]] = []
    inferred: list[dict[str, Any]] = []
    minimum_length = float(cfg.get("wall_min_supported_run_m", 0.20))
    maximum_gap = float(cfg.get("wall_inferred_gap_max_m", 1.20))
    corrected_false_intervals = 0
    tree = cKDTree(exact.centroids[:, :2])
    for record in records:
        line = _record_line(record)
        audit = curve_observation_audit(
            line,
            exact,
            step_m=0.05,
            distance_m=float(cfg.get("wall_observed_distance_m", 0.10)),
            min_height_bins=int(cfg.get("evidence_min_height_bins", 11)),
            min_vertical_span_m=float(cfg.get("evidence_min_vertical_span_m", 1.20)),
            tree=tree,
        )
        support = np.asarray(audit["supported"], dtype=bool)
        arclength = np.asarray(audit["sample_arclength_m"], dtype=float)
        if len(support) < 2:
            continue
        interval_state = support[:-1] & support[1:]
        starts = np.r_[0, np.flatnonzero(interval_state[1:] != interval_state[:-1]) + 1]
        ends = np.r_[starts[1:], len(interval_state)]
        pieces: list[tuple[bool, LineString]] = []
        for start, end in zip(starts, ends):
            first = float(arclength[start])
            last = float(arclength[end])
            piece = LineString(
                [line.interpolate(first).coords[0], line.interpolate(last).coords[0]]
            )
            if piece.length > 1e-6:
                pieces.append((bool(interval_state[start]), piece))
        for index, (is_observed, piece) in enumerate(pieces):
            child = dict(record)
            child["wall_id"] = f"{record['wall_id']}-V5-{index:02d}"
            child["line"] = piece
            child["support_audit"] = {
                "validator": "own_arclength_interval_vertical_run",
                "minimum_height_bins": int(cfg.get("evidence_min_height_bins", 11)),
                "minimum_vertical_span_m": float(cfg.get("evidence_min_vertical_span_m", 1.20)),
            }
            if is_observed and piece.length + 1e-9 >= minimum_length:
                child["status"] = "observed"
                child["source"] = "exact_3d_multiscale_wall_surface"
                observed.append(child)
            elif (
                not is_observed
                and piece.length <= maximum_gap + 1e-9
                and index > 0
                and index + 1 < len(pieces)
                and pieces[index - 1][0]
                and pieces[index + 1][0]
            ):
                child["status"] = "inferred_gap"
                child["source"] = "bounded_gap_between_verified_wall_runs"
                inferred.append(child)
                corrected_false_intervals += 1
    return observed, inferred, {
        "input_candidate_count": len(records),
        "observed_run_count": len(observed),
        "bounded_inferred_run_count": len(inferred),
        "corrected_non_observed_interval_count": corrected_false_intervals,
    }


def _recover_human_wall_models(
    seed_lines: list[LineString],
    existing: list[dict[str, Any]],
    exact: ExactVoxelEvidence,
    wall_supervision: np.ndarray | None,
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Recover complete labelled wall objects without falsifying observation.

    The strict validator above deliberately labels only samples with their own
    3-D height run as observed.  A human wall ROI plus vertical Sonata/normal
    supervision may nevertheless establish that the intervening candidate is
    the same wall object.  Such geometry is retained as an explicit inferred
    model, never copied into the observed products.
    """

    if wall_supervision is None or not np.any(wall_supervision):
        return [], {"enabled": False, "reason": "no_wall_supervision"}
    cells = np.unique(exact.xy_cell[wall_supervision])
    wall_mask = np.zeros(exact.shape, np.uint8)
    wall_mask.ravel()[cells] = 1
    wall_distance = cv2.distanceTransform(
        (wall_mask == 0).astype(np.uint8), cv2.DIST_L2, cv2.DIST_MASK_PRECISE
    ) * exact.grid_m
    coverage_mask = np.zeros(exact.shape, np.uint8)

    def draw_coverage(line: LineString) -> None:
        coordinates = np.asarray(line.coords, dtype=float)
        pixels = np.rint((coordinates - exact.origin_xy) / exact.grid_m - 0.5).astype(np.int32)
        if len(pixels) >= 2:
            cv2.polylines(
                coverage_mask,
                [pixels.reshape(-1, 1, 2)],
                False,
                1,
                thickness=max(1, int(math.ceil(0.20 / exact.grid_m))),
            )

    for value in existing:
        draw_coverage(_record_line(value))
    sample_step = float(cfg.get("semantic_wall_model_step_m", 0.05))
    distance = float(cfg.get("semantic_wall_model_distance_m", 0.12))
    maximum_gap = float(cfg.get("wall_inferred_gap_max_m", 1.20))
    minimum_fraction = float(cfg.get("semantic_wall_model_min_fraction", 0.65))
    minimum_length = float(cfg.get("wall_candidate_min_length_m", 0.20))
    recovered: list[dict[str, Any]] = []
    candidate_piece_count = 0
    duplicate_count = 0

    for seed_index, line in enumerate(seed_lines):
        if line.length < minimum_length:
            continue
        count = max(2, int(math.ceil(line.length / sample_step)) + 1)
        arclength = np.linspace(0.0, line.length, count)
        samples = np.asarray([line.interpolate(float(value)).coords[0] for value in arclength])
        sample_pixels = np.rint(
            (samples - exact.origin_xy) / exact.grid_m - 0.5
        ).astype(np.int64)
        valid_samples = (
            (sample_pixels[:, 0] >= 0)
            & (sample_pixels[:, 0] < exact.shape[1])
            & (sample_pixels[:, 1] >= 0)
            & (sample_pixels[:, 1] < exact.shape[0])
        )
        supported = np.zeros(len(samples), dtype=bool)
        supported[valid_samples] = wall_distance[
            sample_pixels[valid_samples, 1], sample_pixels[valid_samples, 0]
        ] <= distance
        if not np.any(supported):
            continue
        # Close only bounded gaps along the already existing wall candidate.
        # This does not create a new direction or bridge unrelated walls.
        gap_samples = max(1, int(math.floor(maximum_gap / sample_step)))
        closed = cv2.morphologyEx(
            supported.astype(np.uint8).reshape(1, -1),
            cv2.MORPH_CLOSE,
            np.ones((1, gap_samples * 2 + 1), np.uint8),
        ).ravel().astype(bool)
        starts = np.r_[0, np.flatnonzero(closed[1:] != closed[:-1]) + 1]
        ends = np.r_[starts[1:], len(closed)]
        for start, end in zip(starts, ends):
            if not closed[start]:
                continue
            first = float(arclength[start])
            last = float(arclength[min(end, len(arclength) - 1)])
            if last - first < minimum_length:
                continue
            local_support = supported[start : min(end + 1, len(supported))]
            if float(np.mean(local_support)) < minimum_fraction:
                continue
            piece = LineString(
                [line.interpolate(first).coords[0], line.interpolate(last).coords[0]]
            )
            candidate_piece_count += 1
            piece_samples = _sample_line(piece, sample_step)
            piece_pixels = np.rint(
                (piece_samples - exact.origin_xy) / exact.grid_m - 0.5
            ).astype(np.int64)
            valid_pixels = (
                (piece_pixels[:, 0] >= 0)
                & (piece_pixels[:, 0] < exact.shape[1])
                & (piece_pixels[:, 1] >= 0)
                & (piece_pixels[:, 1] < exact.shape[0])
            )
            already_covered = np.zeros(len(piece_pixels), dtype=bool)
            already_covered[valid_pixels] = coverage_mask[
                piece_pixels[valid_pixels, 1], piece_pixels[valid_pixels, 0]
            ] > 0
            if float(np.mean(already_covered)) >= 0.80:
                duplicate_count += 1
                continue
            record = {
                "wall_id": f"HUMAN-WALL-{seed_index:05d}-{len(recovered):03d}",
                "line": piece,
                "geometry_kind": "line",
                "status": "inferred_semantic_object",
                "source": "human_wall_roi_vertical_surface_continuity",
                "semantic_support_fraction": float(np.mean(local_support)),
                "observed": False,
            }
            recovered.append(record)
            draw_coverage(piece)
    return recovered, {
        "enabled": True,
        "labelled_wall_xy_cell_count": int(len(cells)),
        "candidate_piece_count": candidate_piece_count,
        "duplicate_piece_count": duplicate_count,
        "recovered_piece_count": len(recovered),
        "recovered_length_m": float(sum(_record_line(value).length for value in recovered)),
        "status": "inferred_only",
    }


def _repair_metric(
    frozen_candidates: list[dict[str, Any]], final_records: list[dict[str, Any]]
) -> dict[str, Any]:
    if not frozen_candidates:
        return {"frozen_count": 0, "repair_rate": None, "repaired_length_fraction": None}
    samples = [
        (_sample_line(_record_line(value), 0.05), _record_line(value).length)
        for value in frozen_candidates
    ]
    final_samples = np.vstack([_sample_line(_record_line(value), 0.04) for value in final_records])
    tree = cKDTree(final_samples)
    repaired = []
    lengths = []
    for points, length in samples:
        fraction = float(np.mean(tree.query(points, workers=-1)[0] <= 0.10))
        repaired.append(fraction >= 0.90)
        lengths.append(length)
    return {
        "frozen_count": len(frozen_candidates),
        "repaired_count": int(sum(repaired)),
        "repair_rate": float(np.mean(repaired)),
        "frozen_length_m": float(sum(lengths)),
        "repaired_length_fraction": float(
            sum(length for length, ok in zip(lengths, repaired) if ok) / max(sum(lengths), 1e-9)
        ),
        "definition": "candidate frozen before selection; >=90% sampled length within 10cm of landed geometry",
    }


def _write_window_products(
    output: Path,
    exact: ExactVoxelEvidence,
    masks: dict[str, np.ndarray],
    windows: list[Any],
    prefix: str,
    shared_records: list[dict[str, Any]],
) -> dict[str, Any]:
    projection_dir = output / "height_slices" / f"projections_{prefix}"
    dxf_dir = output / "height_slices" / f"dxf_{prefix}"
    projection_dir.mkdir(parents=True, exist_ok=True)
    dxf_dir.mkdir(parents=True, exist_ok=True)
    per_window: list[dict[str, Any]] = []
    tree = cKDTree(exact.centroids[:, :2])
    states_by_wall: dict[str, list[np.ndarray]] = {
        str(record.get("wall_id", index)): [] for index, record in enumerate(shared_records)
    }
    arclength_by_wall: dict[str, np.ndarray] = {}

    def state_segments(line: LineString, state: np.ndarray, arclength: np.ndarray) -> list[LineString]:
        interval = state[:-1] & state[1:]
        if not len(interval) or not np.any(interval):
            return []
        starts = np.r_[0, np.flatnonzero(interval[1:] != interval[:-1]) + 1]
        ends = np.r_[starts[1:], len(interval)]
        result: list[LineString] = []
        for start, end in zip(starts, ends):
            if not interval[start]:
                continue
            first = line.interpolate(float(arclength[start])).coords[0]
            last = line.interpolate(float(arclength[end])).coords[0]
            segment = LineString([first, last])
            if segment.length >= 0.05 - 1e-9:
                result.append(segment)
        return result

    for window in windows:
        mask = masks[window.window_id]
        cv2.imwrite(str(projection_dir / f"{window.window_id}.png"), np.flipud(mask.astype(np.uint8) * 255))
        lines: list[LineString] = []
        for index, record in enumerate(shared_records):
            wall_id = str(record.get("wall_id", index))
            line = _record_line(record)
            audit = curve_observation_audit(
                line,
                exact,
                step_m=0.05,
                distance_m=0.10,
                min_height_bins=2,
                min_vertical_span_m=0.10,
                tree=tree,
                z_min_m=window.z_min_m,
                z_max_m=window.z_max_m,
            )
            state = np.asarray(audit["supported"], dtype=bool)
            arclength = np.asarray(audit["sample_arclength_m"], dtype=float)
            states_by_wall[wall_id].append(state)
            arclength_by_wall[wall_id] = arclength
            lines.extend(state_segments(line, state, arclength))
        doc = ezdxf.new("R2013")
        doc.header["$INSUNITS"] = 6
        doc.layers.add("OBSERVED_SLICE", color=7)
        space = doc.modelspace()
        for line in lines:
            coordinates = np.asarray(line.coords, dtype=float)
            if len(coordinates) >= 2:
                space.add_lwpolyline(coordinates, dxfattribs={"layer": "OBSERVED_SLICE"})
        doc.saveas(dxf_dir / f"{window.window_id}.dxf")
        per_window.append({"window_id": window.window_id, "line_count": len(lines)})

    strict_lines: list[LineString] = []
    union_lines: list[LineString] = []
    for index, record in enumerate(shared_records):
        wall_id = str(record.get("wall_id", index))
        states = states_by_wall[wall_id]
        if not states:
            continue
        line = _record_line(record)
        arclength = arclength_by_wall[wall_id]
        strict_lines.extend(state_segments(line, np.all(np.stack(states), axis=0), arclength))
        union_lines.extend(state_segments(line, np.any(np.stack(states), axis=0), arclength))
    for name, lines in (("strict_intersection", strict_lines), ("maximum_union", union_lines)):
        doc = ezdxf.new("R2013")
        doc.header["$INSUNITS"] = 6
        doc.layers.add("OBSERVED_SET", color=7)
        for line in lines:
            doc.modelspace().add_lwpolyline(np.asarray(line.coords), dxfattribs={"layer": "OBSERVED_SET"})
        doc.saveas(output / "height_slices" / f"{name}_{prefix}.dxf")
    if masks:
        stack = np.stack([masks[window.window_id] for window in windows])
        strict = np.all(stack, axis=0)
        union = np.any(stack, axis=0)
        cv2.imwrite(str(output / "height_slices" / f"strict_intersection_{prefix}.png"), np.flipud(strict.astype(np.uint8) * 255))
        cv2.imwrite(str(output / "height_slices" / f"maximum_union_{prefix}.png"), np.flipud(union.astype(np.uint8) * 255))
    return {
        "window_count": len(windows),
        "windows": per_window,
        "strict_intersection_line_count": len(strict_lines),
        "maximum_union_line_count": len(union_lines),
        "geometry_source": "shared_wall_graph_revalidated_in_each_height_window",
    }


def _render_v5_plan(
    path: Path,
    evidence: VoxelEvidence,
    observed: list[dict[str, Any]],
    inferred: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    openings: list[dict[str, Any]],
    title: str,
) -> None:
    image = np.zeros((*evidence.shape, 3), np.uint8)
    image[evidence.raw_mask] = (42, 42, 42)

    def draw_line(line: LineString, colour: tuple[int, int, int], width: int) -> None:
        coordinates = np.asarray(line.coords, dtype=float)
        pixels = np.rint((coordinates - evidence.origin) / evidence.grid_m - 0.5).astype(np.int32)
        cv2.polylines(image, [pixels.reshape(-1, 1, 2)], False, colour, width, cv2.LINE_AA)

    for record in observed:
        draw_line(_record_line(record), (245, 245, 245), 5)
    for record in inferred:
        draw_line(_record_line(record), (0, 165, 255), 4)
    for record in openings:
        draw_line(_record_line(record), (255, 160, 40), 4)
    for record in columns:
        coordinates = np.asarray(record["polygon"].exterior.coords, dtype=float)
        pixels = np.rint((coordinates - evidence.origin) / evidence.grid_m - 0.5).astype(np.int32)
        cv2.polylines(image, [pixels.reshape(-1, 1, 2)], True, (255, 220, 0), 7, cv2.LINE_AA)
    image = np.flipud(image).copy()
    scale = min(1.0, 3600.0 / max(image.shape[:2]))
    if scale < 1.0:
        image = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    cv2.putText(image, title, (18, 36), cv2.FONT_HERSHEY_SIMPLEX, 0.78, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.imwrite(str(path), image)


def run_structure_v5(
    config_path: str | Path,
    point_cloud_path: str | Path,
    source_point_cloud_path: str | Path,
    transforms_path: str | Path,
    preview_dir: str | Path,
    output_dir: str | Path,
) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    clean_path = Path(point_cloud_path).resolve()
    source_path = Path(source_point_cloud_path).resolve()
    transforms_path = Path(transforms_path).resolve()
    preview = Path(preview_dir).resolve()
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    config = load_config(config_path)
    if config.get("project", {}).get("scene_type") != "underground_parking":
        raise ValueError("Parking V5 requires underground_parking")
    cfg = dict(config.get("parking_structure", {}))
    if cfg.get("algorithm_version") != "parking_structure_v5":
        raise ValueError("V5 runner requires parking_structure_v5")
    transform = np.asarray(read_json(transforms_path)["T_cad_reference_slam"], dtype=float)
    v3_path = Path(cfg.get("v3_geojson", output.parent / "structure_v3" / "architectural_plan.geojson"))
    if not v3_path.is_absolute():
        v3_path = (config_path.parent / v3_path).resolve()
    seed_lines, _ = _read_v3_features(v3_path)
    if not seed_lines:
        seed_lines = _read_v3_features(preview / "persistent_structure.geojson")[0]

    fingerprint = _fingerprint([source_path, clean_path, transforms_path], cfg)
    cache = output / "cache" / "evidence"
    cache.mkdir(parents=True, exist_ok=True)
    cache_file = cache / "exact_voxels.npz"
    cache_meta = cache / "meta.json"
    cache_hit = cache_file.exists() and cache_meta.exists() and read_json(cache_meta).get("fingerprint") == fingerprint
    if cache_hit:
        exact = load_exact_evidence(cache_file)
    else:
        source_cad = _transform_points(read_point_cloud(source_path), transform)
        clean_cad = _transform_points(read_point_cloud(clean_path), transform)
        floor_m = float(
            np.quantile(clean_cad[:, 2], float(cfg.get("surface_floor_quantile", 0.001)))
            - float(cfg.get("surface_floor_restore_margin_m", 0.12))
        )
        ceiling_m = float(
            np.quantile(clean_cad[:, 2], float(cfg.get("surface_ceiling_quantile", 0.999)))
            + float(cfg.get("surface_ceiling_restore_margin_m", 0.12))
        )
        exact = build_exact_voxel_evidence(
            source_cad,
            grid_m=float(cfg.get("evidence_grid_m", 0.05)),
            z_bin_m=float(cfg.get("evidence_z_bin_m", 0.10)),
            floor_guard_m=float(cfg.get("evidence_floor_guard_m", 0.12)),
            ceiling_guard_m=float(cfg.get("evidence_ceiling_guard_m", 0.12)),
            floor_m=floor_m,
            ceiling_m=ceiling_m,
            min_vertical_span_m=float(cfg.get("evidence_min_vertical_span_m", 1.20)),
            min_height_bins=int(cfg.get("evidence_min_height_bins", 11)),
            max_start_above_floor_m=float(cfg.get("evidence_max_start_above_floor_m", 0.80)),
            min_top_above_floor_m=float(cfg.get("evidence_min_top_above_floor_m", 1.80)),
            padding_m=float(cfg.get("raster_padding_m", 0.50)),
        )
        save_exact_evidence(cache_file, exact)
        write_json(cache_meta, {"fingerprint": fingerprint})

    thin = (
        []
        if bool(cfg.get("ablation_disable_thin_windows", False))
        else height_windows(
            exact.floor_m,
            exact.ceiling_m,
            float(cfg.get("thin_slice_thickness_m", 0.50)),
            float(cfg.get("thin_slice_step_m", 0.30)),
            "thin",
        )
    )
    thick = (
        []
        if bool(cfg.get("ablation_disable_thick_windows", False))
        else height_windows(
            exact.floor_m,
            exact.ceiling_m,
            float(cfg.get("thick_slice_thickness_m", 1.00)),
            float(cfg.get("thick_slice_step_m", 0.50)),
            "thick",
        )
    )
    thin_masks = window_occupancy(exact, thin)
    thick_masks = window_occupancy(exact, thick)
    annotation_value = cfg.get("semantic_annotations")
    annotation_path = Path(annotation_value) if annotation_value else None
    if annotation_path is not None and not annotation_path.is_absolute():
        annotation_path = (config_path.parent / annotation_path).resolve()
    objects = _annotation_objects(annotation_path)
    semantic_value = cfg.get("semantic_probability_cache")
    semantic_path = Path(semantic_value) if semantic_value else None
    if semantic_path is not None and not semantic_path.is_absolute():
        semantic_path = (config_path.parent / semantic_path).resolve()
    semantic = _load_semantic_rasters(semantic_path, exact.shape)
    if cfg.get("semantic_required", False) and semantic is None:
        raise ValueError("semantic_required=true but no valid parking semantic probability cache exists")
    supervision_value = cfg.get("semantic_supervision_cache")
    supervision_path = Path(supervision_value) if supervision_value else None
    if supervision_path is not None and not supervision_path.is_absolute():
        supervision_path = (config_path.parent / supervision_path).resolve()
    wall_supervision: np.ndarray | None = None
    column_supervision: np.ndarray | None = None
    if (
        supervision_path is not None
        and supervision_path.exists()
        and bool(cfg.get("manual_wall_column_rois_for_reconstruction", True))
    ):
        with np.load(supervision_path, allow_pickle=False) as values:
            coordinates = values["coordinates"]
            if coordinates.shape != exact.centroids.shape or not np.array_equal(
                coordinates.astype(np.float32), exact.centroids.astype(np.float32)
            ):
                raise ValueError("semantic supervision/evidence coordinate mismatch")
            # Training labels are wall=0, column=1, vehicle=2, ignored=-1.
            supervision_labels = values["labels"].astype(np.int8)
            wall_supervision = supervision_labels == 0
            column_supervision = supervision_labels == 1
    (
        reconstruction_objects,
        reconstruction_wall_supervision,
        reconstruction_column_supervision,
        manual_wall_column_rois_enabled,
    ) = _prepare_reconstruction_annotation_inputs(
        objects, wall_supervision, column_supervision, cfg
    )
    observed_mask, candidate_mask, fusion_metrics = multiscale_fusion(
        exact,
        thin_masks,
        thick_masks,
        None if semantic is None else semantic["wall_probability"],
    )
    # Candidate generation needs only a locally persistent vertical trace;
    # final observed status is assigned later by the stricter 1.2 m
    # per-arclength validator.  This accommodates lateral beam drift without
    # copying a coarse cell's support into its neighbours.
    extraction_mask = vertical_run_mask(
        exact,
        min_bins=int(cfg.get("candidate_min_height_bins", 4)),
        min_span_m=float(cfg.get("candidate_min_vertical_span_m", 0.40)),
    )
    blocked = _annotation_block_mask(objects, exact)
    wall_regions = _annotation_region_mask(reconstruction_objects, exact, {"wall"})
    vehicle_regions = _annotation_region_mask(objects, exact, {"vehicle"})
    semantic_gate_metrics: dict[str, Any] = {"enabled": semantic is not None}
    if semantic is not None:
        confidence = float(cfg.get("semantic_confidence", 0.80))
        agreement = semantic["agreement_probability"] >= float(
            cfg.get("semantic_minimum_agreement_fraction", 2.0 / 3.0)
        )
        wall_semantic = (semantic["wall_probability"] >= confidence) & agreement
        # A three-class softmax must assign every unknown voxel to one of its
        # classes.  Vehicle probability therefore only refines a reviewed
        # vehicle search region; it never turns arbitrary unlabelled space
        # into a negative building mask.
        vehicle_semantic = (
            (semantic["vehicle_probability"] >= confidence)
            & agreement
            & vehicle_regions
        )
        blocked |= vehicle_semantic
        semantic_gate_metrics.update(
            {
                "confidence": confidence,
                "wall_candidate_cell_count": int(np.count_nonzero(wall_semantic)),
                "vehicle_block_cell_count": int(np.count_nonzero(vehicle_semantic)),
                "vehicle_predictions_outside_reviewed_regions_ignored": int(
                    np.count_nonzero(
                        (semantic["vehicle_probability"] >= confidence)
                        & agreement
                        & ~vehicle_regions
                    )
                ),
                "other_definition": "outside geometry/annotation gates or below confidence remains unknown",
            }
        )
        # Thin/thick occupancy is intentionally permissive.  It may propose a
        # missing wall only where the parking semantic head independently
        # agrees; otherwise furniture at one height creates an enormous,
        # connected global skeleton.
        candidate_mask = extraction_mask | (
            candidate_mask
            & wall_semantic
        )
    else:
        # Geometry baseline contains no learned authority for promoting a
        # low-height candidate.  Directional morphology can still suggest
        # bounded bridges later, but candidate pixels are not called walls.
        candidate_mask = extraction_mask.copy()
    candidate_mask &= ~blocked
    observed_mask &= ~blocked
    projection_classifications = []
    projection_classification_metrics: dict[str, Any] = {"enabled": False}
    projection_semantic_products: dict[str, Any] | None = None
    projection_wall_records: list[dict[str, Any]] = []
    projection_wall_metrics: dict[str, Any] = {"enabled": False}
    projection_mode = bool(cfg.get("projection_object_reconstruction", False))
    if projection_mode:
        if semantic is None:
            raise ValueError(
                "projection_object_reconstruction requires voxel semantic probabilities"
            )
        if "voxel_probability" not in semantic or "voxel_agreement" not in semantic:
            raise ValueError(
                "semantic probability cache lacks voxel_probability/voxel_agreement"
            )
        projection_classifications, projection_classification_metrics = (
            classify_height_projections(
                exact,
                [*thin, *thick],
                semantic["voxel_probability"],
                semantic["voxel_agreement"],
                cfg,
                wall_supervision=reconstruction_wall_supervision,
                column_supervision=reconstruction_column_supervision,
            )
        )
        projection_classification_metrics["enabled"] = True
        projection_semantic_products = write_projection_semantic_products(
            output / "projection_semantics",
            exact,
            projection_classifications,
        )
        projection_wall_records, projection_wall_metrics = trace_projection_wall_objects(
            exact,
            projection_classifications,
            cfg,
            blocker_mask=blocked,
        )
        projection_wall_metrics["enabled"] = True
    # The no-network baseline evaluates the new 3-D support/fit on the known
    # V3 candidate neighbourhood.  It does not attempt to skeletonise every
    # stable table/car edge in a 300 m map.  In semantic mode, confident wall
    # probability may introduce candidates outside this corridor.
    corridor = _line_corridor(
        seed_lines,
        exact,
        float(cfg.get("geometry_seed_corridor_m", 0.20)),
    )
    fit_mask = candidate_mask & corridor
    if np.any(wall_regions):
        # Human wall polygons authorise searching for vertical wall evidence,
        # but their interiors are never copied into the mask.  This allows a
        # loose closed ROI to recover walls without turning cars or empty floor
        # inside that ROI into wall supervision.
        fit_mask |= extraction_mask & wall_regions
    if semantic is not None:
        fit_mask |= candidate_mask & wall_semantic
    main_angle = float(cfg.get("cached_main_angle_rad", math.pi / 4.0))
    proposal = _proposal_mask(fit_mask, main_angle, exact.grid_m, cfg)
    evidence = _adapter(exact, fit_mask, proposal, cfg)
    tracking_mask = fit_mask & ~corridor
    legacy_tracking = (
        _tracking_seed_lines(tracking_mask, exact, cfg)
        if np.any(tracking_mask) and not projection_mode
        else []
    )
    projection_length = float(
        sum(value["line"].length for value in projection_wall_records)
    )
    projection_minimum_length = float(
        cfg.get("projection_primary_minimum_total_length_m", 25.0)
    )
    projection_primary = bool(
        projection_mode
        and projection_wall_records
        and projection_length >= projection_minimum_length
    )
    if projection_primary:
        tracking = [value["line"] for value in projection_wall_records]
        source_records = projection_wall_records
        source_lines = tracking
    else:
        tracking = legacy_tracking
        source_lines = [*seed_lines, *tracking]
        source_records = [
            {
                "wall_id": f"V5C-{index:05d}",
                "line": line,
                "geometry_kind": "curve" if len(line.coords) > 2 else "line",
                "status": "candidate",
                "source": (
                    "v3_corridor_candidate"
                    if index < len(seed_lines)
                    else "semantic_multiscale_candidate"
                ),
            }
            for index, line in enumerate(source_lines)
        ]
    projection_wall_metrics.update(
        {
            "used_as_primary": projection_primary,
            "fallback_reason": (
                None
                if projection_primary
                else "directional_total_length_below_guard_or_mode_disabled"
            ),
            "minimum_primary_total_length_m": projection_minimum_length,
        }
    )
    if bool(cfg.get("v5_skip_legacy_global_merge", True)):
        wall_candidates = [
            value
            for value in source_records
            if value["line"].length
            >= float(cfg.get("wall_candidate_min_length_m", 0.20))
        ]
        wall_metrics = {
            "source_line_count": len(source_lines),
            "semantic_tracking_line_count": len(tracking),
            "candidate_count_before_strict_3d_validation": len(wall_candidates),
            "legacy_global_pairwise_merge_skipped": True,
            "projection_object_primary": projection_primary,
        }
    else:
        wall_candidates, wall_metrics = extract_wall_objects(source_lines, evidence, cfg)
        wall_metrics.pop("unverified_bridge_candidates", None)
    walls, preliminary_inferred, strict_validation = _revalidate_wall_records(
        wall_candidates, exact, cfg
    )
    walls, _, node_metrics_before = update_shared_nodes(walls, cfg)
    frozen_candidates = _connection_candidates(walls, evidence, cfg)
    selected_observed, selected_inferred = select_non_competing_connections(
        sorted(frozen_candidates, key=lambda value: value["score"], reverse=True), cfg
    )
    recovered, inferred = split_connections_by_observation(selected_observed + selected_inferred, evidence, cfg)
    combined, nodes, node_metrics = update_shared_nodes(
        walls + preliminary_inferred + recovered + inferred, cfg
    )
    observed, inferred, final_strict_validation = _revalidate_wall_records(
        combined, exact, cfg
    )
    human_wall_models, human_wall_metrics = _recover_human_wall_models(
        source_lines,
        observed + inferred,
        exact,
        reconstruction_wall_supervision,
        cfg,
    )
    human_combined, nodes, human_node_metrics = update_shared_nodes(
        observed + inferred + human_wall_models,
        cfg,
    )
    human_observed = [
        value for value in human_combined if value.get("status") == "observed"
    ]
    human_inferred = [
        value for value in human_combined if value.get("status") != "observed"
    ]
    post_recovery_candidates = _connection_candidates(human_combined, evidence, cfg)
    selected_post_observed, selected_post_inferred = select_non_competing_connections(
        sorted(post_recovery_candidates, key=lambda value: value["score"], reverse=True),
        cfg,
    )
    # V4's splitter calls proximity to a 2-D occupied pixel "observed".  That
    # is insufficient for V5's directional 3-D wall definition.  Connections
    # added after semantic object recovery therefore remain explicitly
    # inferred, even when nearby raw returns improve their score.
    post_recovery_observed: list[dict[str, Any]] = []
    post_recovery_inferred = []
    for value in selected_post_observed + selected_post_inferred:
        record = dict(value)
        record["status"] = "inferred_gap"
        record["source"] = "post_recovery_topology_connector_unverified_3d"
        record["observed"] = False
        post_recovery_inferred.append(record)
    post_recovery_combined, nodes, post_recovery_node_metrics = update_shared_nodes(
        human_observed
        + human_inferred
        + post_recovery_observed
        + post_recovery_inferred,
        cfg,
    )
    stable_cfg = dict(cfg)
    stable_cfg["wall_junction_tolerance_m"] = 0.001
    stable_combined, nodes, stable_node_metrics = update_shared_nodes(
        post_recovery_combined,
        stable_cfg,
    )
    observed = [value for value in stable_combined if value.get("status") == "observed"]
    inferred = [value for value in stable_combined if value.get("status") != "observed"]

    manual_columns, manual_uncertain, manual_templates = _fit_annotated_columns(
        reconstruction_objects,
        exact,
        cfg,
        column_supervision=reconstruction_column_supervision,
        height_window_values=[*thin, *thick],
    )
    automatic_columns, automatic_uncertain, automatic_templates, automatic_column_metrics = (
        _auto_column_candidates(
            exact,
            observed,
            cfg,
            None
            if semantic is None
            else np.where(
                semantic["agreement_probability"]
                >= float(cfg.get("semantic_minimum_agreement_fraction", 2.0 / 3.0)),
                semantic["column_probability"],
                0.0,
            ),
            height_window_values=[*thin, *thick],
        )
    )
    columns = manual_columns + automatic_columns
    uncertain_columns = manual_uncertain + automatic_uncertain
    templates = manual_templates + automatic_templates
    closure_support_threshold = float(
        cfg.get("closed_region_min_observed_fraction", 0.80)
    )
    closure_supported_models = [
        value
        for value in inferred
        if value.get("status") == "inferred_semantic_object"
        and float(value.get("semantic_support_fraction", 0.0))
        >= closure_support_threshold
    ]
    closure_supported_ids = {id(value) for value in closure_supported_models}
    closure_base = observed + closure_supported_models
    closure_connectors = [
        value for value in inferred if id(value) not in closure_supported_ids
    ]
    virtual = _virtual_opening_candidates(closure_base, closure_connectors, cfg)
    regions, closure_edges, closure_metrics = optimise_closed_regions(
        closure_base,
        closure_connectors,
        virtual,
        cfg,
    )
    closure_metrics["semantic_supported_base_count"] = len(closure_supported_models)
    selected_ids = {value.get("connection_id") for value in closure_edges}
    inferred.extend(
        value for value in closure_edges
        if value.get("status") == "inferred_gap" and value.get("connection_id") not in {record.get("connection_id") for record in inferred}
    )
    openings = [value for value in closure_edges if value.get("status") == "virtual_opening"]

    write_architectural_dxf(output / "architectural_plan.dxf", observed, inferred, columns, uncertain_columns)
    write_closed_layout_dxf(output / "closed_layout.dxf", regions, closure_edges)
    write_structure_geojson(
        output / "architectural_plan.geojson", observed, inferred, columns, uncertain_columns, regions, nodes, transform
    )
    write_json(
        output / "building_object_graph.json",
        {
            "algorithm": "parking_structure_v5",
            "walls": [
                {key: value for key, value in record.items() if key != "line"}
                | {"coordinates": np.asarray(_record_line(record).coords).tolist()}
                for record in observed + inferred
            ],
            "columns": [
                {
                    key: value
                    for key, value in record.items()
                    if key
                    not in {"polygon", "center", "cross_height_consensus_center"}
                }
                | {
                    "center": np.asarray(record["center"]).tolist(),
                    "cross_height_consensus_center": (
                        np.asarray(record["cross_height_consensus_center"]).tolist()
                        if record.get("cross_height_consensus_center") is not None
                        else None
                    ),
                    "coordinates": np.asarray(
                        record["polygon"].exterior.coords
                    ).tolist(),
                }
                for record in columns
            ],
            "column_templates": templates,
            "nodes": nodes,
            "regions": [
                {key: value for key, value in region.items() if key != "polygon"}
                | {"coordinates": np.asarray(region["polygon"].exterior.coords).tolist()}
                for region in regions
            ],
        },
    )
    _render_v5_plan(
        output / "architectural_plan.png", evidence, observed, inferred, columns, openings,
        f"ICPAR V5 GEOMETRY={'SEMANTIC' if semantic is not None else 'BASELINE'} - {len(observed)} observed - {len(columns)} columns",
    )
    _render_v5_plan(
        output / "closed_layout.png", evidence, observed, inferred, columns, openings,
        f"ICPAR V5 CLOSED LAYOUT - {len(regions)} regions",
    )
    shared_products = observed + inferred
    thin_products = _write_window_products(
        output, exact, thin_masks, thin, "thin", shared_products
    )
    thick_products = _write_window_products(
        output, exact, thick_masks, thick, "thick", shared_products
    )
    independent = _independent_metrics(observed, exact)
    repairs = _repair_metric(frozen_candidates, observed + inferred)
    disk = audit_written_outputs(output)
    v4_report_value = cfg.get("v4_report")
    v4_report_path = Path(v4_report_value) if v4_report_value else None
    if v4_report_path is not None and not v4_report_path.is_absolute():
        v4_report_path = (config_path.parent / v4_report_path).resolve()
    if v4_report_path is not None and v4_report_path.exists():
        historical_v4 = read_json(v4_report_path)
        v4_lines = _read_v3_features(v4_report_path.parent / "architectural_plan.geojson")[0]
        v4_reaudit = {
            "historical_recommended": historical_v4.get("recommended"),
            "independent_observation_metrics": _independent_metrics(
                [{"line": line} for line in v4_lines], exact
            ) if v4_lines else None,
            "invalidated_historical_metrics": {
                "frozen_fixable_gap_repair_rate": "tautological assignment; not comparable",
                "line_to_raw_p95_m": "2-D XY nearest-cell proxy; renamed and not treated as 3-D wall-plane error",
            },
        }
        write_json(output / "v4_reaudit.json", v4_reaudit)
    else:
        v4_reaudit = None
    annotations_complete = bool(objects) and bool(cfg.get("annotations_complete", False))
    semantic_enabled = semantic is not None
    acceptance = {
        "exact_per_cell_height_support": True,
        "independent_observed_p95_le_10cm": bool(
            independent["line_to_surface_p95_m"] is not None and independent["line_to_surface_p95_m"] <= 0.10
        ),
        "independent_observed_support_ge_95pct": independent["supported_fraction_10cm"] >= 0.95,
        "frozen_gap_repair_ge_90pct": repairs["repair_rate"] is not None and repairs["repair_rate"] >= 0.90,
        "landed_dxf_valid": bool(
            disk["architectural_xdata_count"] == disk["architectural_entity_count"]
            and disk["closed_polylines_self_intersection_count"] == 0
        ),
        "closed_regions_present": bool(len(regions) > 0),
        "full_annotations_present": annotations_complete,
        "parking_semantics_enabled": semantic_enabled,
    }
    report = {
        "algorithm": "parking_structure_v5",
        "stage": "semantic_main" if semantic_enabled else "geometry_baseline",
        "recommended": bool(all(acceptance.values())),
        "acceptance": acceptance,
        "inputs": {
            "clean_pcd": str(clean_path),
            "source_pcd": str(source_path),
            "transforms": str(transforms_path),
            "annotations": str(annotation_path) if annotation_path else None,
            "semantic_probability_cache": str(semantic_path) if semantic_path else None,
            "semantic_supervision_cache": str(supervision_path) if supervision_path else None,
            "evidence_cache_hit": cache_hit,
            "fingerprint": fingerprint,
        },
        "evidence": evidence.source_metrics,
        "multiscale_fusion": fusion_metrics,
        "per_projection_semantics": projection_classification_metrics,
        "per_projection_semantic_products": projection_semantic_products,
        "directional_wall_objects": projection_wall_metrics,
        "semantic_gating": semantic_gate_metrics,
        "wall_reconstruction": wall_metrics,
        "strict_wall_validation": strict_validation,
        "final_strict_wall_validation": final_strict_validation,
        "human_wall_object_recovery": human_wall_metrics,
        "human_wall_node_pass": human_node_metrics,
        "post_recovery_connections": {
            "candidate_count": len(post_recovery_candidates),
            "observed_piece_count": len(post_recovery_observed),
            "inferred_piece_count": len(post_recovery_inferred),
            "node_metrics": post_recovery_node_metrics,
        },
        "node_pass_before_connections": node_metrics_before,
        "node_pass_final": node_metrics,
        "node_pass_stable": stable_node_metrics,
        "frozen_gap_validation": repairs,
        "independent_observation_metrics": independent,
        "columns": {
            "annotated_object_count": int(sum(item.get("semantic") == "column" for item in objects)),
            "reliable_count": len(columns),
            "uncertain_count": len(uncertain_columns),
            "template_count": len(templates),
            "templates": templates,
            "automatic_detection": automatic_column_metrics,
            "cross_height_instance_fusion": (
                "thin/thick views are fit independently; accepted views are "
                "refit from a union of unique xyz voxels"
            ),
        },
        "manual_wall_column_roi_policy": {
            "direct_reconstruction_enabled": manual_wall_column_rois_enabled,
            "mode": (
                "reconstruction_and_semantic_supervision"
                if manual_wall_column_rois_enabled
                else "semantic_supervision_and_evaluation_only"
            ),
            "classifier_probability_gates_remain_enabled": semantic is not None,
        },
        "closure": closure_metrics,
        "selected_closure_connector_ids": sorted(value for value in selected_ids if value),
        "thin_products": thin_products,
        "thick_products": thick_products,
        "disk_audit": disk,
        "v4_reaudit": v4_reaudit,
        "claims": {
            "generalisability": "not evaluated; all labelled parking maps participate in fitting",
            "semantic_accuracy": "not reported without a held-out set",
            "absolute_survey_accuracy": "not claimed",
        },
    }
    write_json(output / "structure_report.json", report)
    return report
