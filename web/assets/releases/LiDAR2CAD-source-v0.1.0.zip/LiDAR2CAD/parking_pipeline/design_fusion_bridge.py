"""Run the validated ICPARK design-CAD/LiDAR fusion bundle in this project.

The validated implementation is kept byte-for-byte in
``代码升级/icpar_design_fusion_20261021.zip``.  This bridge supplies the current
project's official ICPARK GeoJSON, overrides machine-specific source paths,
runs the structural fusion stages, and publishes a fingerprinted result set.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib
import json
import os
import shutil
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BUNDLE = PROJECT_ROOT / "代码升级" / "icpar_design_fusion_20261021.zip"
DEFAULT_LIDAR = (
    PROJECT_ROOT
    / "outputs"
    / "parking"
    / "final_results"
    / "01_icpar_parkinglot"
    / "01_recommended_wall_plan"
    / "ICPAR_wall_plan_v6.geojson"
)
DEFAULT_DESIGN_DXF = (
    Path.home() / "Downloads" / "2021.10.27交通设施A-W-地下室_t8(1)-2.dxf"
)
DEFAULT_REGISTRATION = Path.home() / "Downloads" / "ICPARK_design_registration_preliminary.json"
DEFAULT_OUTPUT = PROJECT_ROOT / "outputs" / "parking" / "design_fusion" / "icpar_r309_aligned"

PUBLISHED_ARTIFACTS = (
    "design_arch.json",
    "arch_alignment.json",
    "arch_cache.json",
    "arch_classification.json",
    "fused_icpark_lidar_frame_structure.dxf",
    "fused_icpark_design_mm_structure.dxf",
    "final_icpark_structure.png",
)


def sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(chunk_size):
            digest.update(block)
    return digest.hexdigest()


def _safe_extract(archive: Path, destination: Path) -> Path:
    """Extract a bundle after rejecting absolute and parent-traversal entries."""
    destination = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        members = zf.infolist()
        for member in members:
            target = (destination / member.filename).resolve()
            try:
                target.relative_to(destination)
            except ValueError as exc:
                raise ValueError(f"unsafe archive member: {member.filename}") from exc
        zf.extractall(destination)

    roots = {Path(info.filename).parts[0] for info in members if Path(info.filename).parts}
    if len(roots) != 1:
        raise RuntimeError(f"expected one bundle root, found: {sorted(roots)}")
    package_root = destination / next(iter(roots))
    if not (package_root / "scripts" / "design_fusion" / "__init__.py").is_file():
        raise RuntimeError(f"design_fusion package missing under {package_root}")
    return package_root


@contextlib.contextmanager
def _working_directory(path: Path):
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, text: str) -> int:
        for stream in self.streams:
            stream.write(text)
            stream.flush()
        return len(text)

    def flush(self) -> None:
        for stream in self.streams:
            stream.flush()


def _require_files(paths: Iterable[Path]) -> None:
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError("required input files are missing:\n  " + "\n  ".join(missing))


def _load_stage(name: str):
    return importlib.import_module(f"scripts.design_fusion.{name}")


def run_fusion(
    *,
    bundle: Path,
    lidar_geojson: Path,
    design_dxf: Path,
    registration: Path,
    output_dir: Path,
) -> Path:
    bundle = bundle.resolve()
    lidar_geojson = lidar_geojson.resolve()
    design_dxf = design_dxf.resolve()
    registration = registration.resolve()
    output_dir = output_dir.resolve()
    _require_files((bundle, lidar_geojson, design_dxf, registration))

    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(
            f"output directory is not empty: {output_dir}; choose a new --output directory"
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    runtime_dir = output_dir / "_runtime"
    package_root = _safe_extract(bundle, runtime_dir)

    runtime_icpar = package_root / "outputs" / "parking" / "icpar_parkinglot"
    runtime_icpar.mkdir(parents=True, exist_ok=True)
    staged_lidar = runtime_icpar / "lidar.geojson"
    shutil.copy2(lidar_geojson, staged_lidar)

    sys.path.insert(0, str(package_root))
    old_argv = sys.argv[:]
    log_path = output_dir / "run.log"
    try:
        extract_arch = _load_stage("extract_arch")
        extract_arch.DXF = design_dxf
        extract_arch.MJSON = registration
        stages = (
            ("extract_arch", extract_arch),
            ("arch_align", _load_stage("arch_align")),
            ("arch_classify", _load_stage("arch_classify")),
            ("export_arch", _load_stage("export_arch")),
            ("render_final", _load_stage("render_final")),
        )
        with log_path.open("w", encoding="utf-8") as log, _working_directory(package_root):
            tee_out = _Tee(sys.stdout, log)
            tee_err = _Tee(sys.stderr, log)
            with contextlib.redirect_stdout(tee_out), contextlib.redirect_stderr(tee_err):
                for stage_name, module in stages:
                    print(f"\n=== {stage_name} ===", flush=True)
                    sys.argv = [f"design_fusion:{stage_name}"]
                    module.main()
    finally:
        sys.argv = old_argv
        if sys.path and sys.path[0] == str(package_root):
            sys.path.pop(0)

    generated_dir = runtime_icpar / "design_fusion"
    artifacts_dir = output_dir / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    _require_files(generated_dir / name for name in PUBLISHED_ARTIFACTS)
    for name in PUBLISHED_ARTIFACTS:
        shutil.copy2(generated_dir / name, artifacts_dir / name)

    alignment = json.loads((artifacts_dir / "arch_alignment.json").read_text(encoding="utf-8"))
    classification = json.loads(
        (artifacts_dir / "arch_classification.json").read_text(encoding="utf-8")
    )
    manifest = {
        "schema": "icpar-design-fusion-run/v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "implementation": {
            "bundle": str(bundle),
            "bundle_sha256": sha256(bundle),
            "bridge": str(Path(__file__).resolve()),
        },
        "inputs": {
            "lidar_geojson": {"path": str(lidar_geojson), "sha256": sha256(lidar_geojson)},
            "design_dxf": {"path": str(design_dxf), "sha256": sha256(design_dxf)},
            "registration": {"path": str(registration), "sha256": sha256(registration)},
        },
        "stages": ["extract_arch", "arch_align", "arch_classify", "export_arch", "render_final"],
        "summary": {
            "alignment_final": alignment.get("final", {}),
            "alignment_transform": alignment.get("transform", {}),
            "design_walls": classification.get("design_walls", {}),
            "lidar_edges": classification.get("lidar_edges", {}),
            "columns": classification.get("columns", {}),
        },
        "artifacts": {
            name: {
                "path": str((artifacts_dir / name).relative_to(output_dir)),
                "bytes": (artifacts_dir / name).stat().st_size,
                "sha256": sha256(artifacts_dir / name),
            }
            for name in PUBLISHED_ARTIFACTS
        },
        "log": str(log_path.relative_to(output_dir)),
    }
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Align the original ICPARK design CAD with the current LiDAR reconstruction."
    )
    parser.add_argument("--bundle", type=Path, default=DEFAULT_BUNDLE)
    parser.add_argument("--lidar-geojson", type=Path, default=DEFAULT_LIDAR)
    parser.add_argument("--design-dxf", type=Path, default=DEFAULT_DESIGN_DXF)
    parser.add_argument("--registration", type=Path, default=DEFAULT_REGISTRATION)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    manifest = run_fusion(
        bundle=args.bundle,
        lidar_geojson=args.lidar_geojson,
        design_dxf=args.design_dxf,
        registration=args.registration,
        output_dir=args.output,
    )
    print(f"\nFusion complete. Manifest: {manifest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
