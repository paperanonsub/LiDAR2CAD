from __future__ import annotations

import argparse
import json
import threading
import webbrowser
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

import cv2
import numpy as np
from shapely import contains_xy
from shapely.geometry import Polygon

from lidar2outline.io import read_json, read_point_cloud, write_json

from .v5_evidence import (
    ExactVoxelEvidence,
    build_exact_voxel_evidence,
    height_windows,
    window_occupancy,
)


LABELS = {"unknown": 0, "wall": 1, "column": 2, "vehicle": 3, "other": 4}
# ``non_architectural`` is the legacy value already stored by the annotation
# UI.  For ICPAR V5 those reviewed regions mean vehicles.  Keep the original
# file untouched and migrate only while building supervision.
ALLOWED_CLASSES = set(LABELS) | {
    "non_architectural",
    "uncertain",
    "opening",
    "scan_boundary",
}


def _transform_points(points: np.ndarray, transform: np.ndarray) -> np.ndarray:
    values = np.ones((len(points), 4), dtype=np.float64)
    values[:, :3] = np.asarray(points[:, :3], dtype=np.float64)
    return (values @ transform.T)[:, :3]


def _density_image(mask_or_count: np.ndarray) -> np.ndarray:
    values = np.asarray(mask_or_count, dtype=np.float32)
    if values.dtype == bool:
        values = values.astype(np.float32)
    positive = values[values > 0]
    if not len(positive):
        return np.zeros((*values.shape, 3), dtype=np.uint8)
    high = max(1.0, float(np.quantile(positive, 0.995)))
    grey = np.clip(np.log1p(values) / np.log1p(high), 0.0, 1.0)
    image = np.rint(grey * 255.0).astype(np.uint8)
    return cv2.cvtColor(np.flipud(image), cv2.COLOR_GRAY2BGR)


def prepare_annotation_workspace(
    source_pcd: str | Path,
    transforms_path: str | Path,
    output_dir: str | Path,
    dataset_id: str,
    clean_pcd: str | Path | None = None,
    cfg: dict[str, Any] | None = None,
) -> dict[str, Any]:
    cfg = dict(cfg or {})
    output = Path(output_dir).resolve()
    view_dir = output / "views"
    view_dir.mkdir(parents=True, exist_ok=True)
    points = read_point_cloud(source_pcd)
    transform = np.asarray(read_json(transforms_path)["T_cad_reference_slam"], dtype=float)
    points_cad = _transform_points(points, transform)
    if clean_pcd is not None:
        clean_cad = _transform_points(read_point_cloud(clean_pcd), transform)
        floor_m = float(
            np.quantile(clean_cad[:, 2], float(cfg.get("surface_floor_quantile", 0.001)))
            - float(cfg.get("surface_floor_restore_margin_m", 0.12))
        )
        ceiling_m = float(
            np.quantile(clean_cad[:, 2], float(cfg.get("surface_ceiling_quantile", 0.999)))
            + float(cfg.get("surface_ceiling_restore_margin_m", 0.12))
        )
    else:
        floor_m = ceiling_m = None
    evidence = build_exact_voxel_evidence(
        points_cad,
        grid_m=float(cfg.get("evidence_grid_m", 0.05)),
        z_bin_m=float(cfg.get("evidence_z_bin_m", 0.10)),
        floor_guard_m=float(cfg.get("evidence_floor_guard_m", 0.12)),
        ceiling_guard_m=float(cfg.get("evidence_ceiling_guard_m", 0.12)),
        floor_m=floor_m,
        ceiling_m=ceiling_m,
        min_vertical_span_m=float(cfg.get("evidence_min_vertical_span_m", 1.20)),
        min_height_bins=int(cfg.get("evidence_min_height_bins", 11)),
        min_top_above_floor_m=float(cfg.get("evidence_min_top_above_floor_m", 1.80)),
        padding_m=float(cfg.get("raster_padding_m", 0.50)),
    )
    thin = height_windows(evidence.floor_m, evidence.ceiling_m, 0.50, 0.30, "thin")
    thick = height_windows(evidence.floor_m, evidence.ceiling_m, 1.00, 0.50, "thick")
    masks = {
        **window_occupancy(evidence, thin, minimum_bins=2),
        **window_occupancy(evidence, thick, minimum_bins=2),
    }
    all_count = np.zeros(evidence.shape, np.int32)
    np.add.at(all_count.ravel(), evidence.xy_cell, evidence.counts)
    views: list[dict[str, Any]] = []
    full_name = "all_heights.png"
    cv2.imwrite(str(view_dir / full_name), _density_image(all_count))
    views.append({"view_id": "all_heights", "label": "ALL HEIGHTS", "file": full_name})
    for window in [*thin, *thick]:
        filename = f"{window.window_id}.png"
        cv2.imwrite(str(view_dir / filename), _density_image(masks[window.window_id]))
        views.append(
            {
                "view_id": window.window_id,
                "label": f"{window.scale.upper()} {window.z_min_m-evidence.floor_m:.2f}–{window.z_max_m-evidence.floor_m:.2f} m",
                "file": filename,
                "scale": window.scale,
                "z_min_m": window.z_min_m,
                "z_max_m": window.z_max_m,
            }
        )
    metadata = {
        "schema_version": "parking-semantic-annotation-workspace-v1",
        "dataset_id": dataset_id,
        "source_pcd": str(Path(source_pcd).resolve()),
        "clean_pcd": str(Path(clean_pcd).resolve()) if clean_pcd is not None else None,
        "transforms": str(Path(transforms_path).resolve()),
        "origin_cad": evidence.origin_xy.tolist(),
        "grid_m_per_px": evidence.grid_m,
        "width_px": evidence.shape[1],
        "height_px": evidence.shape[0],
        "floor_m": evidence.floor_m,
        "ceiling_m": evidence.ceiling_m,
        "views": views,
    }
    write_json(output / "workspace.json", metadata)
    manifest_path = output / "annotations.json"
    if not manifest_path.exists():
        write_json(
            manifest_path,
            {
                "schema_version": "parking-object-regions-v1",
                "dataset_id": dataset_id,
                "coordinate_frame": "CAD",
                "annotation_semantics": "closed ROI containing an object; occupied surface voxels are extracted automatically",
                "outside_regions": "unknown",
                "objects": [],
            },
        )
    return metadata


def _normalise_polygon(value: Any) -> tuple[list[list[float]], Polygon]:
    vertices = np.asarray(value, dtype=float)
    if vertices.ndim != 2 or vertices.shape[1] != 2 or len(vertices) < 3:
        raise ValueError("多边形至少需要三个二维顶点")
    if np.linalg.norm(vertices[0] - vertices[-1]) > 1e-9:
        vertices = np.vstack([vertices, vertices[0]])
    polygon = Polygon(vertices)
    if not polygon.is_valid or polygon.area < 0.01:
        raise ValueError("多边形无效或面积过小")
    return np.asarray(polygon.exterior.coords, dtype=float).tolist(), polygon


def extract_annotation_supervision(
    evidence: ExactVoxelEvidence,
    annotations: dict[str, Any],
    normals: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Extract occupied voxel labels; an ROI interior is never itself truth."""

    labels = np.zeros(len(evidence.centroids), dtype=np.int8)
    object_index = np.full(len(evidence.centroids), -1, dtype=np.int32)
    conflicts = np.zeros(len(evidence.centroids), dtype=bool)
    structural_surface = np.isin(evidence.xy_cell, evidence.structural_xy_cell)
    vertical_surface: np.ndarray | None = None
    if normals is not None:
        normal_values = np.asarray(normals, dtype=np.float32)
        if normal_values.shape != (len(evidence.centroids), 3):
            raise ValueError("normal array does not match evidence voxels")
        # A labelled polygon is a search region.  Its accepted samples must be
        # actual vertical surface returns; collective height continuity is
        # checked per ROI below.  This admits sparse/circular column faces that
        # do not repeatedly land in the very same 5 cm XY cell.
        vertical_surface = np.abs(normal_values[:, 2]) <= 0.35
    records: list[dict[str, Any]] = []
    next_instance = 0
    voxel_order = np.argsort(evidence.xy_cell, kind="stable")
    sorted_voxel_cells = evidence.xy_cell[voxel_order]

    def has_continuous_height_support(rows: np.ndarray) -> bool:
        bins = np.unique(evidence.z_bin[rows])
        if len(bins) < 6:
            return False
        run_start = 0
        for end in range(1, len(bins) + 1):
            if end < len(bins) and bins[end] - bins[end - 1] <= 2:
                continue
            run = bins[run_start:end]
            if len(run) >= 6 and (run[-1] - run[0] + 1) * evidence.z_bin_m >= 1.0:
                return True
            run_start = end
        return False

    def voxel_rows_inside_polygon(polygon: Polygon) -> np.ndarray:
        """Return occupied 3-D voxel rows whose XY cell centre is in an ROI.

        Raster row ranges make this proportional to the small ROI rather than
        to the complete 4.5-million-voxel map for every annotation.
        """
        min_x, min_y, max_x, max_y = polygon.bounds
        origin_x, origin_y = (float(value) for value in evidence.origin_xy)
        height, width = evidence.shape
        column_min = max(0, int(np.floor((min_x - origin_x) / evidence.grid_m)) - 1)
        column_max = min(width - 1, int(np.ceil((max_x - origin_x) / evidence.grid_m)) + 1)
        row_min = max(0, int(np.floor((min_y - origin_y) / evidence.grid_m)) - 1)
        row_max = min(height - 1, int(np.ceil((max_y - origin_y) / evidence.grid_m)) + 1)
        if column_min > column_max or row_min > row_max:
            return np.empty(0, dtype=np.int64)
        rows, columns = np.meshgrid(
            np.arange(row_min, row_max + 1, dtype=np.int64),
            np.arange(column_min, column_max + 1, dtype=np.int64),
            indexing="ij",
        )
        x = origin_x + (columns.ravel().astype(np.float64) + 0.5) * evidence.grid_m
        y = origin_y + (rows.ravel().astype(np.float64) + 0.5) * evidence.grid_m
        contained = contains_xy(polygon, x, y)
        if not np.any(contained):
            return np.empty(0, dtype=np.int64)
        cells = (rows.ravel()[contained] * width + columns.ravel()[contained]).astype(np.int64)
        starts = np.searchsorted(sorted_voxel_cells, cells, side="left")
        ends = np.searchsorted(sorted_voxel_cells, cells, side="right")
        spans = [voxel_order[start:end] for start, end in zip(starts, ends) if end > start]
        return np.concatenate(spans) if spans else np.empty(0, dtype=np.int64)

    def assign_connected_instances(
        selected_rows: np.ndarray,
    ) -> tuple[np.ndarray, list[dict[str, Any]]]:
        """Split a broad vehicle ROI without treating its polygon as an object.

        Closing is used only to associate occupied evidence into instances; it
        never creates supervised points.  Tiny isolated returns stay unknown.
        """
        cells = np.unique(evidence.xy_cell[selected_rows])
        if not len(cells):
            return np.full(len(selected_rows), -1, np.int32), []
        width = evidence.shape[1]
        cell_rows = cells // width
        cell_columns = cells % width
        row_min, row_max = int(cell_rows.min()), int(cell_rows.max())
        column_min, column_max = int(cell_columns.min()), int(cell_columns.max())
        cell_mask = np.zeros(
            (row_max - row_min + 1, column_max - column_min + 1),
            np.uint8,
        )
        cell_mask[cell_rows - row_min, cell_columns - column_min] = 1
        kernel_px = max(1, int(round(0.20 / evidence.grid_m)))
        if kernel_px % 2 == 0:
            kernel_px += 1
        associated = cv2.morphologyEx(
            cell_mask,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_px, kernel_px)),
        )
        count, component = cv2.connectedComponents(associated, connectivity=8)
        selected_cells = evidence.xy_cell[selected_rows]
        selected_cell_rows = selected_cells // width - row_min
        selected_cell_columns = selected_cells % width - column_min
        voxel_components = component[
            selected_cell_rows,
            selected_cell_columns,
        ]
        assignments = np.full(len(selected_rows), -1, np.int32)
        summaries: list[dict[str, Any]] = []
        candidates: list[dict[str, Any]] = []
        for component_id in range(1, count):
            member = voxel_components == component_id
            unique_cells = int(len(np.unique(evidence.xy_cell[selected_rows[member]])))
            voxel_count = int(np.count_nonzero(member))
            if unique_cells < 12 or voxel_count < 20:
                continue
            xy = evidence.centroids[selected_rows[member], :2]
            candidates.append(
                {
                    "component_id": component_id,
                    "voxel_count": voxel_count,
                    "xy_cell_count": unique_cells,
                    "bounds_ref": np.asarray(
                        [xy[:, 0].min(), xy[:, 1].min(), xy[:, 0].max(), xy[:, 1].max()],
                        dtype=float,
                    ),
                }
            )
        if not candidates:
            return assignments, summaries

        # A single car is often split into a large body component plus tiny
        # returns from windows, mirrors and sparse roof samples.  Giving those
        # fragments their own instance would make object-normalised training
        # overweight noise.  Select primary components relative to the largest
        # component in this *particular* ROI, then attach nearby fragments.  Two
        # genuinely separate, similarly sized cars remain separate primaries.
        largest = max(int(item["xy_cell_count"]) for item in candidates)
        primary_min_cells = max(12, min(100, int(np.ceil(0.16 * largest))))
        primary_ids = [
            int(item["component_id"])
            for item in candidates
            if int(item["xy_cell_count"]) >= primary_min_cells
        ]
        if not primary_ids:
            primary_ids = [int(max(candidates, key=lambda item: item["xy_cell_count"])["component_id"])]
        by_id = {int(item["component_id"]): item for item in candidates}
        component_to_group = np.full(count, -1, np.int32)
        for group, component_id in enumerate(primary_ids):
            component_to_group[component_id] = group

        def bbox_gap(left: np.ndarray, right: np.ndarray) -> float:
            dx = max(float(left[0] - right[2]), float(right[0] - left[2]), 0.0)
            dy = max(float(left[1] - right[3]), float(right[1] - left[3]), 0.0)
            return float(np.hypot(dx, dy))

        for item in candidates:
            component_id = int(item["component_id"])
            if component_to_group[component_id] >= 0:
                continue
            gaps = np.asarray(
                [bbox_gap(item["bounds_ref"], by_id[primary]["bounds_ref"]) for primary in primary_ids],
                dtype=float,
            )
            nearest = int(np.argmin(gaps))
            if float(gaps[nearest]) <= 0.75:
                component_to_group[component_id] = nearest

        voxel_groups = component_to_group[voxel_components]
        for local_id in range(len(primary_ids)):
            member = voxel_groups == local_id
            if not np.any(member):
                continue
            assignments[member] = local_id
            xy = evidence.centroids[selected_rows[member], :2]
            summaries.append(
                {
                    "local_instance": local_id,
                    "voxel_count": int(np.count_nonzero(member)),
                    "xy_cell_count": int(
                        len(np.unique(evidence.xy_cell[selected_rows[member]]))
                    ),
                    "bounds_ref": [
                        float(xy[:, 0].min()),
                        float(xy[:, 1].min()),
                        float(xy[:, 0].max()),
                        float(xy[:, 1].max()),
                    ],
                    "associated_component_count": int(
                        np.count_nonzero(component_to_group == local_id)
                    ),
                }
            )
        return assignments, summaries

    for index, item in enumerate(annotations.get("objects", [])):
        raw_semantic = str(item.get("semantic", "uncertain"))
        semantic = "vehicle" if raw_semantic == "non_architectural" else raw_semantic
        if semantic not in LABELS or semantic == "unknown" or item.get("status", "accepted") != "accepted":
            continue
        vertices, polygon = _normalise_polygon(item.get("polygon_ref"))
        inside_rows = voxel_rows_inside_polygon(polygon)
        if semantic in {"wall", "column"}:
            # Both annotations are search regions.  Only voxels whose own XY
            # cell has continuous vertical structural support become semantic
            # supervision; the polygon interior, nearby cars and floor returns
            # never become wall/column truth.
            if vertical_surface is None:
                selected_rows = inside_rows[structural_surface[inside_rows]]
            else:
                selected_rows = inside_rows[vertical_surface[inside_rows]]
                if not has_continuous_height_support(selected_rows):
                    selected_rows = np.empty(0, dtype=np.int64)
        else:
            selected_rows = inside_rows
        raw_selected_rows = selected_rows.copy()
        instance_summaries: list[dict[str, Any]] = []
        instance_assignment: np.ndarray | None = None
        if semantic == "vehicle":
            instance_assignment, instance_summaries = assign_connected_instances(selected_rows)
            retained = instance_assignment >= 0
            selected_rows = selected_rows[retained]
            instance_assignment = instance_assignment[retained]
        existing = labels[selected_rows]
        new_label = LABELS[semantic]
        structural_label = semantic in {"wall", "column"}
        # Vehicle polygons are intentionally broad search regions.  A later
        # human wall/column ROI with verified vertical returns is more specific
        # and therefore replaces vehicle supervision.  Wall-vs-column overlap
        # remains a true semantic conflict and is ignored.
        replaces_vehicle = structural_label & (existing == LABELS["vehicle"])
        occupied_mask = (existing == 0) | replaces_vehicle
        occupied_rows = selected_rows[occupied_mask]
        structural_conflict = (
            ((new_label == LABELS["wall"]) & (existing == LABELS["column"]))
            | ((new_label == LABELS["column"]) & (existing == LABELS["wall"]))
        )
        collision_rows = selected_rows[structural_conflict]
        labels[occupied_rows] = LABELS[semantic]
        if instance_assignment is None:
            object_index[occupied_rows] = next_instance
            next_instance += 1
        else:
            for summary in instance_summaries:
                local = int(summary["local_instance"])
                member = occupied_mask & (instance_assignment == local)
                if np.any(member):
                    object_index[selected_rows[member]] = next_instance
                    summary["supervision_object_index"] = next_instance
                    next_instance += 1
        conflicts[collision_rows] = True
        records.append(
            {
                "object_id": item.get("object_id"),
                "semantic": semantic,
                "source_semantic": raw_semantic,
                "polygon_area_m2": polygon.area,
                "raw_roi_voxel_count": int(len(inside_rows)),
                "selected_voxel_count": int(len(selected_rows)),
                "accepted_voxel_count": int(len(occupied_rows)),
                "conflict_voxel_count": int(len(collision_rows)),
                "derived_instance_count": len(instance_summaries),
                "derived_instances": instance_summaries,
                "polygon_ref": vertices,
            }
        )
    labels[conflicts] = 0
    object_index[conflicts] = -1
    return labels, object_index, {
        "object_count": len(records),
        "label_counts": {
            name: int(np.count_nonzero(labels == value)) for name, value in LABELS.items()
        },
        "conflict_voxel_count": int(np.count_nonzero(conflicts)),
        "objects": records,
        "outside_regions": "unknown",
    }


HTML = r"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ICPAR 建筑对象标注</title><style>
body{margin:0;background:#0b0f14;color:#eef3fa;font-family:Inter,"Microsoft YaHei",sans-serif}header{padding:10px 16px;background:#151b24;display:flex;gap:14px;align-items:center}.layout{display:grid;grid-template-columns:minmax(650px,1fr) 360px;gap:12px;padding:12px}.viewer{background:#000;overflow:hidden}.viewer canvas{display:block;max-width:100%;max-height:calc(100vh - 90px)}aside{background:#171d27;padding:14px;max-height:calc(100vh - 90px);overflow:auto}button,select,input{background:#273141;color:#fff;border:1px solid #526077;border-radius:6px;padding:8px;margin:3px}.primary{background:#286a87}.danger{background:#8f2539}.row{border-bottom:1px solid #344055;padding:7px;font-size:13px}.muted{color:#9aa9bd;font-size:12px}</style></head><body><header><b>ICPAR 全图对象多边形标注</b><select id="view"></select><span id="status"></span></header><div class="layout"><div class="viewer"><canvas id="canvas"></canvas></div><aside><div><select id="semantic"><option value="wall">墙</option><option value="column">柱（可选，V5 自动检测）</option><option value="vehicle">车辆</option><option value="other">其他干扰</option><option value="uncertain">不确定</option><option value="opening">门洞／通道</option><option value="scan_boundary">扫描边界</option></select><input id="subtype" placeholder="子类，可空"><input id="parent" placeholder="同一墙链 ID，可空"></div><button class="primary" id="start">新建对象</button><button id="undo">撤销一点</button><button id="finish">闭合保存</button><button id="cancel">取消</button><p class="muted">左键逐点框选；滚轮缩放；右键或中键平移。多边形只是搜索范围，不是对象外轮廓；一个车辆区域可以包含多辆车，程序会从实际占据点中拆分实例。框外始终为未知。</p><div id="list"></div></aside></div><script>
let s,img,draft=[],drawing=false,editing=null,z=1,px=0,py=0,pan=false,last;const $=x=>document.getElementById(x),c=$("canvas");function cp(e){let r=c.getBoundingClientRect();return[(e.clientX-r.left)*c.width/r.width,(e.clientY-r.top)*c.height/r.height]}function ip(p){return[(p[0]-px)/z,(p[1]-py)/z]}function ref(p){let m=s.workspace;return[m.origin_cad[0]+p[0]*m.grid_m_per_px,m.origin_cad[1]+(m.height_px-1-p[1])*m.grid_m_per_px]}function pix(p){let m=s.workspace;return[(p[0]-m.origin_cad[0])/m.grid_m_per_px,m.height_px-1-(p[1]-m.origin_cad[1])/m.grid_m_per_px]}function normalSemantic(k){return k==='non_architectural'?'vehicle':k}function color(k){return{wall:'#fff',column:'#00e5ff',vehicle:'#ff5252',other:'#ff9800',non_architectural:'#ff5252',uncertain:'#888',opening:'#42a5f5',scan_boundary:'#ab47bc'}[k]||'#ff0'}function poly(ctx,p,col,close){if(!p.length)return;ctx.beginPath();ctx.moveTo(...p[0]);for(let i=1;i<p.length;i++)ctx.lineTo(...p[i]);if(close)ctx.closePath();ctx.strokeStyle=col;ctx.lineWidth=3/z;ctx.stroke();for(let q of p){ctx.beginPath();ctx.arc(q[0],q[1],4/z,0,7);ctx.fillStyle=col;ctx.fill()}}function draw(){if(!img||!s)return;let x=c.getContext('2d');x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,c.width,c.height);x.setTransform(z,0,0,z,px,py);x.drawImage(img,0,0);for(let o of s.annotations.objects)if(o.object_id!==editing)poly(x,o.polygon_ref.map(pix),color(o.semantic),true);poly(x,draft,'#ffd740',false)}function edit(o){editing=o.object_id;draft=o.polygon_ref.slice(0,-1).map(pix);drawing=true;$("semantic").value=normalSemantic(o.semantic);$("subtype").value=o.subtype||'';$("parent").value=o.parent_object_id||'';draw()}function list(){let d=$("list");d.innerHTML='';[...s.annotations.objects].reverse().forEach(o=>{let r=document.createElement('div');r.className='row';r.innerHTML=`<b style="color:${color(o.semantic)}">${o.object_id}</b> ${normalSemantic(o.semantic)} ${o.subtype||''} <button class="edit">编辑</button><button class="danger">删除</button>`;r.querySelector('.edit').onclick=()=>edit(o);r.querySelector('.danger').onclick=()=>del(o.object_id);d.append(r)})}async function load(){s=await(await fetch('/api/state')).json();for(let v of s.workspace.views){let o=document.createElement('option');o.value=v.view_id;o.textContent=v.label;$("view").append(o)}$("view").onchange=loadImage;list();loadImage()}function loadImage(){img=new Image();img.onload=()=>{c.width=img.naturalWidth;c.height=img.naturalHeight;draw()};img.src='/view/'+encodeURIComponent($("view").value)+'.png?'+Date.now()}async function save(){if(draft.length<3)return;let q={object_id:editing,semantic:$("semantic").value,subtype:$("subtype").value,parent_object_id:$("parent").value,polygon_ref:draft.map(ref)};let r=await fetch('/api/object',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(q)}),v=await r.json();if(!r.ok){$("status").textContent=v.error;return}s.annotations=v.annotations;draft=[];drawing=false;editing=null;list();draw()}async function del(id){let r=await fetch('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({object_id:id})}),v=await r.json();if(r.ok){s.annotations=v.annotations;list();draw()}}$("start").onclick=()=>{drawing=true;editing=null;draft=[]};$("undo").onclick=()=>{draft.pop();draw()};$("finish").onclick=save;$("cancel").onclick=()=>{draft=[];drawing=false;editing=null;draw()};c.oncontextmenu=e=>e.preventDefault();c.onmousedown=e=>{if(e.button>0){pan=true;last=cp(e)}};window.onmouseup=()=>pan=false;c.onmousemove=e=>{if(!pan)return;let q=cp(e);px+=q[0]-last[0];py+=q[1]-last[1];last=q;draw()};c.onclick=e=>{if(drawing&&e.button===0){draft.push(ip(cp(e)));draw()}};c.onwheel=e=>{e.preventDefault();let q=cp(e),b=ip(q),f=e.deltaY<0?1.2:1/1.2;z=Math.max(.4,Math.min(12,z*f));px=q[0]-b[0]*z;py=q[1]-b[1]*z;draw()};window.onkeydown=e=>{if(e.key==='Enter')save();if(e.key==='Backspace'){e.preventDefault();draft.pop();draw()}if(e.key==='Escape'){draft=[];drawing=false;editing=null;draw()}};load();
</script></body></html>"""

# Continuous digitising is enabled by default.  After Enter saves one closed
# polygon, the canvas immediately starts a fresh polygon while preserving the
# selected semantic class.  This is especially useful for marking hundreds of
# parking columns, but the switch can be disabled for one-off edits.
HTML = HTML.replace(
    '<button class="primary" id="start">',
    '<label style="display:block;margin:6px 3px"><input type="checkbox" '
    'id="continuous" checked> 连续标注（Enter 保存后立即画下一个）</label>'
    '<button class="primary" id="start">',
)
HTML = HTML.replace(
    's.annotations=v.annotations;draft=[];drawing=false;editing=null;list();draw()',
    's.annotations=v.annotations;let keep=$("continuous").checked;draft=[];'
    'drawing=keep;editing=null;$("status").textContent=keep?'
    '"已保存，可直接点击下一个对象":"已保存";list();draw()',
)


class AnnotationServer(ThreadingHTTPServer):
    def __init__(self, address: tuple[str, int], workspace: Path):
        super().__init__(address, AnnotationHandler)
        self.workspace_dir = workspace
        self.workspace = read_json(workspace / "workspace.json")
        self.annotation_path = workspace / "annotations.json"
        self.lock = threading.Lock()


class AnnotationHandler(BaseHTTPRequestHandler):
    server: AnnotationServer

    def _send_json(self, value: Any, status: int = 200) -> None:
        payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:  # noqa: N802
        try:
            path = unquote(urlparse(self.path).path)
            if path == "/":
                payload = HTML.encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return
            if path == "/api/state":
                self._send_json(
                    {
                        "workspace": self.server.workspace,
                        "annotations": read_json(self.server.annotation_path),
                    }
                )
                return
            if path.startswith("/view/") and path.endswith(".png"):
                view_id = path[len("/view/") : -len(".png")]
                match = next(
                    (item for item in self.server.workspace["views"] if item["view_id"] == view_id),
                    None,
                )
                if match is None:
                    self.send_error(HTTPStatus.NOT_FOUND)
                    return
                payload = (self.server.workspace_dir / "views" / match["file"]).read_bytes()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return
            self.send_error(HTTPStatus.NOT_FOUND)
        except Exception as exc:  # keep UI diagnostics visible instead of closing the socket
            try:
                self._send_json({"error": f"annotation server GET failed: {type(exc).__name__}: {exc}"}, 500)
            except Exception:
                raise

    def do_POST(self) -> None:  # noqa: N802
        try:
            request = json.loads(self.rfile.read(int(self.headers.get("Content-Length", "0"))).decode("utf-8"))
            path = urlparse(self.path).path
            with self.server.lock:
                annotations = read_json(self.server.annotation_path)
                if path == "/api/object":
                    semantic = str(request.get("semantic", ""))
                    if semantic not in ALLOWED_CLASSES:
                        raise ValueError("未知语义类别")
                    vertices, polygon = _normalise_polygon(request.get("polygon_ref"))
                    requested_id = str(request.get("object_id") or "")
                    previous = next(
                        (item for item in annotations["objects"] if item["object_id"] == requested_id),
                        None,
                    )
                    number = max([int(str(item["object_id"]).split("-")[-1]) for item in annotations["objects"]], default=0) + 1
                    item = {
                        "object_id": requested_id if previous is not None else f"obj-{number:05d}",
                        "semantic": semantic,
                        "subtype": str(request.get("subtype", "")),
                        "parent_object_id": str(request.get("parent_object_id", "")),
                        "polygon_ref": vertices,
                        "area_m2": polygon.area,
                        "status": "accepted",
                        "created_at": previous.get("created_at") if previous is not None else datetime.now(timezone.utc).isoformat(),
                        "updated_at": datetime.now(timezone.utc).isoformat(),
                    }
                    if previous is None:
                        annotations["objects"].append(item)
                    else:
                        annotations["objects"] = [
                            item if value["object_id"] == requested_id else value
                            for value in annotations["objects"]
                        ]
                    write_json(self.server.annotation_path, annotations)
                    self._send_json({"ok": True, "item": item, "annotations": annotations})
                    return
                if path == "/api/delete":
                    object_id = str(request.get("object_id", ""))
                    before = len(annotations["objects"])
                    annotations["objects"] = [item for item in annotations["objects"] if item["object_id"] != object_id]
                    if len(annotations["objects"]) == before:
                        raise ValueError("对象不存在")
                    write_json(self.server.annotation_path, annotations)
                    self._send_json({"ok": True, "annotations": annotations})
                    return
            self.send_error(HTTPStatus.NOT_FOUND)
        except (ValueError, OSError, json.JSONDecodeError) as exc:
            self._send_json({"error": str(exc)}, 400)

    def log_message(self, format: str, *args: Any) -> None:
        return


def run_annotation_ui(workspace: str | Path, host: str, port: int, open_browser: bool) -> None:
    workspace_path = Path(workspace).resolve()
    server = AnnotationServer((host, port), workspace_path)
    url = f"http://{host}:{port}/"
    print(f"ICPAR semantic annotation UI: {url}")
    print(f"Annotations: {server.annotation_path}")
    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ICPAR full-map wall/column/non-building annotation")
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare")
    prepare.add_argument("--source-pcd", required=True)
    prepare.add_argument("--transforms", required=True)
    prepare.add_argument("--clean-pcd")
    prepare.add_argument("--output", required=True)
    prepare.add_argument("--dataset-id", default="icpar_parkinglot")
    serve = sub.add_parser("serve")
    serve.add_argument("--workspace", required=True)
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8785)
    serve.add_argument("--no-browser", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "prepare":
        report = prepare_annotation_workspace(
            args.source_pcd,
            args.transforms,
            args.output,
            args.dataset_id,
            clean_pcd=args.clean_pcd,
        )
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        run_annotation_ui(args.workspace, args.host, args.port, not args.no_browser)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
