from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from lidar2outline.config import load_config
from lidar2outline.io import read_json, write_json
from lidar2outline.semantic_v14 import _normals_and_geometry, _wsl_path

from .semantic_annotation import LABELS, extract_annotation_supervision
from .v5_evidence import load_exact_evidence


SCHEMA = "parking-semantic-point-v5"
TRAIN_CLASSES = ("wall", "column", "vehicle")


def prepare_supervision(
    evidence_path: str | Path,
    annotations_path: str | Path,
    output_dir: str | Path,
) -> dict[str, Any]:
    evidence = load_exact_evidence(evidence_path)
    annotations = read_json(annotations_path)
    destination = Path(output_dir).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    supervision = destination / "supervision.npz"
    reused_geometry = False
    normals: np.ndarray
    geometry: np.ndarray
    if supervision.exists():
        with np.load(supervision, allow_pickle=False) as previous:
            previous_coordinates = previous["coordinates"]
            current_coordinates = evidence.centroids.astype(np.float32)
            if (
                previous_coordinates.shape == current_coordinates.shape
                and np.array_equal(previous_coordinates, current_coordinates)
                and "normals" in previous.files
                and "geometry_features" in previous.files
            ):
                normals = previous["normals"].astype(np.float32)
                geometry = previous["geometry_features"].astype(np.float32)
                reused_geometry = True
            else:
                normals, geometry = _normals_and_geometry(evidence.centroids)
    else:
        normals, geometry = _normals_and_geometry(evidence.centroids)
    labels, object_index, audit = extract_annotation_supervision(
        evidence,
        annotations,
        normals=normals,
    )
    # Training uses -1 for ignored rows and contiguous class indices.
    train_labels = np.full(len(labels), -1, np.int8)
    train_labels[labels == LABELS["wall"]] = 0
    train_labels[labels == LABELS["column"]] = 1
    train_labels[labels == LABELS["vehicle"]] = 2
    np.savez_compressed(
        supervision,
        coordinates=evidence.centroids.astype(np.float32),
        normals=normals.astype(np.float32),
        geometry_features=geometry.astype(np.float32),
        labels=train_labels,
        object_index=object_index,
        xy_cell=evidence.xy_cell,
        z_bin=evidence.z_bin,
    )
    report = {
        "schema_version": SCHEMA,
        "training_classes": list(TRAIN_CLASSES),
        "outside_regions": "unknown",
        "supervision": str(supervision),
        "evidence": str(Path(evidence_path).resolve()),
        "annotations": str(Path(annotations_path).resolve()),
        "voxel_count": int(len(labels)),
        "training_label_counts": {
            name: int(np.count_nonzero(train_labels == index))
            for index, name in enumerate(TRAIN_CLASSES)
        },
        "ignored_voxel_count": int(np.count_nonzero(train_labels < 0)),
        "geometry_feature_cache_reused": reused_geometry,
        "annotation_audit": audit,
        "evaluation_note": "No held-out split; later fit scores are not generalisation metrics.",
    }
    write_json(destination / "supervision_report.json", report)
    image = np.zeros((*evidence.shape, 3), np.uint8)
    colours = ((255, 255, 255), (255, 220, 0), (0, 80, 255))
    rows = evidence.xy_cell // evidence.shape[1]
    columns = evidence.xy_cell % evidence.shape[1]
    for index, colour in enumerate(colours):
        selected = train_labels == index
        image[rows[selected], columns[selected]] = colour
    cv2.imwrite(str(destination / "supervision_sources.png"), np.flipud(image))
    return report


def extract_features(
    supervision_path: str | Path,
    output_path: str | Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    settings = config.get("semantic_v5", {})
    if not bool(config.get("parking_structure", {}).get("annotations_complete", False)):
        raise ValueError(
            "ICPAR annotations are not marked complete; review supervision points before Sonata extraction"
        )
    source = Path(supervision_path).resolve()
    destination = Path(output_path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with np.load(source) as values:
        rows = len(values["coordinates"])
        labels = values["labels"].astype(np.int8)
    required_local = settings.get("required_local_classes", ["wall", "vehicle"])
    for name in required_local:
        if name not in TRAIN_CLASSES:
            raise ValueError(f"unknown required_local_class {name}")
        klass = TRAIN_CLASSES.index(name)
        if not np.any(labels == klass):
            raise ValueError(f"full ICPAR annotation is missing class {name}")
    expected_bytes = rows * int(settings.get("expected_feature_channels", 1232)) * 2
    budget = int(float(settings.get("feature_cache_budget_gib", 12.0)) * 1024**3)
    reserve = int(float(settings.get("minimum_free_gib", 5.0)) * 1024**3)
    free = shutil.disk_usage(destination.parent).free
    if expected_bytes > budget or free - expected_bytes < reserve:
        raise ValueError(
            f"Sonata cache needs about {expected_bytes/1024**3:.2f} GiB; "
            f"budget={budget/1024**3:.2f} GiB, free={free/1024**3:.2f} GiB, reserve={reserve/1024**3:.2f} GiB"
        )
    distribution = str(settings.get("wsl_distribution", "Ubuntu-20.04"))
    python_value = str(settings.get("sonata_python", "~/.venvs/lidar2outline-sonata/bin/python"))
    endpoint = str(settings.get("huggingface_endpoint", "https://huggingface.co"))
    script = Path(__file__).resolve().parents[1] / "scripts" / "extract_sonata_point_features.py"
    command = (
        f"HF_ENDPOINT={endpoint} {python_value} {_wsl_path(script, distribution)} "
        f"--input {_wsl_path(source, distribution)} --output {_wsl_path(destination, distribution)} "
        f"--tile-size {float(settings.get('tile_size_m', 8.0))} "
        f"--halo {float(settings.get('tile_halo_m', 1.0))} "
        f"--max-voxels {int(settings.get('tile_max_voxels', 30000))}"
    )
    completed = subprocess.run(
        ["wsl", "-d", distribution, "--", "bash", "-lc", command],
        capture_output=True,
        text=True,
        errors="replace",
    )
    if completed.returncode != 0:
        raise ValueError(
            "Sonata feature extraction failed; no geometry fallback was used. "
            + (completed.stderr.strip() or completed.stdout.strip())
        )
    features = np.load(destination, mmap_mode="r")
    finite = bool(features.ndim == 2 and len(features) == rows)
    if finite:
        # Do not materialise an 11 GiB-sized boolean array merely to audit a
        # memory-mapped feature cache.
        audit_rows = 8192
        finite = all(
            bool(np.isfinite(features[start : start + audit_rows]).all())
            for start in range(0, len(features), audit_rows)
        )
    if not finite:
        raise ValueError(f"invalid Sonata features {features.shape}; expected {rows} rows")
    report = {
        "backend": "sonata_ptv3",
        "frozen_encoder": True,
        "shape": list(features.shape),
        "path": str(destination),
        "no_fallback": True,
    }
    write_json(destination.parent / "feature_extraction_report.json", report)
    return report


def _balanced_weights(labels: np.ndarray, objects: np.ndarray) -> np.ndarray:
    result = np.zeros(len(labels), np.float32)
    for klass in range(len(TRAIN_CLASSES)):
        selected_class = labels == klass
        for object_id in np.unique(objects[selected_class]):
            selected = selected_class & (objects == object_id)
            result[selected] = 1.0 / max(1, np.count_nonzero(selected))
    active = result > 0
    result[active] *= np.count_nonzero(active) / max(float(np.sum(result[active])), 1e-9)
    return result


def train_heads(
    supervision_path: str | Path,
    features_path: str | Path,
    output_dir: str | Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    try:
        import torch
        from torch import nn
    except ImportError as exc:
        raise ValueError("PyTorch is required for parking semantic training") from exc
    settings = config.get("semantic_v5", {})
    with np.load(supervision_path) as values:
        geometry = values["geometry_features"].astype(np.float32)
        labels = values["labels"].astype(np.int64)
        objects = values["object_index"].astype(np.int64)
    semantic = np.load(features_path, mmap_mode="r")
    if len(semantic) != len(labels):
        raise ValueError("Sonata feature/supervision coordinate mismatch")
    for klass, name in enumerate(TRAIN_CLASSES):
        if not np.any(labels == klass):
            raise ValueError(f"full annotation is missing class {name}")
    cap = int(settings.get("max_supervised_voxels_per_object", 2048))
    selected_groups = []
    for klass in range(len(TRAIN_CLASSES)):
        for object_id in np.unique(objects[labels == klass]):
            group = np.flatnonzero((labels == klass) & (objects == object_id))
            if len(group) > cap:
                group = group[np.linspace(0, len(group) - 1, cap, dtype=int)]
            selected_groups.append(group)
    selected = np.unique(np.concatenate(selected_groups))
    features = np.column_stack(
        [np.asarray(semantic[selected], dtype=np.float32), geometry[selected]]
    )
    target = labels[selected]
    object_selected = objects[selected]
    mean = features.mean(axis=0)
    std = features.std(axis=0).clip(1e-6)
    features = (features - mean) / std
    weights = _balanced_weights(target, object_selected)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    x = torch.from_numpy(features).to(device)
    y = torch.from_numpy(target).to(device)
    w = torch.from_numpy(weights).to(device)
    hidden = int(settings.get("head_hidden_channels", 64))

    def make_model() -> Any:
        return nn.Sequential(
            nn.Linear(x.shape[1], hidden),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden, len(TRAIN_CLASSES)),
        ).to(device)

    destination = Path(output_dir).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    runs = []
    for seed in [int(value) for value in settings.get("training_seeds", [23, 47, 89])]:
        torch.manual_seed(seed)
        model = make_model()
        optimiser = torch.optim.AdamW(
            model.parameters(),
            lr=float(settings.get("head_learning_rate", 0.001)),
            weight_decay=float(settings.get("head_weight_decay", 0.0001)),
        )
        criterion = nn.CrossEntropyLoss(reduction="none")
        best_loss, best_state, stale = float("inf"), None, 0
        epochs = 0
        for epoch in range(int(settings.get("head_max_epochs", 300))):
            epochs = epoch + 1
            model.train()
            optimiser.zero_grad()
            loss = torch.sum(criterion(model(x), y) * w) / torch.sum(w)
            loss.backward()
            optimiser.step()
            model.eval()
            with torch.inference_mode():
                fit_loss = float(torch.sum(criterion(model(x), y) * w) / torch.sum(w))
            if fit_loss < best_loss - 1e-7:
                best_loss = fit_loss
                best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                stale = 0
            else:
                stale += 1
            if stale >= int(settings.get("head_patience", 35)):
                break
        checkpoint = destination / f"parking_semantic_head_seed_{seed}.pt"
        torch.save(
            {
                "state_dict": best_state,
                "input_mean": mean,
                "input_std": std,
                "classes": TRAIN_CLASSES,
                "hidden_channels": hidden,
                "input_channels": x.shape[1],
                "backend": "sonata_ptv3",
            },
            checkpoint,
        )
        runs.append({"seed": seed, "epochs": epochs, "fit_loss": best_loss, "checkpoint": str(checkpoint)})
    report = {
        "schema_version": SCHEMA,
        "classes": list(TRAIN_CLASSES),
        "selected_training_voxels": int(len(selected)),
        "runs": runs,
        "evaluation_note": "Training fit only; no held-out split by user request.",
    }
    write_json(destination / "training_report.json", report)
    return report


def train_joint_heads(
    scene_specs: list[dict[str, Any]],
    output_dir: str | Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    """Fit one parking-only head from several explicitly listed scenes.

    A scene may omit a class, but the joint labelled set must contain all
    three classes.  Sampling and weights are normalised by class, scene and
    object so a large ROI or a dense map cannot dominate the fit.
    """
    try:
        import torch
        from torch import nn
    except ImportError as exc:
        raise ValueError("PyTorch is required for parking semantic training") from exc
    settings = config.get("semantic_v5", {})
    cap = int(settings.get("max_supervised_voxels_per_object", 2048))
    scene_batches: list[dict[str, Any]] = []
    class_totals = np.zeros(len(TRAIN_CLASSES), np.int64)
    for scene_index, spec in enumerate(scene_specs):
        dataset_id = str(spec["dataset_id"])
        if dataset_id.lower() == "xh23" or "office" in dataset_id.lower():
            raise ValueError("office/xh23 data is forbidden in the parking V5 classifier")
        supervision_path = Path(spec["supervision"]).resolve()
        features_path = Path(spec["features"]).resolve()
        with np.load(supervision_path) as values:
            geometry = values["geometry_features"].astype(np.float32)
            labels = values["labels"].astype(np.int64)
            if "object_index" in values:
                objects = values["object_index"].astype(np.int64)
            elif "region_ids" in values:
                objects = values["region_ids"].astype(np.int64)
            else:
                raise ValueError(f"{dataset_id}: supervision has no object identifiers")
        semantic = np.load(features_path, mmap_mode="r")
        if semantic.ndim != 2 or len(semantic) != len(labels):
            raise ValueError(f"{dataset_id}: Sonata feature/supervision coordinate mismatch")
        selected_groups: list[np.ndarray] = []
        selected_group_keys: list[tuple[int, int]] = []
        for klass in range(len(TRAIN_CLASSES)):
            for object_id in np.unique(objects[labels == klass]):
                group = np.flatnonzero((labels == klass) & (objects == object_id))
                if not len(group):
                    continue
                if len(group) > cap:
                    group = group[np.linspace(0, len(group) - 1, cap, dtype=int)]
                selected_groups.append(group)
                selected_group_keys.append((klass, int(object_id)))
        if not selected_groups:
            raise ValueError(f"{dataset_id}: no reviewed wall/column/vehicle supervision")
        selected = np.concatenate(selected_groups)
        combined = np.column_stack(
            [np.asarray(semantic[selected], dtype=np.float32), geometry[selected]]
        )
        selected_labels = labels[selected]
        selected_objects = objects[selected]
        class_totals += np.bincount(selected_labels, minlength=len(TRAIN_CLASSES))
        scene_batches.append(
            {
                "dataset_id": dataset_id,
                "features": combined,
                "labels": selected_labels,
                "objects": selected_objects,
                "scene_index": np.full(len(selected), scene_index, np.int32),
                "source_label_counts": {
                    name: int(np.count_nonzero(labels == klass))
                    for klass, name in enumerate(TRAIN_CLASSES)
                },
            }
        )
    for klass, name in enumerate(TRAIN_CLASSES):
        if class_totals[klass] == 0:
            raise ValueError(f"joint parking annotation is missing class {name}")
    features = np.vstack([batch["features"] for batch in scene_batches])
    target = np.concatenate([batch["labels"] for batch in scene_batches])
    objects = np.concatenate([batch["objects"] for batch in scene_batches])
    scene_index = np.concatenate([batch["scene_index"] for batch in scene_batches])
    mean = features.mean(axis=0)
    std = features.std(axis=0).clip(1e-6)
    features = (features - mean) / std

    weights = np.zeros(len(target), np.float32)
    for klass in range(len(TRAIN_CLASSES)):
        scenes = np.unique(scene_index[target == klass])
        for scene in scenes:
            scene_class = (target == klass) & (scene_index == scene)
            object_ids = np.unique(objects[scene_class])
            for object_id in object_ids:
                selected = scene_class & (objects == object_id)
                weights[selected] = (
                    1.0
                    / len(scenes)
                    / len(object_ids)
                    / max(1, np.count_nonzero(selected))
                )
    weights *= np.count_nonzero(weights) / max(float(np.sum(weights)), 1e-9)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    x = torch.from_numpy(features).to(device)
    y = torch.from_numpy(target).to(device)
    w = torch.from_numpy(weights).to(device)
    hidden = int(settings.get("head_hidden_channels", 64))

    def make_model() -> Any:
        return nn.Sequential(
            nn.Linear(x.shape[1], hidden),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden, len(TRAIN_CLASSES)),
        ).to(device)

    destination = Path(output_dir).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    runs = []
    for seed in [int(value) for value in settings.get("training_seeds", [23, 47, 89])]:
        torch.manual_seed(seed)
        model = make_model()
        optimiser = torch.optim.AdamW(
            model.parameters(),
            lr=float(settings.get("head_learning_rate", 0.001)),
            weight_decay=float(settings.get("head_weight_decay", 0.0001)),
        )
        criterion = nn.CrossEntropyLoss(reduction="none")
        best_loss, best_state, stale = float("inf"), None, 0
        epochs = 0
        for epoch in range(int(settings.get("head_max_epochs", 300))):
            epochs = epoch + 1
            model.train()
            optimiser.zero_grad()
            loss = torch.sum(criterion(model(x), y) * w) / torch.sum(w)
            loss.backward()
            optimiser.step()
            model.eval()
            with torch.inference_mode():
                fit_loss = float(torch.sum(criterion(model(x), y) * w) / torch.sum(w))
            if fit_loss < best_loss - 1e-7:
                best_loss = fit_loss
                best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                stale = 0
            else:
                stale += 1
            if stale >= int(settings.get("head_patience", 35)):
                break
        checkpoint = destination / f"parking_semantic_head_seed_{seed}.pt"
        torch.save(
            {
                "state_dict": best_state,
                "input_mean": mean,
                "input_std": std,
                "classes": TRAIN_CLASSES,
                "hidden_channels": hidden,
                "input_channels": x.shape[1],
                "backend": "sonata_ptv3",
                "training_scenes": [batch["dataset_id"] for batch in scene_batches],
            },
            checkpoint,
        )
        runs.append({"seed": seed, "epochs": epochs, "fit_loss": best_loss, "checkpoint": str(checkpoint)})
    report = {
        "schema_version": SCHEMA,
        "classes": list(TRAIN_CLASSES),
        "training_scenes": [
            {
                "dataset_id": batch["dataset_id"],
                "label_counts": batch["source_label_counts"],
            }
            for batch in scene_batches
        ],
        "selected_training_voxels": int(len(target)),
        "weighting": "class_scene_object_normalised",
        "runs": runs,
        "evaluation_note": "Training fit only; all listed parking maps participate and no held-out split exists.",
    }
    write_json(destination / "training_report.json", report)
    return report


def _aggregate_voxel_probabilities(
    probability: np.ndarray,
    agreement: np.ndarray,
    vote_fraction: np.ndarray,
    xy_cell: np.ndarray,
    shape: tuple[int, int],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Aggregate Z voxels without writing through a non-contiguous view."""

    class_count = probability.shape[1]
    cell_count = int(np.prod(shape))
    sums = np.zeros((class_count, cell_count), np.float64)
    maxima = np.zeros((class_count, cell_count), np.float32)
    counts = np.zeros(cell_count, np.int32)
    np.add.at(counts, xy_cell, 1)
    for klass in range(class_count):
        np.add.at(sums[klass], xy_cell, probability[:, klass])
        np.maximum.at(
            maxima[klass],
            xy_cell,
            np.where(agreement, probability[:, klass], 0.0),
        )
    denominator = np.maximum(counts, 1).reshape(shape)
    mean_raster = np.moveaxis(sums.reshape((class_count, *shape)), 0, -1)
    mean_raster = (mean_raster / denominator[..., None]).astype(np.float32)
    max_raster = np.moveaxis(maxima.reshape((class_count, *shape)), 0, -1)
    agreement_flat = np.zeros(cell_count, np.float32)
    np.maximum.at(agreement_flat, xy_cell, vote_fraction)
    return max_raster, mean_raster, agreement_flat.reshape(shape)


def infer_rasters(
    supervision_path: str | Path,
    features_path: str | Path,
    model_dir: str | Path,
    evidence_path: str | Path,
    output_path: str | Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    import torch
    from torch import nn

    settings = config.get("semantic_v5", {})
    evidence = load_exact_evidence(evidence_path)
    with np.load(supervision_path) as values:
        geometry = values["geometry_features"].astype(np.float32)
    semantic = np.load(features_path, mmap_mode="r")
    checkpoints = sorted(Path(model_dir).glob("parking_semantic_head_seed_*.pt"))
    if len(checkpoints) != 3:
        raise ValueError("exactly three parking semantic heads are required")
    probability_sum = np.zeros((len(geometry), len(TRAIN_CLASSES)), np.float64)
    votes = np.zeros_like(probability_sum, dtype=np.uint8)
    batch = int(settings.get("inference_batch_size", 65536))
    for checkpoint_path in checkpoints:
        checkpoint = torch.load(checkpoint_path, map_location="cpu")
        hidden = int(checkpoint["hidden_channels"])
        model = nn.Sequential(
            nn.Linear(int(checkpoint["input_channels"]), hidden),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden, len(TRAIN_CLASSES)),
        )
        model.load_state_dict(checkpoint["state_dict"])
        model.eval()
        chunks = []
        with torch.inference_mode():
            for begin in range(0, len(geometry), batch):
                end = min(len(geometry), begin + batch)
                raw = np.column_stack(
                    [np.asarray(semantic[begin:end], dtype=np.float32), geometry[begin:end]]
                )
                raw = (raw - checkpoint["input_mean"]) / checkpoint["input_std"]
                chunks.append(torch.softmax(model(torch.from_numpy(raw)), dim=1).numpy())
        probability = np.vstack(chunks)
        probability_sum += probability
        votes[np.arange(len(votes)), np.argmax(probability, axis=1)] += 1
    probability = (probability_sum / len(checkpoints)).astype(np.float32)
    agreement = votes.max(axis=1) >= int(settings.get("minimum_model_agreement", 2))
    vote_fraction = votes.max(axis=1).astype(np.float32) / float(len(checkpoints))
    # XY reconstruction needs the strongest consistent evidence at any
    # observed height.  Averaging every Z voxel diluted a clear wall/car face
    # with unrelated context and produced zero high-confidence cells.
    raster, mean_raster, agreement_raster = _aggregate_voxel_probabilities(
        probability,
        agreement,
        vote_fraction,
        evidence.xy_cell,
        evidence.shape,
    )
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        wall_probability=raster[..., 0],
        column_probability=raster[..., 1],
        vehicle_probability=raster[..., 2],
        wall_probability_mean=mean_raster[..., 0],
        column_probability_mean=mean_raster[..., 1],
        vehicle_probability_mean=mean_raster[..., 2],
        agreement_probability=agreement_raster,
        voxel_probability=probability,
        voxel_agreement=agreement,
    )
    report = {
        "output": str(output),
        "classes": list(TRAIN_CLASSES),
        "model_count": len(checkpoints),
        "minimum_confidence": float(settings.get("semantic_confidence", 0.80)),
        "minimum_model_agreement": int(settings.get("minimum_model_agreement", 2)),
        "evaluation_note": "Probabilities augment candidates and never independently delete geometry.",
    }
    write_json(output.parent / "inference_report.json", report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Parking V5 Sonata supervision, training and inference")
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare")
    prepare.add_argument("--evidence", required=True)
    prepare.add_argument("--annotations", required=True)
    prepare.add_argument("--output", required=True)
    features = sub.add_parser("features")
    features.add_argument("--config", required=True)
    features.add_argument("--supervision", required=True)
    features.add_argument("--output", required=True)
    train = sub.add_parser("train")
    train.add_argument("--config", required=True)
    train.add_argument("--supervision")
    train.add_argument("--features")
    train.add_argument(
        "--joint-manifest",
        help="JSON with scenes=[{dataset_id, supervision, features}, ...]",
    )
    train.add_argument("--output", required=True)
    infer = sub.add_parser("infer")
    infer.add_argument("--config", required=True)
    infer.add_argument("--supervision", required=True)
    infer.add_argument("--features", required=True)
    infer.add_argument("--models", required=True)
    infer.add_argument("--evidence", required=True)
    infer.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    if args.command == "prepare":
        report = prepare_supervision(args.evidence, args.annotations, args.output)
    elif args.command == "features":
        report = extract_features(args.supervision, args.output, load_config(args.config))
    elif args.command == "train":
        config = load_config(args.config)
        if args.joint_manifest:
            manifest = read_json(args.joint_manifest)
            scenes = manifest.get("scenes", [])
            if not scenes:
                parser.error("--joint-manifest contains no scenes")
            report = train_joint_heads(scenes, args.output, config)
        else:
            if not args.supervision or not args.features:
                parser.error("train requires --joint-manifest or both --supervision and --features")
            report = train_heads(args.supervision, args.features, args.output, config)
    else:
        report = infer_rasters(
            args.supervision, args.features, args.models, args.evidence, args.output, load_config(args.config)
        )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
