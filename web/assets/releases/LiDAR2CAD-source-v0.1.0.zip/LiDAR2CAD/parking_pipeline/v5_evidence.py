from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString


@dataclass(frozen=True)
class HeightWindow:
    window_id: str
    scale: str
    z_min_m: float
    z_max_m: float


@dataclass
class ExactVoxelEvidence:
    """Unique 5 cm XY / 10 cm Z observations used by parking V5.

    The arrays contain one row per occupied 3-D voxel.  ``xy_cell`` and
    ``z_bin`` are deliberately retained: support for one XY cell can never be
    borrowed from a neighbouring cell by a later stage.
    """

    origin_xy: np.ndarray
    grid_m: float
    z_bin_m: float
    floor_m: float
    ceiling_m: float
    shape: tuple[int, int]
    xy_cell: np.ndarray
    z_bin: np.ndarray
    counts: np.ndarray
    centroids: np.ndarray
    first_point_index: np.ndarray
    all_xy_cell: np.ndarray
    all_z_min_bin: np.ndarray
    all_z_max_bin: np.ndarray
    all_bin_count: np.ndarray
    structural_xy_cell: np.ndarray
    structural_z_min_bin: np.ndarray
    structural_z_max_bin: np.ndarray
    structural_bin_count: np.ndarray

    @property
    def structural_xy(self) -> np.ndarray:
        rows = self.structural_xy_cell // self.shape[1]
        columns = self.structural_xy_cell % self.shape[1]
        return self.origin_xy + (
            np.column_stack([columns, rows]).astype(np.float64) + 0.5
        ) * self.grid_m

    @property
    def raw_mask(self) -> np.ndarray:
        mask = np.zeros(self.shape, dtype=bool)
        mask.flat[self.structural_xy_cell] = True
        return mask

    def voxel_rows_for_xy(self, cells: np.ndarray) -> list[np.ndarray]:
        order = np.argsort(self.xy_cell, kind="stable")
        sorted_cells = self.xy_cell[order]
        starts = np.searchsorted(sorted_cells, cells, side="left")
        ends = np.searchsorted(sorted_cells, cells, side="right")
        return [order[first:last] for first, last in zip(starts, ends)]


def save_exact_evidence(path: str | Path, evidence: ExactVoxelEvidence) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        origin_xy=evidence.origin_xy,
        grid_m=np.asarray(evidence.grid_m),
        z_bin_m=np.asarray(evidence.z_bin_m),
        floor_m=np.asarray(evidence.floor_m),
        ceiling_m=np.asarray(evidence.ceiling_m),
        shape=np.asarray(evidence.shape, dtype=np.int64),
        xy_cell=evidence.xy_cell,
        z_bin=evidence.z_bin,
        counts=evidence.counts,
        centroids=evidence.centroids,
        first_point_index=evidence.first_point_index,
        all_xy_cell=evidence.all_xy_cell,
        all_z_min_bin=evidence.all_z_min_bin,
        all_z_max_bin=evidence.all_z_max_bin,
        all_bin_count=evidence.all_bin_count,
        structural_xy_cell=evidence.structural_xy_cell,
        structural_z_min_bin=evidence.structural_z_min_bin,
        structural_z_max_bin=evidence.structural_z_max_bin,
        structural_bin_count=evidence.structural_bin_count,
    )


def load_exact_evidence(path: str | Path) -> ExactVoxelEvidence:
    with np.load(Path(path)) as values:
        return ExactVoxelEvidence(
            origin_xy=values["origin_xy"],
            grid_m=float(values["grid_m"]),
            z_bin_m=float(values["z_bin_m"]),
            floor_m=float(values["floor_m"]),
            ceiling_m=float(values["ceiling_m"]),
            shape=tuple(int(value) for value in values["shape"]),
            xy_cell=values["xy_cell"],
            z_bin=values["z_bin"],
            counts=values["counts"],
            centroids=values["centroids"],
            first_point_index=values["first_point_index"],
            all_xy_cell=values["all_xy_cell"],
            all_z_min_bin=values["all_z_min_bin"],
            all_z_max_bin=values["all_z_max_bin"],
            all_bin_count=values["all_bin_count"],
            structural_xy_cell=values["structural_xy_cell"],
            structural_z_min_bin=values["structural_z_min_bin"],
            structural_z_max_bin=values["structural_z_max_bin"],
            structural_bin_count=values["structural_bin_count"],
        )


def height_windows(
    floor_m: float,
    ceiling_m: float,
    thickness_m: float,
    step_m: float,
    scale: str,
) -> list[HeightWindow]:
    """Create stable windows and append one ceiling-aligned tail window."""

    if thickness_m <= 0 or step_m <= 0 or ceiling_m <= floor_m:
        raise ValueError("invalid height-window bounds")
    span = ceiling_m - floor_m
    if span <= thickness_m + 1e-9:
        starts = [floor_m]
    else:
        count = int(math.floor((span - thickness_m) / step_m + 1e-9)) + 1
        starts = [floor_m + index * step_m for index in range(count)]
        tail = ceiling_m - thickness_m
        if tail - starts[-1] > 1e-6:
            starts.append(tail)
    result: list[HeightWindow] = []
    for start in starts:
        end = min(ceiling_m, start + thickness_m)
        result.append(
            HeightWindow(
                window_id=f"{scale}_{start-floor_m:.3f}_{end-floor_m:.3f}",
                scale=scale,
                z_min_m=float(start),
                z_max_m=float(end),
            )
        )
    return result


def _best_run_with_one_gap(bins: np.ndarray) -> tuple[int, int, int]:
    """Return the longest valid sub-run, rather than rejecting a whole run."""

    values = np.unique(np.asarray(bins, dtype=np.int64))
    if not len(values):
        return 0, -1, 0
    best = (int(values[0]), int(values[0]), 1)
    left = 0
    for right in range(len(values)):
        while values[right] - values[left] + 1 - (right - left + 1) > 1:
            left += 1
        candidate = (int(values[left]), int(values[right]), int(right - left + 1))
        candidate_span = candidate[1] - candidate[0] + 1
        best_span = best[1] - best[0] + 1
        if (candidate_span, candidate[2]) > (best_span, best[2]):
            best = candidate
    return best


def build_exact_voxel_evidence(
    points_cad: np.ndarray,
    *,
    grid_m: float = 0.05,
    z_bin_m: float = 0.10,
    floor_m: float | None = None,
    ceiling_m: float | None = None,
    floor_guard_m: float = 0.12,
    ceiling_guard_m: float = 0.12,
    min_vertical_span_m: float = 1.20,
    min_height_bins: int = 11,
    max_start_above_floor_m: float = 0.80,
    min_top_above_floor_m: float = 1.80,
    padding_m: float = 0.50,
) -> ExactVoxelEvidence:
    values = np.asarray(points_cad, dtype=np.float64)
    values = values[np.all(np.isfinite(values[:, :3]), axis=1)]
    if not len(values):
        raise ValueError("point cloud is empty")
    if floor_m is None:
        floor_m = float(np.quantile(values[:, 2], 0.001))
    if ceiling_m is None:
        ceiling_m = float(np.quantile(values[:, 2], 0.999))
    if ceiling_m - floor_m <= floor_guard_m + ceiling_guard_m:
        raise ValueError("floor/ceiling range is too small")
    interior = (
        (values[:, 2] >= floor_m + floor_guard_m)
        & (values[:, 2] <= ceiling_m - ceiling_guard_m)
    )
    retained = values[interior]
    source_indices = np.flatnonzero(interior)
    if not len(retained):
        raise ValueError("no points remain after floor/ceiling guards")

    origin = np.floor((retained[:, :2].min(axis=0) - padding_m) / grid_m) * grid_m
    upper = np.ceil((retained[:, :2].max(axis=0) + padding_m) / grid_m) * grid_m
    width, height = (np.ceil((upper - origin) / grid_m).astype(np.int64) + 1).tolist()
    xy_index = np.floor((retained[:, :2] - origin) / grid_m).astype(np.int64)
    z_index = np.floor((retained[:, 2] - floor_m) / z_bin_m + 1e-6).astype(np.int64)
    z_count = int(math.ceil((ceiling_m - floor_m) / z_bin_m)) + 2
    valid = (
        (xy_index[:, 0] >= 0)
        & (xy_index[:, 0] < width)
        & (xy_index[:, 1] >= 0)
        & (xy_index[:, 1] < height)
        & (z_index >= 0)
        & (z_index < z_count)
    )
    retained = retained[valid]
    source_indices = source_indices[valid]
    xy_linear = xy_index[valid, 1] * width + xy_index[valid, 0]
    z_index = z_index[valid]
    packed = xy_linear * z_count + z_index
    unique, first, inverse = np.unique(packed, return_inverse=True, return_index=True)
    counts = np.bincount(inverse, minlength=len(unique)).astype(np.int32)
    centroid = np.column_stack(
        [
            np.bincount(inverse, weights=retained[:, dimension], minlength=len(unique))
            / np.maximum(counts, 1)
            for dimension in range(3)
        ]
    )
    voxel_xy = unique // z_count
    voxel_z = unique % z_count

    order = np.argsort(voxel_xy, kind="stable")
    ordered_xy = voxel_xy[order]
    starts = np.r_[0, np.flatnonzero(ordered_xy[1:] != ordered_xy[:-1]) + 1]
    ends = np.r_[starts[1:], len(order)]
    structural_cell: list[int] = []
    run_min: list[int] = []
    run_max: list[int] = []
    run_count: list[int] = []
    all_cell: list[int] = []
    all_min: list[int] = []
    all_max: list[int] = []
    all_count: list[int] = []
    for start, end in zip(starts, ends):
        rows = order[start:end]
        first_bin, last_bin, actual = _best_run_with_one_gap(voxel_z[rows])
        span_m = (last_bin - first_bin + 1) * z_bin_m
        all_cell.append(int(ordered_xy[start]))
        all_min.append(first_bin)
        all_max.append(last_bin)
        all_count.append(actual)
        if (
            span_m + 1e-9 >= min_vertical_span_m
            and actual >= min_height_bins
            and first_bin * z_bin_m <= max_start_above_floor_m + 1e-9
            and (last_bin + 1) * z_bin_m >= min_top_above_floor_m - 1e-9
        ):
            structural_cell.append(int(ordered_xy[start]))
            run_min.append(first_bin)
            run_max.append(last_bin)
            run_count.append(actual)

    return ExactVoxelEvidence(
        origin_xy=origin,
        grid_m=float(grid_m),
        z_bin_m=float(z_bin_m),
        floor_m=float(floor_m),
        ceiling_m=float(ceiling_m),
        shape=(int(height), int(width)),
        xy_cell=voxel_xy.astype(np.int64),
        z_bin=voxel_z.astype(np.int16),
        counts=counts,
        centroids=centroid.astype(np.float32),
        first_point_index=source_indices[first].astype(np.int64),
        all_xy_cell=np.asarray(all_cell, dtype=np.int64),
        all_z_min_bin=np.asarray(all_min, dtype=np.int16),
        all_z_max_bin=np.asarray(all_max, dtype=np.int16),
        all_bin_count=np.asarray(all_count, dtype=np.int16),
        structural_xy_cell=np.asarray(structural_cell, dtype=np.int64),
        structural_z_min_bin=np.asarray(run_min, dtype=np.int16),
        structural_z_max_bin=np.asarray(run_max, dtype=np.int16),
        structural_bin_count=np.asarray(run_count, dtype=np.int16),
    )


def vertical_run_mask(
    evidence: ExactVoxelEvidence,
    *,
    min_bins: int,
    min_span_m: float,
) -> np.ndarray:
    span = (evidence.all_z_max_bin - evidence.all_z_min_bin + 1) * evidence.z_bin_m
    selected = (evidence.all_bin_count >= min_bins) & (span + 1e-9 >= min_span_m)
    mask = np.zeros(evidence.shape, dtype=bool)
    mask.flat[evidence.all_xy_cell[selected]] = True
    return mask


def window_occupancy(
    evidence: ExactVoxelEvidence,
    windows: Iterable[HeightWindow],
    *,
    minimum_bins: int = 2,
) -> dict[str, np.ndarray]:
    """Project each window without converting overlapping windows to votes."""

    result: dict[str, np.ndarray] = {}
    for window in windows:
        lower = int(math.floor((window.z_min_m - evidence.floor_m) / evidence.z_bin_m + 1e-9))
        upper = int(math.ceil((window.z_max_m - evidence.floor_m) / evidence.z_bin_m - 1e-9))
        selected = (evidence.z_bin >= lower) & (evidence.z_bin < upper)
        cells, counts = np.unique(evidence.xy_cell[selected], return_counts=True)
        mask = np.zeros(evidence.shape, dtype=bool)
        mask.flat[cells[counts >= minimum_bins]] = True
        result[window.window_id] = mask
    return result


def multiscale_fusion(
    evidence: ExactVoxelEvidence,
    thin_masks: dict[str, np.ndarray],
    thick_masks: dict[str, np.ndarray],
    semantic_wall_probability: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Fuse windows by unique height bins; projection count is diagnostic only."""

    shape = evidence.shape
    structural = evidence.raw_mask.astype(np.float32)
    thin_count = np.zeros(shape, np.int16)
    thick_count = np.zeros(shape, np.int16)
    for mask in thin_masks.values():
        thin_count += mask.astype(np.int16)
    for mask in thick_masks.values():
        thick_count += mask.astype(np.int16)
    unique_bin_fraction = np.zeros(shape, np.float32)
    cells, counts = np.unique(evidence.xy_cell, return_counts=True)
    normaliser = max(1, int(math.ceil((evidence.ceiling_m - evidence.floor_m) / evidence.z_bin_m)))
    unique_bin_fraction.flat[cells] = np.minimum(1.0, counts / normaliser)
    thin_presence = (thin_count > 0).astype(np.float32)
    thick_presence = (thick_count > 0).astype(np.float32)
    score = 0.55 * structural + 0.25 * unique_bin_fraction + 0.10 * thin_presence + 0.10 * thick_presence
    if semantic_wall_probability is not None:
        probability = np.asarray(semantic_wall_probability, dtype=np.float32)
        if probability.shape != shape:
            raise ValueError("semantic wall probability has wrong raster shape")
        score = np.clip(0.75 * score + 0.25 * probability, 0.0, 1.0)
    observed = structural.astype(bool)
    # A candidate may be visible in only one height range.  This threshold is
    # intentionally lower than the structural/observed decision; subsequent
    # wall fitting still has to pass local 3-D support checks.
    candidate = score >= 0.20
    return observed, candidate, {
        "thin_window_count": len(thin_masks),
        "thick_window_count": len(thick_masks),
        "observed_xy_cell_count": int(np.count_nonzero(observed)),
        "candidate_xy_cell_count": int(np.count_nonzero(candidate)),
        "maximum_thin_projection_overlap": int(thin_count.max(initial=0)),
        "maximum_thick_projection_overlap": int(thick_count.max(initial=0)),
        "confidence_definition": "unique_xyz_bins_plus_local_projection_presence",
    }


def curve_observation_audit(
    line: LineString,
    evidence: ExactVoxelEvidence,
    *,
    step_m: float = 0.05,
    distance_m: float = 0.10,
    min_height_bins: int = 11,
    min_vertical_span_m: float = 1.20,
    tree: cKDTree | None = None,
    z_min_m: float | None = None,
    z_max_m: float | None = None,
    row_mask: np.ndarray | None = None,
    row_tangents: np.ndarray | None = None,
    direction_tolerance_deg: float = 20.0,
    include_sources: bool = False,
) -> dict[str, Any]:
    """Audit each arclength interval using points physically inside that interval."""

    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    distances = np.linspace(0.0, line.length, count)
    samples = np.asarray([line.interpolate(float(value)).coords[0] for value in distances])
    tangents = np.gradient(samples, axis=0)
    tangent_norm = np.linalg.norm(tangents, axis=1)
    tangents = tangents / np.maximum(tangent_norm[:, None], 1e-12)
    if not len(evidence.centroids):
        return {
            "sample_count": len(samples),
            "matched_count": 0,
            "unmatched_count": len(samples),
            "matched_fraction": 0.0,
            "supported_fraction": 0.0,
            "p95_m": None,
            "supported": [False] * len(samples),
            "nearest_distance_m": [None] * len(samples),
            "sample_arclength_m": distances.tolist(),
            **({"source_voxel_rows": [[] for _ in samples],
                "height_bin_count": [0] * len(samples),
                "vertical_span_m": [0.0] * len(samples),
                "geometric_consistency": [0.0] * len(samples)} if include_sources else {}),
        }
    tree = tree or cKDTree(evidence.centroids[:, :2])
    neighbours = tree.query_ball_point(samples, distance_m, workers=-1)
    supported = np.zeros(len(samples), dtype=bool)
    nearest = np.full(len(samples), np.inf, dtype=float)
    source_rows: list[list[int]] = [[] for _ in samples]
    bin_counts = np.zeros(len(samples), dtype=int)
    spans = np.zeros(len(samples), dtype=float)
    consistency = np.zeros(len(samples), dtype=float)
    if row_mask is not None and np.shape(row_mask) != (len(evidence.centroids),):
        raise ValueError('row_mask must have one entry per unique voxel')
    if row_tangents is not None and np.shape(row_tangents) != (len(evidence.centroids), 2):
        raise ValueError('row_tangents must have shape (unique voxels, 2)')
    for index, rows in enumerate(neighbours):
        if not rows:
            continue
        rows_array = np.asarray(rows, dtype=np.int64)
        # A wide transverse search radius is useful for finding the wall
        # plane, but it must not borrow points from the preceding/following
        # arclength interval.  Assign every point to its actual interval.
        offsets = evidence.centroids[rows_array, :2] - samples[index]
        numeric_pad = (max(1e-9, float(np.finfo(evidence.centroids.dtype).eps)
            * max(1.0, float(np.max(np.abs(samples[index])))) * 2)
            if include_sources or row_tangents is not None else 1e-9)
        own = np.abs(offsets @ tangents[index]) <= step_m * 0.5 + numeric_pad
        rows_array = rows_array[own]
        if row_mask is not None:
            rows_array = rows_array[row_mask[rows_array]]
        if row_tangents is not None and len(rows_array):
            alignment = np.abs(row_tangents[rows_array] @ tangents[index])
            rows_array = rows_array[alignment >= math.cos(math.radians(direction_tolerance_deg))]
        if z_min_m is not None:
            rows_array = rows_array[
                evidence.centroids[rows_array, 2] >= z_min_m - 1e-9
            ]
        if z_max_m is not None:
            rows_array = rows_array[
                evidence.centroids[rows_array, 2] < z_max_m + 1e-9
            ]
        if not len(rows_array):
            continue
        nearest[index] = float(np.min(np.linalg.norm(evidence.centroids[rows_array, :2] - samples[index], axis=1)))
        first_bin, last_bin, actual = _best_run_with_one_gap(evidence.z_bin[rows_array])
        bin_counts[index] = actual
        spans[index] = (last_bin - first_bin + 1) * evidence.z_bin_m
        consistency[index] = (float(np.mean(np.abs(row_tangents[rows_array] @ tangents[index])))
                              if row_tangents is not None else 1.0)
        if include_sources:
            source_rows[index] = sorted(set(int(value) for value in rows_array))
        supported[index] = (
            actual >= min_height_bins
            and (last_bin - first_bin + 1) * evidence.z_bin_m + 1e-9 >= min_vertical_span_m
        )
    finite = nearest[np.isfinite(nearest)]
    matched = np.isfinite(nearest)
    return {
        "sample_count": int(len(samples)),
        "matched_count": int(np.count_nonzero(matched)),
        "unmatched_count": int(np.count_nonzero(~matched)),
        "matched_fraction": float(np.mean(matched)),
        "supported_fraction": float(np.mean(supported)),
        "p95_m": float(np.quantile(finite, 0.95)) if len(finite) else None,
        "supported": supported.tolist(),
        # ``None`` preserves unmatched intervals in JSON.  Consumers must not
        # silently drop these intervals when reporting geometric quality.
        "nearest_distance_m": [
            float(value) if np.isfinite(value) else None for value in nearest
        ],
        "sample_arclength_m": distances.tolist(),
        **({"source_voxel_rows": source_rows, "height_bin_count": bin_counts.tolist(),
            "vertical_span_m": spans.tolist(), "geometric_consistency": consistency.tolist()}
           if include_sources else {}),
    }
