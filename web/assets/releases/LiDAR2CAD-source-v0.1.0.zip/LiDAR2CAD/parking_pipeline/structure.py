from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import cv2
import ezdxf
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Polygon, mapping, shape

from lidar2outline.config import load_config
from lidar2outline.io import read_json, read_point_cloud, write_json
from lidar2outline.transforms import transform_points
from lidar2outline.vectorize import _snap_line_junctions


def _axis(line: LineString) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    coordinates = np.asarray(line.coords, dtype=float)[[0, -1]]
    delta = coordinates[1] - coordinates[0]
    length = float(np.linalg.norm(delta))
    if length <= 1e-9:
        raise ValueError("Degenerate line")
    direction = delta / length
    if direction[0] < 0.0 or (abs(direction[0]) < 1e-12 and direction[1] < 0.0):
        direction *= -1.0
    normal = np.asarray([-direction[1], direction[0]])
    return direction, normal, coordinates, length


def _angle_difference(first: np.ndarray, second: np.ndarray) -> float:
    return math.acos(float(np.clip(abs(first @ second), -1.0, 1.0)))


def _dominant_angle(lines: list[LineString], minimum_length_m: float = 1.0) -> float:
    candidates: list[tuple[float, float]] = []
    for line in lines:
        if line.length < minimum_length_m:
            continue
        direction, _, _, length = _axis(line)
        # Fold the two orthogonal architectural directions into one family.
        angle = math.atan2(direction[1], direction[0]) % (math.pi / 2.0)
        candidates.append((angle, length))
    if not candidates:
        return 0.0
    bins = 360
    histogram = np.zeros(bins, dtype=float)
    for angle, weight in candidates:
        index = int(round(angle / (math.pi / 2.0) * bins)) % bins
        histogram[index] += weight
    histogram = np.convolve(
        np.r_[histogram[-6:], histogram, histogram[:6]],
        np.hanning(13),
        mode="same",
    )[6:-6]
    return float(np.argmax(histogram) / bins * (math.pi / 2.0))


def _snap_direction_to_frame(
    direction: np.ndarray, main_angle: float, tolerance_deg: float
) -> np.ndarray:
    angle = math.atan2(direction[1], direction[0])
    choices = [main_angle + value * math.pi / 2.0 for value in range(-2, 3)]
    chosen = min(
        choices,
        key=lambda value: abs(math.atan2(math.sin(angle - value), math.cos(angle - value))),
    )
    difference = abs(math.atan2(math.sin(angle - chosen), math.cos(angle - chosen)))
    difference = min(difference, abs(math.pi - difference))
    if difference <= math.radians(tolerance_deg):
        result = np.asarray([math.cos(chosen), math.sin(chosen)])
        if result[0] < 0.0 or (abs(result[0]) < 1e-12 and result[1] < 0.0):
            result *= -1.0
        return result
    return direction


def _interval_gap(first: tuple[float, float], second: tuple[float, float]) -> float:
    return max(0.0, max(first[0], second[0]) - min(first[1], second[1]))


def _interval_overlap(first: tuple[float, float], second: tuple[float, float]) -> float:
    return max(0.0, min(first[1], second[1]) - max(first[0], second[0]))


def _weighted_median(values: np.ndarray, weights: np.ndarray) -> float:
    order = np.argsort(values)
    ordered_values = values[order]
    cumulative = np.cumsum(weights[order])
    return float(ordered_values[np.searchsorted(cumulative, cumulative[-1] * 0.5)])


def _sample_line(line: LineString, step_m: float) -> np.ndarray:
    count = max(2, int(math.ceil(line.length / max(step_m, 1e-3))) + 1)
    return np.asarray(
        [line.interpolate(value, normalized=True).coords[0] for value in np.linspace(0, 1, count)],
        dtype=float,
    )


def _mask_distances(
    points: np.ndarray,
    distance_m: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
) -> np.ndarray:
    cells = np.rint((np.asarray(points, dtype=float) - origin) / grid_m).astype(int)
    result = np.full(len(cells), np.inf, dtype=float)
    valid = (
        (cells[:, 0] >= 0)
        & (cells[:, 1] >= 0)
        & (cells[:, 0] < distance_m.shape[1])
        & (cells[:, 1] < distance_m.shape[0])
    )
    result[valid] = distance_m[cells[valid, 1], cells[valid, 0]]
    return result


def _line_support(
    line: LineString,
    distance_m: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    threshold_m: float,
) -> tuple[float, float]:
    distances = _mask_distances(
        _sample_line(line, max(grid_m * 0.5, 0.025)),
        distance_m,
        origin,
        grid_m,
    )
    finite = distances[np.isfinite(distances)]
    if not len(finite):
        return 0.0, float("inf")
    return float(np.mean(finite <= threshold_m)), float(np.quantile(finite, 0.95))


def merge_wall_fragments(
    lines: list[LineString],
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    cfg: dict[str, Any],
) -> tuple[list[dict], list[dict], dict]:
    """Fit full wall axes before dividing them into observed and inferred runs."""

    minimum_source = float(cfg.get("wall_source_min_length_m", 0.40))
    minimum_wall = float(cfg.get("wall_min_length_m", 0.75))
    angle_limit = math.radians(float(cfg.get("wall_merge_angle_deg", 3.0)))
    offset_limit = float(cfg.get("wall_merge_offset_m", 0.10))
    staggered_angle_limit = math.radians(
        float(cfg.get("wall_staggered_merge_angle_deg", 5.0))
    )
    staggered_offset_limit = float(cfg.get("wall_staggered_merge_offset_m", 0.25))
    parallel_overlap_guard = float(cfg.get("wall_parallel_overlap_guard_m", 0.30))
    grouping_gap = float(cfg.get("wall_group_gap_m", 1.20))
    observed_join_gap = float(cfg.get("wall_observed_join_gap_m", 0.25))
    inferred_gap_limit = float(cfg.get("wall_inferred_gap_m", 1.20))
    support_distance = float(cfg.get("wall_support_distance_m", 0.20))
    inferred_support = float(cfg.get("wall_inferred_min_support", 0.30))
    main_angle = _dominant_angle(lines, minimum_wall)
    distance_m = cv2.distanceTransform((mask == 0).astype(np.uint8), cv2.DIST_L2, 5) * grid_m

    groups: list[dict] = []
    for line in sorted(lines, key=lambda value: value.length, reverse=True):
        if line.length < minimum_source:
            continue
        direction, _, coordinates, length = _axis(line)
        best: tuple[float, dict] | None = None
        for group in groups:
            angle = _angle_difference(direction, group["direction"])
            if angle > staggered_angle_limit:
                continue
            projected_offset = float(np.mean(coordinates @ group["normal"]))
            lateral = abs(projected_offset - group["offset"])
            interval = tuple(sorted((coordinates @ group["direction"]).tolist()))
            group_interval = (group["minimum"], group["maximum"])
            gap = _interval_gap(interval, group_interval)
            overlap = _interval_overlap(interval, group_interval)
            ordinary_match = angle <= angle_limit and lateral <= offset_limit
            # End-to-end fragments may be displaced because different tiles
            # fitted different parts of a thick return. Absorb them into the
            # stronger wall axis, but never use this relaxed gate when the two
            # candidates overlap enough to be a resolvable parallel double.
            staggered_match = (
                lateral <= staggered_offset_limit
                and overlap <= parallel_overlap_guard
            )
            if not (ordinary_match or staggered_match):
                continue
            if gap > grouping_gap:
                continue
            score = (
                angle / max(staggered_angle_limit, 1e-9)
                + lateral / max(staggered_offset_limit, 1e-9)
                + (2.0 if staggered_match and not ordinary_match else 0.0)
            )
            if best is None or score < best[0]:
                best = (score, group)
        if best is None:
            normal = np.asarray([-direction[1], direction[0]])
            offset = float(np.mean(coordinates @ normal))
            interval = tuple(sorted((coordinates @ direction).tolist()))
            groups.append(
                {
                    "direction": direction,
                    "normal": normal,
                    "offset": offset,
                    "minimum": interval[0],
                    "maximum": interval[1],
                    "sources": [line],
                }
            )
        else:
            group = best[1]
            interval = tuple(sorted((coordinates @ group["direction"]).tolist()))
            group["minimum"] = min(group["minimum"], interval[0])
            group["maximum"] = max(group["maximum"], interval[1])
            group["sources"].append(line)

    observed: list[dict] = []
    inferred: list[dict] = []
    rejected_groups = 0
    for group_index, group in enumerate(groups):
        source_length = float(sum(value.length for value in group["sources"]))
        if source_length < minimum_wall:
            rejected_groups += 1
            continue
        # Weighted axial mean straightens tile fragments without moving the
        # wall to the midpoint between two separately observed parallel faces.
        anchor = group["direction"]
        vectors = []
        weights = []
        for source in group["sources"]:
            direction, _, _, length = _axis(source)
            if direction @ anchor < 0.0:
                direction *= -1.0
            vectors.append(direction)
            weights.append(length)
        direction = np.average(np.asarray(vectors), axis=0, weights=np.asarray(weights))
        direction /= max(float(np.linalg.norm(direction)), 1e-12)
        direction = _snap_direction_to_frame(
            direction,
            main_angle,
            float(cfg.get("wall_frame_snap_deg", 2.0)),
        )
        normal = np.asarray([-direction[1], direction[0]])
        offsets = []
        offset_weights = []
        for source in group["sources"]:
            values = np.asarray(source.coords, dtype=float)[[0, -1]]
            offsets.append(float(np.mean(values @ normal)))
            offset_weights.append(float(source.length))
        offset = _weighted_median(np.asarray(offsets), np.asarray(offset_weights))
        intervals = []
        for source in group["sources"]:
            values = np.asarray(source.coords, dtype=float)[[0, -1]]
            intervals.append(tuple(sorted((values @ direction).tolist())))
        intervals.sort()
        runs: list[list[float]] = []
        for start, end in intervals:
            if not runs or start > runs[-1][1] + observed_join_gap:
                runs.append([start, end])
            else:
                runs[-1][1] = max(runs[-1][1], end)
        wall_id = f"WALL-{group_index:05d}"
        accepted_runs: list[tuple[float, float]] = []
        for start, end in runs:
            if end - start < minimum_wall:
                continue
            line = LineString(
                [direction * start + normal * offset, direction * end + normal * offset]
            )
            fraction, p95 = _line_support(
                line, distance_m, origin, grid_m, support_distance
            )
            if fraction < float(cfg.get("wall_observed_min_support", 0.55)):
                continue
            accepted_runs.append((start, end))
            observed.append(
                {
                    "wall_id": wall_id,
                    "line": line,
                    "support_fraction": fraction,
                    "support_p95_m": p95,
                    "source_count": len(group["sources"]),
                    "status": "observed",
                }
            )
        for first, second in zip(accepted_runs, accepted_runs[1:]):
            gap = second[0] - first[1]
            if gap < max(0.15, observed_join_gap) or gap > inferred_gap_limit:
                continue
            bridge = LineString(
                [
                    direction * first[1] + normal * offset,
                    direction * second[0] + normal * offset,
                ]
            )
            fraction, p95 = _line_support(
                bridge, distance_m, origin, grid_m, support_distance
            )
            if fraction < inferred_support:
                continue
            inferred.append(
                {
                    "wall_id": wall_id,
                    "line": bridge,
                    "support_fraction": fraction,
                    "support_p95_m": p95,
                    "source_count": len(group["sources"]),
                    "status": "inferred_gap",
                }
            )

    records = observed + inferred
    snapped = _snap_line_junctions(
        [value["line"] for value in records],
        float(cfg.get("wall_junction_tolerance_m", 0.35)),
    )
    # All inputs exceed the snap helper's 0.40 m retention threshold except
    # optional short inferred bridges. Preserve those bridges unchanged.
    if len(snapped) == len(records):
        for value, line in zip(records, snapped):
            value["line"] = line
    observed = [value for value in records if value["status"] == "observed"]
    inferred = [value for value in records if value["status"] != "observed"]
    return observed, inferred, {
        "source_line_count": len(lines),
        "axis_group_count": len(groups),
        "rejected_axis_group_count": rejected_groups,
        "dominant_angle_deg": math.degrees(main_angle),
    }


def detect_column_rectangles(
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    wall_records: list[dict],
    cfg: dict[str, Any],
) -> tuple[list[dict], list[dict]]:
    """Fit compact persistent components as rectangular column hypotheses."""

    distance_m = cv2.distanceTransform((mask == 0).astype(np.uint8), cv2.DIST_L2, 5) * grid_m
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    columns: list[dict] = []
    uncertain: list[dict] = []
    minimum_side = float(cfg.get("column_min_side_m", 0.20))
    maximum_side = float(cfg.get("column_max_side_m", 1.80))
    maximum_aspect = float(cfg.get("column_max_aspect", 3.0))
    minimum_area = float(cfg.get("column_min_area_m2", 0.06))
    maximum_area = float(cfg.get("column_max_area_m2", 2.50))
    side_threshold = float(cfg.get("column_side_support_distance_m", 0.18))
    confirmed_side_count = int(cfg.get("column_confirmed_side_count", 3))
    walls = [value["line"] for value in wall_records]
    wall_samples = (
        np.vstack([_sample_line(line, 0.10) for line in walls]) if walls else np.empty((0, 2))
    )
    wall_tree = cKDTree(wall_samples) if len(wall_samples) else None

    for component in range(1, count):
        area_cells = int(stats[component, cv2.CC_STAT_AREA])
        if area_cells < int(cfg.get("column_min_cells", 6)):
            continue
        rows, columns_px = np.nonzero(labels == component)
        pixel_points = np.column_stack([columns_px, rows]).astype(np.float32)
        rectangle = cv2.minAreaRect(pixel_points)
        width_m, height_m = sorted(
            [max(float(value) * grid_m, grid_m) for value in rectangle[1]]
        )
        if (
            width_m < minimum_side
            or height_m > maximum_side
            or height_m / max(width_m, 1e-9) > maximum_aspect
        ):
            continue
        box_pixels = cv2.boxPoints(rectangle).astype(float)
        box_cad = origin + box_pixels * grid_m
        polygon = Polygon(box_cad).buffer(0)
        if polygon.is_empty or not polygon.is_valid:
            continue
        if polygon.area < minimum_area or polygon.area > maximum_area:
            continue
        edges = [
            LineString([box_cad[index], box_cad[(index + 1) % 4]]) for index in range(4)
        ]
        side_support = [
            _line_support(edge, distance_m, origin, grid_m, side_threshold)[0]
            for edge in edges
        ]
        supported_sides = sum(
            value >= float(cfg.get("column_side_min_support", 0.45))
            for value in side_support
        )
        overall_support = float(np.mean(side_support))
        if supported_sides < 2 or overall_support < float(
            cfg.get("column_min_mean_support", 0.35)
        ):
            continue
        center = np.asarray(polygon.centroid.coords[0], dtype=float)
        wall_distance = (
            float(wall_tree.query(center)[0]) if wall_tree is not None else float("inf")
        )
        record = {
            "column_id": f"COLUMN-{component:05d}",
            "polygon": polygon,
            "width_m": width_m,
            "height_m": height_m,
            "supported_side_count": int(supported_sides),
            "side_support": side_support,
            "mean_support": overall_support,
            "nearest_wall_m": wall_distance,
            "observed_edge_count": int(supported_sides),
        }
        if supported_sides >= confirmed_side_count and wall_distance >= float(
            cfg.get("column_wall_clearance_m", 0.20)
        ):
            record["status"] = "confirmed"
            columns.append(record)
        else:
            record["status"] = "uncertain"
            uncertain.append(record)
    return columns, uncertain


def _endpoint_connectivity(lines: list[LineString], tolerance_m: float = 0.03) -> dict:
    if not lines:
        return {"endpoint_count": 0, "connected_endpoint_count": 0, "connected_fraction": 0.0}
    samples = np.vstack([_sample_line(line, max(tolerance_m, 0.02)) for line in lines])
    tree = cKDTree(samples)
    connected = 0
    for index, line in enumerate(lines):
        for point in np.asarray(line.coords, dtype=float)[[0, -1]]:
            # Two nearby samples are expected on the endpoint's own line. A
            # larger local count indicates a shared endpoint or T junction.
            if len(tree.query_ball_point(point, tolerance_m)) >= 3:
                connected += 1
    total = 2 * len(lines)
    return {
        "endpoint_count": total,
        "connected_endpoint_count": connected,
        "connected_fraction": float(connected / max(total, 1)),
    }


def _line_metrics(
    records: list[dict], mask: np.ndarray, origin: np.ndarray, grid_m: float
) -> dict:
    lines = [value["line"] for value in records]
    if not lines:
        return {
            "line_count": 0,
            "total_length_m": 0.0,
            "mask_support_fraction_20cm": 0.0,
            "mask_distance_p95_m": None,
            "persistent_evidence_coverage_20cm": 0.0,
        }
    line_samples = np.vstack([_sample_line(line, 0.05) for line in lines])
    evidence_yx = np.column_stack(np.nonzero(mask))
    evidence_xy = origin + evidence_yx[:, ::-1] * grid_m
    evidence_tree = cKDTree(evidence_xy)
    line_distances = evidence_tree.query(line_samples)[0]
    line_tree = cKDTree(line_samples)
    evidence_distances = line_tree.query(evidence_xy)[0]
    return {
        "line_count": len(lines),
        "total_length_m": float(sum(line.length for line in lines)),
        "mask_support_fraction_20cm": float(np.mean(line_distances <= 0.20)),
        "mask_distance_p95_m": float(np.quantile(line_distances, 0.95)),
        "persistent_evidence_coverage_20cm": float(np.mean(evidence_distances <= 0.20)),
        **_endpoint_connectivity(lines),
    }


def _write_dxf(
    path: Path,
    observed: list[dict],
    inferred: list[dict],
    columns: list[dict],
    uncertain: list[dict],
) -> None:
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6
    for layer, color in (
        ("WALL_OBSERVED", 7),
        ("WALL_INFERRED", 30),
        ("COLUMN", 4),
        ("UNCERTAIN_DETAIL", 8),
    ):
        document.layers.add(layer, color=color)
    modelspace = document.modelspace()
    for layer, records in (("WALL_OBSERVED", observed), ("WALL_INFERRED", inferred)):
        for value in records:
            coordinates = np.asarray(value["line"].coords, dtype=float)[[0, -1]]
            modelspace.add_line(coordinates[0], coordinates[1], dxfattribs={"layer": layer})
    for layer, records in (("COLUMN", columns), ("UNCERTAIN_DETAIL", uncertain)):
        for value in records:
            coordinates = list(value["polygon"].exterior.coords)[:-1]
            modelspace.add_lwpolyline(coordinates, close=True, dxfattribs={"layer": layer})
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def _write_geojson(
    path: Path,
    observed: list[dict],
    inferred: list[dict],
    columns: list[dict],
    uncertain: list[dict],
) -> None:
    features = []
    for klass, records in (("WALL", observed), ("INFERRED_WALL", inferred)):
        for value in records:
            features.append(
                {
                    "type": "Feature",
                    "geometry": mapping(value["line"]),
                    "properties": {
                        key: item
                        for key, item in value.items()
                        if key != "line" and isinstance(item, (str, int, float, bool))
                    }
                    | {"class": klass},
                }
            )
    for klass, records in (("COLUMN", columns), ("UNCERTAIN_DETAIL", uncertain)):
        for value in records:
            features.append(
                {
                    "type": "Feature",
                    "geometry": mapping(value["polygon"]),
                    "properties": {
                        key: item
                        for key, item in value.items()
                        if key != "polygon" and isinstance(item, (str, int, float, bool))
                    }
                    | {"class": klass},
                }
            )
    write_json(
        path,
        {
            "type": "FeatureCollection",
            "local_coordinate_system": {"units": "metre", "frame": "CAD"},
            "features": features,
        },
    )


def _draw_line(
    image: np.ndarray,
    line: LineString,
    origin: np.ndarray,
    grid_m: float,
    color: tuple[int, int, int],
    width: int,
) -> None:
    pixels = np.rint((np.asarray(line.coords, dtype=float) - origin) / grid_m).astype(np.int32)
    cv2.polylines(image, [pixels.reshape(-1, 1, 2)], False, color, width, cv2.LINE_AA)


def _write_preview(
    path: Path,
    mask: np.ndarray,
    origin: np.ndarray,
    grid_m: float,
    observed: list[dict],
    inferred: list[dict],
    columns: list[dict],
    uncertain: list[dict],
) -> None:
    image = np.zeros((*mask.shape, 3), dtype=np.uint8)
    image[mask > 0] = (45, 45, 45)
    for value in observed:
        _draw_line(image, value["line"], origin, grid_m, (245, 245, 245), 2)
    for value in inferred:
        _draw_line(image, value["line"], origin, grid_m, (0, 165, 255), 2)
    for value in uncertain:
        pixels = np.rint(
            (np.asarray(value["polygon"].exterior.coords, dtype=float) - origin) / grid_m
        ).astype(np.int32)
        cv2.polylines(image, [pixels.reshape(-1, 1, 2)], True, (100, 100, 100), 1, cv2.LINE_AA)
    for value in columns:
        pixels = np.rint(
            (np.asarray(value["polygon"].exterior.coords, dtype=float) - origin) / grid_m
        ).astype(np.int32)
        cv2.polylines(image, [pixels.reshape(-1, 1, 2)], True, (255, 220, 0), 2, cv2.LINE_AA)
    image = np.flipud(image).copy()
    cv2.putText(
        image,
        f"PARKING STRUCTURE V3 - {len(observed)} observed - {len(inferred)} inferred - {len(columns)} columns",
        (18, 36),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.75,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )
    if not cv2.imwrite(str(path), image):
        raise OSError(f"Could not write image: {path}")


def _read_candidate_lines(path: Path) -> list[LineString]:
    document = read_json(path)
    return [shape(value["geometry"]) for value in document.get("features", [])]


def run_structure_stage(
    config_path: str | Path,
    point_cloud_path: str | Path,
    transforms_path: str | Path,
    preview_dir: str | Path,
    output_dir: str | Path,
) -> dict:
    cfg = load_config(config_path)
    if cfg.get("project", {}).get("scene_type") != "underground_parking":
        raise ValueError("Parking structure stage requires underground_parking")
    preview = Path(preview_dir).resolve()
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    structure_cfg = dict(cfg.get("parking_structure", {}))
    preview_report = read_json(preview / "persistent_preview_report.json")
    grid_m = float(preview_report["grid_m"])
    mask = np.flipud(cv2.imread(str(preview / "persistent_mask.png"), cv2.IMREAD_GRAYSCALE)).copy()
    mask = np.where(mask > 0, 255, 0).astype(np.uint8)
    points_ref = read_point_cloud(point_cloud_path)
    transform = np.asarray(read_json(transforms_path)["T_cad_reference_slam"], dtype=float)
    points_cad = transform_points(points_ref, transform)
    finite = points_cad[np.all(np.isfinite(points_cad), axis=1)]
    padding_m = float(structure_cfg.get("raster_padding_m", 0.5))
    origin = np.floor((finite[:, :2].min(axis=0) - padding_m) / grid_m) * grid_m
    expected_maximum = np.ceil((finite[:, :2].max(axis=0) + padding_m) / grid_m) * grid_m
    expected_shape = np.maximum(1, np.ceil((expected_maximum - origin) / grid_m).astype(int) + 1)
    if tuple(mask.shape) != (int(expected_shape[1]), int(expected_shape[0])):
        raise ValueError(
            f"Persistent mask shape {mask.shape} does not match point cloud frame "
            f"{(int(expected_shape[1]), int(expected_shape[0]))}"
        )
    candidate_lines = _read_candidate_lines(preview / "persistent_structure.geojson")
    observed, inferred, merge_metrics = merge_wall_fragments(
        candidate_lines, mask, origin, grid_m, structure_cfg
    )
    columns, uncertain = detect_column_rectangles(
        mask, origin, grid_m, observed + inferred, structure_cfg
    )
    observed_metrics = _line_metrics(observed, mask, origin, grid_m)
    full_metrics = _line_metrics(observed + inferred, mask, origin, grid_m)
    report = {
        "algorithm": str(structure_cfg.get("algorithm_version", "parking_structure_v3")),
        "source_preview": str(preview),
        "grid_m": grid_m,
        "origin_cad": origin.tolist(),
        "input_candidate_line_count": len(candidate_lines),
        "observed_wall_metrics": observed_metrics,
        "full_wall_metrics": full_metrics,
        "inferred_wall_count": len(inferred),
        "inferred_wall_length_m": float(sum(value["line"].length for value in inferred)),
        "confirmed_column_count": len(columns),
        "uncertain_detail_count": len(uncertain),
        **merge_metrics,
    }
    _write_dxf(output / "architectural_plan.dxf", observed, inferred, columns, uncertain)
    _write_geojson(output / "architectural_plan.geojson", observed, inferred, columns, uncertain)
    _write_preview(
        output / "architectural_plan.png",
        mask,
        origin,
        grid_m,
        observed,
        inferred,
        columns,
        uncertain,
    )
    write_json(output / "structure_report.json", report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Fit shared parking walls, junctions and column instances"
    )
    parser.add_argument("--config", required=True)
    parser.add_argument("--pcd", required=True)
    parser.add_argument(
        "--source-pcd",
        help="Height-uncropped source point cloud required by parking_structure_v4",
    )
    parser.add_argument("--transforms", required=True)
    parser.add_argument("--preview", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    cfg = load_config(args.config)
    algorithm = str(cfg.get("parking_structure", {}).get("algorithm_version", "parking_structure_v3"))
    if algorithm in {"parking_structure_v4", "parking_structure_v5"}:
        if not args.source_pcd:
            parser.error(f"--source-pcd is required for {algorithm}")
        if algorithm == "parking_structure_v5":
            from .structure_v5 import run_structure_v5

            report = run_structure_v5(
                args.config,
                args.pcd,
                args.source_pcd,
                args.transforms,
                args.preview,
                args.output,
            )
        else:
            from .structure_v4 import run_structure_v4

            report = run_structure_v4(
                args.config,
                args.pcd,
                args.source_pcd,
                args.transforms,
                args.preview,
                args.output,
            )
    else:
        report = run_structure_stage(
            args.config,
            args.pcd,
            args.transforms,
            args.preview,
            args.output,
        )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
