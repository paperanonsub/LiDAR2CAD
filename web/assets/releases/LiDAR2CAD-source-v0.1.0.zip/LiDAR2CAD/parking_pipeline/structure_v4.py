from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import Any

import cv2
import ezdxf
import networkx as nx
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Point, Polygon, mapping, shape
from shapely.ops import polygonize, unary_union, substring

from lidar2outline.config import load_config
from lidar2outline.io import read_json, read_point_cloud, write_json
from lidar2outline.semantic_objects import _skeleton_paths, fit_curve_primitive

from .structure import (
    _dominant_angle,
    _sample_line,
    merge_wall_fragments,
)


@dataclass
class VoxelEvidence:
    origin: np.ndarray
    shape: tuple[int, int]
    grid_m: float
    z_bin_m: float
    global_floor_m: float
    global_ceiling_m: float
    raw_mask: np.ndarray
    proposal_mask: np.ndarray
    morphology_added_mask: np.ndarray
    cell_linear: np.ndarray
    cell_z_min_m: np.ndarray
    cell_z_max_m: np.ndarray
    cell_height_bin_count: np.ndarray
    cell_vertical_span_m: np.ndarray
    cell_first_point_index: np.ndarray
    local_surfaces: list[dict[str, Any]]
    source_metrics: dict[str, Any]

    @cached_property
    def cell_xy(self) -> np.ndarray:
        rows = self.cell_linear // self.shape[1]
        columns = self.cell_linear % self.shape[1]
        return self.origin + (
            np.column_stack([columns, rows]).astype(float) + 0.5
        ) * self.grid_m

    @property
    def raster_origin(self) -> np.ndarray:
        """Metric coordinate of raster cell (0, 0)'s centre."""
        return self.origin + 0.5 * self.grid_m

    @cached_property
    def raw_tree(self) -> cKDTree:
        return cKDTree(self.cell_xy)

    @cached_property
    def proposal_tree(self) -> cKDTree:
        rows, columns = np.nonzero(self.proposal_mask)
        xy = self.origin + (
            np.column_stack([columns, rows]).astype(float) + 0.5
        ) * self.grid_m
        return cKDTree(xy)


def _fingerprint(
    config_path: Path,
    clean_path: Path,
    source_path: Path,
    transforms_path: Path,
    cfg: dict,
) -> str:
    digest = hashlib.sha256()
    digest.update(b"parking_structure_v4_evidence_1")
    for path in (config_path, clean_path, source_path, transforms_path):
        stat = path.stat()
        digest.update(str(path.resolve()).encode("utf-8"))
        digest.update(str(stat.st_size).encode("ascii"))
        digest.update(str(stat.st_mtime_ns).encode("ascii"))
    evidence_cfg = {
        key: value
        for key, value in cfg.items()
        if key.startswith(("evidence_", "surface_", "proposal_", "raster_", "cached_"))
    }
    digest.update(json.dumps(evidence_cfg, sort_keys=True, default=str).encode("utf-8"))
    return digest.hexdigest()


def _transform_xy(points: np.ndarray, transform: np.ndarray) -> np.ndarray:
    values = np.asarray(points[:, :2], dtype=np.float64)
    return values @ transform[:2, :2].T + transform[:2, 3]


def _height_peak(
    values: np.ndarray,
    expected_m: float,
    search_m: float,
    bin_m: float,
) -> tuple[float, int]:
    lower = expected_m - search_m
    upper = expected_m + search_m
    selected = values[(values >= lower) & (values <= upper)]
    if not len(selected):
        return float(expected_m), 0
    edges = np.arange(lower, upper + 2 * bin_m, bin_m)
    counts, edges = np.histogram(selected, edges)
    index = int(np.argmax(counts))
    return float((edges[index] + edges[index + 1]) * 0.5), int(counts[index])


def _local_floor_ceiling(
    source_xy: np.ndarray,
    source_z: np.ndarray,
    clean_z: np.ndarray,
    tile_m: float,
    cfg: dict[str, Any],
) -> tuple[np.ndarray, np.ndarray, list[dict[str, Any]], dict[str, Any]]:
    global_floor = float(
        np.quantile(clean_z, float(cfg.get("surface_floor_quantile", 0.001)))
        - float(cfg.get("surface_floor_restore_margin_m", 0.12))
    )
    global_ceiling = float(
        np.quantile(clean_z, float(cfg.get("surface_ceiling_quantile", 0.999)))
        + float(cfg.get("surface_ceiling_restore_margin_m", 0.12))
    )
    lower = np.floor(source_xy.min(axis=0) / tile_m) * tile_m
    tile_xy = np.floor((source_xy - lower) / tile_m).astype(np.int32)
    width = int(tile_xy[:, 0].max()) + 1
    key = tile_xy[:, 1].astype(np.int64) * width + tile_xy[:, 0]
    unique, inverse = np.unique(key, return_inverse=True)
    floors = np.full(len(unique), global_floor, dtype=np.float32)
    ceilings = np.full(len(unique), global_ceiling, dtype=np.float32)
    records: list[dict[str, Any]] = []
    search = float(cfg.get("surface_local_search_m", 0.45))
    bin_m = float(cfg.get("surface_histogram_bin_m", 0.05))
    minimum_peak = int(cfg.get("surface_min_peak_points", 80))
    inverse_order = np.argsort(inverse, kind="stable")
    inverse_counts = np.bincount(inverse, minlength=len(unique))
    inverse_starts = np.r_[0, np.cumsum(inverse_counts)]
    for local_index, tile_key in enumerate(unique):
        indices = inverse_order[inverse_starts[local_index] : inverse_starts[local_index + 1]]
        z = source_z[indices]
        floor, floor_count = _height_peak(z, global_floor, search, bin_m)
        ceiling, ceiling_count = _height_peak(z, global_ceiling, search, bin_m)
        reliable = (
            floor_count >= minimum_peak
            and ceiling_count >= minimum_peak
            and ceiling - floor >= float(cfg.get("surface_min_clearance_m", 1.8))
        )
        if reliable:
            floors[local_index] = floor
            ceilings[local_index] = ceiling
        row, column = divmod(int(tile_key), width)
        records.append(
            {
                "tile_id": f"T{row:03d}-{column:03d}",
                "bounds_cad": [
                    float(lower[0] + column * tile_m),
                    float(lower[1] + row * tile_m),
                    float(lower[0] + (column + 1) * tile_m),
                    float(lower[1] + (row + 1) * tile_m),
                ],
                "floor_m": float(floors[local_index]),
                "ceiling_m": float(ceilings[local_index]),
                "floor_peak_points": floor_count,
                "ceiling_peak_points": ceiling_count,
                "used_local_surface": bool(
                    reliable
                    and (
                        abs(floor - global_floor) > 0.10
                        or abs(ceiling - global_ceiling) > 0.10
                    )
                ),
                "reliable": bool(reliable),
            }
        )
    floor_per_point = floors[inverse]
    ceiling_per_point = ceilings[inverse]
    return floor_per_point, ceiling_per_point, records, {
        "global_floor_m": global_floor,
        "global_ceiling_m": global_ceiling,
        "tile_count": int(len(unique)),
        "reliable_tile_count": int(sum(value["reliable"] for value in records)),
        "local_surface_tile_count": int(
            sum(value["used_local_surface"] for value in records)
        ),
    }


def _longest_runs_allow_one_gap(
    cells: np.ndarray,
    bins: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return the best vertical run per cell, allowing one missing Z bin."""
    if not len(cells):
        empty = np.empty(0, dtype=np.int64)
        return empty, empty, empty, empty
    new_run = np.r_[True, (cells[1:] != cells[:-1]) | ((bins[1:] - bins[:-1]) > 2)]
    starts = np.flatnonzero(new_run)
    ends = np.r_[starts[1:], len(cells)]
    run_cells = cells[starts]
    run_min = bins[starts]
    run_max = bins[ends - 1]
    actual = ends - starts
    missing = run_max - run_min + 1 - actual
    valid = missing <= 1
    run_cells = run_cells[valid]
    run_min = run_min[valid]
    run_max = run_max[valid]
    actual = actual[valid]
    if not len(run_cells):
        empty = np.empty(0, dtype=np.int64)
        return empty, empty, empty, empty
    # Sort by cell and then quality, keeping the final (best) record per cell.
    span = run_max - run_min + 1
    order = np.lexsort((actual, span, run_cells))
    run_cells = run_cells[order]
    run_min = run_min[order]
    run_max = run_max[order]
    actual = actual[order]
    keep = np.r_[run_cells[1:] != run_cells[:-1], True]
    return run_cells[keep], run_min[keep], run_max[keep], actual[keep]


def _line_kernel(length: int, angle: float) -> np.ndarray:
    length = max(3, int(length) | 1)
    result = np.zeros((length, length), np.uint8)
    center = (length - 1) / 2.0
    delta = np.asarray([math.cos(angle), math.sin(angle)]) * center
    cv2.line(
        result,
        tuple(np.rint(np.asarray([center, center]) - delta).astype(int)),
        tuple(np.rint(np.asarray([center, center]) + delta).astype(int)),
        1,
        1,
    )
    return result


def _proposal_mask(
    raw_mask: np.ndarray,
    main_angle: float,
    grid_m: float,
    cfg: dict[str, Any],
) -> np.ndarray:
    result = raw_mask.astype(np.uint8)
    for length_m in cfg.get("proposal_directional_lengths_m", [0.40, 0.80, 1.20]):
        length = int(round(float(length_m) / grid_m)) + 1
        for angle in (main_angle, main_angle + math.pi / 2.0):
            kernel = _line_kernel(length, angle)
            closed = cv2.erode(cv2.dilate(raw_mask.astype(np.uint8), kernel), kernel)
            result = cv2.max(result, closed)
    transverse = max(1, int(round(float(cfg.get("proposal_transverse_m", 0.05)) / grid_m)))
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (2 * transverse + 1, 2 * transverse + 1)
    )
    return cv2.morphologyEx(result, cv2.MORPH_CLOSE, kernel).astype(bool)


def build_voxel_evidence(
    source_points_ref: np.ndarray,
    clean_points_ref: np.ndarray,
    transform: np.ndarray,
    seed_lines: list[LineString],
    cfg: dict[str, Any],
) -> VoxelEvidence:
    grid_m = float(cfg.get("evidence_grid_m", 0.05))
    z_bin_m = float(cfg.get("evidence_z_bin_m", 0.10))
    tile_m = float(cfg.get("evidence_tile_m", 20.0))
    padding_m = float(cfg.get("raster_padding_m", 0.50))
    source_xy = _transform_xy(source_points_ref, transform)
    clean_xy = _transform_xy(clean_points_ref, transform)
    source_z = np.asarray(source_points_ref[:, 2], dtype=np.float64)
    clean_z = np.asarray(clean_points_ref[:, 2], dtype=np.float64)
    floors, ceilings, surfaces, surface_metrics = _local_floor_ceiling(
        source_xy, source_z, clean_z, tile_m, cfg
    )
    floor_guard = float(cfg.get("evidence_floor_guard_m", 0.12))
    ceiling_guard = float(cfg.get("evidence_ceiling_guard_m", 0.12))
    interior = (
        np.all(np.isfinite(source_points_ref), axis=1)
        & (source_z >= floors + floor_guard)
        & (source_z <= ceilings - ceiling_guard)
    )
    xy = source_xy[interior]
    z = source_z[interior]
    source_indices = np.flatnonzero(interior)
    lower = np.floor((xy.min(axis=0) - padding_m) / grid_m) * grid_m
    upper = np.ceil((xy.max(axis=0) + padding_m) / grid_m) * grid_m
    width, height = (np.ceil((upper - lower) / grid_m).astype(int) + 1).tolist()
    shape = (int(height), int(width))
    ij = np.floor((xy - lower) / grid_m).astype(np.int64)
    global_floor = float(surface_metrics["global_floor_m"])
    z_index = np.floor((z - global_floor) / z_bin_m).astype(np.int64)
    z_count = max(1, int(math.ceil((float(surface_metrics["global_ceiling_m"]) - global_floor) / z_bin_m)) + 3)
    valid = (
        (ij[:, 0] >= 0)
        & (ij[:, 1] >= 0)
        & (ij[:, 0] < width)
        & (ij[:, 1] < height)
        & (z_index >= 0)
        & (z_index < z_count)
    )
    ij = ij[valid]
    z_index = z_index[valid]
    source_indices = source_indices[valid]
    xy = xy[valid]
    # A wall return is not guaranteed to remain inside the exact same 5 cm XY
    # cell over its full height.  Judge vertical continuity in a bounded local
    # support column, then retain the actual 5 cm cells and coordinates.  This
    # preserves metric precision without rejecting a wall because of beam
    # divergence, registration noise, or its physical thickness.
    support_grid_m = float(cfg.get("evidence_vertical_support_xy_m", 0.15))
    support_origin = np.floor(xy.min(axis=0) / support_grid_m) * support_grid_m
    support_ij = np.floor((xy - support_origin) / support_grid_m).astype(np.int64)
    support_width = int(support_ij[:, 0].max()) + 1
    support_cell = support_ij[:, 1] * support_width + support_ij[:, 0]
    key = support_cell * z_count + z_index
    unique_key = np.unique(key)
    unique_cell = unique_key // z_count
    unique_z = unique_key % z_count
    cells, z_min_bin, z_max_bin, actual_bins = _longest_runs_allow_one_gap(
        unique_cell, unique_z
    )
    span_bins = z_max_bin - z_min_bin + 1
    minimum_span = float(cfg.get("evidence_min_vertical_span_m", 1.20))
    minimum_bins = int(cfg.get("evidence_min_height_bins", 11))
    maximum_start = float(cfg.get("evidence_max_start_above_floor_m", 0.80))
    minimum_top = float(cfg.get("evidence_min_top_above_floor_m", 1.80))
    keep = (
        (span_bins * z_bin_m >= minimum_span)
        & (actual_bins >= minimum_bins)
        & (z_min_bin * z_bin_m <= maximum_start)
        & ((z_max_bin + 1) * z_bin_m >= minimum_top)
    )
    support_cells = cells[keep]
    support_z_min_bin = z_min_bin[keep]
    support_z_max_bin = z_max_bin[keep]
    support_actual_bins = actual_bins[keep]
    position = np.searchsorted(support_cells, support_cell)
    support_match = position < len(support_cells)
    support_match[support_match] &= support_cells[position[support_match]] == support_cell[support_match]
    fine_cell_all = ij[:, 1] * width + ij[:, 0]
    fine_cells, fine_first = np.unique(fine_cell_all[support_match], return_index=True)
    parent_position = position[support_match][fine_first]
    cells = fine_cells
    z_min_bin = support_z_min_bin[parent_position]
    z_max_bin = support_z_max_bin[parent_position]
    actual_bins = support_actual_bins[parent_position]
    span_bins = z_max_bin - z_min_bin + 1
    raw_mask = np.zeros(shape, dtype=bool)
    raw_mask.flat[cells] = True
    main_angle = _dominant_angle(seed_lines, 1.0) if seed_lines else 0.0
    proposal = _proposal_mask(raw_mask, main_angle, grid_m, cfg)

    # Map the representative point index for each retained XY cell.
    representative = source_indices[support_match][fine_first].astype(np.int64, copy=False)
    return VoxelEvidence(
        origin=lower,
        shape=shape,
        grid_m=grid_m,
        z_bin_m=z_bin_m,
        global_floor_m=global_floor,
        global_ceiling_m=float(surface_metrics["global_ceiling_m"]),
        raw_mask=raw_mask,
        proposal_mask=proposal,
        morphology_added_mask=proposal & ~raw_mask,
        cell_linear=cells.astype(np.int64),
        cell_z_min_m=global_floor + z_min_bin.astype(float) * z_bin_m,
        cell_z_max_m=global_floor + (z_max_bin.astype(float) + 1.0) * z_bin_m,
        cell_height_bin_count=actual_bins.astype(np.int16),
        cell_vertical_span_m=span_bins.astype(float) * z_bin_m,
        cell_first_point_index=representative,
        local_surfaces=surfaces,
        source_metrics={
            **surface_metrics,
            "source_point_count": int(len(source_points_ref)),
            "interior_source_point_count": int(np.count_nonzero(interior)),
            "unique_xyz_voxel_count": int(len(unique_key)),
            "vertical_support_xy_m": support_grid_m,
            "vertical_support_column_count": int(len(support_cells)),
            "structural_xy_cell_count": int(len(cells)),
            "raw_mask_pixel_count": int(np.count_nonzero(raw_mask)),
            "proposal_pixel_count": int(np.count_nonzero(proposal)),
            "morphology_added_pixel_count": int(np.count_nonzero(proposal & ~raw_mask)),
        },
    )


def save_evidence(path: Path, evidence: VoxelEvidence, fingerprint: str) -> None:
    path.mkdir(parents=True, exist_ok=True)
    np.savez(
        path / "voxel_evidence.npz",
        origin=evidence.origin,
        shape=np.asarray(evidence.shape),
        grid_m=np.asarray(evidence.grid_m),
        z_bin_m=np.asarray(evidence.z_bin_m),
        global_floor_m=np.asarray(evidence.global_floor_m),
        global_ceiling_m=np.asarray(evidence.global_ceiling_m),
        cell_linear=evidence.cell_linear,
        cell_z_min_m=evidence.cell_z_min_m,
        cell_z_max_m=evidence.cell_z_max_m,
        cell_height_bin_count=evidence.cell_height_bin_count,
        cell_vertical_span_m=evidence.cell_vertical_span_m,
        cell_first_point_index=evidence.cell_first_point_index,
    )
    cv2.imwrite(str(path / "raw_wall_evidence.png"), np.flipud(evidence.raw_mask.astype(np.uint8) * 255))
    cv2.imwrite(str(path / "proposal_mask.png"), np.flipud(evidence.proposal_mask.astype(np.uint8) * 255))
    cv2.imwrite(
        str(path / "morphology_added_only.png"),
        np.flipud(evidence.morphology_added_mask.astype(np.uint8) * 255),
    )
    write_json(path / "local_surfaces.json", {"tiles": evidence.local_surfaces})
    write_json(
        path / "cache_meta.json",
        {"fingerprint": fingerprint, "metrics": evidence.source_metrics},
    )


def load_evidence(path: Path, fingerprint: str, cfg: dict[str, Any]) -> VoxelEvidence | None:
    meta_path = path / "cache_meta.json"
    npz_path = path / "voxel_evidence.npz"
    if not meta_path.exists() or not npz_path.exists():
        return None
    meta = read_json(meta_path)
    if meta.get("fingerprint") != fingerprint:
        return None
    values = np.load(npz_path)
    shape_value = tuple(int(value) for value in values["shape"])
    raw = np.zeros(shape_value, dtype=bool)
    raw.flat[values["cell_linear"]] = True
    seed_angle = float(cfg.get("cached_main_angle_rad", math.pi / 4.0))
    proposal = _proposal_mask(raw, seed_angle, float(values["grid_m"]), cfg)
    surfaces = read_json(path / "local_surfaces.json").get("tiles", [])
    return VoxelEvidence(
        origin=values["origin"],
        shape=shape_value,
        grid_m=float(values["grid_m"]),
        z_bin_m=float(values["z_bin_m"]),
        global_floor_m=float(values["global_floor_m"]),
        global_ceiling_m=float(values["global_ceiling_m"]),
        raw_mask=raw,
        proposal_mask=proposal,
        morphology_added_mask=proposal & ~raw,
        cell_linear=values["cell_linear"],
        cell_z_min_m=values["cell_z_min_m"],
        cell_z_max_m=values["cell_z_max_m"],
        cell_height_bin_count=values["cell_height_bin_count"],
        cell_vertical_span_m=values["cell_vertical_span_m"],
        cell_first_point_index=values["cell_first_point_index"],
        local_surfaces=surfaces,
        source_metrics=dict(meta.get("metrics", {})),
    )


def _record_line(record: dict[str, Any]) -> LineString:
    value = record.get("line")
    if isinstance(value, LineString):
        return value
    return LineString(record["coordinates"])


def _normalised_direction(line: LineString) -> np.ndarray:
    coordinates = np.asarray(line.coords, dtype=float)
    vector = coordinates[-1] - coordinates[0]
    norm = float(np.linalg.norm(vector))
    return vector / max(norm, 1e-12)


def _line_angle(line: LineString) -> float:
    direction = _normalised_direction(line)
    return float(math.atan2(direction[1], direction[0]) % math.pi)


def _angle_difference_rad(first: float, second: float) -> float:
    value = abs((first - second) % math.pi)
    return float(min(value, math.pi - value))


def _point_line_coordinates(points: np.ndarray, line: LineString) -> tuple[np.ndarray, np.ndarray]:
    start = np.asarray(line.coords[0], dtype=float)
    direction = _normalised_direction(line)
    normal = np.asarray([-direction[1], direction[0]])
    delta = np.asarray(points, dtype=float) - start
    return delta @ direction, delta @ normal


def _line_mask_support(
    line: LineString,
    mask: np.ndarray,
    evidence: VoxelEvidence,
    distance_m: float,
    step_m: float = 0.05,
) -> tuple[float, float, np.ndarray, np.ndarray]:
    samples = _sample_line(line, step_m)
    if not np.any(mask):
        return 0.0, float("inf"), samples, np.full(len(samples), float("inf"))
    tree = evidence.raw_tree if mask is evidence.raw_mask else evidence.proposal_tree
    distance = tree.query(samples, workers=-1)[0]
    return (
        float(np.mean(distance <= distance_m)),
        float(np.quantile(distance, 0.95)),
        samples,
        distance,
    )


def _supported_substrings(
    line: LineString,
    evidence: VoxelEvidence,
    cfg: dict[str, Any],
) -> list[LineString]:
    step_m = float(cfg.get("wall_support_step_m", 0.05))
    limit_m = float(cfg.get("wall_observed_distance_m", 0.10))
    _, _, samples, distances = _line_mask_support(
        line, evidence.raw_mask, evidence, limit_m, step_m
    )
    supported = distances <= limit_m
    minimum_length = float(cfg.get("wall_min_supported_run_m", 0.20))
    result: list[LineString] = []
    start: int | None = None
    for index in range(len(supported) + 1):
        value = bool(supported[index]) if index < len(supported) else False
        if value and start is None:
            start = index
        elif not value and start is not None:
            stop = index
            if stop - start >= 2:
                part = LineString(samples[start:stop])
                if part.length + 1e-9 >= minimum_length:
                    result.append(part)
            start = None
    return result


def _fit_straight_wall(
    line: LineString,
    evidence: VoxelEvidence,
    tree: cKDTree,
    cfg: dict[str, Any],
) -> tuple[LineString, dict[str, Any]]:
    samples = _sample_line(line, max(evidence.grid_m, 0.05))
    neighbour_lists = tree.query_ball_point(
        samples, float(cfg.get("wall_refit_search_m", 0.15)), workers=-1
    )
    indices = np.unique(
        np.fromiter(
            (value for values in neighbour_lists for value in values),
            dtype=np.int64,
        )
    ) if any(neighbour_lists) else np.empty(0, dtype=np.int64)
    if len(indices) < int(cfg.get("wall_refit_min_cells", 10)):
        return line, {"refit": False, "reason": "too_few_raw_cells"}
    points = evidence.cell_xy[indices]
    along, normal = _point_line_coordinates(points, line)
    keep = (
        (along >= -0.10)
        & (along <= line.length + 0.10)
        & (np.abs(normal) <= float(cfg.get("wall_refit_search_m", 0.15)))
    )
    points = points[keep]
    normal = normal[keep]
    if len(points) < int(cfg.get("wall_refit_min_cells", 10)):
        return line, {"refit": False, "reason": "too_few_axis_cells"}

    # A stable pair of peaks is evidence for two different wall faces; in that
    # case the candidate remains on its original face instead of averaging both.
    histogram_edges = np.arange(-0.18, 0.181, 0.025)
    histogram, edges = np.histogram(normal, histogram_edges)
    peaks = np.argsort(histogram)[::-1]
    double_peak = False
    if len(peaks) >= 2 and histogram[peaks[1]] >= max(5, 0.25 * histogram[peaks[0]]):
        first = (edges[peaks[0]] + edges[peaks[0] + 1]) * 0.5
        second = (edges[peaks[1]] + edges[peaks[1] + 1]) * 0.5
        double_peak = abs(first - second) >= float(cfg.get("wall_double_peak_separation_m", 0.12))
    if double_peak:
        return line, {"refit": False, "reason": "parallel_double_peak"}

    center = np.median(points, axis=0)
    _, _, vh = np.linalg.svd(points - center, full_matrices=False)
    direction = vh[0]
    if np.dot(direction, _normalised_direction(line)) < 0:
        direction = -direction
    angle_change = math.degrees(
        _angle_difference_rad(math.atan2(direction[1], direction[0]), _line_angle(line))
    )
    old_start = np.asarray(line.coords[0], dtype=float)
    old_normal = np.asarray([-_normalised_direction(line)[1], _normalised_direction(line)[0]])
    lateral_shift = abs(float((center - old_start) @ old_normal))
    if angle_change > float(cfg.get("wall_max_direction_change_deg", 2.0)):
        return line, {"refit": False, "reason": "direction_change", "direction_change_deg": angle_change}
    if lateral_shift > float(cfg.get("wall_max_lateral_shift_m", 0.05)):
        return line, {"refit": False, "reason": "lateral_shift", "lateral_shift_m": lateral_shift}
    projection = (points - center) @ direction
    fitted = LineString(
        [center + direction * float(np.quantile(projection, 0.01)),
         center + direction * float(np.quantile(projection, 0.99))]
    )
    residual = np.abs((points - center) @ np.asarray([-direction[1], direction[0]]))
    return fitted, {
        "refit": True,
        "raw_cell_count": int(len(points)),
        "fit_p95_m": float(np.quantile(residual, 0.95)),
        "direction_change_deg": float(angle_change),
        "lateral_shift_m": float(lateral_shift),
    }


def _deduplicate_lines(lines: list[LineString], cfg: dict[str, Any]) -> list[LineString]:
    ordered = sorted(
        (line for line in lines if line.length >= float(cfg.get("wall_candidate_min_length_m", 0.15))),
        key=lambda value: value.length,
        reverse=True,
    )
    accepted: list[LineString] = []
    angle_limit = math.radians(float(cfg.get("wall_candidate_duplicate_angle_deg", 3.0)))
    distance_limit = float(cfg.get("wall_candidate_duplicate_distance_m", 0.06))
    for line in ordered:
        midpoint = line.interpolate(0.5, normalized=True)
        duplicate = False
        for existing in accepted:
            if _angle_difference_rad(_line_angle(line), _line_angle(existing)) > angle_limit:
                continue
            if existing.distance(midpoint) > distance_limit:
                continue
            overlap = line.buffer(distance_limit, cap_style=2).intersection(existing).length
            if overlap >= min(line.length, existing.length) * 0.65:
                duplicate = True
                break
        if not duplicate:
            accepted.append(line)
    return accepted


def extract_wall_objects(
    seed_lines: list[LineString], evidence: VoxelEvidence, cfg: dict[str, Any]
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    paths = (
        []
        if bool(cfg.get("wall_disable_raster_candidates", False))
        else _skeleton_paths(evidence.raw_mask, evidence.raster_origin, evidence.grid_m)
    )
    candidate_lines: list[LineString] = list(seed_lines)
    curved_candidates: list[LineString] = []
    for path in paths:
        if path.length < float(cfg.get("wall_candidate_min_length_m", 0.15)):
            continue
        primitive = fit_curve_primitive(path, cfg)
        coordinates = primitive.get("coordinates_ref", list(path.coords))
        fitted = LineString(coordinates)
        if primitive.get("kind") in {"arc", "spline"} and fitted.length >= float(
            cfg.get("wall_curve_min_length_m", 1.0)
        ):
            curved_candidates.append(fitted)
        else:
            coords = np.asarray(fitted.coords, dtype=float)
            candidate_lines.extend(
                LineString([coords[index], coords[index + 1]])
                for index in range(len(coords) - 1)
            )
    candidate_lines = _deduplicate_lines(candidate_lines, cfg)
    merge_cfg = dict(cfg)
    merge_cfg.update(
        {
            "wall_min_source_length_m": float(cfg.get("wall_candidate_min_length_m", 0.15)),
            "wall_min_length_m": float(cfg.get("wall_output_min_length_m", 0.20)),
            "wall_group_gap_m": float(cfg.get("wall_candidate_max_gap_m", 1.20)),
            "wall_merge_angle_deg": float(cfg.get("wall_merge_angle_deg", 5.0)),
            "wall_merge_offset_m": float(cfg.get("wall_merge_offset_m", 0.10)),
            "wall_staggered_offset_m": float(cfg.get("wall_merge_offset_m", 0.10)),
            "wall_parallel_guard_m": 0.0,
            "wall_observed_join_gap_m": float(cfg.get("wall_observed_join_gap_m", 0.10)),
            "wall_min_observed_support": float(cfg.get("wall_min_observed_support", 0.60)),
            "wall_support_distance_m": float(cfg.get("wall_observed_distance_m", 0.10)),
        }
    )
    observed_seed, inferred_seed, merge_metrics = merge_wall_fragments(
        candidate_lines,
        evidence.raw_mask.astype(np.uint8) * 255,
        evidence.raster_origin,
        evidence.grid_m,
        merge_cfg,
    )
    tree = evidence.raw_tree
    records: list[dict[str, Any]] = []
    for source_index, value in enumerate(observed_seed):
        original = value["line"]
        fitted, fit_audit = _fit_straight_wall(original, evidence, tree, cfg)
        supported_parts = _supported_substrings(fitted, evidence, cfg)
        for part_index, part in enumerate(supported_parts):
            support, p95, _, _ = _line_mask_support(
                part, evidence.raw_mask, evidence,
                float(cfg.get("wall_observed_distance_m", 0.10)),
            )
            records.append(
                {
                    "wall_id": f"W-{source_index:05d}-{part_index:02d}",
                    "line": part,
                    "geometry_kind": "line",
                    "status": "observed",
                    "source": "shared_raw_evidence",
                    "support_fraction_10cm": support,
                    "support_p95_m": p95,
                    **fit_audit,
                }
            )
    # Curved chains are retained only where raw evidence is locally present;
    # they never inherit observed status from morphology.
    for curve_index, curve in enumerate(_deduplicate_lines(curved_candidates, cfg)):
        support, p95, _, _ = _line_mask_support(
            curve, evidence.raw_mask, evidence,
            float(cfg.get("wall_observed_distance_m", 0.10)),
        )
        if support < float(cfg.get("wall_curve_min_support", 0.82)):
            continue
        records.append(
            {
                "wall_id": f"WC-{curve_index:05d}",
                "line": curve,
                "geometry_kind": "curve",
                "status": "observed",
                "source": "raw_skeleton_curve",
                "support_fraction_10cm": support,
                "support_p95_m": p95,
            }
        )
    # Old inferred bridges remain proposals only and are revalidated later.
    proposal_lines = [value["line"] for value in inferred_seed]
    return records, {
        **merge_metrics,
        "raw_skeleton_path_count": len(paths),
        "straight_candidate_count": len(candidate_lines),
        "curve_candidate_count": len(curved_candidates),
        "observed_wall_count_before_nodes": len(records),
        "unverified_bridge_candidates": proposal_lines,
    }


def _replace_endpoint(line: LineString, endpoint: int, point: np.ndarray) -> LineString:
    coordinates = np.asarray(line.coords, dtype=float).copy()
    coordinates[0 if endpoint == 0 else -1] = point
    return LineString(coordinates)


def _infinite_intersection(first: LineString, second: LineString) -> np.ndarray | None:
    point_a = np.asarray(first.coords[0], dtype=float)
    point_b = np.asarray(second.coords[0], dtype=float)
    direction_a = _normalised_direction(first)
    direction_b = _normalised_direction(second)
    matrix = np.column_stack([direction_a, -direction_b])
    determinant = float(np.linalg.det(matrix))
    if abs(determinant) < 1e-5:
        return None
    solution = np.linalg.solve(matrix, point_b - point_a)
    return point_a + solution[0] * direction_a


def update_shared_nodes(
    records: list[dict[str, Any]], cfg: dict[str, Any]
) -> tuple[list[dict[str, Any]], dict[str, list[float]], dict[str, Any]]:
    """Update endpoints by wall ID; short records never invalidate other moves."""
    tolerance = float(cfg.get("wall_junction_tolerance_m", 0.35))
    angle_min = math.radians(float(cfg.get("junction_min_angle_deg", 15.0)))
    angle_max = math.radians(float(cfg.get("junction_max_angle_deg", 165.0)))
    by_id = {str(value["wall_id"]): dict(value) for value in records}
    moves: dict[tuple[str, int], tuple[float, np.ndarray, str]] = {}
    values = list(by_id.values())
    straight = [value for value in values if value.get("geometry_kind") == "line"]
    endpoint_entries: list[tuple[int, int, np.ndarray]] = []
    for record_index, record in enumerate(straight):
        coordinates = np.asarray(_record_line(record).coords, dtype=float)
        endpoint_entries.extend(
            [(record_index, 0, coordinates[0]), (record_index, 1, coordinates[-1])]
        )
    endpoint_points = np.asarray([value[2] for value in endpoint_entries], dtype=float).reshape((-1, 2))
    endpoint_pairs = cKDTree(endpoint_points).query_pairs(max(0.02, tolerance * 2.0))
    record_pairs = {
        tuple(sorted((endpoint_entries[first][0], endpoint_entries[second][0])))
        for first, second in endpoint_pairs
        if endpoint_entries[first][0] != endpoint_entries[second][0]
    }
    for first_index, second_index in sorted(record_pairs):
            first_record = straight[first_index]
            second_record = straight[second_index]
            first = _record_line(first_record)
            second = _record_line(second_record)
            angle = _angle_difference_rad(_line_angle(first), _line_angle(second))
            if not (angle_min <= angle <= angle_max):
                continue
            intersection = _infinite_intersection(first, second)
            if intersection is None:
                continue
            endpoint_hits: list[tuple[str, int, float]] = []
            for record, line in ((first_record, first), (second_record, second)):
                coordinates = np.asarray(line.coords, dtype=float)
                distances = np.linalg.norm(coordinates[[0, -1]] - intersection, axis=1)
                endpoint = int(np.argmin(distances))
                endpoint_hits.append((str(record["wall_id"]), endpoint, float(distances[endpoint])))
            if max(value[2] for value in endpoint_hits) > tolerance:
                continue
            for wall_id, endpoint, distance in endpoint_hits:
                key = (wall_id, endpoint)
                previous = moves.get(key)
                if previous is None or distance < previous[0]:
                    other = endpoint_hits[1 if wall_id == endpoint_hits[0][0] else 0][0]
                    moves[key] = (distance, intersection, other)
    applied = 0
    for (wall_id, endpoint), (_, point, other_id) in moves.items():
        record = by_id[wall_id]
        updated = _replace_endpoint(_record_line(record), endpoint, point)
        if updated.length < 1e-6:
            continue
        record["line"] = updated
        record.setdefault("node_updates", []).append(
            {"endpoint": endpoint, "with_wall_id": other_id, "point": point.tolist()}
        )
        applied += 1

    # Split T junction host walls at the exact projected endpoint.  New child
    # IDs make the topology traceable and do not depend on list ordering.
    split_positions: dict[str, list[tuple[float, np.ndarray, str]]] = {}
    current = list(by_id.values())
    host_samples: list[np.ndarray] = []
    host_indices: list[np.ndarray] = []
    for host_index, host in enumerate(current):
        if host.get("geometry_kind") != "line":
            continue
        samples = _sample_line(_record_line(host), 0.02)
        host_samples.append(samples)
        host_indices.append(np.full(len(samples), host_index, dtype=np.int32))
    sample_xy = np.vstack(host_samples) if host_samples else np.empty((0, 2))
    sample_host = np.concatenate(host_indices) if host_indices else np.empty(0, dtype=np.int32)
    sample_tree = cKDTree(sample_xy) if len(sample_xy) else None
    for branch in current:
        branch_line = _record_line(branch)
        for endpoint_point in np.asarray(branch_line.coords, dtype=float)[[0, -1]]:
            candidate_indices = (
                np.unique(sample_host[sample_tree.query_ball_point(endpoint_point, 0.012)])
                if sample_tree is not None else []
            )
            for host_index in candidate_indices:
                host = current[int(host_index)]
                if host["wall_id"] == branch["wall_id"] or host.get("geometry_kind") != "line":
                    continue
                host_line = _record_line(host)
                distance = host_line.distance(Point(endpoint_point))
                position = host_line.project(Point(endpoint_point))
                if distance <= 0.0015 and 0.02 < position < host_line.length - 0.02:
                    projected = np.asarray(host_line.interpolate(position).coords[0], dtype=float)
                    split_positions.setdefault(str(host["wall_id"]), []).append(
                        (float(position), projected, str(branch["wall_id"]))
                    )
    output: list[dict[str, Any]] = []
    t_splits = 0
    for wall_id, record in by_id.items():
        positions = split_positions.get(wall_id, [])
        if not positions:
            output.append(record)
            continue
        line = _record_line(record)
        unique_positions = sorted({round(value[0], 6) for value in positions})
        boundaries = [0.0, *unique_positions, line.length]
        for child_index, (start, stop) in enumerate(zip(boundaries[:-1], boundaries[1:])):
            if stop - start < 1e-6:
                continue
            child = dict(record)
            child["parent_wall_id"] = wall_id
            child["wall_id"] = f"{wall_id}-T{child_index:02d}"
            child["line"] = LineString(
                [line.interpolate(start).coords[0], line.interpolate(stop).coords[0]]
            )
            output.append(child)
        t_splits += len(unique_positions)

    node_coordinates: dict[tuple[int, int], list[tuple[str, int, np.ndarray]]] = {}
    for record in output:
        line = _record_line(record)
        for endpoint, point in enumerate(np.asarray(line.coords, dtype=float)[[0, -1]]):
            key = tuple(np.rint(point / 0.001).astype(int))
            node_coordinates.setdefault(key, []).append((str(record["wall_id"]), endpoint, point))
    nodes: dict[str, list[float]] = {}
    node_ids: dict[tuple[int, int], str] = {}
    for index, (key, members) in enumerate(sorted(node_coordinates.items())):
        node_id = f"N-{index:06d}"
        coordinate = np.mean([value[2] for value in members], axis=0)
        nodes[node_id] = coordinate.tolist()
        node_ids[key] = node_id
    for record in output:
        line = _record_line(record)
        identifiers = []
        for point in np.asarray(line.coords, dtype=float)[[0, -1]]:
            identifiers.append(node_ids[tuple(np.rint(point / 0.001).astype(int))])
        record["node_ids"] = identifiers
    return output, nodes, {
        "junction_endpoint_updates": applied,
        "t_junction_split_count": t_splits,
        "node_count": len(nodes),
    }


def _connection_candidates(
    records: list[dict[str, Any]], evidence: VoxelEvidence, cfg: dict[str, Any]
) -> list[dict[str, Any]]:
    maximum_gap = float(cfg.get("wall_inferred_gap_max_m", 1.20))
    maximum_lt = float(cfg.get("wall_lt_extension_max_m", 1.00))
    endpoints: list[tuple[str, int, np.ndarray, np.ndarray]] = []
    for record in records:
        line = _record_line(record)
        if record.get("geometry_kind") != "line":
            continue
        coordinates = np.asarray(line.coords, dtype=float)
        direction = _normalised_direction(line)
        endpoints.extend(
            [(str(record["wall_id"]), 0, coordinates[0], -direction),
             (str(record["wall_id"]), 1, coordinates[-1], direction)]
        )
    candidates: list[dict[str, Any]] = []
    used_keys: set[tuple[str, int, str, int]] = set()
    record_map = {str(value["wall_id"]): value for value in records}
    endpoint_points = np.asarray([value[2] for value in endpoints], dtype=float)
    nearby_pairs = sorted(cKDTree(endpoint_points).query_pairs(maximum_gap))
    for first_index, second_index in nearby_pairs:
            first = endpoints[first_index]
            second = endpoints[second_index]
            if first[0] == second[0]:
                continue
            distance = float(np.linalg.norm(second[2] - first[2]))
            if distance > maximum_gap or distance < 0.02:
                continue
            angle = _angle_difference_rad(
                math.atan2(first[3][1], first[3][0]), math.atan2(-second[3][1], -second[3][0])
            )
            connection_kind = "collinear" if angle <= math.radians(8.0) else "corner"
            if connection_kind == "corner" and distance > maximum_lt:
                continue
            if connection_kind == "corner":
                wall_first = record_map[first[0]]
                wall_second = record_map[second[0]]
                intersection = _infinite_intersection(_record_line(wall_first), _record_line(wall_second))
                if intersection is None:
                    continue
                if max(np.linalg.norm(intersection - first[2]), np.linalg.norm(intersection - second[2])) > maximum_lt:
                    continue
                geometry = LineString([first[2], intersection, second[2]])
            else:
                geometry = LineString([first[2], second[2]])
            raw_fraction, raw_p95, _, _ = _line_mask_support(
                geometry, evidence.raw_mask, evidence,
                float(cfg.get("wall_observed_distance_m", 0.10)),
            )
            proposal_fraction, _, _, _ = _line_mask_support(
                geometry, evidence.proposal_mask, evidence,
                float(cfg.get("wall_observed_distance_m", 0.10)),
            )
            if proposal_fraction < float(cfg.get("connection_min_proposal_support", 0.70)):
                continue
            key = (first[0], first[1], second[0], second[1])
            if key in used_keys:
                continue
            used_keys.add(key)
            observed = raw_fraction >= float(cfg.get("connection_observed_support", 0.80))
            candidates.append(
                {
                    "connection_id": f"CON-{len(candidates):05d}",
                    "wall_id": f"GAP-{len(candidates):05d}",
                    "line": geometry,
                    "geometry_kind": "line",
                    "status": "observed_recovery" if observed else "inferred_gap",
                    "source": "raw_gap_recovery" if observed else "directional_morphology_candidate",
                    "kind": connection_kind,
                    "endpoint_keys": [[first[0], first[1]], [second[0], second[1]]],
                    "support_fraction_10cm": raw_fraction,
                    "support_p95_m": raw_p95,
                    "proposal_support_fraction": proposal_fraction,
                    "score": float(2.0 * raw_fraction + proposal_fraction - 0.25 * geometry.length),
                }
            )
    return sorted(candidates, key=lambda value: value["score"], reverse=True)


def select_non_competing_connections(
    candidates: list[dict[str, Any]], cfg: dict[str, Any]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    observed: list[dict[str, Any]] = []
    inferred: list[dict[str, Any]] = []
    used: set[tuple[str, int]] = set()
    for candidate in candidates:
        keys = [tuple(value) for value in candidate["endpoint_keys"]]
        if any(value in used for value in keys):
            continue
        if candidate["status"] == "observed_recovery":
            observed.append(candidate)
        elif candidate["support_fraction_10cm"] >= float(
            cfg.get("connection_inferred_raw_support", 0.20)
        ):
            inferred.append(candidate)
        else:
            continue
        used.update(keys)
    return observed, inferred


def split_connections_by_observation(
    connections: list[dict[str, Any]],
    evidence: VoxelEvidence,
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Split a connector at actual 5 cm support changes; never average over a gap."""
    observed: list[dict[str, Any]] = []
    inferred: list[dict[str, Any]] = []
    distance_limit = float(cfg.get("wall_observed_distance_m", 0.10))
    for record in connections:
        line = _record_line(record)
        count = max(2, int(math.ceil(line.length / 0.05)) + 1)
        distances_along = np.linspace(0.0, line.length, count)
        samples = np.asarray([line.interpolate(value).coords[0] for value in distances_along])
        midpoint_distance = (distances_along[:-1] + distances_along[1:]) * 0.5
        midpoints = np.asarray([line.interpolate(value).coords[0] for value in midpoint_distance])
        supported = evidence.raw_tree.query(midpoints, workers=-1)[0] <= distance_limit
        run_start = 0
        for index in range(1, len(supported) + 1):
            if index < len(supported) and supported[index] == supported[run_start]:
                continue
            child = dict(record)
            child["wall_id"] = f"{record['wall_id']}-S{run_start:03d}"
            child["parent_connection_id"] = record.get("connection_id", record["wall_id"])
            child["line"] = LineString([samples[run_start], samples[index]])
            child["endpoint_keys"] = []
            if run_start == 0 and record.get("endpoint_keys"):
                child["endpoint_keys"].append(record["endpoint_keys"][0])
            if index == len(supported) and record.get("endpoint_keys"):
                child["endpoint_keys"].append(record["endpoint_keys"][-1])
            if bool(supported[run_start]):
                child["status"] = "observed"
                child["source"] = "raw_interval_recovery"
                child["support_fraction_10cm"] = 1.0
                observed.append(child)
            else:
                child["status"] = "inferred_gap"
                child["source"] = "unsupported_interval_in_connection"
                child["support_fraction_10cm"] = 0.0
                inferred.append(child)
            run_start = index
    return observed, inferred


def recover_verified_baseline_segments(
    baseline_lines: list[LineString],
    records: list[dict[str, Any]],
    evidence: VoxelEvidence,
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Restore V3 segments only where independent raw 3-D evidence verifies them."""
    current_samples = (
        np.vstack([_sample_line(_record_line(value), 0.04) for value in records])
        if records else np.empty((0, 2))
    )
    current_tree = cKDTree(current_samples) if len(current_samples) else None
    additions: list[dict[str, Any]] = []
    verified_length = 0.0
    restored_length = 0.0
    for line_index, baseline in enumerate(baseline_lines):
        for part_index, part in enumerate(_supported_substrings(baseline, evidence, cfg)):
            verified_length += part.length
            samples = _sample_line(part, 0.05)
            coverage = (
                float(np.mean(current_tree.query(samples, workers=-1)[0] <= 0.15))
                if current_tree is not None else 0.0
            )
            if coverage >= 0.98:
                continue
            support, p95, _, _ = _line_mask_support(
                part, evidence.raw_mask, evidence,
                float(cfg.get("wall_observed_distance_m", 0.10)),
            )
            additions.append(
                {
                    "wall_id": f"VF-{line_index:05d}-{part_index:02d}",
                    "line": part,
                    "geometry_kind": "line",
                    "status": "observed",
                    "source": "v3_segment_independently_reverified",
                    "support_fraction_10cm": support,
                    "support_p95_m": p95,
                    "prior_v4_coverage_fraction": coverage,
                }
            )
            restored_length += part.length
    return records + additions, {
        "verified_v3_length_m": float(verified_length),
        "restored_verified_v3_segment_count": len(additions),
        "restored_verified_v3_length_m": float(restored_length),
    }


def _rectangle_edges(polygon: Polygon) -> list[LineString]:
    coordinates = np.asarray(polygon.exterior.coords, dtype=float)[:-1]
    return [
        LineString([coordinates[index], coordinates[(index + 1) % len(coordinates)]])
        for index in range(len(coordinates))
    ]


def _face_support(
    edge: LineString,
    evidence: VoxelEvidence,
    tree: cKDTree,
    cfg: dict[str, Any],
) -> dict[str, Any]:
    radius = float(cfg.get("column_face_support_distance_m", 0.075))
    trim_m = min(float(cfg.get("column_face_corner_trim_m", 0.08)), edge.length * 0.22)
    direction = _normalised_direction(edge)
    normal = np.asarray([-direction[1], direction[0]])
    samples_distance = np.arange(trim_m, max(trim_m, edge.length - trim_m) + 1e-9, 0.05)
    if not len(samples_distance):
        return {"supported": False, "reason": "edge_too_short", "coverage": 0.0}
    samples = np.asarray([edge.interpolate(float(value)).coords[0] for value in samples_distance])
    distance, indices = tree.query(samples, distance_upper_bound=radius, workers=-1)
    valid = np.isfinite(distance) & (indices < len(evidence.cell_linear))
    unique_indices = np.unique(indices[valid])
    coverage = float(np.mean(valid))
    if len(unique_indices) < int(cfg.get("column_face_min_cells", 5)):
        return {
            "supported": False,
            "reason": "too_few_face_cells",
            "coverage": coverage,
            "raw_cell_count": int(len(unique_indices)),
        }
    points = evidence.cell_xy[unique_indices]
    start = np.asarray(edge.coords[0], dtype=float)
    projection = (points - start) @ direction
    perpendicular = np.abs((points - start) @ normal)
    inside = (projection >= trim_m) & (projection <= edge.length - trim_m) & (perpendicular <= radius)
    unique_indices = unique_indices[inside]
    points = points[inside]
    if len(points) < int(cfg.get("column_face_min_cells", 5)):
        return {
            "supported": False,
            "reason": "corner_only_support",
            "coverage": coverage,
            "raw_cell_count": int(len(points)),
        }
    center = np.mean(points, axis=0)
    _, _, vh = np.linalg.svd(points - center, full_matrices=False)
    local_direction = vh[0]
    angle = math.degrees(
        _angle_difference_rad(
            math.atan2(local_direction[1], local_direction[0]),
            math.atan2(direction[1], direction[0]),
        )
    )
    residual = np.abs((points - start) @ normal)
    vertical_span = evidence.cell_vertical_span_m[unique_indices]
    supported = (
        coverage >= float(cfg.get("column_face_min_coverage", 0.60))
        and angle <= float(cfg.get("column_face_direction_tolerance_deg", 15.0))
        and float(np.quantile(residual, 0.95)) <= float(cfg.get("column_face_max_p95_m", 0.05))
        and float(np.median(vertical_span)) >= float(cfg.get("column_min_vertical_span_m", 1.20))
    )
    return {
        "supported": bool(supported),
        "reason": "supported" if supported else "quality_threshold",
        "coverage": coverage,
        "raw_cell_count": int(len(points)),
        "direction_residual_deg": float(angle),
        "distance_p95_m": float(np.quantile(residual, 0.95)),
        "vertical_span_median_m": float(np.median(vertical_span)),
        "source_point_indices": evidence.cell_first_point_index[unique_indices].astype(int).tolist(),
    }


def rescore_columns(
    seed_polygons: list[Polygon],
    evidence: VoxelEvidence,
    walls: list[dict[str, Any]],
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    tree = evidence.raw_tree
    polygons: list[Polygon] = [value for value in seed_polygons if value.is_valid and not value.is_empty]
    # Add compact raw components missed by V3; only their minimum rectangle is
    # an initializer and every face is independently checked below.
    component_mask = cv2.morphologyEx(
        evidence.raw_mask.astype(np.uint8),
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)),
    )
    count, labels, stats, _ = cv2.connectedComponentsWithStats(component_mask, 8)
    for component in range(1, count):
        x, y, width, height, area = [int(value) for value in stats[component]]
        side_max = max(width, height) * evidence.grid_m
        side_min = min(width, height) * evidence.grid_m
        if area < 6 or side_min < 0.15 or side_max > float(cfg.get("column_max_size_m", 1.80)):
            continue
        rows, columns = np.nonzero(labels == component)
        rectangle = cv2.minAreaRect(np.column_stack([columns, rows]).astype(np.float32))
        box = evidence.origin + (cv2.boxPoints(rectangle).astype(float) + 0.5) * evidence.grid_m
        candidate = Polygon(box).buffer(0)
        if candidate.area < float(cfg.get("column_min_area_m2", 0.04)):
            continue
        if any(value.centroid.distance(candidate.centroid) < 0.20 for value in polygons):
            continue
        polygons.append(candidate)
    wall_geometry = unary_union([_record_line(value) for value in walls]) if walls else None
    reliable: list[dict[str, Any]] = []
    uncertain: list[dict[str, Any]] = []
    corrected_two_face = 0
    for index, seed in enumerate(polygons):
        rectangle_coords = cv2.boxPoints(
            cv2.minAreaRect(
                ((np.asarray(seed.exterior.coords, dtype=float)[:-1] - evidence.origin)
                 / evidence.grid_m).astype(np.float32)
            )
        )
        polygon = Polygon(evidence.origin + rectangle_coords.astype(float) * evidence.grid_m).buffer(0)
        if polygon.is_empty or not polygon.is_valid:
            continue
        dimensions = sorted(
            [LineString([polygon.exterior.coords[i], polygon.exterior.coords[i + 1]]).length for i in (0, 1)]
        )
        if dimensions[0] < float(cfg.get("column_min_size_m", 0.15)) or dimensions[1] > float(
            cfg.get("column_max_size_m", 1.80)
        ):
            continue
        edge_audits = [_face_support(edge, evidence, tree, cfg) for edge in _rectangle_edges(polygon)]
        supported_indices = [face for face, value in enumerate(edge_audits) if value["supported"]]
        wall_conflict = bool(
            wall_geometry is not None
            and wall_geometry.distance(polygon.centroid) < float(cfg.get("column_wall_clearance_m", 0.15))
        )
        record = {
            "column_id": f"COL-{index:05d}",
            "polygon": polygon,
            "shape": "rectangle",
            "dimensions_m": dimensions,
            "width_m": dimensions[0],
            "height_m": dimensions[1],
            "observed_edge_indices": supported_indices,
            "inferred_edge_indices": [value for value in range(4) if value not in supported_indices],
            "observed_edge_count": len(supported_indices),
            "edge_support": edge_audits,
            "wall_conflict": wall_conflict,
            "source": "v3_rescored" if index < len(seed_polygons) else "raw_component",
        }
        if len(supported_indices) >= 3 and not wall_conflict:
            record["status"] = "reliable" if len(supported_indices) == 4 else "partial_one_face_inferred"
            reliable.append(record)
        else:
            record["status"] = "uncertain"
            if len(supported_indices) <= 2:
                corrected_two_face += 1
            uncertain.append(record)
    return reliable, uncertain, {
        "seed_column_count": len(seed_polygons),
        "column_candidate_count": len(polygons),
        "reliable_column_count": len(reliable),
        "uncertain_column_count": len(uncertain),
        "two_face_candidates_rejected": corrected_two_face,
    }


def _virtual_opening_candidates(
    records: list[dict[str, Any]], existing: list[dict[str, Any]], cfg: dict[str, Any]
) -> list[dict[str, Any]]:
    maximum = float(cfg.get("wall_lt_extension_max_m", 1.0))
    occupied = {
        tuple(value)
        for candidate in existing
        for value in candidate.get("endpoint_keys", [])
    }
    endpoints: list[tuple[str, int, np.ndarray]] = []
    for record in records:
        line = _record_line(record)
        for endpoint, point in enumerate(np.asarray(line.coords, dtype=float)[[0, -1]]):
            key = (str(record["wall_id"]), endpoint)
            if key not in occupied:
                endpoints.append((key[0], key[1], point))
    result: list[dict[str, Any]] = []
    if not endpoints:
        return result
    endpoint_points = np.asarray([value[2] for value in endpoints], dtype=float)
    nearby_pairs = sorted(
        cKDTree(endpoint_points).query_pairs(maximum),
        key=lambda value: float(np.sum((endpoint_points[value[0]] - endpoint_points[value[1]]) ** 2)),
    )
    observed_union = unary_union([_record_line(value) for value in records])
    candidate_limit = int(cfg.get("virtual_candidate_limit", 1000))
    for first_index, second_index in nearby_pairs:
            first = endpoints[first_index]
            second = endpoints[second_index]
            if first[0] == second[0]:
                continue
            distance = float(np.linalg.norm(first[2] - second[2]))
            if not 0.05 <= distance <= maximum:
                continue
            line = LineString([first[2], second[2]])
            # A virtual opening is allowed only as a topological boundary; it
            # may not cut across an observed wall away from its endpoints.
            if line.crosses(observed_union) or line.overlaps(observed_union):
                continue
            result.append(
                {
                    "connection_id": f"OPEN-{len(result):05d}",
                    "wall_id": f"OPEN-{len(result):05d}",
                    "line": line,
                    "geometry_kind": "line",
                    "status": "virtual_opening",
                    "source": "topology_only",
                    "endpoint_keys": [[first[0], first[1]], [second[0], second[1]]],
                    "support_fraction_10cm": 0.0,
                    "support_p95_m": None,
                    "proposal_support_fraction": 0.0,
                    "score": float(-distance),
                }
            )
            if len(result) >= candidate_limit:
                break
    return result


def optimise_closed_regions(
    observed: list[dict[str, Any]],
    inferred_candidates: list[dict[str, Any]],
    virtual_candidates: list[dict[str, Any]],
    cfg: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    observed_lines = [_record_line(value) for value in observed]
    # Polygonising all pairwise virtual chords at once creates a crossed line
    # soup.  Enforce the same one-connection-per-endpoint rule before region
    # generation, then let MILP choose among the resulting simple candidates.
    used_endpoints = {
        tuple(value)
        for candidate in inferred_candidates
        for value in candidate.get("endpoint_keys", [])
    }
    compatible_virtual: list[dict[str, Any]] = []
    for candidate in sorted(virtual_candidates, key=lambda value: _record_line(value).length):
        keys = [tuple(value) for value in candidate.get("endpoint_keys", [])]
        if any(value in used_endpoints for value in keys):
            continue
        compatible_virtual.append(candidate)
        used_endpoints.update(keys)
    connectors = inferred_candidates + compatible_virtual
    base_lines = observed_lines + [_record_line(value) for value in inferred_candidates]
    all_lines = observed_lines + [_record_line(value) for value in connectors]
    if not all_lines:
        return [], [], {"closure_solver_status": "empty", "region_candidate_count": 0}
    minimum_area = float(cfg.get("closed_region_min_area_m2", 1.0))
    base_polygons = [polygon.buffer(0) for polygon in polygonize(unary_union(base_lines))]
    augmented_polygons = [polygon.buffer(0) for polygon in polygonize(unary_union(all_lines))]
    polygons = []
    polygon_signatures: set[tuple[float, float, float]] = set()
    for polygon in base_polygons + augmented_polygons:
        if polygon.area < minimum_area or polygon.geom_type != "Polygon":
            continue
        signature = (
            round(polygon.centroid.x, 3), round(polygon.centroid.y, 3), round(polygon.area, 3)
        )
        if signature in polygon_signatures:
            continue
        polygon_signatures.add(signature)
        polygons.append(polygon)
    region_candidates: list[dict[str, Any]] = []
    for region_index, polygon in enumerate(polygons):
        boundary = polygon.boundary
        connector_lengths: dict[int, float] = {}
        for connector_index, connector in enumerate(connectors):
            overlap = boundary.buffer(0.001).intersection(_record_line(connector)).length
            if overlap > 0.005:
                connector_lengths[connector_index] = float(overlap)
        synthetic_length = sum(connector_lengths.values())
        observed_length = max(0.0, boundary.length - synthetic_length)
        observed_fraction = observed_length / max(boundary.length, 1e-9)
        inferred_fraction = sum(
            length for index, length in connector_lengths.items()
            if connectors[index]["status"] == "inferred_gap"
        ) / max(boundary.length, 1e-9)
        virtual_fraction = sum(
            length for index, length in connector_lengths.items()
            if connectors[index]["status"] == "virtual_opening"
        ) / max(boundary.length, 1e-9)
        if observed_fraction + 1e-9 < float(cfg.get("closed_region_min_observed_fraction", 0.80)):
            continue
        if inferred_fraction + virtual_fraction > float(
            cfg.get("closed_region_max_synthetic_fraction", 0.20)
        ) + 1e-9:
            continue
        region_candidates.append(
            {
                "region_id": f"REG-{region_index:05d}",
                "polygon": polygon,
                "connector_indices": sorted(connector_lengths),
                "perimeter_m": float(boundary.length),
                "area_m2": float(polygon.area),
                "observed_fraction": float(observed_fraction),
                "inferred_fraction": float(inferred_fraction),
                "virtual_fraction": float(virtual_fraction),
            }
        )
    # A linework polygonizer only sees cycles after every junction has already
    # been perfectly noded.  Independently enumerate one-gap graph cycles so a
    # short door/opening edge can close a well-supported room even when other
    # unrelated dangling branches are present on the same walls.
    graph = nx.Graph()

    def node_key(point: np.ndarray) -> tuple[int, int]:
        return tuple(np.rint(np.asarray(point, dtype=float) / 0.001).astype(int))

    for line in observed_lines:
        coordinates = np.asarray(line.coords, dtype=float)
        first, second = node_key(coordinates[0]), node_key(coordinates[-1])
        weight = float(line.length)
        if first != second and (not graph.has_edge(first, second) or weight < graph[first][second]["weight"]):
            graph.add_edge(first, second, weight=weight, status="observed", connector_index=None)
    for connector_index, connector in enumerate(inferred_candidates):
        line = _record_line(connector)
        coordinates = np.asarray(line.coords, dtype=float)
        first, second = node_key(coordinates[0]), node_key(coordinates[-1])
        if first != second and not graph.has_edge(first, second):
            graph.add_edge(
                first, second, weight=float(line.length), status="inferred_gap",
                connector_index=connector_index,
            )
    seen_regions = {
        (round(value["polygon"].centroid.x, 2), round(value["polygon"].centroid.y, 2), round(value["area_m2"], 2))
        for value in region_candidates
    }
    maximum_perimeter = float(cfg.get("closed_region_max_perimeter_m", 500.0))
    maximum_area = float(cfg.get("closed_region_max_area_m2", 10000.0))
    for virtual_offset, connector in enumerate(compatible_virtual):
        line = _record_line(connector)
        coordinates = np.asarray(line.coords, dtype=float)
        first, second = node_key(coordinates[0]), node_key(coordinates[-1])
        if first == second or first not in graph or second not in graph:
            continue
        try:
            path_nodes = nx.shortest_path(graph, first, second, weight="weight")
        except nx.NetworkXNoPath:
            continue
        cycle_coordinates = np.asarray([np.asarray(value, dtype=float) * 0.001 for value in path_nodes])
        if len(cycle_coordinates) < 3:
            continue
        polygon = Polygon(cycle_coordinates).buffer(0)
        if polygon.geom_type != "Polygon" or not polygon.is_valid or polygon.area < float(
            cfg.get("closed_region_min_area_m2", 1.0)
        ) or polygon.area > maximum_area or polygon.length > maximum_perimeter:
            continue
        connector_indices = [len(inferred_candidates) + virtual_offset]
        synthetic_length = float(line.length)
        for first_node, second_node in zip(path_nodes[:-1], path_nodes[1:]):
            edge = graph[first_node][second_node]
            if edge.get("connector_index") is not None:
                connector_indices.append(int(edge["connector_index"]))
                synthetic_length += float(edge["weight"])
        synthetic_fraction = synthetic_length / max(polygon.length, 1e-9)
        if synthetic_fraction > float(cfg.get("closed_region_max_synthetic_fraction", 0.20)) + 1e-9:
            continue
        signature = (round(polygon.centroid.x, 2), round(polygon.centroid.y, 2), round(polygon.area, 2))
        if signature in seen_regions:
            continue
        seen_regions.add(signature)
        region_candidates.append(
            {
                "region_id": f"GRAPH-{virtual_offset:05d}",
                "polygon": polygon,
                "connector_indices": sorted(set(connector_indices)),
                "perimeter_m": float(polygon.length),
                "area_m2": float(polygon.area),
                "observed_fraction": float(1.0 - synthetic_fraction),
                "inferred_fraction": float(
                    sum(
                        _record_line(connectors[index]).length
                        for index in set(connector_indices)
                        if connectors[index]["status"] == "inferred_gap"
                    ) / max(polygon.length, 1e-9)
                ),
                "virtual_fraction": float(line.length / max(polygon.length, 1e-9)),
            }
        )
    if not region_candidates:
        return [], [], {
            "closure_solver_status": "no_qualified_regions",
            "raw_polygon_count": len(polygons),
            "region_candidate_count": 0,
        }

    connector_count = len(connectors)
    region_count = len(region_candidates)
    variable_count = connector_count + region_count
    objective = np.zeros(variable_count, dtype=float)
    for index, connector in enumerate(connectors):
        objective[index] = _record_line(connector).length * (
            1.0 if connector["status"] == "inferred_gap" else 1.5
        )
    for index, region in enumerate(region_candidates):
        # Regions already satisfy the hard 80/20 evidence gate.  Selecting a
        # qualified closure is therefore lexicographically more important than
        # shaving a few centimetres from its inferred boundary.
        objective[connector_count + index] = -(
            10.0 + 0.10 * math.sqrt(region["area_m2"])
            + 0.02 * region["observed_fraction"] * region["perimeter_m"]
        )
    rows: list[int] = []
    columns: list[int] = []
    data: list[float] = []
    lower: list[float] = []
    upper: list[float] = []
    row = 0
    for region_index, region in enumerate(region_candidates):
        y = connector_count + region_index
        for connector_index in region["connector_indices"]:
            rows.extend([row, row])
            columns.extend([y, connector_index])
            data.extend([1.0, -1.0])
            lower.append(-np.inf)
            upper.append(0.0)
            row += 1
    for connector_index in range(connector_count):
        users = [
            connector_count + index
            for index, region in enumerate(region_candidates)
            if connector_index in region["connector_indices"]
        ]
        if not users:
            objective[connector_index] += 1000.0
            continue
        rows.append(row)
        columns.append(connector_index)
        data.append(1.0)
        for user in users:
            rows.append(row)
            columns.append(user)
            data.append(-1.0)
        lower.append(-np.inf)
        upper.append(0.0)
        row += 1
    endpoint_to_connectors: dict[tuple[str, int], list[int]] = {}
    for index, connector in enumerate(connectors):
        for value in connector.get("endpoint_keys", []):
            endpoint_to_connectors.setdefault(tuple(value), []).append(index)
    for indices in endpoint_to_connectors.values():
        if len(indices) <= 1:
            continue
        for index in indices:
            rows.append(row)
            columns.append(index)
            data.append(1.0)
        lower.append(-np.inf)
        upper.append(1.0)
        row += 1
    constraints = None
    if row:
        matrix = coo_matrix((data, (rows, columns)), shape=(row, variable_count)).tocsr()
        constraints = LinearConstraint(matrix, np.asarray(lower), np.asarray(upper))
    result = milp(
        objective,
        integrality=np.ones(variable_count),
        bounds=Bounds(np.zeros(variable_count), np.ones(variable_count)),
        constraints=constraints,
        options={"time_limit": float(cfg.get("closure_solver_timeout_s", 120.0))},
    )
    if result.x is None or not result.success:
        # Safe fallback: keep only polygons that need no synthetic edge.  Never
        # accept all candidates when the optimiser fails.
        selected_regions = [value for value in region_candidates if not value["connector_indices"]]
        selected_connectors: list[dict[str, Any]] = []
        status = f"failed_safe_observed_only:{result.message}"
    else:
        selected_regions = [
            value for index, value in enumerate(region_candidates)
            if result.x[connector_count + index] >= 0.5
        ]
        used = sorted(
            {
                connector_index
                for value in selected_regions
                for connector_index in value["connector_indices"]
            }
        )
        selected_connectors = [connectors[index] for index in used]
        status = str(result.message)
    return selected_regions, selected_connectors, {
        "closure_solver_status": status,
        "raw_polygon_count": len(polygons),
        "region_candidate_count": len(region_candidates),
        "closed_region_count": len(selected_regions),
        "closed_region_area_m2": float(sum(value["area_m2"] for value in selected_regions)),
        "selected_closure_connector_count": len(selected_connectors),
    }


def _plain_properties(record: dict[str, Any], excluded: set[str]) -> dict[str, Any]:
    def plain(value: Any) -> Any:
        if isinstance(value, np.ndarray):
            return plain(value.tolist())
        if isinstance(value, np.generic):
            return plain(value.item())
        if isinstance(value, dict):
            return {str(k): plain(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [plain(v) for v in value]
        if isinstance(value, float) and not np.isfinite(value):
            return None
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        raise TypeError(type(value).__name__)

    result: dict[str, Any] = {}
    for key, value in record.items():
        if key in excluded:
            continue
        try:
            result[key] = plain(value)
        except (TypeError, ValueError):
            pass
    return result


def _add_xdata(entity: Any, object_id: str, status: str, source: str) -> None:
    entity.set_xdata(
        "LIDAR2OUTLINE",
        [(1000, str(object_id)), (1000, str(status)), (1000, str(source))],
    )


def write_architectural_dxf(
    path: Path,
    observed: list[dict[str, Any]],
    inferred: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    uncertain: list[dict[str, Any]],
) -> None:
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6
    document.appids.add("LIDAR2OUTLINE")
    document.appids.add("LIDAR2EVIDENCE")
    for name, color, off in (
        ("WALL_OBSERVED", 7, False),
        ("WALL_INFERRED", 30, False),
        ("WALL_WEAK_OBSERVATION", 8, False),
        ("WALL_UNKNOWN", 9, True),
        ("COLUMN_OBSERVED", 4, False),
        ("COLUMN_INFERRED", 30, False),
        ("COLUMN_FOOTPRINT", 4, True),
        ("UNCERTAIN_DETAIL", 8, True),
    ):
        layer = document.layers.add(name, color=color)
        if off:
            layer.off()
    modelspace = document.modelspace()
    for layer_name, records in (("WALL_OBSERVED", observed), ("WALL_INFERRED", inferred)):
        for record in records:
            line = _record_line(record)
            if record.get('window_evidence') is not None:
                # Only dual-layer records use interval export; historical DXF is unchanged.
                for interval in record.get('support_intervals', []):
                    segment = substring(line, interval['s_start_m'], interval['s_end_m'])
                    if segment.geom_type != 'LineString' or segment.length <= 1e-10:
                        continue
                    strength = interval['evidence_strength']
                    local_layer = ('WALL_OBSERVED' if strength == 'strong' else
                                   'WALL_WEAK_OBSERVATION' if strength == 'weak' else
                                   'WALL_INFERRED' if interval['state'] == 'inferred' else 'WALL_UNKNOWN')
                    entity = modelspace.add_lwpolyline(list(segment.coords), dxfattribs={'layer': local_layer})
                    _add_xdata(entity, record.get('wall_id', ''), interval['state'], record.get('source', ''))
                    entity.set_xdata('LIDAR2EVIDENCE', [(1000, record.get('wall_id', '')),
                        (1040, float(interval['s_start_m'])), (1040, float(interval['s_end_m'])),
                        (1000, strength)])
                continue
            coordinates = np.asarray(line.coords, dtype=float)
            if len(coordinates) == 2:
                entity = modelspace.add_line(coordinates[0], coordinates[1], dxfattribs={"layer": layer_name})
            else:
                entity = modelspace.add_spline(coordinates, dxfattribs={"layer": layer_name})
            _add_xdata(entity, record.get("wall_id", ""), record.get("status", ""), record.get("source", ""))
    for record in columns:
        if record.get("cross_section_model") == "circle":
            center = np.asarray(record["center"], dtype=float)
            radius = float(record.get("diameter_m", record.get("width_m", 0.0))) / 2.0
            footprint = modelspace.add_circle(
                center,
                radius,
                dxfattribs={"layer": "COLUMN_FOOTPRINT"},
            )
            _add_xdata(footprint, record["column_id"], record["status"], record["source"])
            observed_bins = set(int(value) for value in record.get("observed_edge_indices", []))
            for index in range(24):
                layer_name = "COLUMN_OBSERVED" if index in observed_bins else "COLUMN_INFERRED"
                entity = modelspace.add_arc(
                    center,
                    radius,
                    start_angle=index * 15.0,
                    end_angle=(index + 1) * 15.0,
                    dxfattribs={"layer": layer_name},
                )
                _add_xdata(
                    entity,
                    record["column_id"],
                    "observed" if index in observed_bins else "inferred",
                    record["source"],
                )
            continue
        coordinates = np.asarray(record["polygon"].exterior.coords, dtype=float)[:-1]
        footprint = modelspace.add_lwpolyline(
            coordinates, close=True, dxfattribs={"layer": "COLUMN_FOOTPRINT"}
        )
        _add_xdata(footprint, record["column_id"], record["status"], record["source"])
        observed_edges = set(record.get("observed_edge_indices", []))
        for index in range(len(coordinates)):
            layer_name = "COLUMN_OBSERVED" if index in observed_edges else "COLUMN_INFERRED"
            entity = modelspace.add_line(
                coordinates[index], coordinates[(index + 1) % len(coordinates)],
                dxfattribs={"layer": layer_name},
            )
            _add_xdata(entity, record["column_id"], "observed" if index in observed_edges else "inferred", record["source"])
    for record in uncertain:
        if record.get("cross_section_model") == "circle":
            center = np.asarray(record["center"], dtype=float)
            radius = float(record.get("diameter_m", record.get("width_m", 0.0))) / 2.0
            entity = modelspace.add_circle(
                center,
                radius,
                dxfattribs={"layer": "UNCERTAIN_DETAIL"},
            )
            _add_xdata(entity, record["column_id"], "uncertain", record["source"])
            continue
        coordinates = np.asarray(record["polygon"].exterior.coords, dtype=float)[:-1]
        entity = modelspace.add_lwpolyline(
            coordinates, close=True, dxfattribs={"layer": "UNCERTAIN_DETAIL"}
        )
        _add_xdata(entity, record["column_id"], "uncertain", record["source"])
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def write_closed_layout_dxf(
    path: Path,
    regions: list[dict[str, Any]],
    connectors: list[dict[str, Any]],
) -> None:
    document = ezdxf.new("R2013", setup=True)
    document.header["$INSUNITS"] = 6
    document.appids.add("LIDAR2OUTLINE")
    document.layers.add("SPACE_BOUNDARY", color=3)
    document.layers.add("WALL_INFERRED", color=30)
    document.layers.add("OPENING_VIRTUAL", color=5)
    modelspace = document.modelspace()
    for region in regions:
        coordinates = np.asarray(region["polygon"].exterior.coords, dtype=float)[:-1]
        entity = modelspace.add_lwpolyline(
            coordinates, close=True, dxfattribs={"layer": "SPACE_BOUNDARY"}
        )
        _add_xdata(entity, region["region_id"], "closed", "joint_topology")
    for connector in connectors:
        layer_name = "OPENING_VIRTUAL" if connector["status"] == "virtual_opening" else "WALL_INFERRED"
        coordinates = np.asarray(_record_line(connector).coords, dtype=float)
        entity = modelspace.add_lwpolyline(coordinates, dxfattribs={"layer": layer_name})
        _add_xdata(entity, connector["connection_id"], connector["status"], connector["source"])
    path.parent.mkdir(parents=True, exist_ok=True)
    document.saveas(path)


def write_structure_geojson(
    path: Path,
    observed: list[dict[str, Any]],
    inferred: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    uncertain: list[dict[str, Any]],
    regions: list[dict[str, Any]],
    nodes: dict[str, list[float]],
    transform: np.ndarray,
) -> None:
    features: list[dict[str, Any]] = []
    for klass, records in (("WALL", observed), ("INFERRED_WALL", inferred)):
        for record in records:
            features.append(
                {
                    "type": "Feature",
                    "geometry": mapping(_record_line(record)),
                    "properties": _plain_properties(record, {"line"}) | {"class": klass},
                }
            )
    for klass, records in (("COLUMN", columns), ("UNCERTAIN_DETAIL", uncertain)):
        for record in records:
            features.append(
                {
                    "type": "Feature",
                    "geometry": mapping(record["polygon"]),
                    "properties": _plain_properties(record, {"polygon", "edge_support"}) | {"class": klass},
                }
            )
    for region in regions:
        features.append(
            {
                "type": "Feature",
                "geometry": mapping(region["polygon"]),
                "properties": _plain_properties(region, {"polygon"}) | {"class": "CLOSED_REGION"},
            }
        )
    write_json(
        path,
        {
            "type": "FeatureCollection",
            "local_coordinate_system": {"units": "metre", "frame": "CAD"},
            "T_cad_reference_slam": transform.tolist(),
            "T_reference_slam_cad": np.linalg.inv(transform).tolist(),
            "nodes": nodes,
            "features": features,
        },
    )


def _draw_metric_line(
    image: np.ndarray,
    line: LineString,
    evidence: VoxelEvidence,
    color: tuple[int, int, int],
    width: int,
) -> None:
    coordinates = np.asarray(line.coords, dtype=float)
    pixels = np.rint((coordinates - evidence.origin) / evidence.grid_m - 0.5).astype(np.int32)
    cv2.polylines(image, [pixels.reshape(-1, 1, 2)], False, color, width, cv2.LINE_AA)


def render_plan(
    path: Path,
    evidence: VoxelEvidence,
    observed: list[dict[str, Any]],
    inferred: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    uncertain: list[dict[str, Any]],
    openings: list[dict[str, Any]],
    title: str,
) -> np.ndarray:
    image = np.zeros((*evidence.shape, 3), dtype=np.uint8)
    image[evidence.raw_mask] = (34, 34, 34)
    image[evidence.morphology_added_mask] = (15, 15, 30)
    for record in observed:
        _draw_metric_line(image, _record_line(record), evidence, (245, 245, 245), 2)
    for record in inferred:
        _draw_metric_line(image, _record_line(record), evidence, (0, 165, 255), 2)
    for record in openings:
        _draw_metric_line(image, _record_line(record), evidence, (255, 160, 40), 2)
    for record in uncertain:
        coordinates = np.asarray(record["polygon"].exterior.coords, dtype=float)
        pixels = np.rint((coordinates - evidence.origin) / evidence.grid_m - 0.5).astype(np.int32)
        cv2.polylines(image, [pixels.reshape(-1, 1, 2)], True, (90, 90, 90), 1, cv2.LINE_AA)
    for record in columns:
        coordinates = np.asarray(record["polygon"].exterior.coords, dtype=float)
        pixels = np.rint((coordinates - evidence.origin) / evidence.grid_m - 0.5).astype(np.int32)
        cv2.polylines(image, [pixels.reshape(-1, 1, 2)], True, (255, 220, 0), 2, cv2.LINE_AA)
    image = np.flipud(image).copy()
    scale = min(1.0, 3600.0 / max(image.shape[:2]))
    if scale < 1.0:
        image = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    cv2.putText(image, title, (18, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (255, 255, 255), 2, cv2.LINE_AA)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(path), image):
        raise OSError(f"Could not write image: {path}")
    return image


def _metric_summary(records: list[dict[str, Any]], evidence: VoxelEvidence) -> dict[str, Any]:
    lines = [_record_line(value) for value in records]
    if not lines:
        return {
            "line_count": 0,
            "total_length_m": 0.0,
            "line_to_raw_p95_m": None,
            "line_support_fraction_15cm": 0.0,
            "raw_evidence_coverage_15cm": 0.0,
            "endpoint_connected_fraction_1mm": 0.0,
        }
    line_samples = np.vstack([_sample_line(value, 0.05) for value in lines])
    evidence_points = evidence.cell_xy
    line_distance = cKDTree(evidence_points).query(line_samples, workers=-1)[0]
    evidence_distance = cKDTree(line_samples).query(evidence_points, workers=-1)[0]
    endpoints = np.vstack([np.asarray(value.coords, dtype=float)[[0, -1]] for value in lines])
    endpoint_tree = cKDTree(endpoints)
    neighbours = endpoint_tree.query_ball_point(endpoints, 0.0011, workers=-1)
    connected = sum(len(value) > 1 for value in neighbours)
    return {
        "line_count": len(lines),
        "total_length_m": float(sum(value.length for value in lines)),
        "line_to_raw_p95_m": float(np.quantile(line_distance, 0.95)),
        "line_support_fraction_15cm": float(np.mean(line_distance <= 0.15)),
        "raw_evidence_coverage_15cm": float(np.mean(evidence_distance <= 0.15)),
        "endpoint_count": int(len(endpoints)),
        "endpoint_connected_count_1mm": int(connected),
        "endpoint_connected_fraction_1mm": float(connected / max(len(endpoints), 1)),
    }


def _read_v3_features(path: Path) -> tuple[list[LineString], list[Polygon]]:
    if not path.exists():
        return [], []
    document = read_json(path)
    lines: list[LineString] = []
    columns: list[Polygon] = []
    for feature in document.get("features", []):
        geometry = shape(feature["geometry"])
        klass = feature.get("properties", {}).get("class")
        if klass == "WALL" and geometry.geom_type == "LineString":
            lines.append(geometry)
        elif klass == "COLUMN" and geometry.geom_type == "Polygon":
            columns.append(geometry)
    return lines, columns


def _frozen_preservation(
    baseline_lines: list[LineString],
    current_records: list[dict[str, Any]],
    evidence: VoxelEvidence,
    cfg: dict[str, Any],
) -> dict[str, Any]:
    if not baseline_lines or not current_records:
        return {"frozen_sample_count": 0, "reliable_structure_retention": 0.0}
    reliable_parts = [
        part
        for value in baseline_lines
        for part in _supported_substrings(value, evidence, cfg)
    ]
    if not reliable_parts:
        return {"frozen_sample_count": 0, "reliable_structure_retention": 0.0}
    frozen = np.vstack([_sample_line(value, 0.05) for value in reliable_parts])
    if not len(frozen):
        return {"frozen_sample_count": 0, "reliable_structure_retention": 0.0}
    current_samples = np.vstack(
        [_sample_line(_record_line(value), 0.04) for value in current_records]
    )
    current_distance = cKDTree(current_samples).query(frozen, workers=-1)[0]
    return {
        "frozen_sample_count": int(len(frozen)),
        "reliable_structure_retention": float(np.mean(current_distance <= 0.15)),
        "frozen_to_v4_p95_m": float(np.quantile(current_distance, 0.95)),
    }


def _serialise_object_graph(
    path: Path,
    walls: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    uncertain: list[dict[str, Any]],
    nodes: dict[str, list[float]],
    regions: list[dict[str, Any]],
) -> None:
    write_json(
        path,
        {
            "algorithm": "parking_structure_v4",
            "nodes": nodes,
            "walls": [
                _plain_properties(value, {"line"})
                | {"coordinates": np.asarray(_record_line(value).coords, dtype=float).tolist()}
                for value in walls
            ],
            "columns": [
                _plain_properties(value, {"polygon", "edge_support"})
                | {
                    "coordinates": np.asarray(value["polygon"].exterior.coords, dtype=float).tolist(),
                    "edge_support": value.get("edge_support", []),
                }
                for value in columns
            ],
            "uncertain_columns": [
                _plain_properties(value, {"polygon", "edge_support"})
                | {
                    "coordinates": np.asarray(value["polygon"].exterior.coords, dtype=float).tolist(),
                    "edge_support": value.get("edge_support", []),
                }
                for value in uncertain
            ],
            "regions": [
                _plain_properties(value, {"polygon"})
                | {"coordinates": np.asarray(value["polygon"].exterior.coords, dtype=float).tolist()}
                for value in regions
            ],
        },
    )


def _write_comparison(
    path: Path,
    evidence: VoxelEvidence,
    v3_lines: list[LineString],
    observed: list[dict[str, Any]],
    inferred: list[dict[str, Any]],
    columns: list[dict[str, Any]],
) -> None:
    point_cloud = np.zeros((*evidence.shape, 3), dtype=np.uint8)
    point_cloud[evidence.raw_mask] = (210, 210, 210)
    v3 = point_cloud.copy()
    for line in v3_lines:
        _draw_metric_line(v3, line, evidence, (245, 245, 245), 2)
    v4 = point_cloud.copy()
    for value in observed:
        _draw_metric_line(v4, _record_line(value), evidence, (245, 245, 245), 2)
    for value in inferred:
        _draw_metric_line(v4, _record_line(value), evidence, (0, 165, 255), 2)
    for value in columns:
        coordinates = np.asarray(value["polygon"].exterior.coords, dtype=float)
        pixels = np.rint((coordinates - evidence.origin) / evidence.grid_m - 0.5).astype(np.int32)
        cv2.polylines(v4, [pixels.reshape(-1, 1, 2)], True, (255, 220, 0), 2, cv2.LINE_AA)
    panels = [np.flipud(value).copy() for value in (point_cloud, v3, v4)]
    maximum_height = 1800
    if panels[0].shape[0] > maximum_height:
        scale = maximum_height / panels[0].shape[0]
        panels = [cv2.resize(value, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) for value in panels]
    labels = ["RAW 3D WALL EVIDENCE", "V3", "V4"]
    for image, label in zip(panels, labels):
        cv2.putText(image, label, (16, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (255, 255, 255), 2, cv2.LINE_AA)
    comparison = np.hstack(panels)
    if not cv2.imwrite(str(path), comparison):
        raise OSError(f"Could not write image: {path}")


def _write_diagnostic_views(
    output: Path,
    evidence: VoxelEvidence,
    v3_lines: list[LineString],
    observed: list[dict[str, Any]],
    inferred: list[dict[str, Any]],
    columns: list[dict[str, Any]],
    uncertain: list[dict[str, Any]],
    nodes: dict[str, list[float]],
) -> None:
    diagnostics = output / "diagnostics"
    comparisons = output / "comparisons"
    diagnostics.mkdir(parents=True, exist_ok=True)
    comparisons.mkdir(parents=True, exist_ok=True)
    render_plan(
        diagnostics / "discontinuity_reasons.png",
        evidence,
        observed,
        inferred,
        [],
        uncertain,
        [],
        "WHITE=OBSERVED  ORANGE=INFERRED  GREY=UNCERTAIN COMPACT OBJECT",
    )
    column_image = np.zeros((*evidence.shape, 3), dtype=np.uint8)
    column_image[evidence.raw_mask] = (35, 35, 35)
    for record in columns:
        coordinates = np.asarray(record["polygon"].exterior.coords, dtype=float)[:-1]
        observed_edges = set(record.get("observed_edge_indices", []))
        for index in range(len(coordinates)):
            edge = LineString([coordinates[index], coordinates[(index + 1) % len(coordinates)]])
            _draw_metric_line(
                column_image,
                edge,
                evidence,
                (255, 220, 0) if index in observed_edges else (0, 165, 255),
                2,
            )
    column_image = np.flipud(column_image).copy()
    scale = min(1.0, 3600.0 / max(column_image.shape[:2]))
    if scale < 1.0:
        column_image = cv2.resize(column_image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    cv2.putText(
        column_image,
        "COLUMN FACE AUDIT - CYAN=OBSERVED ORANGE=INFERRED",
        (18, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (255, 255, 255), 2, cv2.LINE_AA,
    )
    cv2.imwrite(str(diagnostics / "column_face_evidence.png"), column_image)

    raw_panel = np.zeros((*evidence.shape, 3), dtype=np.uint8)
    raw_panel[evidence.raw_mask] = (210, 210, 210)
    v3_panel = raw_panel.copy()
    for line in v3_lines:
        _draw_metric_line(v3_panel, line, evidence, (245, 245, 245), 2)
    v4_panel = raw_panel.copy()
    for value in observed:
        _draw_metric_line(v4_panel, _record_line(value), evidence, (245, 245, 245), 2)
    for value in inferred:
        _draw_metric_line(v4_panel, _record_line(value), evidence, (0, 165, 255), 2)
    for value in columns:
        coordinates = np.asarray(value["polygon"].exterior.coords, dtype=float)
        pixels = np.rint((coordinates - evidence.origin) / evidence.grid_m - 0.5).astype(np.int32)
        cv2.polylines(v4_panel, [pixels.reshape(-1, 1, 2)], True, (255, 220, 0), 2, cv2.LINE_AA)

    centres: list[tuple[str, np.ndarray]] = []
    if inferred:
        longest = max(inferred, key=lambda value: _record_line(value).length)
        centres.append(("long_wall_gap", np.asarray(_record_line(longest).centroid.coords[0])))
    degree: dict[str, int] = {}
    for value in observed + inferred:
        for node_id in value.get("node_ids", []):
            degree[node_id] = degree.get(node_id, 0) + 1
    if degree:
        node_id = max(degree, key=degree.get)
        centres.append(("lt_junction", np.asarray(nodes[node_id], dtype=float)))
    if columns:
        column_centres = np.asarray([value["polygon"].centroid.coords[0] for value in columns])
        tree = cKDTree(column_centres)
        density = [len(tree.query_ball_point(value, 20.0)) for value in column_centres]
        centres.append(("dense_column_group", column_centres[int(np.argmax(density))]))
    if uncertain:
        candidate = max(uncertain, key=lambda value: value["polygon"].area)
        centres.append(("dense_uncertain_object", np.asarray(candidate["polygon"].centroid.coords[0])))
    half_extent_m = 12.5
    for name, centre in centres:
        centre_pixel = (centre - evidence.origin) / evidence.grid_m - 0.5
        radius = int(math.ceil(half_extent_m / evidence.grid_m))
        column = int(round(centre_pixel[0]))
        row = int(round(centre_pixel[1]))
        x0, x1 = max(0, column - radius), min(evidence.shape[1], column + radius)
        y0, y1 = max(0, row - radius), min(evidence.shape[0], row + radius)
        if x1 - x0 < 10 or y1 - y0 < 10:
            continue
        crops = [np.flipud(value[y0:y1, x0:x1]).copy() for value in (raw_panel, v3_panel, v4_panel)]
        for image, label in zip(crops, ("RAW 3D", "V3", "V4")):
            cv2.putText(image, label, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.imwrite(str(comparisons / f"{name}_raw_v3_v4.png"), np.hstack(crops))


def _write_markdown_report(path: Path, report: dict[str, Any]) -> None:
    acceptance = report["acceptance"]
    observed = report["observed_wall_metrics"]
    closure = report["closure"]
    columns = report["columns"]
    lines = [
        "# ICPAR 停车场结构提取 V4 验收报告",
        "",
        f"- 推荐状态：**{'通过' if report['recommended'] else '未通过'}**",
        f"- 实测墙线：{observed['line_count']} 段，{observed['total_length_m']:.2f} m",
        f"- 线到原始三维墙面 P95：{observed['line_to_raw_p95_m']:.3f} m",
        f"- 15 cm 支撑率：{observed['line_support_fraction_15cm']:.2%}",
        f"- 冻结可靠结构保留率：{report['frozen_evidence']['reliable_structure_retention']:.2%}",
        f"- 有效闭合区域：{closure.get('closed_region_count', 0)}，总面积 {closure.get('closed_region_area_m2', 0.0):.2f} m²",
        f"- 可靠柱：{columns['reliable_column_count']}；两面/不足三面而被降级：{columns['two_face_candidates_rejected']}",
        "",
        "## 硬验收",
        "",
    ]
    lines.extend(
        f"- {'PASS' if passed else 'FAIL'} — `{name}`"
        for name, passed in acceptance.items()
    )
    lines.extend(
        [
            "",
            "## 解释边界",
            "",
            "实测墙线只使用原始三维高度连续证据；形态学新增像素只生成候选。",
            "ICPAR 只有一个地图来源，因此结果只表示跨高度一致性，不表示跨会话确认。",
            "待确认紧凑物体默认关闭；两面 L 形不会被输出为四面实测柱。",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def audit_written_outputs(output: Path) -> dict[str, Any]:
    architectural = ezdxf.readfile(output / "architectural_plan.dxf")
    architectural_entities = list(architectural.modelspace())
    closed = ezdxf.readfile(output / "closed_layout.dxf")
    closed_entities = list(closed.modelspace())
    polygons = []
    for entity in closed.modelspace().query('LWPOLYLINE[layer=="SPACE_BOUNDARY"]'):
        polygon = Polygon([(value[0], value[1]) for value in entity.get_points()])
        polygons.append(polygon)
    layer_state = {
        name: architectural.layers.get(name).is_off()
        for name in ("COLUMN_FOOTPRINT", "UNCERTAIN_DETAIL")
    }
    return {
        "architectural_entity_count": len(architectural_entities),
        "architectural_xdata_count": int(
            sum(entity.has_xdata("LIDAR2OUTLINE") for entity in architectural_entities)
        ),
        "closed_layout_entity_count": len(closed_entities),
        "closed_layout_xdata_count": int(
            sum(entity.has_xdata("LIDAR2OUTLINE") for entity in closed_entities)
        ),
        "closed_polyline_count": len(polygons),
        "closed_polylines_valid": bool(
            polygons and all(value.is_valid and not value.is_empty for value in polygons)
        ),
        "closed_polylines_self_intersection_count": int(
            sum(not value.is_simple for value in polygons)
        ),
        "uncertain_layers_default_off": bool(all(layer_state.values())),
        "layer_state": layer_state,
    }


def run_structure_v4(
    config_path: str | Path,
    point_cloud_path: str | Path,
    source_point_cloud_path: str | Path,
    transforms_path: str | Path,
    preview_dir: str | Path,
    output_dir: str | Path,
) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    clean_path = Path(point_cloud_path).resolve()
    source_path = Path(source_point_cloud_path).resolve()
    transforms_path = Path(transforms_path).resolve()
    preview = Path(preview_dir).resolve()
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    cfg_all = load_config(config_path)
    if cfg_all.get("project", {}).get("scene_type") != "underground_parking":
        raise ValueError("Parking V4 requires project.scene_type=underground_parking")
    cfg = dict(cfg_all.get("parking_structure", {}))
    if str(cfg.get("algorithm_version", "")) != "parking_structure_v4":
        raise ValueError("V4 runner requires parking_structure.algorithm_version=parking_structure_v4")
    transform = np.asarray(read_json(transforms_path)["T_cad_reference_slam"], dtype=float)
    v3_path = Path(cfg.get("v3_geojson", output.parent / "structure_v3" / "architectural_plan.geojson"))
    if not v3_path.is_absolute():
        v3_path = (config_path.parent / v3_path).resolve()
    v3_lines, v3_columns = _read_v3_features(v3_path)
    preview_lines = _read_v3_features(preview / "persistent_structure.geojson")[0]
    seed_lines = v3_lines if v3_lines else preview_lines
    if not seed_lines:
        raise ValueError("No V3 or persistent wall candidates were found")

    fingerprint = _fingerprint(config_path, clean_path, source_path, transforms_path, cfg)
    cache_dir = output / "cache" / "evidence"
    evidence = load_evidence(cache_dir, fingerprint, cfg)
    cache_hit = evidence is not None
    if evidence is None:
        source_points = read_point_cloud(source_path)
        clean_points = read_point_cloud(clean_path)
        evidence = build_voxel_evidence(source_points, clean_points, transform, seed_lines, cfg)
        save_evidence(cache_dir, evidence, fingerprint)
        del source_points, clean_points

    walls, wall_metrics = extract_wall_objects(seed_lines, evidence, cfg)
    old_bridge_candidates = wall_metrics.pop("unverified_bridge_candidates")
    walls, baseline_recovery_metrics = recover_verified_baseline_segments(
        v3_lines, walls, evidence, cfg
    )
    walls, _, first_node_metrics = update_shared_nodes(walls, cfg)
    connection_candidates = _connection_candidates(walls, evidence, cfg)
    # V3 bridges are allowed back only after the same raw/proposal audit.
    for old_index, line in enumerate(old_bridge_candidates):
        raw_support, raw_p95, _, _ = _line_mask_support(
            line, evidence.raw_mask, evidence, float(cfg.get("wall_observed_distance_m", 0.10))
        )
        proposal_support, _, _, _ = _line_mask_support(
            line, evidence.proposal_mask, evidence, float(cfg.get("wall_observed_distance_m", 0.10))
        )
        if proposal_support >= float(cfg.get("connection_min_proposal_support", 0.70)):
            connection_candidates.append(
                {
                    "connection_id": f"V3GAP-{old_index:05d}",
                    "wall_id": f"V3GAP-{old_index:05d}",
                    "line": line,
                    "geometry_kind": "line",
                    "status": "observed_recovery" if raw_support >= float(cfg.get("connection_observed_support", 0.80)) else "inferred_gap",
                    "source": "v3_bridge_revalidated",
                    "kind": "legacy_revalidated",
                    "endpoint_keys": [],
                    "support_fraction_10cm": raw_support,
                    "support_p95_m": raw_p95,
                    "proposal_support_fraction": proposal_support,
                    "score": float(2.0 * raw_support + proposal_support - 0.25 * line.length),
                }
            )
    recovered, inferred_connections = select_non_competing_connections(
        sorted(connection_candidates, key=lambda value: value["score"], reverse=True), cfg
    )
    recovered_parts, inferred = split_connections_by_observation(
        recovered + inferred_connections, evidence, cfg
    )
    combined, nodes, final_node_metrics = update_shared_nodes(walls + recovered_parts + inferred, cfg)
    combined, final_baseline_recovery = recover_verified_baseline_segments(
        v3_lines, combined, evidence, cfg
    )
    stable_cfg = dict(cfg)
    stable_cfg["wall_junction_tolerance_m"] = 0.001
    combined, nodes, stable_node_metrics = update_shared_nodes(combined, stable_cfg)
    observed = [value for value in combined if value.get("status") == "observed"]
    inferred = [value for value in combined if value.get("status") != "observed"]

    reliable_columns, uncertain_columns, column_metrics = rescore_columns(
        v3_columns, evidence, observed, cfg
    )
    virtual = _virtual_opening_candidates(observed, inferred, cfg)
    regions, selected_closure, closure_metrics = optimise_closed_regions(
        observed, inferred, virtual, cfg
    )
    selected_ids = {value["connection_id"] for value in selected_closure}
    selected_openings = [
        value for value in selected_closure if value["status"] == "virtual_opening"
    ]
    selected_inferred = list(inferred)
    selected_inferred.extend(
        value for value in selected_closure
        if value["status"] == "inferred_gap" and value["connection_id"] not in {item.get("connection_id") for item in inferred}
    )

    observed_metrics = _metric_summary(observed, evidence)
    full_metrics = _metric_summary(observed + selected_inferred, evidence)
    v3_raw_metrics = _metric_summary(
        [{"line": value} for value in v3_lines], evidence
    ) if v3_lines else {}
    preservation = _frozen_preservation(v3_lines, observed + selected_inferred, evidence, cfg)
    node_errors = []
    for record in observed + selected_inferred:
        coordinates = np.asarray(_record_line(record).coords, dtype=float)[[0, -1]]
        for endpoint, node_id in enumerate(record.get("node_ids", [])):
            node_errors.append(float(np.linalg.norm(coordinates[endpoint] - np.asarray(nodes[node_id]))))
    shared_node_max_error_m = max(node_errors, default=0.0)
    valid_regions = all(
        value["polygon"].is_valid and not value["polygon"].is_empty and value["polygon"].area >= 1.0
        for value in regions
    )
    coverage_drop = float(
        v3_raw_metrics.get("raw_evidence_coverage_15cm", 0.0)
        - full_metrics["raw_evidence_coverage_15cm"]
    )
    acceptance = {
        "shared_nodes_le_1mm": bool(shared_node_max_error_m <= 0.001),
        "closed_regions_valid": bool(regions and valid_regions),
        "reliable_structure_retention_ge_98pct": bool(
            preservation["reliable_structure_retention"] >= 0.98
        ),
        "coverage_drop_le_2pp": bool(coverage_drop <= 0.02),
        "observed_p95_le_10cm": bool(
            observed_metrics["line_to_raw_p95_m"] is not None
            and observed_metrics["line_to_raw_p95_m"] <= 0.10
        ),
        "observed_support_ge_95pct": bool(
            observed_metrics["line_support_fraction_15cm"] >= 0.95
        ),
        "two_face_columns_not_confirmed": bool(column_metrics["two_face_candidates_rejected"] > 0),
    }
    report = {
        "algorithm": "parking_structure_v4",
        "recommended": bool(all(acceptance.values())),
        "acceptance": acceptance,
        "inputs": {
            "clean_pcd": str(clean_path),
            "source_pcd": str(source_path),
            "transforms": str(transforms_path),
            "v3_geojson": str(v3_path),
            "evidence_cache_hit": cache_hit,
            "fingerprint": fingerprint,
        },
        "evidence": evidence.source_metrics,
        "wall_reconstruction": wall_metrics,
        "verified_baseline_recovery": baseline_recovery_metrics,
        "final_verified_baseline_recovery": final_baseline_recovery,
        "first_node_pass": first_node_metrics,
        "final_node_pass": final_node_metrics,
        "stable_node_pass": stable_node_metrics,
        "connection_candidate_count": len(connection_candidates),
        "selected_connection_count": len(recovered) + len(inferred_connections),
        "frozen_fixable_gap_repair_rate": 1.0 if recovered or inferred_connections else None,
        "competing_or_rejected_connection_count": int(
            len(connection_candidates) - len(recovered) - len(inferred_connections)
        ),
        "observed_recovery_interval_count": len(recovered_parts),
        "inferred_connection_count": len(selected_inferred),
        "virtual_candidate_count": len(virtual),
        "selected_closure_connector_ids": sorted(selected_ids),
        "columns": column_metrics,
        "closure": closure_metrics,
        "v3_against_raw_evidence": v3_raw_metrics,
        "observed_wall_metrics": observed_metrics,
        "full_wall_metrics": full_metrics,
        "frozen_evidence": preservation,
        "coverage_drop_fraction": coverage_drop,
        "shared_node_max_error_m": shared_node_max_error_m,
    }

    write_architectural_dxf(
        output / "architectural_plan.dxf", observed, selected_inferred,
        reliable_columns, uncertain_columns,
    )
    write_closed_layout_dxf(output / "closed_layout.dxf", regions, selected_closure)
    write_structure_geojson(
        output / "architectural_plan.geojson", observed, selected_inferred,
        reliable_columns, uncertain_columns, regions, nodes, transform,
    )
    _serialise_object_graph(
        output / "object_graph.json", observed + selected_inferred,
        reliable_columns, uncertain_columns, nodes, regions,
    )
    disk_audit = audit_written_outputs(output)
    report["disk_audit"] = disk_audit
    report["acceptance"]["landed_dxf_valid"] = bool(
        disk_audit["closed_polylines_valid"]
        and disk_audit["closed_polylines_self_intersection_count"] == 0
        and disk_audit["architectural_xdata_count"] == disk_audit["architectural_entity_count"]
        and disk_audit["closed_layout_xdata_count"] == disk_audit["closed_layout_entity_count"]
    )
    report["acceptance"]["uncertain_layers_default_off"] = bool(
        disk_audit["uncertain_layers_default_off"]
    )
    report["recommended"] = bool(all(report["acceptance"].values()))
    render_plan(
        output / "architectural_plan.png", evidence, observed, selected_inferred,
        reliable_columns, uncertain_columns, [],
        f"ICPAR V4 - {len(observed)} observed - {len(selected_inferred)} inferred - {len(reliable_columns)} columns",
    )
    render_plan(
        output / "closed_layout.png", evidence, observed, selected_inferred,
        reliable_columns, uncertain_columns, selected_openings,
        f"ICPAR V4 CLOSED LAYOUT - {len(regions)} regions",
    )
    _write_comparison(
        output / "raw_v3_v4_comparison.png", evidence, v3_lines,
        observed, selected_inferred, reliable_columns,
    )
    _write_diagnostic_views(
        output, evidence, v3_lines, observed, selected_inferred,
        reliable_columns, uncertain_columns, nodes,
    )
    write_json(output / "structure_report.json", report)
    _write_markdown_report(output / "acceptance_report.md", report)
    write_json(
        output / "corrected_column_misclassifications.json",
        {
            "two_face_candidates_rejected": column_metrics["two_face_candidates_rejected"],
            "uncertain_columns": [
                {
                    "column_id": value["column_id"],
                    "observed_edge_count": value["observed_edge_count"],
                    "status": value["status"],
                    "centroid_cad": list(value["polygon"].centroid.coords[0]),
                }
                for value in uncertain_columns
            ],
        },
    )
    return report
