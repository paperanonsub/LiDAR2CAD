from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import nearest_points, unary_union

from lidar2outline.io import read_json, write_json

from .structure_v4 import (
    audit_written_outputs,
    write_architectural_dxf,
    write_closed_layout_dxf,
    write_structure_geojson,
)
from .structure_v5 import _adapter, _independent_metrics, _render_v5_plan
from .v5_evidence import curve_observation_audit, load_exact_evidence


def _wall_records(document: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for value in document.get("walls", []):
        coordinates = value.get("coordinates", [])
        if len(coordinates) < 2:
            continue
        record = {key: item for key, item in value.items() if key != "coordinates"}
        record["line"] = LineString(coordinates)
        result.append(record)
    return result


def _column_records(document: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for value in document.get("columns", []):
        coordinates = value.get("coordinates", [])
        if len(coordinates) < 4:
            continue
        record = {
            key: item
            for key, item in value.items()
            if key not in {"coordinates", "center", "cross_height_consensus_center"}
        }
        record["center"] = np.asarray(value["center"], dtype=float)
        record["polygon"] = Polygon(coordinates)
        if value.get("cross_height_consensus_center") is not None:
            record["cross_height_consensus_center"] = np.asarray(
                value["cross_height_consensus_center"], dtype=float
            )
        result.append(record)
    return result


def _region_records(document: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for value in document.get("regions", []):
        coordinates = value.get("coordinates", [])
        if len(coordinates) < 4:
            continue
        record = {key: item for key, item in value.items() if key != "coordinates"}
        record["polygon"] = Polygon(coordinates)
        result.append(record)
    return result


def _geometry_digest(records: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for record in records:
        digest.update(np.asarray(record["line"].coords, dtype=np.float64).tobytes())
        digest.update(str(record.get("status")).encode("utf-8"))
    return digest.hexdigest()


def _landed_baseline_geometry_audit(
    baseline_document: dict[str, Any], landed_document: dict[str, Any]
) -> dict[str, int]:
    def wall_signature(value: dict[str, Any]) -> tuple[Any, Any]:
        return value.get("status"), value.get("coordinates")

    baseline_walls = {
        value["wall_id"]: wall_signature(value)
        for value in baseline_document.get("walls", [])
    }
    landed_walls = {
        value["wall_id"]: wall_signature(value)
        for value in landed_document.get("walls", [])
    }
    baseline_columns = {
        value["column_id"]: value.get("coordinates")
        for value in baseline_document.get("columns", [])
    }
    landed_columns = {
        value["column_id"]: value.get("coordinates")
        for value in landed_document.get("columns", [])
    }
    return {
        "baseline_wall_missing_count": sum(
            identifier not in landed_walls for identifier in baseline_walls
        ),
        "baseline_wall_geometry_changed_count": sum(
            landed_walls.get(identifier) != signature
            for identifier, signature in baseline_walls.items()
        ),
        "baseline_column_missing_count": sum(
            identifier not in landed_columns for identifier in baseline_columns
        ),
        "baseline_column_geometry_changed_count": sum(
            landed_columns.get(identifier) != coordinates
            for identifier, coordinates in baseline_columns.items()
        ),
    }


def _line_direction_rad(line: LineString) -> float:
    coordinates = np.asarray(line.coords, dtype=float)
    delta = coordinates[-1] - coordinates[0]
    return float(np.arctan2(delta[1], delta[0]) % np.pi)


def _parallel_angle_difference_rad(first: float, second: float) -> float:
    difference = abs(first - second) % np.pi
    return float(min(difference, np.pi - difference))


def _audited_new_observed_segments(
    baseline: list[dict[str, Any]],
    experiment: list[dict[str, Any]],
    exact: Any,
    *,
    duplicate_distance_m: float,
    minimum_length_m: float,
    minimum_support_fraction: float,
    maximum_p95_m: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    baseline_union = unary_union([value["line"] for value in baseline])
    covered = baseline_union.buffer(
        duplicate_distance_m, cap_style=2, join_style=2
    )
    tree = cKDTree(exact.centroids[:, :2])
    additions: list[dict[str, Any]] = []
    connectors: list[dict[str, Any]] = []
    rejected: dict[str, int] = {}

    def reject(reason: str) -> None:
        rejected[reason] = rejected.get(reason, 0) + 1

    # Prefer a complete experimental observation to a short fragment.  Once a
    # piece is accepted, later near-parallel geometry inside the same 10 cm
    # corridor is removed.  Perpendicular crossings are deliberately exempt:
    # they are topology, not duplicate wall observations.
    ordered_sources = sorted(
        (value for value in experiment if value.get("status") == "observed"),
        key=lambda value: value["line"].length,
        reverse=True,
    )
    accepted_directions: list[float] = []
    for source in ordered_sources:
        difference = source["line"].difference(covered)
        initial_pieces = list(getattr(difference, "geoms", [difference]))
        for initial_piece in initial_pieces:
            if (
                initial_piece.is_empty
                or initial_piece.geom_type != "LineString"
                or initial_piece.length < minimum_length_m
            ):
                reject("duplicate_or_too_short")
                continue
            direction = _line_direction_rad(initial_piece)
            parallel = [
                value["line"]
                for value, accepted_direction in zip(additions, accepted_directions)
                if _parallel_angle_difference_rad(direction, accepted_direction)
                <= np.deg2rad(5.0)
            ]
            residual = initial_piece
            if parallel:
                parallel_covered = unary_union(parallel).buffer(
                    duplicate_distance_m, cap_style=2, join_style=2
                )
                residual = initial_piece.difference(parallel_covered)
            pieces = list(getattr(residual, "geoms", [residual]))
            for piece in pieces:
                if piece.geom_type != "LineString" or piece.length < minimum_length_m:
                    reject("duplicate_or_too_short")
                    continue
                audit = curve_observation_audit(piece, exact, tree=tree)
                if (
                    audit["supported_fraction"] + 1e-9 < minimum_support_fraction
                    or audit["p95_m"] is None
                    or audit["p95_m"] > maximum_p95_m
                ):
                    reject("failed_independent_3d_support")
                    continue
                addition_id = f"CONSERVATIVE-OBS-{len(additions):04d}"
                additions.append(
                    {
                        "wall_id": addition_id,
                        "line": piece,
                        "geometry_kind": "polyline" if len(piece.coords) > 2 else "line",
                        "status": "observed",
                        "source": "projection_object_unique_segment_independently_revalidated",
                        "support_audit": audit,
                        "source_wall_id": source.get("wall_id"),
                    }
                )
                accepted_directions.append(_line_direction_rad(piece))
                # Difference-by-buffer deliberately ends just outside the frozen
                # backbone.  Add a separately labelled connector to the exact
                # nearest point; never move or split the baseline entity itself.
                coordinates = np.asarray(piece.coords, dtype=float)
                for endpoint_index, coordinate in ((0, coordinates[0]), (1, coordinates[-1])):
                    point = Point(float(coordinate[0]), float(coordinate[1]))
                    if point.distance(baseline_union) > duplicate_distance_m * 1.25:
                        continue
                    _, target = nearest_points(point, baseline_union)
                    connector = LineString([point.coords[0], target.coords[0]])
                    if connector.length <= 0.005:
                        continue
                    connectors.append(
                        {
                            "wall_id": f"CONSERVATIVE-SNAP-{len(connectors):04d}",
                            "line": connector,
                            "geometry_kind": "line",
                            "status": "inferred_gap",
                            "source": "conservative_snap_to_frozen_v5_backbone",
                            "observed": False,
                            "source_wall_id": addition_id,
                            "source_endpoint": endpoint_index,
                        }
                    )
    return additions, connectors, {
        "candidate_source": "experimental observed walls only",
        "accepted_observed_piece_count": len(additions),
        "accepted_observed_length_m": float(sum(value["line"].length for value in additions)),
        "snap_connector_count": len(connectors),
        "snap_connector_length_m": float(sum(value["line"].length for value in connectors)),
        "rejected_reasons": rejected,
        "duplicate_distance_m": duplicate_distance_m,
        "minimum_support_fraction": minimum_support_fraction,
        "maximum_p95_m": maximum_p95_m,
    }


def _conservative_columns(
    baseline: list[dict[str, Any]], experiment: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    experimental_by_id = {value["column_id"]: value for value in experiment}
    baseline_ids = {value["column_id"] for value in baseline}
    output = []
    metadata_upgrades = 0
    for original in baseline:
        record = dict(original)
        candidate = experimental_by_id.get(original["column_id"])
        if candidate is not None and candidate.get("height_window_observations"):
            for key in (
                "cross_height_consensus_center",
                "cross_height_center_spread_m",
                "cross_height_observation_count",
                "cross_height_rejected_observation_count",
                "cross_height_fusion",
                "height_window_observations",
            ):
                if key in candidate:
                    record[key] = candidate[key]
            metadata_upgrades += 1
        # Geometry is intentionally retained byte-for-byte from baseline.
        output.append(record)
    additions = []
    duplicate_rejections = 0
    baseline_polygons = [value["polygon"] for value in baseline]
    accepted_polygons = list(baseline_polygons)
    for candidate in experiment:
        if candidate["column_id"] in baseline_ids:
            continue
        observations = int(candidate.get("cross_height_observation_count", 0))
        spread = candidate.get("cross_height_center_spread_m")
        residual = candidate.get("robust_residual_p95_m")
        if (
            candidate.get("status") not in {"reliable", "template_completed"}
            or observations < 3
            or spread is None
            or float(spread) > 0.15
            or residual is None
            or float(residual) > 0.075
        ):
            continue
        polygon = candidate["polygon"]
        duplicate = False
        for existing in accepted_polygons:
            smaller = min(polygon.area, existing.area)
            overlap = polygon.intersection(existing).area / max(smaller, 1e-12)
            if polygon.distance(existing) <= 0.10 or overlap >= 0.10:
                duplicate = True
                break
        if duplicate:
            duplicate_rejections += 1
            continue
        record = dict(candidate)
        record["source"] = "new_cross_height_column_absent_from_frozen_v5"
        additions.append(record)
        accepted_polygons.append(polygon)
    output.extend(additions)
    return output, {
        "baseline_column_count": len(baseline),
        "baseline_geometry_retained_count": len(baseline),
        "cross_height_metadata_upgrade_count": metadata_upgrades,
        "new_reliable_column_count": len(additions),
        "new_column_duplicate_rejection_count": duplicate_rejections,
        "final_column_count": len(output),
    }


def run_conservative_fusion(
    baseline_graph_path: str | Path,
    experimental_graph_path: str | Path,
    evidence_path: str | Path,
    transforms_path: str | Path,
    output_dir: str | Path,
) -> dict[str, Any]:
    baseline_document = read_json(Path(baseline_graph_path))
    experiment_document = read_json(Path(experimental_graph_path))
    baseline_walls = _wall_records(baseline_document)
    experiment_walls = _wall_records(experiment_document)
    baseline_columns = _column_records(baseline_document)
    experiment_columns = _column_records(experiment_document)
    regions = _region_records(baseline_document)
    nodes = baseline_document.get("nodes", {})
    exact = load_exact_evidence(evidence_path)
    original_digest = _geometry_digest(baseline_walls)
    additions, snap_connectors, wall_metrics = _audited_new_observed_segments(
        baseline_walls,
        experiment_walls,
        exact,
        duplicate_distance_m=0.10,
        minimum_length_m=0.20,
        minimum_support_fraction=0.95,
        maximum_p95_m=0.10,
    )
    columns, column_metrics = _conservative_columns(
        baseline_columns, experiment_columns
    )
    baseline_observed = [
        value for value in baseline_walls if value.get("status") == "observed"
    ]
    baseline_inferred = [
        value for value in baseline_walls if value.get("status") != "observed"
    ]
    observed = [*baseline_observed, *additions]
    inferred = [*baseline_inferred, *snap_connectors]
    if _geometry_digest(baseline_walls) != original_digest:
        raise RuntimeError("frozen baseline geometry changed during fusion")

    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    transform = np.asarray(
        read_json(Path(transforms_path))["T_cad_reference_slam"], dtype=float
    )
    write_architectural_dxf(
        output / "architectural_plan.dxf", observed, inferred, columns, []
    )
    write_closed_layout_dxf(output / "closed_layout.dxf", regions, [])
    write_structure_geojson(
        output / "architectural_plan.geojson",
        observed,
        inferred,
        columns,
        [],
        regions,
        nodes,
        transform,
    )
    evidence = _adapter(exact, exact.raw_mask, exact.raw_mask, {})
    _render_v5_plan(
        output / "architectural_plan.png",
        evidence,
        observed,
        inferred,
        columns,
        [],
        "ICPAR V5+ CONSERVATIVE - FROZEN V5 BACKBONE + AUDITED LOCAL ADDITIONS",
    )
    _render_v5_plan(
        output / "closed_layout.png",
        evidence,
        observed,
        inferred,
        columns,
        [],
        f"ICPAR V5+ CLOSED LAYOUT - {len(regions)} FROZEN REGIONS",
    )
    graph_columns = []
    for record in columns:
        value = {
            key: item
            for key, item in record.items()
            if key not in {"polygon", "center", "cross_height_consensus_center"}
        }
        value["center"] = np.asarray(record["center"]).tolist()
        value["coordinates"] = np.asarray(record["polygon"].exterior.coords).tolist()
        if record.get("cross_height_consensus_center") is not None:
            value["cross_height_consensus_center"] = np.asarray(
                record["cross_height_consensus_center"]
            ).tolist()
        graph_columns.append(value)
    graph_document = {
            "algorithm": "parking_structure_v5_conservative_fusion",
            "baseline_geometry_policy": "immutable",
            "walls": [
                {
                    key: item
                    for key, item in record.items()
                    if key != "line"
                }
                | {"coordinates": np.asarray(record["line"].coords).tolist()}
                for record in observed + inferred
            ],
            "columns": graph_columns,
            "nodes": nodes,
            "regions": [
                {
                    key: item
                    for key, item in region.items()
                    if key != "polygon"
                }
                | {"coordinates": np.asarray(region["polygon"].exterior.coords).tolist()}
                for region in regions
            ],
        }
    graph_path = output / "building_object_graph.json"
    write_json(graph_path, graph_document)
    landed_geometry = _landed_baseline_geometry_audit(
        baseline_document, read_json(graph_path)
    )
    independent_additions = _independent_metrics(additions, exact)
    disk = audit_written_outputs(output)
    baseline_retained = bool(
        _geometry_digest(baseline_walls) == original_digest
        and not any(landed_geometry.values())
    )
    acceptance = {
        "baseline_wall_geometry_retained": baseline_retained,
        "new_observed_support_ge_95pct": bool(
            not additions
            or independent_additions["supported_fraction_10cm"] >= 0.95
        ),
        "new_observed_p95_le_10cm": bool(
            not additions
            or (
                independent_additions["line_to_surface_p95_m"] is not None
                and independent_additions["line_to_surface_p95_m"] <= 0.10
            )
        ),
        "baseline_closed_regions_retained": len(regions)
        == len(baseline_document.get("regions", [])),
        "landed_dxf_valid": bool(
            disk["architectural_xdata_count"]
            == disk["architectural_entity_count"]
            and disk["closed_polylines_self_intersection_count"] == 0
        ),
    }
    report = {
        "algorithm": "parking_structure_v5_conservative_fusion",
        "recommended": bool(all(acceptance.values())),
        "acceptance": acceptance,
        "baseline": {
            "graph": str(Path(baseline_graph_path).resolve()),
            "wall_count": len(baseline_walls),
            "wall_length_m": float(sum(value["line"].length for value in baseline_walls)),
            "closed_region_count": len(regions),
            "geometry_sha256": original_digest,
        },
        "experiment": {"graph": str(Path(experimental_graph_path).resolve())},
        "wall_additions": wall_metrics,
        "new_observed_metrics": independent_additions,
        "columns": column_metrics,
        "disk_audit": disk,
        "landed_baseline_geometry_audit": landed_geometry,
        "interpretation": (
            "The original V5 wall geometry is immutable. Experimental geometry "
            "may only add independently revalidated segments outside its 10 cm corridor."
        ),
    }
    write_json(output / "structure_report.json", report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Conservatively augment a frozen parking V5 plan")
    parser.add_argument("--baseline-graph", required=True)
    parser.add_argument("--experimental-graph", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--transforms", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    report = run_conservative_fusion(
        args.baseline_graph,
        args.experimental_graph,
        args.evidence,
        args.transforms,
        args.output,
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
