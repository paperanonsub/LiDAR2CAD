"""Point-cloud-only R309 reconstruction and staged evidence ablations.

Run: python -m parking_pipeline.reconstruction_r309 --config CONFIG.yaml
The evidence-cache input references unique aggregated voxel observations
produced from the registered cloud; no CAD or manual region input is consumed.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from time import perf_counter
from typing import Any

import numpy as np
from shapely.geometry import LineString, Point
from lidar2outline.config import load_config
from lidar2outline.io import read_point_cloud, write_json
from .evidence_association import (ObjectEvidenceIndex, annotate_dual_evidence,
    associate_height_fragments, enrich_connection_evidence, extract_height_fragments,
    reconstruction_windows)
from .v5_evidence import (HeightWindow, build_exact_voxel_evidence, load_exact_evidence, save_exact_evidence)
from .topology_v6 import (generate_connection_candidates, generate_supplemental_endpoint_candidates,
    generate_directional_trace_candidates,
    select_continuity_connections, topology_statistics, _records_to_document)
from .structure_v4 import update_shared_nodes, write_architectural_dxf, write_structure_geojson, _plain_properties
from .structure_v5 import _auto_column_candidates


def _digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def _column_evidence(columns, exact, windows):
    """Preserve actual side sources separately from a fitted/template footprint."""
    from scipy.spatial import cKDTree
    tree = cKDTree(exact.centroids[:, :2])
    for column in columns:
        polygon = column['polygon']
        center = np.asarray(column['center'])
        radius = max(np.linalg.norm(np.asarray(polygon.exterior.coords) - center, axis=1)) + .075
        rows = np.asarray(tree.query_ball_point(center, radius), int)
        rows = rows[[polygon.boundary.distance(Point(exact.centroids[r, :2])) <= .075 for r in rows]]
        column['source_voxel_rows'] = rows.tolist()
        column['provenance'] = {'kind': 'template_completion' if column['status'] == 'template_completed'
                                else 'cross_height_surface_fit'}
        column['window_evidence'] = {w.window_id: {'source_voxel_rows': rows[
            (exact.centroids[rows, 2] >= w.z_min_m) & (exact.centroids[rows, 2] < w.z_max_m)].tolist()}
                                    for w in windows}
        column['template_faces_are_measured'] = False
    return columns


def run_reconstruction(config_path: str | Path) -> dict[str, Any]:
    started = perf_counter()
    config_path = Path(config_path).resolve()
    config = load_config(config_path)
    cfg = dict(config['parking_structure'])
    # Revision experiments expose the four conceptual switches explicitly.
    # Keep the historical keys as aliases so old configurations remain
    # reproducible while A--F runs are self-describing in their manifests.
    if 'cross_height_association_enabled' in cfg:
        cfg['explicit_cross_height_association'] = bool(cfg['cross_height_association_enabled'])
    if 'host_identity_gate_enabled' in cfg:
        cfg['object_consistent_gate'] = bool(cfg['host_identity_gate_enabled'])
    if 'directional_search_enabled' in cfg:
        cfg['topology_directional_trace_enabled'] = bool(cfg['directional_search_enabled'])
    cfg.setdefault('cross_height_association_enabled', bool(cfg.get('explicit_cross_height_association', True)))
    cfg.setdefault('host_identity_gate_enabled', bool(cfg.get('object_consistent_gate', True)))
    cfg.setdefault('directional_search_enabled', bool(cfg.get('topology_directional_trace_enabled', False)))
    cfg.setdefault('short_gap_continuation_enabled', True)
    output = Path(config['project']['output_dir']).resolve()
    output.mkdir(parents=True, exist_ok=True)
    module_times: dict[str, float] = {}

    def progress(phase: str, **values: Any) -> None:
        write_json(output / 'run_progress.json', {
            'algorithm': 'LiDAR2CAD-R309', 'phase': phase,
            'elapsed_seconds': perf_counter() - started,
            'config': str(config_path), **values,
        })

    def resolve(value: str) -> Path:
        path = Path(value)
        return path if path.is_absolute() else (config_path.parent / path).resolve()

    phase_started = perf_counter()
    if cfg.get('input_cloud'):
        cloud_path = resolve(cfg['input_cloud'])
        points = read_point_cloud(cloud_path)
        exact = build_exact_voxel_evidence(points, floor_m=cfg.get('floor_m'), ceiling_m=cfg.get('ceiling_m'))
        cache_path = output / 'exact_voxels.npz'
        save_exact_evidence(cache_path, exact)
    else:
        cache_path = resolve(cfg['input_evidence_cache'])
        exact = load_exact_evidence(cache_path)
    if cfg.get('crop_bounds_xy') is not None:
        from dataclasses import replace
        xmin, ymin, xmax, ymax = [float(v) for v in cfg['crop_bounds_xy']]
        keep = ((exact.centroids[:, 0] >= xmin) & (exact.centroids[:, 0] <= xmax)
                & (exact.centroids[:, 1] >= ymin) & (exact.centroids[:, 1] <= ymax))
        # Preserve the parent row map explicitly when creating a local regression fixture.
        parent_rows = np.flatnonzero(keep)
        fields = ['xy_cell', 'z_bin', 'counts', 'centroids', 'first_point_index']
        exact = replace(exact, **{name: getattr(exact, name)[keep] for name in fields})
        if not len(exact.centroids):
            raise ValueError('crop contains no unique voxels')
        active_cells = np.unique(exact.xy_cell)
        for prefix in ['all', 'structural']:
            member = np.isin(getattr(exact, prefix + '_xy_cell'), active_cells)
            exact = replace(exact, **{prefix + suffix: getattr(exact, prefix + suffix)[member]
                for suffix in ['_xy_cell', '_z_min_bin', '_z_max_bin', '_bin_count']})
    else:
        parent_rows = np.arange(len(exact.centroids))
    windows = reconstruction_windows(exact)
    evidence_fingerprint = _digest(cache_path)
    row_fingerprint = hashlib.sha256(parent_rows.astype('<i8').tobytes()).hexdigest()
    wall_probability = None
    if cfg.get('semantic_probability_cache'):
        with np.load(resolve(cfg['semantic_probability_cache'])) as values:
            wall_probability = np.asarray(values['wall_probability'], np.float32)
            if wall_probability.shape != exact.shape:
                raise ValueError('semantic raster/evidence shape mismatch')
            cfg['_topology_wall_probability'] = wall_probability
            if 'agreement_probability' in values:
                cfg['_topology_semantic_agreement'] = np.asarray(values['agreement_probability'], np.float32)
    association_windows = (windows if cfg.get('explicit_cross_height_association', True) else
                           [HeightWindow('shared_xy', 'shared', exact.floor_m, exact.ceiling_m)])
    module_times['evidence_input'] = perf_counter() - phase_started
    progress('evidence_input_complete', unique_voxel_count=len(exact.centroids))

    phase_started = perf_counter()
    columns, uncertain, templates, column_report = ([], [], [], {'enabled': False})
    excluded = None
    if cfg.get('automatic_columns', True):
        # Detect compact column instances before wall extraction, so their own
        # sides cannot be mistaken for pre-existing walls in the conflict test.
        column_exact = exact
        if cfg.get('crop_bounds_xy') is not None:
            column_exact = build_exact_voxel_evidence(exact.centroids, floor_m=exact.floor_m, ceiling_m=exact.ceiling_m)
        columns, uncertain, templates, column_report = _auto_column_candidates(column_exact, [], cfg, height_window_values=windows)
        columns = _column_evidence(columns, exact, windows)
        uncertain = _column_evidence(uncertain, exact, windows)
        # Exclude only reliably identified footprints. Ambiguous candidates do
        # not erase observations from the wall search.
        if columns:
            from shapely import contains_xy
            excluded = np.zeros(exact.shape, bool)
            cells = np.unique(exact.xy_cell)
            rr, cc = np.divmod(cells, exact.shape[1])
            xy = exact.origin_xy + (np.c_[cc, rr] + .5) * exact.grid_m
            for column in columns:
                excluded.ravel()[cells[contains_xy(column['polygon'].buffer(.075), xy[:, 0], xy[:, 1])]] = True
    module_times['column_detection'] = perf_counter() - phase_started
    progress('column_detection_complete', column_count=len(columns),
             uncertain_column_count=len(uncertain))

    phase_started = perf_counter()
    fragments = extract_height_fragments(exact, association_windows, cfg, wall_probability=wall_probability, excluded_cells=excluded)
    progress('fragment_extraction_complete', fragment_count=len(fragments))
    walls, association_report = associate_height_fragments(
        fragments, cfg, source_xy=exact.centroids[:, :2]
    )
    # Joint refit on UNIQUE physical source centroids, never weighted by window count.
    for wall in walls:
        rows = np.asarray(wall['source_voxel_rows'], int)
        xy = exact.centroids[rows, :2]
        center = xy.mean(axis=0)
        _, _, vh = np.linalg.svd(xy - center, full_matrices=False)
        tangent = vh[0]
        along = (xy - center) @ tangent
        wall['line'] = LineString([center + along.min() * tangent, center + along.max() * tangent])
    index = ObjectEvidenceIndex(exact, walls)
    module_times['height_association'] = perf_counter() - phase_started
    progress('height_association_complete', fragment_count=len(fragments), wall_object_count=len(walls))

    phase_started = perf_counter()
    # A frozen candidate file permits V3 gates to be compared on exactly one pool.
    if cfg.get('frozen_candidate_file'):
        with resolve(cfg['frozen_candidate_file']).open(encoding='utf-8') as handle:
            frozen = json.load(handle)
        if (frozen['evidence_sha256'] != evidence_fingerprint
                or frozen.get('source_rows_sha256') != row_fingerprint
                or frozen['object_ids'] != sorted(w['wall_id'] for w in walls)):
            raise ValueError('frozen candidates belong to different evidence/objects')
        candidates = [{**c, 'line': LineString(c['coordinates'])} for c in frozen['candidates']]
        for c in candidates:
            c.pop('coordinates', None)
        source_counts = Counter(str(c.get('source', 'unknown')) for c in candidates)
        frozen_report = {
            'loaded_from_frozen_candidates': True,
            'frozen_candidate_file': str(resolve(cfg['frozen_candidate_file'])),
        }
        conventional_report = {
            **frozen_report,
            'candidate_count': int(source_counts.get('v6_directional_topology_candidate', 0)),
        }
        supplemental_report = {
            **frozen_report,
            'candidate_count': int(source_counts.get('v6_3d_recovered_gap', 0)),
        }
        direction_report = {
            **frozen_report,
            'enabled': bool(cfg['directional_search_enabled']),
            'candidate_count': int(source_counts.get('v7_direction_state_trace', 0)),
        }
    else:
        conventional, conventional_report = generate_connection_candidates(walls, columns, exact, cfg)
        supplemental, supplemental_report = generate_supplemental_endpoint_candidates(
            walls, columns, exact, cfg, conventional
        )
        directional_pool = conventional + supplemental
        directional, direction_report = (generate_directional_trace_candidates(walls, columns, exact, cfg, directional_pool)
                                         if cfg['directional_search_enabled'] else ([], {'enabled': False, 'reason': 'ablation_disabled'}))
        candidates = conventional + supplemental + directional
    frozen = {'evidence_sha256': evidence_fingerprint, 'source_rows_sha256': row_fingerprint,
              'object_ids': sorted(w['wall_id'] for w in walls),
              'candidates': _records_to_document(candidates)}
    write_json(output / 'frozen_candidates.json', frozen)
    module_times['candidate_generation'] = perf_counter() - phase_started
    progress('candidate_generation_complete', candidate_count=len(candidates))

    phase_started = perf_counter()
    candidates = enrich_connection_evidence(candidates, walls, index, cfg)
    candidates.sort(key=lambda c: c['score'], reverse=True)
    observed_c, inferred_c, selection_report = select_continuity_connections(candidates, cfg)
    module_times['evidence_and_selection'] = perf_counter() - phase_started
    progress('evidence_and_selection_complete', selected_connection_count=len(observed_c) + len(inferred_c))

    phase_started = perf_counter()
    # Closure cannot introduce unvetted physical edges. Spatial regions are optional
    # derivatives and intentionally omitted from this structural reconstruction.
    final, nodes, node_report = update_shared_nodes(
        walls + observed_c + inferred_c,
        {**cfg, 'wall_junction_tolerance_m': float(cfg.get('node_tolerance_m', .001))},
    )
    final = annotate_dual_evidence(final, index, windows)
    observed = [w for w in final if w['status'] == 'observed']
    inferred = [w for w in final if w['status'] != 'observed']
    module_times['topology_and_annotation'] = perf_counter() - phase_started

    phase_started = perf_counter()
    write_architectural_dxf(output / 'architectural_plan.dxf', observed, inferred, columns, uncertain)
    write_structure_geojson(output / 'architectural_plan.geojson', observed, inferred, columns, uncertain, [], nodes, np.eye(4))
    source_reference = {'cache_path': str(cache_path), 'cache_sha256': frozen['evidence_sha256'],
                        'source_row_space': ('local_filtered_cache' if cfg.get('crop_bounds_xy') is not None
                                             else 'parent_cache'),
                        'voxel_id': ('local reconstruction row resolved through local_to_parent_rows; '
                                     'parent xy_cell + z_bin identifies the physical voxel'),
                        'raw_point_index': 'cache.first_point_index is a representative raw point, not all raw points',
                        'local_to_parent_rows': parent_rows.tolist() if cfg.get('crop_bounds_xy') is not None else 'identity'}
    write_json(output / 'associated_wall_objects.json', {
        'evidence_reference': source_reference,
        'walls': _records_to_document(walls),
    })
    graph = {'algorithm': 'LiDAR2CAD-R309', 'evidence_reference': source_reference,
             'walls': _records_to_document(final), 'nodes': nodes,
             'columns': [_plain_properties(c, {'polygon'}) | {'coordinates': list(c['polygon'].exterior.coords)} for c in columns],
             'uncertain_columns': [_plain_properties(c, {'polygon'}) | {'coordinates': list(c['polygon'].exterior.coords)} for c in uncertain],
             'column_templates': templates}
    write_json(output / 'building_object_graph.json', graph)
    write_json(output / 'height_fragment_graph.json', {'fragments': [
        {'fragment_id': f.fragment_id, 'window_id': f.window_id, 'z_min_m': f.z_min_m, 'z_max_m': f.z_max_m,
         'coordinates': list(f.line.coords), 'source_voxel_rows': f.source_rows.tolist()} for f in fragments],
         'association': association_report})
    selected = {c['connection_id'] for c in observed_c + inferred_c}
    write_json(output / 'candidate_audit.json', {'candidates': _records_to_document(
        [{**c, 'selected': c['connection_id'] in selected} for c in candidates])})
    module_times['export_and_audit'] = perf_counter() - phase_started
    module_times['measured_total'] = sum(module_times.values())
    report = {'algorithm': 'LiDAR2CAD-R309', 'runtime_seconds': perf_counter() - started,
              'module_times_seconds': module_times,
              'stages': {'dual_evidence': True, 'explicit_association': bool(cfg.get('cross_height_association_enabled', True)),
                         'object_gate': bool(cfg.get('host_identity_gate_enabled', True)),
                         'directional_search': bool(cfg.get('directional_search_enabled', False)),
                         'short_gap_continuation': bool(cfg.get('short_gap_continuation_enabled', True))},
              'association': association_report, 'columns': column_report,
              'conventional': conventional_report, 'supplemental': supplemental_report,
              'directional': direction_report,
              'selection': selection_report, 'nodes': node_report,
              'topology': topology_statistics(final),
              'validation': {'kind': 'unlabelled_reconstruction_diagnostics', 'independent_accuracy_evaluated': False},
              'evidence_reference': source_reference}
    write_json(output / 'structure_report.json', report)
    progress('completed', runtime_seconds=report['runtime_seconds'])
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    args = parser.parse_args()
    report = run_reconstruction(args.config)
    # The full report on disk includes source-row mappings; keep the console useful.
    summary = {key: value for key, value in report.items() if key != 'evidence_reference'}
    summary['association'] = {key: value for key, value in report['association'].items()
                              if key != 'accepted_edges'}
    summary['association']['accepted_edge_count'] = len(report['association']['accepted_edges'])
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
