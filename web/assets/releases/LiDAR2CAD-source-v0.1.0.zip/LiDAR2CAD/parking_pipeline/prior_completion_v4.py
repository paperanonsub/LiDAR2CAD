"""Continue a joint scene with explicit, retractable design-prior completion.

This module never reads GT. Missing returns are not free-space evidence. Two
observed face anchors can support an *inferred* continuation without returns in
the gap. Unanchored design geometry remains an unverified template, not a wall
observation or an accepted CONNECT. The frozen upstream solution is a checkpoint,
not a claim that its fixed-point iteration converged.
"""
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path

import ezdxf
import numpy as np
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import substring, unary_union
from shapely.strtree import STRtree

from .joint_reconstruction_v3 import digest, file_hash, unit, write_csv, write_json

CONFIG = {
    "schema": "lidar2cad-prior-completion/v4", "gap_min_m": .30,
    "gap_max_m": 6., "anchor_min_length_m": .50, "anchor_min_voxels": 8,
    "anchor_min_vertical_coverage": .45, "same_face_offset_m": .06,
    "same_face_angle_deg": 3., "outward_cosine_min": .98,
    "design_corridor_m": .50, "design_coverage_min": .98,
    "opening_buffer_m": .20, "column_buffer_m": .04,
    "duplicate_distance_m": .04, "minimum_output_piece_m": .15,
    "ray_endpoint_margin_m": .10, "minimum_free_crossing_rays": 2,
    "maximum_completion_passes": 3,
    "unknown_visibility_policy": "two_observed_anchors_allow_explicit_hypothesis",
    "unanchored_design_policy": "unverified_template_only_no_connect",
    "inferred_geometry_seeds_new_candidates": False,
}
ACTIVE_KINDS = {"WALL_FACE_TRACE", "INFERRED_WALL_FACE", "PRIOR_INFERRED_WALL_FACE"}


def parts(geometry, minimum=0.):
    if geometry.is_empty:
        return []
    if geometry.geom_type == "LineString":
        return [geometry] if geometry.length >= minimum else []
    return [p for child in getattr(geometry, "geoms", []) for p in parts(child, minimum)]


class RegisteredRays:
    """Optional synchronized sensor-origin/return pairs in the scene frame.

    A path without corresponding registered returns is insufficient. Crossing
    rays must pass through the candidate at wall height; floor rays cannot veto
    walls. No rays are synthesized from aggregated map points or nearest poses.
    """
    def __init__(self, origins=None, returns=None, frame_verified=False, source=None):
        self.source = source
        self.available = origins is not None and returns is not None and frame_verified
        if origins is not None and not frame_verified:
            raise ValueError("Ray-to-map frame and timestamp association must be verified")
        self.origins = np.asarray(origins if origins is not None else [], float).reshape(-1, 3)
        self.returns = np.asarray(returns if returns is not None else [], float).reshape(-1, 3)
        if self.origins.shape != self.returns.shape:
            raise ValueError("One registered return is required for each sensor origin")
        if not np.isfinite(self.origins).all() or not np.isfinite(self.returns).all():
            raise ValueError("Nonfinite rays")
        self.lines = [LineString([a[:2], b[:2]]) for a, b in zip(self.origins, self.returns)]
        self.tree = STRtree(self.lines)

    def inspect(self, line, height_range, cfg):
        if not self.available:
            return {"status": "unknown_no_registered_rays", "free_crossing_ray_ids": [],
                    "absence_of_points_is_not_free_space": True}
        hits = []
        for ix in self.tree.query(line, predicate="intersects"):
            i = int(ix)
            intersection = line.intersection(self.lines[i])
            if intersection.geom_type != "Point":
                continue
            distance = self.lines[i].project(intersection)
            length = self.lines[i].length
            if distance <= cfg["ray_endpoint_margin_m"] or length-distance <= cfg["ray_endpoint_margin_m"]:
                continue
            z = self.origins[i, 2] + distance/length * (self.returns[i, 2]-self.origins[i, 2])
            if height_range[0] <= z <= height_range[1]:
                hits.append(i)
        return {"status": "free_space_conflict" if len(hits) >= cfg["minimum_free_crossing_rays"]
                else "unknown_no_sufficient_crossing_rays", "free_crossing_ray_ids": hits,
                "source": self.source, "height_range_m": list(height_range)}


def _anchor(obj, evidence, cfg):
    rows = obj["support_evidence"].get("source_voxel_rows", [])
    rows = np.asarray(rows, int)
    rows = rows[(rows >= 0) & (rows < len(evidence.points))]
    rows = rows[evidence.eligible[rows]]
    z = evidence.points[rows, 2]
    support = obj["support_evidence"]
    vertical = support.get("vertical_fraction", support.get("multiheight_coverage", 0.))
    good = (len(rows) >= cfg["anchor_min_voxels"] and vertical >= cfg["anchor_min_vertical_coverage"]
            and LineString(obj["current_geometry"]).length >= cfg["anchor_min_length_m"]
            and len(np.unique(np.floor(z/.1))) >= 2)
    return {"eligible": bool(good), "voxel_count": len(rows), "vertical_coverage": vertical,
            "source_voxel_rows": rows.tolist(), "z_range": [float(z.min()), float(z.max())] if len(z) else None}


def generate_candidates(scene, evidence, cfg):
    groups = defaultdict(set)
    observed = {k: o for k, o in scene["objects"].items() if o["kind"] == "WALL_FACE_TRACE"}
    anchor = {k: _anchor(o, evidence, cfg) for k, o in observed.items()}
    for oid, obj in observed.items():
        for did in obj["matched_design_entity_ids"]:
            design = scene["design_entities"].get(did)
            if design:
                groups[design["design_wall_id"]].add(oid)
    design_groups = defaultdict(list)
    for did, d in scene["design_entities"].items():
        design_groups[d["design_wall_id"]].append((did, LineString(d["original_geometry"])))
    found = {}
    for group, members in sorted(groups.items()):
        endpoints = [(oid, ep, observed[oid]["current_geometry"][[0, -1][ep]])
                     for oid in sorted(members) for ep in (0, 1)]
        tree = STRtree([Point(xy) for _, _, xy in endpoints])
        for i, (left, le, a) in enumerate(endpoints):
            for j in tree.query(Point(a).buffer(cfg["gap_max_m"])):
                j = int(j)
                if j <= i:
                    continue
                right, re, b = endpoints[j]
                if left == right:
                    continue
                gap = LineString([a, b])
                if not cfg["gap_min_m"] <= gap.length <= cfg["gap_max_m"]:
                    continue
                rid = "PCREL-" + digest([left, le, right, re])[:20]
                if rid in found:
                    continue
                c = {"predicted_relation_id": rid, "host_wall_ids": [left, right],
                     "endpoint_indices": [le, re], "coordinates": [list(a), list(b)],
                     "branches": ["design_anchored_missing_observation"],
                     "source_candidate_ids": [rid], "selected": False, "stages": [],
                     "design_wall_id": group, "anchor_evidence": [anchor[left], anchor[right]]}
                oa, ob = observed[left], observed[right]
                va, vb, vg = unit(oa["current_geometry"]), unit(ob["current_geometry"]), unit([a, b])
                n = np.array([-va[1], va[0]])
                offset = float(max(np.abs((np.asarray(ob["current_geometry"])-np.asarray(a)) @ n)))
                originals = [np.asarray(o["original_lidar_geometry"]) for o in (oa, ob)]
                raw_v = unit(originals[0]); raw_n = np.array([-raw_v[1], raw_v[0]])
                raw_offset = float(max(np.abs((originals[1]-originals[0][0]) @ raw_n)))
                checks = [
                    ("observed_hosts", anchor[left]["eligible"] and anchor[right]["eligible"], "insufficient_anchor_evidence"),
                    ("same_face", abs(va@vb) >= np.cos(np.deg2rad(cfg["same_face_angle_deg"]))
                     and max(offset, raw_offset) <= cfg["same_face_offset_m"], "different_wall_faces"),
                    ("outward_endpoints", float((va if le else -va)@vg) >= cfg["outward_cosine_min"]
                     and float((vb if re else -vb)@(-vg)) >= cfg["outward_cosine_min"], "non_outward_endpoints"),
                ]
                for stage, ok, reason in checks:
                    c["stages"].append({"stage": stage, "accepted": bool(ok), "reason": "passed" if ok else reason})
                c["face_offset_m"] = offset
                # Equivalent short-circuit: an anchor/face/outward failure can
                # never be rescued by design coverage. Avoid hundreds of design
                # buffers per already-rejected pair in large architectural groups.
                if not all(s["accepted"] for s in c["stages"]):
                    c["decision"] = next(s["reason"] for s in c["stages"] if not s["accepted"])
                    c["design_entity_ids"] = []
                    c["design_coverage"] = None
                    found[rid] = c
                    continue
                compatible = [(did, line) for did, line in design_groups[group]
                              if abs(unit(line.coords)@vg) >= np.cos(np.deg2rad(cfg["same_face_angle_deg"]))]
                corridor = unary_union([line.buffer(cfg["design_corridor_m"]) for _, line in compatible])
                coverage = gap.intersection(corridor).length / gap.length
                c["design_entity_ids"] = [did for did, line in compatible if line.distance(gap) <= cfg["design_corridor_m"]]
                c["design_coverage"] = coverage
                c["stages"].append({"stage": "continuous_design_prior", "accepted": coverage >= cfg["design_coverage_min"],
                                    "reason": "passed" if coverage >= cfg["design_coverage_min"] else "discontinuous_design"})
                c["selected"] = all(s["accepted"] for s in c["stages"])
                c["decision"] = "eligible" if c["selected"] else next(s["reason"] for s in c["stages"] if not s["accepted"])
                found[rid] = c
    return sorted(found.values(), key=lambda c: (LineString(c["coordinates"]).length, c["predicted_relation_id"]))


def _object(oid, kind, coords, source_ids, design_ids, evidence, provenance):
    return {"object_id": oid, "kind": kind, "current_geometry": coords,
            "original_lidar_geometry": None, "wall_instance_id": None, "wall_face_id": None,
            "source_lidar_object_ids": source_ids, "matched_design_entity_ids": design_ids,
            "design_reference_geometry": [], "support_evidence": evidence,
            "geometry_provenance": [provenance], "topology_relations": [],
            "review_or_conflict_status": "conditional_design_anchored_inference" if kind == "PRIOR_INFERRED_WALL_FACE"
            else "design_template_unverified_visibility_unknown"}


def complete_scene(scene, evidence, rays=None, cfg=None, progress=print):
    """Deterministic continuation on one state; repeated invocation is idempotent."""
    cfg = cfg or CONFIG
    rays = rays or RegisteredRays()
    # Remove only this module's previous output before recomputing from anchors.
    old_ids = {r["predicted_relation_id"] for r in scene["relations"] if r.get("completion_stage") == "prior_completion_v4"}
    scene["relations"] = [r for r in scene["relations"] if r["predicted_relation_id"] not in old_ids]
    scene["objects"] = {k: o for k, o in scene["objects"].items() if o["kind"] not in {"PRIOR_INFERRED_WALL_FACE", "DESIGN_PRIOR_UNVERIFIED"}}
    for obj in scene["objects"].values():
        obj["topology_relations"] = [r for r in obj["topology_relations"] if r not in old_ids]
    scene["geometry_changes"] = [c for c in scene["geometry_changes"] if c.get("stage") != "prior_completion_v4"]
    scene["config"]["prior_completion"] = deepcopy(cfg)
    scene.setdefault("upstream_termination", scene.get("termination", "unknown"))
    openings = [LineString(o["coordinates"]).buffer(cfg["opening_buffer_m"]) for o in scene["design_openings"]]
    columns = [Polygon(o["current_geometry"]).buffer(cfg["column_buffer_m"]) for o in scene["objects"].values() if o["kind"] == "COLUMN_FOOTPRINT"]
    blockers = openings + columns
    blocker_tree = STRtree(blockers)
    used = {(h, ep) for r in scene["relations"] for h, ep in zip(r["host_wall_ids"], r["endpoint_indices"])}
    active = [LineString(o["current_geometry"]) for o in scene["objects"].values() if o["kind"] in ACTIVE_KINDS]
    tree = STRtree(active)
    additions = []
    candidates = generate_candidates(scene, evidence, cfg)
    progress(f"Prior completion: {len(candidates)} design-anchored candidates", flush=True)
    for c in candidates:
        if not c["selected"]:
            continue
        line = LineString(c["coordinates"])
        reason = None
        near_blockers = list(map(int, blocker_tree.query(line, predicate="intersects")))
        if near_blockers:
            reason = "design_opening_conflict" if any(i < len(openings) for i in near_blockers) else "column_conflict"
        height = [max(a["z_range"][0] for a in c["anchor_evidence"]), min(a["z_range"][1] for a in c["anchor_evidence"])]
        visibility = rays.inspect(line, height, cfg)
        if visibility["status"] == "free_space_conflict":
            reason = "measured_free_space_conflict"
        c["visibility_evidence"] = visibility
        c["field_evidence"] = evidence.sample(c["coordinates"])
        endpoints = list(zip(c["host_wall_ids"], c["endpoint_indices"]))
        if any(e in used for e in endpoints):
            reason = reason or "competing_endpoint"
        interior = substring(line, min(.1, line.length/4), line.length-min(.1, line.length/4))
        nearby = [active[int(i)] for i in tree.query(line.buffer(cfg["duplicate_distance_m"]))] + additions
        uncovered = line
        for other in nearby:
            parallel = abs(unit(other.coords)@unit(line.coords)) >= np.cos(np.deg2rad(cfg["same_face_angle_deg"]))
            if parallel:
                uncovered = uncovered.difference(other.buffer(cfg["duplicate_distance_m"], cap_style=2))
            elif other.intersects(interior):
                reason = reason or "crosses_observed_structure"
        output_parts = parts(uncovered, cfg["minimum_output_piece_m"])
        if not output_parts:
            reason = reason or "already_covered_geometry"
        c["stages"].append({"stage": "evidence_conflict_and_competition", "accepted": reason is None,
                            "reason": reason or "two_anchor_design_hypothesis"})
        c["selected"] = reason is None
        c["decision"] = reason or "accepted_conditional_design_inference"
        if reason:
            continue
        rid = c["predicted_relation_id"]
        geometry_ids = []
        for i, piece in enumerate(output_parts):
            oid = f"PCGAP-{rid}-{i}"
            xy = list(map(list, piece.coords))
            obj = _object(oid, "PRIOR_INFERRED_WALL_FACE", xy, c["host_wall_ids"], c["design_entity_ids"],
                          {"gap_observations": c["field_evidence"], "anchors": c["anchor_evidence"], "visibility": visibility},
                          {"kind": "two_anchor_design_prior_inference", "predicted_relation_id": rid,
                           "not_directly_observed": True, "design_wall_id": c["design_wall_id"]})
            obj["topology_relations"] = [rid]
            obj["design_reference_geometry"] = [scene["design_entities"][did]["original_geometry"] for did in c["design_entity_ids"]]
            scene["objects"][oid] = obj
            geometry_ids.append(oid)
            additions.append(piece)
            scene["geometry_changes"].append({"stage": "prior_completion_v4", "action": "design_anchored_gap_inferred",
                "object_id": oid, "before": None, "after": xy, "length_m": piece.length, "predicted_relation_id": rid})
        relation = {"predicted_relation_id": rid, "predicted_relation_type": "CONNECT",
                    "relation_semantics": "same_face_continuation_hypothesis", "completion_stage": "prior_completion_v4",
                    "verification_status": "conditional_not_site_verified", "identity_merge_committed": False,
                    "host_wall_ids": c["host_wall_ids"], "endpoint_indices": c["endpoint_indices"],
                    "endpoint_coordinates": c["coordinates"], "connection_geometry": c["coordinates"],
                    "host_wall_geometries": [scene["objects"][h]["current_geometry"] for h in c["host_wall_ids"]],
                    "geometry_object_ids": geometry_ids, "logical_only": False, "branches": c["branches"],
                    "source_lidar_object_ids": c["host_wall_ids"], "evidence": c["field_evidence"],
                    "visibility_evidence": visibility, "selected": True}
        scene["relations"].append(relation)
        for h in c["host_wall_ids"]:
            scene["objects"][h]["topology_relations"].append(rid)
        used.update(endpoints)
    # Corrected design tracks cover only their own physical face. No two-sided
    # wall merging; unvalidated references do not acquire an observed face ID.
    active += additions
    tree = STRtree(active)
    template_audit, templates = [], []
    for did, d in sorted(scene["design_entities"].items()):
        tracks = d.get("validated_faces") or [{"face_id": did, "coordinates": d["original_geometry"], "source_lidar_object_ids": []}]
        for track in tracks:
            original = LineString(track["coordinates"])
            line = original
            for ix in blocker_tree.query(line, predicate="intersects"):
                line = line.difference(blockers[int(ix)])
            for ix in tree.query(line.buffer(cfg["duplicate_distance_m"])):
                other = active[int(ix)]
                if abs(unit(other.coords)@unit(original.coords)) >= np.cos(np.deg2rad(cfg["same_face_angle_deg"])):
                    line = line.difference(other.buffer(cfg["duplicate_distance_m"], cap_style=2))
            out_ids = []
            for i, piece in enumerate(parts(line, cfg["minimum_output_piece_m"])):
                visibility = rays.inspect(piece, (.5, 2.), cfg)
                if visibility["status"] == "free_space_conflict":
                    template_audit.append({"design_entity_id": did, "decision": "measured_free_space_conflict", "coordinates": list(piece.coords)})
                    continue
                oid = "DPRIOR-" + digest([did, track["face_id"], i, list(piece.coords)])[:20]
                obj = _object(oid, "DESIGN_PRIOR_UNVERIFIED", list(map(list, piece.coords)),
                              track.get("source_lidar_object_ids", []), [did], {"visibility": visibility},
                              {"kind": "unverified_design_retention", "design_entity_id": did,
                               "design_face_track_id": track["face_id"], "original_design_geometry": d["original_geometry"],
                               "locally_corrected_by_lidar": bool(d.get("validated_faces"))})
                obj["design_reference_geometry"] = [d["original_geometry"]]
                scene["objects"][oid] = obj
                templates.append(piece); out_ids.append(oid)
            template_audit.append({"design_entity_id": did, "track_id": track["face_id"],
                                   "decision": "retained_unverified" if out_ids else "covered_or_blocked",
                                   "output_object_ids": out_ids})
    scene["relations"].sort(key=lambda r: r["predicted_relation_id"])
    scene["prior_completion_audit"] = {"candidates": candidates, "design_retention": template_audit}
    scene["prior_completion_summary"] = {
        "generated": len(candidates), "accepted": sum(c["selected"] for c in candidates),
        "rejected": sum(not c["selected"] for c in candidates),
        "rejection_reasons": dict(Counter(c["decision"] for c in candidates if not c["selected"])),
        "new_inferred_objects": len(additions), "new_inferred_length_m": sum(l.length for l in additions),
        "unverified_design_objects": len(templates), "unverified_design_length_m": sum(l.length for l in templates),
        "registered_rays_available": rays.available, "GT_used": False,
        "upstream_termination": scene["upstream_termination"],
        "unverified_design_is_not_evaluated_as_observed_wall": True,
        "unverified_design_can_still_conflict_with_site_openings": not rays.available,
    }
    return scene


def completion_signature(scene):
    return digest({"objects": {k: [o["current_geometry"], o["kind"], o["topology_relations"]] for k, o in scene["objects"].items()},
                   "relations": scene["relations"]})


def validate_scene(scene):
    objects = scene["objects"]
    relation_ids = {r["predicted_relation_id"] for r in scene["relations"]}
    assert len(relation_ids) == len(scene["relations"])
    for obj in objects.values():
        assert set(obj["topology_relations"]) <= relation_ids
        assert np.isfinite(obj["current_geometry"]).all()
        if obj["kind"] == "DESIGN_PRIOR_UNVERIFIED":
            assert not obj["topology_relations"] and obj["original_lidar_geometry"] is None
    for r in scene["relations"]:
        for h, ep, xy in zip(r["host_wall_ids"], r["endpoint_indices"], r["endpoint_coordinates"]):
            assert np.allclose(objects[h]["current_geometry"][[0, -1][ep]], xy)
        for oid in r["host_wall_ids"] + r["geometry_object_ids"]:
            assert r["predicted_relation_id"] in objects[oid]["topology_relations"]
        assert np.allclose(np.asarray(r["connection_geometry"])[[0, -1]], r["endpoint_coordinates"])
    return {"valid": True, "dangling_references": 0, "objects": len(objects), "relations": len(relation_ids)}


def export_scene(scene, output, run_id, inputs, parent_audit=None):
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    for key in ("scene_state_sha256", "scene_hash_definition", "config_sha256", "run_id", "input_hashes"):
        scene.pop(key, None)
    audit = scene.pop("prior_completion_audit")
    scene.update(run_id=run_id, config_sha256=digest(scene["config"]), input_hashes=inputs)
    state_hash = digest(scene)
    scene["scene_state_sha256"] = state_hash
    scene["scene_hash_definition"] = "canonical JSON excluding scene_state_sha256 and scene_hash_definition"
    metadata = {k: scene[k] for k in ("run_id", "scene_state_sha256", "config_sha256")}
    doc = ezdxf.new("R2013"); doc.header["$INSUNITS"] = 6
    doc.appids.add("LIDAR2CAD_JOINT")
    layers = {"WALL_FACE_TRACE": ("JOINT_WALL_OBSERVED", 7), "INFERRED_WALL_FACE": ("JOINT_WALL_INFERRED", 30),
              "PRIOR_INFERRED_WALL_FACE": ("PRIOR_WALL_INFERRED", 2), "DESIGN_PRIOR_UNVERIFIED": ("DESIGN_PRIOR_UNVERIFIED", 8),
              "COLUMN_FOOTPRINT": ("JOINT_COLUMN_OBSERVED", 3), "LEGACY_INFERRED_REFERENCE": ("LIDAR_INFERENCE_REFERENCE_ONLY", 8)}
    doc.linetypes.add("PRIOR_DASH", pattern=[.4, .25, -.15])
    for kind, (name, color) in layers.items():
        layer = doc.layers.add(name, color=color)
        if kind in {"PRIOR_INFERRED_WALL_FACE", "DESIGN_PRIOR_UNVERIFIED"}:
            layer.dxf.linetype = "PRIOR_DASH"
        if kind == "LEGACY_INFERRED_REFERENCE":
            layer.off()
    model = doc.modelspace(); entity_map = {}
    for oid, obj in sorted(scene["objects"].items()):
        ent = model.add_lwpolyline(obj["current_geometry"], dxfattribs={"layer": layers[obj["kind"]][0]})
        tags = [oid, obj["wall_instance_id"] or "", obj["wall_face_id"] or "", run_id, state_hash,
                metadata["config_sha256"], obj["kind"], *obj["topology_relations"]]
        ent.set_xdata("LIDAR2CAD_JOINT", [(1000, s) for s in tags]); entity_map[oid] = ent.dxf.handle
    doc.rootdict.add_xrecord("LIDAR2CAD_JOINT_RUN").extend([(1, __import__("json").dumps(metadata, sort_keys=True))])
    doc.saveas(output / "joint_final_geometry.dxf")
    topology = {**metadata, "schema": "lidar2cad-joint-topology/v4", "coordinate_frame": scene["coordinate_frame"],
                "entity_map": entity_map, "relations": deepcopy(scene["relations"])}
    for r in topology["relations"]:
        r["dxf_host_handles"] = [entity_map[h] for h in r["host_wall_ids"]]
        r["dxf_geometry_handles"] = [entity_map[g] for g in r["geometry_object_ids"]]
    write_json(output / "joint_final_topology.json", topology)
    write_json(output / "joint_scene_state.json", scene)
    write_json(output / "prior_completion_audit.json", {**metadata, **audit})
    if parent_audit is not None:
        parent_audit["candidates"].extend(audit["candidates"])
        parent_audit.update(metadata)
        write_json(output / "joint_candidate_audit.json", parent_audit)
    write_csv(output / "joint_geometry_changes.csv", scene["geometry_changes"],
              ["stage", "iteration", "object_id", "action", "before", "after", "length_m", "predicted_relation_id"])
    write_json(output / "prior_completion_summary.json", scene["prior_completion_summary"])
    manifest = {**metadata, "schema": "lidar2cad-joint-run/v4", "inputs": inputs, "checks": validate_scene(scene),
                "execution": "incremental prior-completion stage from frozen unified upstream checkpoint",
                "upstream_termination": scene["upstream_termination"], "completion_termination": scene.get("completion_termination"),
                "artifacts": {}}
    for name in ["joint_final_geometry.dxf", "joint_final_topology.json", "joint_scene_state.json", "prior_completion_audit.json"]:
        manifest["artifacts"][name] = {"sha256": file_hash(output/name), **metadata}
    write_json(output / "joint_run_manifest.json", manifest)
    return manifest
