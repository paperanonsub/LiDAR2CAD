"""Underground-parking LiDAR-to-CAD product profile."""

from .cli import main

__all__ = ["main"]
