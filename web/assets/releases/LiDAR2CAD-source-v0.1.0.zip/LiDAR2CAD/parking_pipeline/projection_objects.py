from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import cv2
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString

from lidar2outline.io import write_json
from lidar2outline.semantic_objects import _skeleton_paths, fit_curve_primitive

from .v5_evidence import ExactVoxelEvidence, HeightWindow


@dataclass(frozen=True)
class ProjectionClassification:
    """Sparse semantic classification for one physical height window.

    Arrays contain XY cell ids only.  Keeping them sparse avoids retaining a
    120 MB float image for every overlapping height window.  ``wall_cells``
    are observations in this window; pixels added by directional propagation
    are deliberately not stored here and can therefore never become measured
    support in a per-height DXF.
    """

    window_id: str
    scale: str
    z_min_m: float
    z_max_m: float
    occupied_cells: np.ndarray
    wall_cells: np.ndarray
    column_cells: np.ndarray
    vehicle_cells: np.ndarray
    wall_score_u8: np.ndarray


def write_projection_semantic_products(
    output_dir: str | Path,
    evidence: ExactVoxelEvidence,
    projections: list[ProjectionClassification],
) -> dict[str, Any]:
    """Write an inspectable semantic map for every thin/thick projection."""

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    products = []
    for item in projections:
        image = np.zeros((*evidence.shape, 3), np.uint8)
        flat = image.reshape(-1, 3)
        flat[item.occupied_cells] = (24, 24, 24)
        # BGR: vehicle red, wall white, column cyan.  Column is rendered last
        # so a reviewed compact instance remains visible at a wall junction.
        flat[item.vehicle_cells] = (48, 72, 230)
        flat[item.wall_cells] = (235, 235, 235)
        flat[item.column_cells] = (230, 210, 20)
        image = np.flipud(image)
        scale = min(1.0, 3600.0 / max(image.shape[:2]))
        if scale < 1.0:
            image = cv2.resize(
                image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA
            )
        cv2.putText(
            image,
            f"{item.window_id}  wall=white  column=cyan  vehicle=red",
            (16, 32),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        path = output / f"{item.window_id}.png"
        cv2.imwrite(str(path), image)
        products.append(
            {
                "window_id": item.window_id,
                "scale": item.scale,
                "z_min_m": item.z_min_m,
                "z_max_m": item.z_max_m,
                "path": str(path),
                "wall_cell_count": int(len(item.wall_cells)),
                "column_cell_count": int(len(item.column_cells)),
                "vehicle_cell_count": int(len(item.vehicle_cells)),
            }
        )
    manifest = {
        "coordinate_orientation": "CAD x right, CAD y up",
        "legend": {"wall": "white", "column": "cyan", "vehicle": "red"},
        "products": products,
    }
    write_json(output / "manifest.json", manifest)
    return manifest


def _window_rows(evidence: ExactVoxelEvidence, window: HeightWindow) -> np.ndarray:
    lower = int(
        math.floor((window.z_min_m - evidence.floor_m) / evidence.z_bin_m + 1e-9)
    )
    upper = int(
        math.ceil((window.z_max_m - evidence.floor_m) / evidence.z_bin_m - 1e-9)
    )
    return np.flatnonzero((evidence.z_bin >= lower) & (evidence.z_bin < upper))


def _aggregate_max(
    cells: np.ndarray, values: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    unique, inverse, counts = np.unique(cells, return_inverse=True, return_counts=True)
    maxima = np.zeros((len(unique), values.shape[1]), np.float32)
    for channel in range(values.shape[1]):
        np.maximum.at(maxima[:, channel], inverse, values[:, channel])
    return unique.astype(np.int64), maxima, counts.astype(np.int16)


def classify_height_projections(
    evidence: ExactVoxelEvidence,
    windows: Iterable[HeightWindow],
    voxel_probability: np.ndarray,
    voxel_agreement: np.ndarray,
    cfg: dict[str, Any],
    *,
    wall_supervision: np.ndarray | None = None,
    column_supervision: np.ndarray | None = None,
) -> tuple[list[ProjectionClassification], dict[str, Any]]:
    """Classify wall/column/vehicle evidence independently in every projection.

    A height window only sees voxels that physically belong to it.  The same
    voxel may be displayed in overlapping windows, but is represented by one
    row in ``ExactVoxelEvidence`` and is not counted as another observation.
    """

    probability = np.asarray(voxel_probability, dtype=np.float32)
    agreement = np.asarray(voxel_agreement, dtype=bool)
    if probability.shape != (len(evidence.xy_cell), 3):
        raise ValueError("voxel semantic probability/evidence row mismatch")
    if agreement.shape != (len(evidence.xy_cell),):
        raise ValueError("voxel semantic agreement/evidence row mismatch")
    wall_review = (
        np.zeros(len(evidence.xy_cell), dtype=bool)
        if wall_supervision is None
        else np.asarray(wall_supervision, dtype=bool)
    )
    column_review = (
        np.zeros(len(evidence.xy_cell), dtype=bool)
        if column_supervision is None
        else np.asarray(column_supervision, dtype=bool)
    )
    if wall_review.shape != agreement.shape or column_review.shape != agreement.shape:
        raise ValueError("semantic supervision/evidence row mismatch")

    confidence = float(cfg.get("projection_semantic_confidence", 0.80))
    low_confidence = float(cfg.get("projection_semantic_low_confidence", 0.48))
    minimum_bins = int(cfg.get("projection_minimum_height_bins", 2))
    margin = float(cfg.get("projection_class_margin", 0.04))
    records: list[ProjectionClassification] = []
    summary: list[dict[str, Any]] = []
    for window in windows:
        rows = _window_rows(evidence, window)
        if not len(rows):
            continue
        values = probability[rows].copy()
        # An unagreed softmax is retained as unknown.  Human-confirmed surface
        # voxels remain eligible even if the small classifier is uncertain.
        values[~agreement[rows]] = 0.0
        cells, maxima, counts = _aggregate_max(evidence.xy_cell[rows], values)
        inverse_position = np.searchsorted(cells, evidence.xy_cell[rows])
        reviewed_wall = np.zeros(len(cells), dtype=bool)
        reviewed_column = np.zeros(len(cells), dtype=bool)
        np.logical_or.at(reviewed_wall, inverse_position, wall_review[rows])
        np.logical_or.at(reviewed_column, inverse_position, column_review[rows])
        occupied = counts >= minimum_bins
        wall = occupied & (
            reviewed_wall
            | (
                (maxima[:, 0] >= low_confidence)
                & (maxima[:, 0] + margin >= maxima[:, 1])
                & (maxima[:, 0] + margin >= maxima[:, 2])
            )
        )
        column = occupied & (
            reviewed_column
            | (
                (maxima[:, 1] >= confidence)
                & (maxima[:, 1] >= maxima[:, 0] + margin)
                & (maxima[:, 1] >= maxima[:, 2] + margin)
            )
        )
        vehicle = occupied & (
            (maxima[:, 2] >= confidence)
            & (maxima[:, 2] >= maxima[:, 0] + margin)
            & (maxima[:, 2] >= maxima[:, 1] + margin)
        )
        wall_score = np.clip(np.rint(maxima[wall, 0] * 255.0), 0, 255).astype(np.uint8)
        record = ProjectionClassification(
            window_id=window.window_id,
            scale=window.scale,
            z_min_m=float(window.z_min_m),
            z_max_m=float(window.z_max_m),
            occupied_cells=cells[occupied],
            wall_cells=cells[wall],
            column_cells=cells[column],
            vehicle_cells=cells[vehicle],
            wall_score_u8=wall_score,
        )
        records.append(record)
        summary.append(
            {
                "window_id": window.window_id,
                "scale": window.scale,
                "occupied_cell_count": int(np.count_nonzero(occupied)),
                "wall_cell_count": int(np.count_nonzero(wall)),
                "column_cell_count": int(np.count_nonzero(column)),
                "vehicle_cell_count": int(np.count_nonzero(vehicle)),
                "reviewed_wall_cell_count": int(np.count_nonzero(reviewed_wall & occupied)),
                "reviewed_column_cell_count": int(
                    np.count_nonzero(reviewed_column & occupied)
                ),
            }
        )
    return records, {
        "window_count": len(records),
        "windows": summary,
        "classification_scope": "per_height_projection_before_object_reconstruction",
        "overlap_weighting": "one unique xyz voxel; repeated windows do not create observations",
    }


def _line_kernel(length_px: int, angle_deg: float) -> np.ndarray:
    size = max(3, int(length_px) | 1)
    kernel = np.zeros((size, size), np.uint8)
    center = (size - 1) / 2.0
    angle = math.radians(angle_deg)
    delta = np.asarray([math.cos(angle), math.sin(angle)]) * (size - 1) / 2.0
    first = tuple(np.rint(np.asarray([center, center]) - delta).astype(int))
    last = tuple(np.rint(np.asarray([center, center]) + delta).astype(int))
    cv2.line(kernel, first, last, 1, 1, cv2.LINE_8)
    kernel[size // 2, size // 2] = 1
    return kernel


def tangent_guided_propagation(
    seed_mask: np.ndarray,
    support_mask: np.ndarray,
    blocker_mask: np.ndarray,
    *,
    grid_m: float,
    cfg: dict[str, Any],
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Grow wall evidence along locally supported tangent directions.

    This is a deterministic, auditable "snake".  Growth is anisotropic: a
    candidate has to lie on a thin line kernel with multiple measured support
    pixels.  Re-running all orientations lets the front turn at an evidenced
    L/T junction, while an isolated equally sparse off-wall pixel cannot pull
    it sideways.  Added pixels are returned separately and remain inferred.
    """

    seed = np.asarray(seed_mask, dtype=bool)
    support = np.asarray(support_mask, dtype=bool)
    blocked = np.asarray(blocker_mask, dtype=bool)
    if seed.shape != support.shape or seed.shape != blocked.shape:
        raise ValueError("directional propagation masks must share one shape")
    observed = support & ~blocked
    angles = tuple(float(value) for value in cfg.get(
        "projection_trace_angles_deg", list(range(0, 180, 15))
    ))
    lengths_m = tuple(
        float(value)
        for value in cfg.get("projection_trace_lengths_m", [0.40, 0.80, 1.20])
    )
    minimum_hits = int(cfg.get("projection_trace_minimum_hits", 3))
    evidence_u8 = observed.astype(np.uint8)
    # Estimate one local tangent family at measured pixels.  This prevents the
    # old all-directions union from drawing diagonal chords between unrelated
    # sparse points.  A corner still turns: horizontal and vertical measured
    # arms carry different tangent labels and their independently propagated
    # paths meet at the junction.
    orientation_length = float(
        cfg.get("projection_orientation_neighbourhood_m", min(lengths_m))
    )
    orientation_kernels = [
        _line_kernel(max(3, int(round(orientation_length / grid_m))), angle)
        for angle in angles
    ]
    best_response = np.zeros(observed.shape, np.uint16)
    best_orientation = np.zeros(observed.shape, np.uint8)
    for index, kernel in enumerate(orientation_kernels):
        response = cv2.filter2D(evidence_u8, cv2.CV_16U, kernel)
        better = response > best_response
        best_response[better] = response[better]
        best_orientation[better] = index

    proposed = np.zeros_like(observed)
    orientation_count = len(angles)
    orientation_i16 = best_orientation.astype(np.int16)
    maximum_orientation_delta = int(
        cfg.get("projection_trace_orientation_bin_tolerance", 1)
    )
    for length in lengths_m:
        for index, angle in enumerate(angles):
            kernel = _line_kernel(max(3, int(round(length / grid_m))), angle)
            closed = cv2.morphologyEx(evidence_u8, cv2.MORPH_CLOSE, kernel)
            count = cv2.filter2D(evidence_u8, cv2.CV_16U, kernel)
            delta = np.minimum(
                (orientation_i16 - index) % orientation_count,
                (index - orientation_i16) % orientation_count,
            )
            tangent_seed = seed & (delta <= maximum_orientation_delta)
            reached = cv2.dilate(tangent_seed.astype(np.uint8), kernel)
            proposed |= (closed > 0) & (reached > 0) & (count >= minimum_hits)
    total_added = proposed & ~observed & ~blocked
    active = observed | total_added
    return active, total_added, {
        "orientation_count": len(angles),
        "kernel_lengths_m": list(lengths_m),
        "orientation_neighbourhood_m": orientation_length,
        "orientation_bin_tolerance": maximum_orientation_delta,
        "iterations_run": 1,
        "added_cell_count_by_iteration": [int(np.count_nonzero(total_added))],
        "added_cell_count": int(np.count_nonzero(total_added)),
        "added_pixels_semantics": "inferred_directional_candidate_not_measured",
    }


def _sample_line_cells(
    line: LineString, evidence: ExactVoxelEvidence, step_m: float
) -> np.ndarray:
    count = max(2, int(math.ceil(line.length / step_m)) + 1)
    points = np.asarray(
        [line.interpolate(value).coords[0] for value in np.linspace(0.0, line.length, count)]
    )
    pixels = np.floor((points - evidence.origin_xy) / evidence.grid_m).astype(np.int64)
    valid = (
        (pixels[:, 0] >= 0)
        & (pixels[:, 0] < evidence.shape[1])
        & (pixels[:, 1] >= 0)
        & (pixels[:, 1] < evidence.shape[0])
    )
    return np.unique(pixels[valid, 1] * evidence.shape[1] + pixels[valid, 0])


def _membership_fraction(samples: np.ndarray, sorted_cells: np.ndarray) -> float:
    if not len(samples) or not len(sorted_cells):
        return 0.0
    positions = np.searchsorted(sorted_cells, samples)
    valid = positions < len(sorted_cells)
    present = np.zeros(len(samples), dtype=bool)
    present[valid] = sorted_cells[positions[valid]] == samples[valid]
    return float(np.mean(present))


def trace_projection_wall_objects(
    evidence: ExactVoxelEvidence,
    projections: list[ProjectionClassification],
    cfg: dict[str, Any],
    *,
    blocker_mask: np.ndarray | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Fuse local projection decisions, then trace one shared wall-object map."""

    cell_count = int(np.prod(evidence.shape))
    wall_score = np.zeros(cell_count, np.uint8)
    projection_presence = np.zeros(cell_count, np.uint8)
    observed = np.zeros(cell_count, dtype=bool)
    column = np.zeros(cell_count, dtype=bool)
    vehicle = np.zeros(cell_count, dtype=bool)
    for item in projections:
        observed[item.wall_cells] = True
        column[item.column_cells] = True
        vehicle[item.vehicle_cells] = True
        projection_presence[item.wall_cells] = np.minimum(
            255, projection_presence[item.wall_cells].astype(np.uint16) + 1
        ).astype(np.uint8)
        np.maximum.at(wall_score, item.wall_cells, item.wall_score_u8)
    observed_image = observed.reshape(evidence.shape)
    score_image = wall_score.reshape(evidence.shape).astype(np.float32) / 255.0
    blockers = vehicle.reshape(evidence.shape) & ~observed_image
    blockers |= column.reshape(evidence.shape) & ~observed_image
    if blocker_mask is not None:
        blockers |= np.asarray(blocker_mask, dtype=bool) & ~observed_image
    measured = observed_image & ~blockers

    # Extract measured wall fragments first.  Connections are then selected in
    # object space, rather than filling a raster with every possible oriented
    # closing (which produced diagonal chords and thousands of extra nodes).
    paths = _skeleton_paths(
        measured,
        evidence.origin_xy + 0.5 * evidence.grid_m,
        evidence.grid_m,
    )
    records: list[dict[str, Any]] = []
    minimum_length = float(cfg.get("wall_candidate_min_length_m", 0.20))
    connection_seed_length = float(
        cfg.get("projection_trace_min_seed_length_m", 0.35)
    )
    provenance_threshold = float(cfg.get("projection_source_min_fraction", 0.08))
    for path in paths:
        if path.length < minimum_length:
            continue
        primitive = fit_curve_primitive(path, cfg)
        line = LineString(primitive.get("coordinates_ref", list(path.coords)))
        if line.length < minimum_length:
            continue
        samples = _sample_line_cells(line, evidence, max(0.05, evidence.grid_m))
        sources = []
        for item in projections:
            fraction = _membership_fraction(samples, item.wall_cells)
            if fraction >= provenance_threshold:
                sources.append(
                    {
                        "window_id": item.window_id,
                        "scale": item.scale,
                        "observed_fraction": fraction,
                    }
                )
        # Short fragments survive only when more than one projection sees the
        # same local object.  Projection count is not used as confidence; this
        # is merely a clutter guard before graph search.
        if line.length < connection_seed_length and len(sources) < 2:
            continue
        records.append(
            {
                "wall_id": f"PROJ-WALL-{len(records):05d}",
                "line": line,
                "geometry_kind": primitive.get("kind", "line"),
                "status": "candidate",
                "source": "per_projection_measured_wall_fragment",
                "source_windows": sources,
                "directional_inferred_fraction": 0.0,
            }
        )

    def endpoint_tangent(line: LineString, endpoint: int) -> np.ndarray:
        coordinates = np.asarray(line.coords, dtype=float)
        if endpoint == 0:
            vector = coordinates[0] - coordinates[min(2, len(coordinates) - 1)]
        else:
            vector = coordinates[-1] - coordinates[max(0, len(coordinates) - 3)]
        return vector / max(float(np.linalg.norm(vector)), 1e-9)

    endpoint_values: list[tuple[int, int, np.ndarray, np.ndarray]] = []
    for index, record in enumerate(records):
        line = record["line"]
        if line.length < connection_seed_length:
            continue
        coordinates = np.asarray(line.coords, dtype=float)
        endpoint_values.extend(
            [
                (index, 0, coordinates[0], endpoint_tangent(line, 0)),
                (index, 1, coordinates[-1], endpoint_tangent(line, 1)),
            ]
        )
    support_radius_px = max(
        1,
        int(
            math.ceil(
                float(cfg.get("projection_trace_support_distance_m", 0.10))
                / evidence.grid_m
            )
        ),
    )
    near_support = cv2.dilate(
        measured.astype(np.uint8),
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (2 * support_radius_px + 1, 2 * support_radius_px + 1),
        ),
    ).astype(bool)
    near_cells = np.flatnonzero(near_support).astype(np.int64)
    blocked_cells = np.flatnonzero(blockers).astype(np.int64)
    maximum_gap = float(cfg.get("projection_trace_max_gap_m", 1.20))
    maximum_extension = float(cfg.get("projection_trace_max_corner_extension_m", 1.00))
    straight_angle = math.radians(
        float(cfg.get("projection_trace_endpoint_angle_deg", 35.0))
    )
    minimum_corner_angle = math.radians(
        float(cfg.get("projection_trace_min_corner_angle_deg", 20.0))
    )
    minimum_score = float(cfg.get("projection_trace_min_score", 0.46))
    candidates: list[dict[str, Any]] = []
    if endpoint_values:
        positions = np.asarray([value[2] for value in endpoint_values])
        tree = cKDTree(positions)
        radius = math.hypot(maximum_extension, maximum_extension) * 1.05
        for left, neighbours in enumerate(tree.query_ball_tree(tree, radius)):
            a = endpoint_values[left]
            for right in neighbours:
                if right <= left:
                    continue
                b = endpoint_values[right]
                if a[0] == b[0]:
                    continue
                delta_xy = b[2] - a[2]
                distance = float(np.linalg.norm(delta_xy))
                if distance <= evidence.grid_m:
                    continue
                direction = delta_xy / distance
                error_a = math.acos(float(np.clip(np.dot(a[3], direction), -1.0, 1.0)))
                error_b = math.acos(float(np.clip(np.dot(b[3], -direction), -1.0, 1.0)))
                coordinates: np.ndarray | None = None
                connection_kind = None
                direction_score = 0.0
                allowed_length = maximum_gap
                if distance <= maximum_gap and max(error_a, error_b) <= straight_angle:
                    coordinates = np.asarray([a[2], b[2]])
                    connection_kind = "straight_tangent_continuation"
                    direction_score = 1.0 - max(error_a, error_b) / max(straight_angle, 1e-9)
                else:
                    axis_angle = math.acos(
                        float(np.clip(abs(np.dot(a[3], b[3])), -1.0, 1.0))
                    )
                    if axis_angle < minimum_corner_angle:
                        continue
                    matrix = np.column_stack([a[3], -b[3]])
                    if abs(float(np.linalg.det(matrix))) <= 1e-4:
                        continue
                    extension = np.linalg.solve(matrix, b[2] - a[2])
                    if (
                        extension[0] < -0.05
                        or extension[1] < -0.05
                        or extension[0] > maximum_extension
                        or extension[1] > maximum_extension
                    ):
                        continue
                    corner = a[2] + max(0.0, float(extension[0])) * a[3]
                    coordinates = np.asarray([a[2], corner, b[2]])
                    connection_kind = "supported_turn_at_wall_axis_intersection"
                    allowed_length = 2.0 * maximum_extension
                    direction_score = min(1.0, axis_angle / (math.pi / 2))
                candidate_line = LineString(coordinates)
                sample_cells = _sample_line_cells(
                    candidate_line, evidence, max(evidence.grid_m, 0.05)
                )
                support_fraction = _membership_fraction(sample_cells, near_cells)
                blocker_fraction = _membership_fraction(sample_cells, blocked_cells)
                if blocker_fraction > float(
                    cfg.get("projection_trace_max_blocker_fraction", 0.10)
                ):
                    continue
                semantic_values = wall_score[sample_cells] / 255.0 if len(sample_cells) else np.zeros(0)
                semantic_mean = float(np.mean(semantic_values)) if len(semantic_values) else 0.0
                shortness = max(0.0, 1.0 - candidate_line.length / max(allowed_length, 1e-6))
                score = (
                    0.34 * direction_score
                    + 0.30 * support_fraction
                    + 0.20 * semantic_mean
                    + 0.16 * shortness
                )
                short_strong = candidate_line.length <= 0.35 and direction_score >= 0.75
                if score < minimum_score and not short_strong:
                    continue
                candidates.append(
                    {
                        "left_endpoint": left,
                        "right_endpoint": right,
                        "line": candidate_line,
                        "score": float(score),
                        "support_fraction": support_fraction,
                        "semantic_mean": semantic_mean,
                        "connection_kind": connection_kind,
                    }
                )

    occupied_endpoints: set[int] = set()
    selected_connections: list[dict[str, Any]] = []
    for candidate in sorted(candidates, key=lambda value: value["score"], reverse=True):
        left = int(candidate["left_endpoint"])
        right = int(candidate["right_endpoint"])
        if left in occupied_endpoints or right in occupied_endpoints:
            continue
        a, b = endpoint_values[left], endpoint_values[right]
        source_ids = {
            value["window_id"]
            for record_index in (a[0], b[0])
            for value in records[record_index].get("source_windows", [])
        }
        selected_connections.append(
            {
                "wall_id": f"PROJ-CONN-{len(selected_connections):05d}",
                "line": candidate["line"],
                "geometry_kind": "polyline",
                "status": "candidate",
                "source": "tangent_state_wall_snake_connection",
                "source_windows": sorted(source_ids),
                "directional_inferred_fraction": float(
                    1.0 - candidate["support_fraction"]
                ),
                "connection_kind": candidate["connection_kind"],
                "connection_score": candidate["score"],
                "_left_record": int(a[0]),
                "_left_endpoint": int(a[1]),
                "_right_record": int(b[0]),
                "_right_endpoint": int(b[1]),
            }
        )
        occupied_endpoints.update((left, right))

    # Absorb selected connections into ordered wall chains *before* the
    # generic node optimiser.  This is the crucial distinction between a wall
    # object and a bag of fragments: height/status splitting happens later.
    adjacency: list[list[int]] = [[] for _ in records]
    for edge_index, connection in enumerate(selected_connections):
        adjacency[connection["_left_record"]].append(edge_index)
        adjacency[connection["_right_record"]].append(edge_index)
    visited_records: set[int] = set()
    visited_edges: set[int] = set()
    chains: list[dict[str, Any]] = []

    def edge_other(edge: dict[str, Any], record_index: int) -> tuple[int, int, int]:
        if edge["_left_record"] == record_index:
            return (
                int(edge["_right_record"]),
                int(edge["_left_endpoint"]),
                int(edge["_right_endpoint"]),
            )
        return (
            int(edge["_left_record"]),
            int(edge["_right_endpoint"]),
            int(edge["_left_endpoint"]),
        )

    for initial in range(len(records)):
        if initial in visited_records:
            continue
        component: set[int] = set()
        stack = [initial]
        while stack:
            current = stack.pop()
            if current in component:
                continue
            component.add(current)
            for edge_index in adjacency[current]:
                other, _, _ = edge_other(selected_connections[edge_index], current)
                if other not in component:
                    stack.append(other)
        start = next(
            (value for value in component if len(adjacency[value]) < 2), initial
        )
        start_edges = adjacency[start]
        if not start_edges:
            chains.append(records[start])
            visited_records.add(start)
            continue
        first_edge = start_edges[0]
        _, start_connected_endpoint, _ = edge_other(
            selected_connections[first_edge], start
        )
        coordinates = np.asarray(records[start]["line"].coords, dtype=float)
        # Begin at the free side and arrive at the first connected endpoint.
        if start_connected_endpoint == 0:
            coordinates = coordinates[::-1]
        chain_coordinates = coordinates.tolist()
        current = start
        current_edge = first_edge
        inferred_length = 0.0
        component_sources: dict[str, dict[str, Any]] = {}
        while current_edge not in visited_edges:
            edge = selected_connections[current_edge]
            visited_edges.add(current_edge)
            other, current_endpoint, other_endpoint = edge_other(edge, current)
            edge_coordinates = np.asarray(edge["line"].coords, dtype=float)
            if edge["_left_record"] != current:
                edge_coordinates = edge_coordinates[::-1]
            chain_coordinates.extend(edge_coordinates[1:].tolist())
            inferred_length += float(edge["line"].length)
            other_coordinates = np.asarray(records[other]["line"].coords, dtype=float)
            if other_endpoint == 1:
                other_coordinates = other_coordinates[::-1]
            chain_coordinates.extend(other_coordinates[1:].tolist())
            visited_records.update((current, other))
            current = other
            remaining = [
                value for value in adjacency[current] if value not in visited_edges
            ]
            if not remaining:
                break
            current_edge = remaining[0]
        clean_coordinates = [chain_coordinates[0]]
        for value in chain_coordinates[1:]:
            if np.linalg.norm(np.asarray(value) - np.asarray(clean_coordinates[-1])) > 1e-8:
                clean_coordinates.append(value)
        line = LineString(clean_coordinates)
        for record_index in component:
            for source in records[record_index].get("source_windows", []):
                existing = component_sources.get(source["window_id"])
                if existing is None or source["observed_fraction"] > existing["observed_fraction"]:
                    component_sources[source["window_id"]] = source
        chains.append(
            {
                "wall_id": f"PROJ-CHAIN-{len(chains):05d}",
                "line": line,
                "geometry_kind": "polyline" if len(clean_coordinates) > 2 else "line",
                "status": "candidate",
                "source": "ordered_projection_wall_chain_with_tangent_connections",
                "source_windows": list(component_sources.values()),
                "directional_inferred_fraction": float(
                    inferred_length / max(line.length, 1e-9)
                ),
                "absorbed_fragment_count": len(component),
                "absorbed_connection_count": int(
                    sum(len(adjacency[value]) for value in component) // 2
                ),
            }
        )
        visited_records.update(component)
    records = chains
    metrics = {
        "projection_count": len(projections),
        "measured_wall_cell_count": int(np.count_nonzero(measured)),
        "measured_skeleton_path_count": len(paths),
        "measured_object_piece_count": int(
            sum(value.get("absorbed_fragment_count", 1) for value in records)
        ),
        "connection_candidate_count": len(candidates),
        "selected_tangent_connection_count": len(selected_connections),
        "ordered_wall_chain_count": len(records),
        "traced_object_piece_count": len(records),
        "traced_total_length_m": float(sum(value["line"].length for value in records)),
        "object_definition": "measured per-projection wall fragments plus non-competing tangent-state connections",
        "turning_definition": "two outward wall tangents may meet at their fitted-axis intersection; each endpoint accepts one connection",
        "added_pixels_semantics": "none; connections remain vector objects and are revalidated in 3-D",
    }
    return records, metrics
