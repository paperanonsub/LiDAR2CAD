"""Evidence-constrained CAD/LiDAR fixed-point reconstruction in one scene state.

No ground truth is imported or read here. Coordinates are visible wall faces,
never wall centre lines. Original observations and design references are immutable.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path

import ezdxf
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Point, Polygon
from shapely.strtree import STRtree

from .design_assisted_r309 import (
    _angle_difference, _sample_line, generate_identity_candidates,
    generate_proximity_candidates, match_walls_to_design,
)

DEFAULT_CONFIG = {
    "schema": "lidar2cad-joint-config/v1", "max_iterations": 5,
    "match_distance_m": .50, "direction_tolerance_deg": 12.,
    "gap_min_m": .15, "gap_max_m": 3., "same_face_offset_m": .06,
    "same_face_angle_deg": 6., "point_corridor_m": .075,
    "opening_buffer_m": .20, "wall_probability_min": .50,
    "minimum_height_bins": 2, "minimum_fit_points": 6,
    "minimum_gap_coverage": .60, "minimum_multheight_coverage": .45,
    "maximum_unsupported_span_m": .30, "sampling_step_m": .05,
    "maximum_geometry_shift_m": .075, "design_orientation_weight": .15,
    "residual_improvement_m": .0001, "geometry_stability_m": .001,
    "minimum_host_support": .45, "minimum_outward_cosine": .85,
    "proximity_scope": "all_observed_wall_endpoints_before_competition",
}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows, fields):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                             for k, v in row.items()})


def unit(coords):
    xy = np.asarray(coords, float)
    v = xy[-1, :2] - xy[0, :2]
    return v / max(np.linalg.norm(v), 1e-12)


class PointEvidence:
    """Raw unique voxel centroids, semantic eligibility and vertical-bin support."""
    def __init__(self, points, probabilities=None, config=None):
        self.points = np.asarray(points)
        self.config = config or DEFAULT_CONFIG
        if probabilities is None:
            self.eligible = np.ones(len(points), dtype=bool)
        else:
            self.eligible = ((probabilities[:, 0] >= self.config["wall_probability_min"])
                             & (probabilities[:, 0] >= probabilities[:, 1])
                             & (probabilities[:, 0] >= probabilities[:, 2]))
        self.rows = np.flatnonzero(self.eligible)
        self.tree = cKDTree(self.points[self.rows, :2])

    def host_points(self, obj):
        rows = np.asarray(obj["support_evidence"].get("original_source_voxel_rows", obj["support_evidence"].get("source_voxel_rows", [])), dtype=int)
        rows = rows[(rows >= 0) & (rows < len(self.points))]
        rows = rows[self.eligible[rows]]
        if len(rows):
            original = np.asarray(obj["original_lidar_geometry"], float)
            v = unit(original)
            n = np.array([-v[1], v[0]])
            xy = self.points[rows, :2]
            rows = rows[np.abs((xy - original[0]) @ n) <= self.config["point_corridor_m"]]
        return rows, self.points[rows]

    def sample(self, coords):
        line = LineString(coords)
        samples = _sample_line(line, self.config["sampling_step_m"])
        groups = self.tree.query_ball_point(samples, self.config["point_corridor_m"])
        supported, multi, all_rows = [], [], set()
        for group in groups:
            rows = self.rows[np.asarray(group, int)]
            all_rows.update(rows.tolist())
            bins = np.unique(np.floor(self.points[rows, 2] / .10).astype(int))
            supported.append(bool(len(rows)))
            multi.append(len(bins) >= self.config["minimum_height_bins"])
        longest = count = 0
        for value in supported:
            count = 0 if value else count + 1
            longest = max(longest, count)
        return {"coverage": float(np.mean(supported)), "multiheight_coverage": float(np.mean(multi)),
                "maximum_unsupported_span_m": float(longest * line.length / max(len(samples) - 1, 1)),
                "source_voxel_rows": sorted(all_rows), "sample_count": len(samples),
                "evidence_kind": "raw_unique_voxel_wall_semantics_and_0.10m_height_bins"}


def make_scene(walls, columns, design, config):
    objects = {}
    for wall in walls:
        oid = str(wall["wall_id"])
        objects[oid] = {
            "object_id": oid, "kind": "WALL_FACE_TRACE", "wall_instance_id": "WI-" + oid,
            "wall_face_id": "WF-" + oid, "source_lidar_object_ids": [oid],
            "matched_design_entity_ids": [], "current_geometry": deepcopy(wall["coordinates"]),
            "original_lidar_geometry": deepcopy(wall["coordinates"]), "design_reference_geometry": [],
            "support_evidence": {"source_voxel_rows": wall.get("source_voxel_rows", []),
                                 "original_source_voxel_rows": wall.get("source_voxel_rows", []),
                                 "original_observed_support_fraction": wall.get("observed_support_fraction", 0.),
                                 "original_matched_support_fraction": wall.get("matched_support_fraction", 0.),
                                 "source_windows": wall.get("source_windows", [])},
            "geometry_provenance": [{"kind": "observed_lidar_surface", "source": wall.get("source"),
                                     "original_status": wall.get("status")}],
            "topology_relations": [], "review_or_conflict_status": "unassociated",
        }
        if wall.get("status") == "inferred_gap":
            objects[oid].update(kind="LEGACY_INFERRED_REFERENCE", original_lidar_geometry=None,
                original_inferred_geometry=deepcopy(wall["coordinates"]),
                review_or_conflict_status="historical_inference_requires_joint_revalidation",
                geometry_provenance=[{"kind": "historical_inferred_reference", "source": wall.get("source")}])
    for index, column in enumerate(columns):
        oid = "COLUMN-" + str(column.get("column_id", f"{index:05d}"))
        objects[oid] = {
            "object_id": oid, "kind": "COLUMN_FOOTPRINT", "wall_instance_id": None, "wall_face_id": None,
            "source_lidar_object_ids": [oid], "matched_design_entity_ids": [],
            "current_geometry": column["coordinates"], "original_lidar_geometry": column["coordinates"],
            "design_reference_geometry": [], "support_evidence": {
                "source_voxel_rows": column.get("source_voxel_rows", []),
                "observed_edge_indices": column.get("observed_edge_indices", []),
                "template_faces_are_measured": False},
            "geometry_provenance": [column.get("provenance", {"kind": "lidar_column_fit"})],
            "topology_relations": [], "review_or_conflict_status": column.get("status", "observed"),
        }
    references = {d["design_segment_id"]: {
        "design_entity_id": d["design_segment_id"], "design_wall_id": d["design_wall_id"],
        "original_geometry": list(map(list, d["line"].coords)), "validated_faces": [],
        "status": "design_reference_only", "source_lidar_object_ids": []}
        for d in design["wall_segments"]}
    return {"schema": "lidar2cad-joint-scene/v1", "coordinate_frame": "ICPARK registered LiDAR map frame; XY metres",
            "config": deepcopy(config), "objects": objects, "design_entities": references,
            "design_openings": [{"design_opening_id": d["design_opening_id"],
                                 "coordinates": list(map(list, d["line"].coords))} for d in design["openings"]],
            "registration": design.get("registration", {}), "relations": [], "iterations": [],
            "geometry_changes": [], "identity_changes": [], "design_changes": [], "conflicts": [],
            "candidate_history": {}, "candidate_generation": []}


def wall_records(scene):
    return [{"wall_id": o["object_id"], "physical_wall_id": o["wall_instance_id"],
             "coordinates": o["current_geometry"],
             "observed_support_fraction": o["support_evidence"].get("coverage", 0.),
             "design_correspondence": o.get("design_correspondence", {})}
            for o in scene["objects"].values() if o["kind"] == "WALL_FACE_TRACE"]


def working_design(scene):
    result = []
    for key, d in scene["design_entities"].items():
        faces = d["validated_faces"] or [{"face_id": key, "coordinates": d["original_geometry"]}]
        for face in faces:
            result.append({"design_segment_id": face["face_id"], "design_wall_id": d["design_wall_id"],
                           "root_design_id": key, "line": LineString(face["coordinates"])})
    return result


def associate(scene, iteration):
    cfg = scene["config"]
    design = working_design(scene)
    lookup = {d["design_segment_id"]: d for d in design}
    enriched, _ = match_walls_to_design(wall_records(scene), design,
        maximum_distance_m=cfg["match_distance_m"], maximum_direction_difference_deg=cfg["direction_tolerance_deg"])
    changes = 0
    for w in enriched:
        obj = scene["objects"][w["wall_id"]]
        match = w["design_correspondence"]
        previous = obj.get("design_correspondence", {})
        if match.get("matched"):
            d = lookup[match["design_segment_id"]]
            match["root_design_id"] = d["root_design_id"]
            obj["matched_design_entity_ids"] = [d["root_design_id"]]
            obj["design_reference_geometry"] = [scene["design_entities"][d["root_design_id"]]["original_geometry"]]
            obj["working_design_geometry"] = list(map(list, d["line"].coords))
            obj["review_or_conflict_status"] = "design_associated_pending_evidence"
        else:
            obj["matched_design_entity_ids"] = []
            obj["design_reference_geometry"] = []
            obj.pop("working_design_geometry", None)
            obj["review_or_conflict_status"] = "lidar_only_unmatched_design"
        if previous.get("design_segment_id") != match.get("design_segment_id"):
            changes += 1
            scene["design_changes"].append({"iteration": iteration, "object_id": w["wall_id"],
                "action": "reassociate" if iteration else "initial_association",
                "before": previous, "after": deepcopy(match)})
        obj["design_correspondence"] = match
    return changes


def refit_wall(obj, evidence, cfg):
    """Design-guided orientation is accepted only if raw point residual improves."""
    rows, points = evidence.host_points(obj)
    if len(points) < cfg["minimum_fit_points"]:
        return None
    if len(np.unique(np.floor(points[:, 2] / .10))) < cfg["minimum_height_bins"]:
        return None
    old = np.asarray(obj["current_geometry"], float)
    v0 = unit(old)
    xy = points[:, :2]
    # Robust trim is tied to the immutable single-face observation, not a CAD centreline.
    center = np.median(xy, axis=0)
    _, _, vt = np.linalg.svd(xy - center, full_matrices=False)
    direction = vt[0]
    if direction @ v0 < 0:
        direction = -direction
    normal = np.array([-direction[1], direction[0]])
    residual = np.abs((xy - center) @ normal)
    xy = xy[residual <= max(.02, float(np.quantile(residual, .85)))]
    if len(xy) < cfg["minimum_fit_points"]:
        return None
    center = np.median(xy, axis=0)
    if "working_design_geometry" in obj:
        vd = unit(obj["working_design_geometry"])
        if vd @ direction < 0:
            vd = -vd
        weight = cfg["design_orientation_weight"]
        direction = (1 - weight) * direction + weight * vd
        direction /= np.linalg.norm(direction)
    proposed = center + np.outer((old - center) @ direction, direction)
    shift = float(np.max(np.linalg.norm(proposed - old, axis=1)))
    immutable = np.asarray(obj["original_lidar_geometry"], float)
    if np.max(np.linalg.norm(proposed - immutable, axis=1)) > cfg["maximum_geometry_shift_m"]:
        return None
    if shift < cfg["geometry_stability_m"]:
        return None
    old_n = np.array([-v0[1], v0[0]])
    new_n = np.array([-direction[1], direction[0]])
    before = float(np.mean(np.abs((points[:, :2] - old[0]) @ old_n)))
    after = float(np.mean(np.abs((points[:, :2] - proposed[0]) @ new_n)))
    if after + cfg["residual_improvement_m"] >= before:
        return None
    if _angle_difference(LineString(old), LineString(proposed)) > cfg["same_face_angle_deg"]:
        return None
    return proposed.tolist(), {"before_residual_m": before, "after_residual_m": after,
                               "maximum_shift_m": shift, "fit_voxel_count": len(rows),
                               "design_orientation_used": "working_design_geometry" in obj}


def update_design(scene, iteration):
    """LiDAR -> separate supported design face tracks; these drive next association."""
    groups = defaultdict(list)
    for o in scene["objects"].values():
        if o["kind"] == "WALL_FACE_TRACE" and o["matched_design_entity_ids"]:
            if o["support_evidence"].get("multiheight_coverage", 0) >= scene["config"]["minimum_host_support"]:
                groups[o["matched_design_entity_ids"][0]].append(o)
    changed = 0
    for key, d in scene["design_entities"].items():
        prior = deepcopy(d["validated_faces"])
        v = unit(d["original_geometry"])
        n = np.array([-v[1], v[0]])
        origin = np.asarray(d["original_geometry"][0])
        sorted_objects = sorted(groups[key], key=lambda o: float((np.mean(o["current_geometry"], axis=0) - origin) @ n))
        clusters = []
        for obj in sorted_objects:
            offset = float((np.mean(obj["current_geometry"], axis=0) - origin) @ n)
            if not clusters or offset - clusters[-1][0][0] > scene["config"]["same_face_offset_m"]:
                clusters.append([])
            clusters[-1].append((offset, obj))
        faces = []
        for cluster in clusters:
            offset = float(np.median([x[0] for x in cluster]))
            # Stable track name based on source members, never renumber existing objects.
            ids = sorted(x[1]["object_id"] for x in cluster)
            fid = key + "-FACE-" + digest(ids)[:10]
            coords = (np.asarray(d["original_geometry"]) + offset * n).tolist()
            faces.append({"face_id": fid, "coordinates": coords, "offset_from_design_m": offset,
                          "source_lidar_object_ids": ids,
                          "status": "lidar_corrected_design_face" if abs(offset) > .001 else "lidar_validated_design_face"})
        d["validated_faces"] = faces
        d["source_lidar_object_ids"] = sorted(o["object_id"] for o in groups[key])
        d["status"] = "lidar_validated_or_corrected" if faces else "design_reference_only"
        if digest(prior) != digest(faces):
            changed += 1
            scene["design_changes"].append({"iteration": iteration, "design_entity_id": key,
                "action": "lidar_updates_design_face_tracks", "before": prior, "after": deepcopy(faces)})
    return changed


def proximity_pool(walls, cfg):
    """Generate BEFORE competition, including walls without a CAD match."""
    if not walls:
        return []
    xy = np.asarray([p for w in walls for p in [w["coordinates"][0], w["coordinates"][-1]]])
    result = []
    for i, j in sorted(cKDTree(xy).query_pairs(cfg["gap_max_m"])):
        if i // 2 == j // 2:
            continue
        line = LineString([xy[i], xy[j]])
        if line.length < cfg["gap_min_m"]:
            continue
        a, b = walls[i // 2], walls[j // 2]
        if min(_angle_difference(line, LineString(a["coordinates"])),
               _angle_difference(line, LineString(b["coordinates"]))) > cfg["direction_tolerance_deg"]:
            continue
        result.append({"host_wall_ids": [a["wall_id"], b["wall_id"]],
                       "coordinates": [xy[i].tolist(), xy[j].tolist()],
                       "source": "proximity_without_identity", "endpoint_indices": [i % 2, j % 2]})
    return result


def candidate_key(record, scene):
    hosts = record["host_wall_ids"]
    endpoints = record.get("endpoint_indices")
    if endpoints is None:
        endpoints = [int(np.argmin(np.linalg.norm(np.asarray(scene["objects"][h]["current_geometry"])[[0, -1]]
                                                   - np.asarray(p), axis=1)))
                     for h, p in zip(hosts, [record["coordinates"][0], record["coordinates"][-1]])]
    pairs = sorted(zip(hosts, endpoints))
    return "JREL-" + digest(pairs)[:18], [p[0] for p in pairs], [int(p[1]) for p in pairs]


def validate_candidate(c, scene, evidence, opening_tree, openings, column_tree, columns):
    cfg = scene["config"]
    hosts = [scene["objects"][h] for h in c["host_wall_ids"]]
    coords = [h["current_geometry"][[0, -1][e]] for h, e in zip(hosts, c["endpoint_indices"])]
    c["coordinates"] = deepcopy(coords)
    line = LineString(coords)
    steps = []
    def gate(stage, passed, reason):
        steps.append({"stage": stage, "accepted": bool(passed), "reason": "passed" if passed else reason})
        return passed
    a, b = [np.asarray(h["current_geometry"]) for h in hosts]
    va, vb = unit(a), unit(b)
    perpendicular = max(abs(float((np.asarray(coords[1]) - coords[0]) @ np.array([-va[1], va[0]]))),
                        abs(float((np.asarray(coords[1]) - coords[0]) @ np.array([-vb[1], vb[0]]))))
    raw_hosts = all(h["kind"] == "WALL_FACE_TRACE" for h in hosts)
    gate("observed_hosts", raw_hosts, "host_is_unvalidated_historical_inference")
    same = (raw_hosts and _angle_difference(LineString(a), LineString(b)) <= cfg["same_face_angle_deg"]
            and perpendicular <= cfg["same_face_offset_m"])
    gate("same_face_identity", same, "different_face_offset_or_direction")
    outward = True
    if line.length > 1e-9:
        for k, (arr, endpoint) in enumerate(zip([a, b], c["endpoint_indices"])):
            away = unit(arr) * (1 if endpoint else -1)
            to_other = (np.asarray(coords[1-k]) - coords[k]) / line.length
            outward &= float(away @ to_other) >= cfg["minimum_outward_cosine"]
    gate("outward_endpoints", outward, "overlap_or_inward_connection")
    # Cheap geometry failures do not trigger expensive point queries.
    ev = evidence.sample(coords) if same and outward else None
    c["field_evidence"] = ev
    support = bool(ev and ev["coverage"] >= cfg["minimum_gap_coverage"]
                   and ev["multiheight_coverage"] >= cfg["minimum_multheight_coverage"]
                   and ev["maximum_unsupported_span_m"] <= cfg["maximum_unsupported_span_m"])
    gate("field_evidence", support, "insufficient_raw_cross_height_support" if ev else "not_reached_identity_gate")
    near = [] if opening_tree is None else [int(i) for i in opening_tree.query(line.buffer(cfg["opening_buffer_m"]), predicate="intersects")]
    c["near_design_opening_ids"] = [openings[i]["design_opening_id"] for i in near]
    gate("design_opening", not near, "design_opening_conflict")
    near_columns = [] if column_tree is None else [int(i) for i in column_tree.query(line, predicate="intersects")]
    gate("column_conflict", not near_columns, "connector_crosses_column_footprint")
    c["stages"] = steps
    c["selected"] = all(s["accepted"] for s in steps)
    c["decision"] = "eligible" if c["selected"] else next(s["reason"] for s in steps if not s["accepted"])
    c["score"] = float(ev["multiheight_coverage"] if ev else 0.)
    return c


def select_candidates(candidates, scene):
    selected, used, geometry = [], set(), []
    parent = {o: o for o in scene["objects"]}
    components = {o: [o] for o in scene["objects"]}
    def root(x):
        while parent[x] != x:
            x = parent[x]
        return x
    for c in sorted(candidates, key=lambda r: (-r["score"], LineString(r["coordinates"]).length, r["predicted_relation_id"])):
        if not c["selected"]:
            continue
        keys = list(zip(c["host_wall_ids"], c["endpoint_indices"]))
        line = LineString(c["coordinates"])
        duplicate = any(line.hausdorff_distance(g) < .01 for g in geometry)
        competing = any(k in used for k in keys)
        if duplicate or competing:
            c.update(selected=False, decision="duplicate_geometry" if duplicate else "competing_endpoint")
            c["stages"].append({"stage": "duplicate_and_competition", "accepted": False, "reason": c["decision"]})
            continue
        c["stages"].append({"stage": "duplicate_and_competition", "accepted": True, "reason": "passed"})
        left, right = map(root, c["host_wall_ids"])
        if left == right:
            c.update(selected=False, decision="redundant_identity_cycle")
            c["stages"].append({"stage": "topology_consistency", "accepted": False, "reason": c["decision"]})
            continue
        # Pairwise proximity is not transitive evidence of one face: prevent offset drift.
        members = components[left] + components[right]
        base = scene["objects"][members[0]]["original_lidar_geometry"]
        v = unit(base)
        n = np.array([-v[1], v[0]])
        offsets = [float((np.mean(scene["objects"][h]["original_lidar_geometry"], axis=0)
                          - np.asarray(base[0])) @ n) for h in members]
        if max(offsets) - min(offsets) > scene["config"]["same_face_offset_m"]:
            c.update(selected=False, decision="component_face_offset_drift")
            c["stages"].append({"stage": "topology_consistency", "accepted": False, "reason": c["decision"]})
            continue
        parent[right] = left
        components[left] = members
        c["stages"].append({"stage": "topology_consistency", "accepted": True, "reason": "passed"})
        c.update(selected=True, decision="accepted_joint_evidence")
        c["stages"].append({"stage": "final_selection", "accepted": True, "reason": "accepted_joint_evidence"})
        used.update(keys)
        selected.append(c)
        geometry.append(line)
    return selected


def apply_relations(scene, selected, iteration):
    """Commit identities and gap geometry transactionally, then export by object ID."""
    objects = scene["objects"]
    previous = {r["predicted_relation_id"]: r for r in scene["relations"]}
    for oid in [k for k, o in objects.items() if o["kind"] == "INFERRED_WALL_FACE"]:
        del objects[oid]
    parent = {o["object_id"]: o["object_id"] for o in objects.values() if o["kind"] == "WALL_FACE_TRACE"}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for c in selected:
        x, y = map(find, c["host_wall_ids"])
        parent[max(x, y)] = min(x, y)
    members = defaultdict(list)
    for oid in parent:
        members[find(oid)].append(oid)
    for o in objects.values():
        o["topology_relations"] = []
        if o["kind"] != "WALL_FACE_TRACE":
            continue
        ids = sorted(members[find(o["object_id"])] )
        face = "WF-" + (digest(ids)[:18] if len(ids) > 1 else o["object_id"])
        instance = "WI-" + (digest(ids)[:18] if len(ids) > 1 else o["object_id"])
        if face != o["wall_face_id"]:
            scene["identity_changes"].append({"iteration": iteration, "object_id": o["object_id"],
                "before_wall_face_id": o["wall_face_id"], "after_wall_face_id": face,
                "before_wall_instance_id": o["wall_instance_id"], "after_wall_instance_id": instance,
                "source_lidar_object_ids": ids, "reason": "validated_same_face_relation_components"})
        o.update(wall_face_id=face, wall_instance_id=instance)
    relations = []
    measured_ids = [oid for oid, o in objects.items() if o["kind"] == "WALL_FACE_TRACE"]
    measured_lines = [LineString(objects[oid]["current_geometry"]) for oid in measured_ids]
    measured_tree = STRtree(measured_lines) if measured_lines else None
    for c in selected:
        rid = c["predicted_relation_id"]
        hosts = [objects[h] for h in c["host_wall_ids"]]
        gid = "GAP-" + rid
        coords = deepcopy(c["coordinates"])
        new_object = {
            "object_id": gid, "kind": "INFERRED_WALL_FACE", "wall_face_id": hosts[0]["wall_face_id"],
            "wall_instance_id": hosts[0]["wall_instance_id"], "source_lidar_object_ids": c["host_wall_ids"],
            "matched_design_entity_ids": sorted(set(sum([h["matched_design_entity_ids"] for h in hosts], []))),
            "current_geometry": coords, "original_lidar_geometry": None,
            "design_reference_geometry": sum([h["design_reference_geometry"] for h in hosts], []),
            "support_evidence": c["field_evidence"],
            "geometry_provenance": [{"kind": "inferred_gap_with_raw_multheight_support", "predicted_relation_id": rid,
                                     "source_lidar_object_ids": c["host_wall_ids"], "branches": c["branches"]}],
            "topology_relations": [rid], "review_or_conflict_status": "accepted_evidence_constrained_inference"}
        line = LineString(coords)
        covered, existing_ids = [], []
        if measured_tree is not None:
            for ix in measured_tree.query(line.buffer(.01), predicate="intersects"):
                other = measured_lines[int(ix)]
                if _angle_difference(line, other) > scene["config"]["same_face_angle_deg"]:
                    continue
                v = unit(coords)
                n = np.array([-v[1], v[0]])
                xy = np.asarray(other.coords)
                if np.max(np.abs((xy - np.asarray(coords[0])) @ n)) > .01:
                    continue
                lo, hi = sorted(float((p - np.asarray(coords[0])) @ v) for p in xy[[0, -1]])
                lo, hi = max(0., lo), min(line.length, hi)
                if hi > lo + 1e-8:
                    covered.append((lo, hi))
                    existing_ids.append(measured_ids[int(ix)])
        uncovered, cursor = [], 0.
        for lo, hi in sorted(covered):
            if lo > cursor + 1e-8:
                uncovered.append((cursor, lo))
            cursor = max(cursor, hi)
        if cursor < line.length - 1e-8:
            uncovered.append((cursor, line.length))
        geometry_ids = list(existing_ids)
        for part, (lo, hi) in enumerate(uncovered):
            part_id = gid if len(uncovered) == 1 else gid + f"-P{part:03d}"
            part_obj = deepcopy(new_object)
            part_obj["object_id"] = part_id
            part_obj["current_geometry"] = [list(line.interpolate(lo).coords[0]), list(line.interpolate(hi).coords[0])]
            objects[part_id] = part_obj
            geometry_ids.append(part_id)
        relation = {"predicted_relation_id": rid, "predicted_relation_type": "CONNECT",
            "host_wall_ids": c["host_wall_ids"], "host_wall_geometries": [h["current_geometry"] for h in hosts],
            "endpoint_indices": c["endpoint_indices"], "endpoint_coordinates": coords,
            "geometry_object_ids": geometry_ids, "logical_only": not uncovered,
            "source_lidar_object_ids": c["host_wall_ids"],
            "branches": c["branches"], "evidence": c["field_evidence"], "selected": True}
        relations.append(relation)
        for oid in existing_ids:
            if rid not in objects[oid]["topology_relations"]:
                objects[oid]["topology_relations"].append(rid)
        for host in hosts:
            host["topology_relations"].append(rid)
            host["review_or_conflict_status"] = "joint_geometry_identity_topology_validated"
        if rid not in previous or previous[rid]["endpoint_coordinates"] != coords:
            scene["geometry_changes"].append({"iteration": iteration, "object_id": gid,
                "action": ("logical_connection_existing_geometry" if not uncovered else
                           "gap_created" if rid not in previous else "gap_recomputed_from_updated_hosts"),
                "before": previous.get(rid, {}).get("endpoint_coordinates"), "after": coords,
                "predicted_relation_id": rid, "length_m": LineString(coords).length})
    for rid in previous.keys() - {r["predicted_relation_id"] for r in relations}:
        scene["geometry_changes"].append({"iteration": iteration, "object_id": "GAP-" + rid,
            "action": "gap_retracted_after_revalidation", "before": previous[rid]["endpoint_coordinates"], "after": None,
            "predicted_relation_id": rid})
    scene["relations"] = sorted(relations, key=lambda r: r["predicted_relation_id"])


def reconstruct(scene, evidence, progress=print):
    cfg = scene["config"]
    openings = scene["design_openings"]
    opening_tree = STRtree([LineString(o["coordinates"]) for o in openings]) if openings else None
    columns = [Polygon(o["current_geometry"]) for o in scene["objects"].values() if o["kind"] == "COLUMN_FOOTPRINT"]
    column_tree = STRtree(columns) if columns else None
    associate(scene, 0)
    # Preserve historical generator stage for direct 8/47 benchmark lineage, without its decisions.
    initial_walls = wall_records(scene)
    # The original generator operated on observed AND historical inferred records.
    legacy = [{"wall_id": o["object_id"], "physical_wall_id": o["object_id"], "coordinates": o["current_geometry"],
               "observed_support_fraction": o["support_evidence"]["original_observed_support_fraction"]}
              for o in scene["objects"].values() if o["kind"] == "LEGACY_INFERRED_REFERENCE"]
    if legacy:
        legacy, _ = match_walls_to_design(legacy, working_design(scene), maximum_distance_m=cfg["match_distance_m"],
                                         maximum_direction_difference_deg=cfg["direction_tolerance_deg"])
        initial_walls += legacy
    initial_design = working_design(scene)
    kwargs = {"minimum_gap_m": cfg["gap_min_m"], "maximum_gap_m": cfg["gap_max_m"],
              "maximum_direction_difference_deg": cfg["direction_tolerance_deg"]}
    scene["historical_generator_baseline"] = {
        "design_identity": generate_identity_candidates(initial_walls, initial_design, **kwargs),
        "proximity_without_identity": generate_proximity_candidates(initial_walls, **kwargs)}
    previous_signature = None
    for iteration in range(1, cfg["max_iterations"] + 1):
        progress(f"joint iteration {iteration}: geometry and evidence", flush=True)
        geometry_count = 0
        for obj in scene["objects"].values():
            if obj["kind"] != "WALL_FACE_TRACE":
                continue
            update = refit_wall(obj, evidence, cfg)
            if update is not None:
                coords, detail = update
                before = deepcopy(obj["current_geometry"])
                obj["current_geometry"] = coords
                provenance = {"kind": "raw_lidar_fit_with_validated_design_orientation", "iteration": iteration, **detail}
                obj["geometry_provenance"].append(provenance)
                scene["geometry_changes"].append({"iteration": iteration, "object_id": obj["object_id"],
                    "action": "face_refit", "before": before, "after": coords, **detail})
                geometry_count += 1
            if iteration == 1 or update is not None:
                obj["support_evidence"].update(evidence.sample(obj["current_geometry"]))
        design_updates = update_design(scene, iteration)
        correspondence_changes = associate(scene, iteration)
        walls = wall_records(scene)
        identities = generate_identity_candidates(walls, working_design(scene), **kwargs)
        proximity = proximity_pool(walls, cfg)
        # Retain initial proposals and revalidate against current endpoints after every geometry update.
        sources = [("design_identity", identities), ("proximity_without_identity", proximity)]
        sources += [(k, v) for k, v in scene["historical_generator_baseline"].items()]
        sources.append(("lidar_native", scene.get("native_candidates", [])))
        candidates = {}
        for branch, records in sources:
            for record in records:
                if len(record.get("host_wall_ids", [])) != 2 or any(h not in scene["objects"] for h in record["host_wall_ids"]):
                    continue
                rid, hosts, endpoints = candidate_key(record, scene)
                if rid not in candidates:
                    candidates[rid] = {"predicted_relation_id": rid, "host_wall_ids": hosts,
                        "endpoint_indices": endpoints, "branches": [], "source_candidate_ids": []}
                if branch not in candidates[rid]["branches"]:
                    candidates[rid]["branches"].append(branch)
                source_id = record.get("connection_id")
                if source_id and source_id not in candidates[rid]["source_candidate_ids"]:
                    candidates[rid]["source_candidate_ids"].append(source_id)
        progress(f"joint iteration {iteration}: validating {len(candidates)} candidates", flush=True)
        for c in candidates.values():
            validate_candidate(c, scene, evidence, opening_tree, openings, column_tree, columns)
        selected = select_candidates(list(candidates.values()), scene)
        apply_relations(scene, selected, iteration)
        for rid, c in candidates.items():
            history = scene["candidate_history"].setdefault(rid, {"first_iteration": iteration, "iterations": []})
            previous = history.get("final")
            if previous is None or any(previous[k] != c[k] for k in ["decision", "selected", "coordinates", "stages"]):
                history["iterations"].append({"iteration": iteration, "decision": c["decision"], "selected": c["selected"],
                                              "coordinates": c["coordinates"], "stages": c["stages"]})
            history["final"] = deepcopy(c)
        branch_stats = {b: {"generated": sum(b in c["branches"] for c in candidates.values()),
                            "accepted": sum(b in c["branches"] and c["selected"] for c in candidates.values())}
                        for b in ["design_identity", "proximity_without_identity", "lidar_native"]}
        for v in branch_stats.values():
            v["rejected"] = v["generated"] - v["accepted"]
        signature = digest({"objects": {k: [o["current_geometry"], o["wall_face_id"], o.get("matched_design_entity_ids")]
                                         for k, o in scene["objects"].items()},
                            "relations": scene["relations"], "design": scene["design_entities"]})
        stable = signature == previous_signature
        scene["iterations"].append({"iteration": iteration, "wall_refits": geometry_count,
            "lidar_to_design_updates": design_updates, "correspondence_changes": correspondence_changes,
            "selected_connections": len(selected), "branches": branch_stats, "state_signature": signature,
            "stable": stable})
        previous_signature = signature
        progress(json.dumps(scene["iterations"][-1]), flush=True)
        if stable:
            break
    scene["termination"] = "stable" if scene["iterations"][-1]["stable"] else "maximum_iterations_reached"
    scene["final_candidates"] = [h["final"] for h in scene["candidate_history"].values()]
    final_ids = {r["predicted_relation_id"] for r in scene["relations"]}
    for c in scene["final_candidates"]:
        if c["predicted_relation_id"] not in final_ids and c["selected"]:
            c.update(selected=False, decision="not_regenerated_in_final_iteration")
        if not c["selected"]:
            scene["conflicts"].append({"predicted_relation_id": c["predicted_relation_id"],
                "host_wall_ids": c["host_wall_ids"], "branches": c["branches"], "reason": c["decision"]})
    validate_scene(scene)
    return scene


def validate_scene(scene):
    objects = scene["objects"]
    ids = [r["predicted_relation_id"] for r in scene["relations"]]
    assert len(ids) == len(set(ids)), "duplicate relation ID"
    for r in scene["relations"]:
        hosts = [objects[h] for h in r["host_wall_ids"]]
        assert hosts[0]["wall_face_id"] == hosts[1]["wall_face_id"]
        for h, e, xy in zip(hosts, r["endpoint_indices"], r["endpoint_coordinates"]):
            assert np.allclose(h["current_geometry"][[0, -1][e]], xy, atol=1e-9)
            assert r["predicted_relation_id"] in h["topology_relations"]
        for gid in r["geometry_object_ids"]:
            if objects[gid]["kind"] == "INFERRED_WALL_FACE":
                assert LineString(objects[gid]["current_geometry"]).difference(LineString(r["endpoint_coordinates"]).buffer(1e-7)).length < 1e-7
            assert r["predicted_relation_id"] in objects[gid]["topology_relations"]
    return {"valid": True, "objects": len(objects), "relations": len(ids), "dangling_references": 0}


def export_scene(scene, output, run_id, input_hashes):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    state = deepcopy(scene)
    audit = {"schema": "lidar2cad-joint-candidates/v1", "historical_generator_baseline": state.pop("historical_generator_baseline"),
             "candidate_history": state.pop("candidate_history"), "candidates": state.pop("final_candidates")}
    state.pop("native_candidates", None)
    # Final record is already stored in candidates; histories contain only changed decisions.
    for history in audit["candidate_history"].values():
        history.pop("final", None)
    state.update(run_id=run_id, config_sha256=digest(state["config"]), input_hashes=input_hashes)
    state_hash = digest(state)
    metadata = {"run_id": run_id, "scene_state_sha256": state_hash, "config_sha256": state["config_sha256"],
                "scene_hash_definition": "canonical_sorted_compact_JSON_without_scene_state_sha256"}
    state.update(metadata)
    # Hash definition excludes the metadata fields added after payload hashing.
    state["scene_hash_definition"] = "canonical payload before export metadata; see joint_scene_payload_sha256.json"
    write_json(output / "joint_scene_payload_sha256.json", {"sha256": state_hash,
        "exclude_keys": ["scene_state_sha256", "scene_hash_definition"]})
    document = ezdxf.new("R2013")
    document.header["$INSUNITS"] = 6
    document.appids.add("LIDAR2CAD_JOINT")
    layers = {"WALL_FACE_TRACE": "JOINT_WALL_OBSERVED", "INFERRED_WALL_FACE": "JOINT_WALL_INFERRED",
              "COLUMN_FOOTPRINT": "JOINT_COLUMN_OBSERVED", "LEGACY_INFERRED_REFERENCE": "LIDAR_INFERENCE_REFERENCE_ONLY"}
    for i, name in enumerate(layers.values()):
        layer = document.layers.add(name, color=[7, 30, 3, 8][i])
        if name == "LIDAR_INFERENCE_REFERENCE_ONLY":
            layer.off()
    ref_layer = document.layers.add("DESIGN_REFERENCE_ONLY", color=8)
    ref_layer.off()
    model = document.modelspace()
    entity_map = {}
    for oid, obj in sorted(state["objects"].items()):
        e = model.add_lwpolyline(obj["current_geometry"], dxfattribs={"layer": layers[obj["kind"]]})
        tags = [oid, obj["wall_instance_id"] or "", obj["wall_face_id"] or "", run_id, state_hash,
                metadata["config_sha256"], obj["kind"], *obj["topology_relations"]]
        e.set_xdata("LIDAR2CAD_JOINT", [(1000, s) for s in tags])
        entity_map[oid] = e.dxf.handle
    for did, d in sorted(state["design_entities"].items()):
        e = model.add_lwpolyline(d["original_geometry"], dxfattribs={"layer": "DESIGN_REFERENCE_ONLY"})
        e.set_xdata("LIDAR2CAD_JOINT", [(1000, x) for x in [did, "design_reference_only", run_id, state_hash]])
    document.rootdict.add_xrecord("LIDAR2CAD_JOINT_RUN").extend([(1, json.dumps(metadata, sort_keys=True))])
    document.saveas(output / "joint_final_geometry.dxf")
    topology = {"schema": "lidar2cad-joint-topology/v1", **metadata, "coordinate_frame": state["coordinate_frame"],
                "relations": deepcopy(state["relations"]), "entity_map": entity_map}
    for r in topology["relations"]:
        r["dxf_host_handles"] = [entity_map[h] for h in r["host_wall_ids"]]
        r["dxf_geometry_handles"] = [entity_map[g] for g in r["geometry_object_ids"]]
    audit.update(metadata)
    write_json(output / "joint_scene_state.json", state)
    write_json(output / "joint_final_topology.json", topology)
    write_json(output / "joint_candidate_audit.json", audit)
    write_csv(output / "joint_geometry_changes.csv", state["geometry_changes"],
        ["iteration", "object_id", "action", "before", "after", "predicted_relation_id", "length_m",
         "before_residual_m", "after_residual_m", "maximum_shift_m", "design_orientation_used"])
    write_csv(output / "joint_identity_changes.csv", state["identity_changes"],
        ["iteration", "object_id", "before_wall_face_id", "after_wall_face_id", "before_wall_instance_id",
         "after_wall_instance_id", "source_lidar_object_ids", "reason"])
    write_csv(output / "joint_conflict_report.csv", state["conflicts"],
        ["predicted_relation_id", "host_wall_ids", "branches", "reason"])
    write_json(output / "joint_design_changes.json", state["design_changes"])
    manifest = {"schema": "lidar2cad-joint-run/v1", **metadata, "inputs": input_hashes,
                "termination": state["termination"], "iterations": state["iterations"],
                "checks": validate_scene(state), "artifacts": {}}
    for filename in ["joint_final_geometry.dxf", "joint_final_topology.json", "joint_scene_state.json", "joint_candidate_audit.json"]:
        manifest["artifacts"][filename] = {"sha256": file_hash(output / filename), **metadata}
    write_json(output / "joint_run_manifest.json", manifest)
    return manifest
