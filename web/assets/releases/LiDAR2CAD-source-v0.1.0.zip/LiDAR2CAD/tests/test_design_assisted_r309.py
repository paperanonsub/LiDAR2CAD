from pathlib import Path

import numpy as np
from shapely.geometry import LineString

from parking_pipeline.design_assisted_r309 import (
    EvidenceSampler,
    apply_design_intervention,
    classify_candidates,
    generate_identity_candidates,
    match_walls_to_design,
    topology_proxy,
)


def _wall(wall_id: str, coordinates: list[list[float]]) -> dict:
    return {
        "wall_id": wall_id,
        "physical_wall_id": wall_id,
        "coordinates": coordinates,
        "status": "observed",
        "source": "fixture",
        "observed_support_fraction": 1.0,
    }


def test_design_identity_candidate_uses_same_segment() -> None:
    design = [{
        "design_wall_id": "DW-1",
        "design_segment_id": "DW-1-S0",
        "line": LineString([(0.0, 0.0), (5.0, 0.0)]),
    }]
    walls, matches = match_walls_to_design(
        [_wall("A", [[0.0, 0.02], [1.0, 0.02]]),
         _wall("B", [[2.0, -0.01], [3.0, -0.01]])],
        design,
        maximum_distance_m=0.5,
        maximum_direction_difference_deg=12.0,
    )
    candidates = generate_identity_candidates(
        walls,
        design,
        minimum_gap_m=0.15,
        maximum_gap_m=3.0,
        maximum_direction_difference_deg=12.0,
    )
    assert len(matches) == 2
    assert len(candidates) == 1
    assert candidates[0]["design_segment_id"] == "DW-1-S0"
    assert candidates[0]["host_wall_ids"] == ["A", "B"]


def test_evidence_gate_keeps_direct_support_and_rejects_opening(tmp_path: Path) -> None:
    evidence_path = tmp_path / "evidence.npz"
    semantic_path = tmp_path / "semantic.npz"
    shape = (4, 8)
    xy_cell = np.arange(shape[0] * shape[1], dtype=np.int64)
    np.savez_compressed(
        evidence_path,
        origin_xy=np.asarray([0.0, 0.0]),
        grid_m=np.asarray(0.05),
        shape=np.asarray(shape),
        xy_cell=xy_cell,
    )
    wall = np.ones(shape, np.float32)
    vehicle = np.zeros(shape, np.float32)
    voxel_probability = np.column_stack([np.ones(len(xy_cell)), np.zeros(len(xy_cell)),
                                          np.zeros(len(xy_cell))]).astype(np.float32)
    np.savez_compressed(
        semantic_path,
        wall_probability=wall,
        vehicle_probability=vehicle,
        agreement_probability=np.ones(shape, np.float32),
        voxel_probability=voxel_probability,
    )
    candidate = {
        "connection_id": "C", "wall_id": "C", "physical_wall_id": "C",
        "coordinates": [[0.05, 0.075], [0.30, 0.075]], "length_m": 0.25,
        "host_observed_support_fraction": [1.0, 1.0],
    }
    sampler = EvidenceSampler(evidence_path, semantic_path)
    accepted = classify_candidates(
        [candidate], sampler, [], apply_evidence_gate=True,
        direct_support_minimum=0.6, weak_support_minimum=0.45,
        vehicle_fraction_minimum=0.3, context_support_minimum=0.6,
        context_only_maximum_gap_m=1.0, opening_buffer_m=0.02,
    )[0]
    assert accepted["selected"]
    assert accepted["decision"] == "accepted_direct_wall_evidence"

    rejected = classify_candidates(
        [candidate], sampler,
        [{"design_opening_id": "DO-1", "line": LineString([(0.2, 0.0), (0.2, 0.2)])}],
        apply_evidence_gate=True, direct_support_minimum=0.6,
        weak_support_minimum=0.45, vehicle_fraction_minimum=0.3,
        context_support_minimum=0.6, context_only_maximum_gap_m=1.0,
        opening_buffer_m=0.02,
    )[0]
    assert not rejected["selected"]
    assert rejected["decision"] == "rejected_design_opening_conflict"


def test_topology_proxy_counts_components_and_dangling_nodes() -> None:
    disconnected = [_wall("A", [[0.0, 0.0], [1.0, 0.0]]),
                    _wall("B", [[2.0, 0.0], [3.0, 0.0]])]
    baseline = topology_proxy(disconnected, snap_m=0.05)
    connected = topology_proxy(disconnected + [_wall("C", [[1.0, 0.0], [2.0, 0.0]])],
                               snap_m=0.05)
    assert baseline["component_count"] == 2
    assert baseline["dangling_endpoint_count"] == 4
    assert connected["component_count"] == 1
    assert connected["dangling_endpoint_count"] == 2


def test_design_intervention_is_deterministic_and_does_not_mutate_input() -> None:
    design = {
        "wall_polylines": [
            {"design_wall_id": f"DW-{index}", "coordinates": [[0.0, index], [1.0, index]]}
            for index in range(20)
        ],
        "wall_segments": [
            {"design_wall_id": f"DW-{index}", "design_segment_id": f"DW-{index}-S0",
             "line": LineString([(0.0, index), (1.0, index)])}
            for index in range(20)
        ],
        "openings": [],
        "columns": [],
        "registration": {"mode": "fixture"},
    }
    first = apply_design_intervention(
        design, drop_fraction=0.25, perturb_x_m=0.3, perturb_y_m=-0.1, seed=309,
    )
    second = apply_design_intervention(
        design, drop_fraction=0.25, perturb_x_m=0.3, perturb_y_m=-0.1, seed=309,
    )
    first_ids = [value["design_wall_id"] for value in first["wall_segments"]]
    second_ids = [value["design_wall_id"] for value in second["wall_segments"]]
    assert first_ids == second_ids
    assert len(first_ids) < 20
    assert list(first["wall_segments"][0]["line"].coords)[0][0] == 0.3
    assert design["wall_polylines"][0]["coordinates"][0] == [0.0, 0]
    assert list(design["wall_segments"][0]["line"].coords)[0] == (0.0, 0.0)
