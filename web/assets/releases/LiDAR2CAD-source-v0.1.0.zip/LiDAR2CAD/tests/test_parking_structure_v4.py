from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Polygon

from parking_pipeline.structure_v4 import (
    VoxelEvidence,
    _face_support,
    optimise_closed_regions,
    split_connections_by_observation,
    update_shared_nodes,
)


def _evidence(points: np.ndarray, shape: tuple[int, int] = (80, 80)) -> VoxelEvidence:
    grid = 0.05
    origin = np.asarray([-1.0, -1.0])
    ij = np.floor((points - origin) / grid).astype(int)
    linear = np.unique(ij[:, 1] * shape[1] + ij[:, 0])
    raw = np.zeros(shape, dtype=bool)
    raw.flat[linear] = True
    count = len(linear)
    return VoxelEvidence(
        origin=origin,
        shape=shape,
        grid_m=grid,
        z_bin_m=0.10,
        global_floor_m=0.0,
        global_ceiling_m=2.5,
        raw_mask=raw,
        proposal_mask=raw.copy(),
        morphology_added_mask=np.zeros(shape, dtype=bool),
        cell_linear=linear,
        cell_z_min_m=np.zeros(count),
        cell_z_max_m=np.full(count, 2.0),
        cell_height_bin_count=np.full(count, 20, dtype=np.int16),
        cell_vertical_span_m=np.full(count, 2.0),
        cell_first_point_index=np.arange(count),
        local_surfaces=[],
        source_metrics={},
    )


def test_short_line_does_not_discard_other_junction_updates() -> None:
    records = [
        {"wall_id": "a", "line": LineString([(0, 0), (2, 0)]), "geometry_kind": "line", "status": "observed"},
        {"wall_id": "b", "line": LineString([(2.1, -1), (2.1, -0.1)]), "geometry_kind": "line", "status": "observed"},
        {"wall_id": "short", "line": LineString([(5, 5), (5.2, 5)]), "geometry_kind": "line", "status": "inferred_gap"},
    ]
    updated, _, metrics = update_shared_nodes(records, {"wall_junction_tolerance_m": 0.35})
    line_a = next(value["line"] for value in updated if value["wall_id"].startswith("a"))
    assert np.allclose(line_a.coords[-1], [2.1, 0.0], atol=1e-9)
    assert any(value["wall_id"] == "short" for value in updated)
    assert metrics["junction_endpoint_updates"] >= 2


def test_two_face_l_shape_does_not_support_four_column_faces() -> None:
    values = np.arange(0.0, 0.301, 0.05)
    points = np.vstack(
        [np.column_stack([values, np.zeros_like(values)]), np.column_stack([np.zeros_like(values), values])]
    )
    evidence = _evidence(points)
    tree = cKDTree(evidence.cell_xy)
    polygon = Polygon([(0, 0), (0.3, 0), (0.3, 0.3), (0, 0.3)])
    edges = [LineString([polygon.exterior.coords[i], polygon.exterior.coords[i + 1]]) for i in range(4)]
    support = [_face_support(edge, evidence, tree, {}) for edge in edges]
    assert sum(value["supported"] for value in support) <= 2


def test_inferred_short_edge_can_close_valid_region() -> None:
    observed = [
        {"wall_id": "w0", "line": LineString([(0.5, 0), (4, 0)]), "status": "observed"},
        {"wall_id": "w1", "line": LineString([(4, 0), (4, 4)]), "status": "observed"},
        {"wall_id": "w2", "line": LineString([(4, 4), (0, 4)]), "status": "observed"},
        {"wall_id": "w3", "line": LineString([(0, 4), (0, 0)]), "status": "observed"},
    ]
    inferred = [
        {
            "connection_id": "c0",
            "wall_id": "c0",
            "line": LineString([(0, 0), (0.5, 0)]),
            "status": "inferred_gap",
            "endpoint_keys": [["w3", 1], ["w0", 0]],
        }
    ]
    regions, selected, metrics = optimise_closed_regions(
        observed,
        inferred,
        [],
        {
            "closed_region_min_observed_fraction": 0.80,
            "closed_region_max_synthetic_fraction": 0.20,
            "closure_solver_timeout_s": 5,
        },
    )
    assert len(regions) == 1
    assert regions[0]["polygon"].is_valid
    assert {value["connection_id"] for value in selected} == {"c0"}
    assert metrics["closed_region_count"] == 1


def test_twenty_centimetre_gap_is_not_averaged_into_observed_line() -> None:
    left = np.column_stack([np.arange(0.0, 0.401, 0.05), np.zeros(9)])
    right = np.column_stack([np.arange(0.60, 1.001, 0.05), np.zeros(9)])
    evidence = _evidence(np.vstack([left, right]))
    connection = {
        "connection_id": "gap",
        "wall_id": "gap",
        "line": LineString([(0, 0), (1, 0)]),
        "status": "observed_recovery",
        "endpoint_keys": [["left", 1], ["right", 0]],
    }
    observed, inferred = split_connections_by_observation([connection], evidence, {})
    assert observed
    assert inferred
    assert sum(value["line"].length for value in inferred) >= 0.10
    assert all(value["status"] == "inferred_gap" for value in inferred)
