from __future__ import annotations

import cv2
import numpy as np

from parking_pipeline.projection_objects import (
    classify_height_projections,
    tangent_guided_propagation,
    trace_projection_wall_objects,
)
from parking_pipeline.v5_evidence import (
    HeightWindow,
    build_exact_voxel_evidence,
    height_windows,
)
from parking_pipeline.v5_objects import fit_column_across_height_windows


def test_tangent_growth_closes_sparse_wall_and_turns_at_supported_corner() -> None:
    support = np.zeros((44, 44), dtype=bool)
    support[28, 3:12] = True
    support[28, 17:29] = True
    support[12:20, 28] = True
    support[23:29, 28] = True
    # An equally sparse off-wall return is not enough to pull the path sideways.
    support[35, 13] = True
    traced, added, _ = tangent_guided_propagation(
        support.copy(),
        support,
        np.zeros_like(support),
        grid_m=0.10,
        cfg={
            "projection_trace_angles_deg": [0, 45, 90, 135],
            "projection_trace_lengths_m": [0.8],
            "projection_trace_iterations": 2,
            "projection_trace_minimum_hits": 3,
        },
    )
    assert traced[28, 12:17].all()
    assert traced[20:23, 28].all()
    count, labels = cv2.connectedComponents(traced.astype(np.uint8), connectivity=8)
    assert labels[28, 5] == labels[14, 28]
    assert labels[35, 13] != labels[28, 5]
    assert np.count_nonzero(added) >= 8


def test_projection_semantics_are_computed_inside_each_height_window() -> None:
    points = []
    for z in (0.2, 0.3, 0.6, 0.7, 1.0, 1.1):
        points.append([0.02, 0.02, z])
    evidence = build_exact_voxel_evidence(
        np.asarray(points),
        floor_m=0.0,
        ceiling_m=1.4,
        min_vertical_span_m=1.2,
        min_height_bins=11,
        min_top_above_floor_m=1.2,
        padding_m=0.0,
    )
    probability = np.tile(np.asarray([[0.92, 0.04, 0.04]], np.float32), (len(points), 1))
    windows = height_windows(0.0, 1.4, 0.5, 0.3, "thin")
    records, metrics = classify_height_projections(
        evidence,
        windows,
        probability,
        np.ones(len(points), dtype=bool),
        {"projection_minimum_height_bins": 2},
    )
    assert metrics["window_count"] == len(windows)
    assert sum(len(item.wall_cells) > 0 for item in records) >= 3
    # The physical evidence remains the same six xyz voxels despite appearing
    # in overlapping projection views.
    assert len(evidence.xy_cell) == 6


def test_wall_snake_absorbs_two_sparse_arms_through_a_supported_turn() -> None:
    xy = [(x, 0.025) for x in np.arange(0.025, 0.526, 0.05)]
    xy += [(1.025, y) for y in np.arange(0.525, 1.026, 0.05)]
    points = np.asarray([[x, y, z] for x, y in xy for z in (0.2, 0.3)])
    evidence = build_exact_voxel_evidence(
        points,
        floor_m=0.0,
        ceiling_m=1.2,
        min_vertical_span_m=1.2,
        min_height_bins=11,
        min_top_above_floor_m=1.2,
        padding_m=0.10,
    )
    probability = np.tile(
        np.asarray([[0.95, 0.03, 0.02]], np.float32),
        (len(evidence.xy_cell), 1),
    )
    projections, _ = classify_height_projections(
        evidence,
        [HeightWindow("thin_test", "thin", 0.0, 0.5)],
        probability,
        np.ones(len(evidence.xy_cell), dtype=bool),
        {"projection_minimum_height_bins": 2},
    )
    walls, metrics = trace_projection_wall_objects(
        evidence,
        projections,
        {
            "wall_candidate_min_length_m": 0.20,
            "projection_trace_min_seed_length_m": 0.35,
            "projection_trace_max_corner_extension_m": 0.80,
            "projection_trace_min_score": 0.30,
        },
    )
    assert metrics["selected_tangent_connection_count"] == 1
    assert metrics["ordered_wall_chain_count"] == 1
    assert len(walls) == 1
    assert walls[0]["absorbed_fragment_count"] == 2
    assert walls[0]["line"].length >= 1.8


def _rectangle_surface(center=(2.0, 3.0), width=0.6, length=0.9) -> np.ndarray:
    values = np.linspace(-0.5, 0.5, 15)
    cx, cy = center
    return np.asarray(
        [(cx + value * length, cy - width / 2) for value in values]
        + [(cx + length / 2, cy + value * width) for value in values]
        + [(cx + value * length, cy + width / 2) for value in values]
        + [(cx - length / 2, cy + value * width) for value in values]
    )


def test_column_height_views_fuse_one_center_and_dimensions_without_double_counting() -> None:
    surface = _rectangle_surface()
    points = np.vstack([surface for _ in range(12)])
    bins = np.repeat(np.arange(12), len(surface))
    fit = fit_column_across_height_windows(
        points,
        bins,
        [
            ("thin_a", "thin", 0, 5),
            ("thin_b", "thin", 3, 8),
            ("thin_c", "thin", 6, 11),
            ("thick_a", "thick", 0, 10),
            ("thick_b", "thick", 2, 12),
        ],
    )
    assert fit["status"] == "reliable"
    assert np.allclose(fit["center"], [2.0, 3.0], atol=0.04)
    assert np.allclose([fit["width_m"], fit["length_m"]], [0.6, 0.9], atol=0.05)
    assert fit["cross_height_observation_count"] >= 3
    assert fit["cross_height_fusion"].startswith("per_projection_fit")
