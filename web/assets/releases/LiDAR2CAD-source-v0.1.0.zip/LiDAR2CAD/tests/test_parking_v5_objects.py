from __future__ import annotations

import numpy as np

from parking_pipeline.v5_objects import (
    ColumnTemplate,
    fit_best_column_instance,
    fit_column_instance,
    learn_column_templates,
)


def _rectangle_surface(center=(2.0, 3.0), width=0.6, length=0.9, faces=(0, 1, 2, 3)):
    values = np.linspace(-0.5, 0.5, 21)
    result = []
    cx, cy = center
    for face in faces:
        if face == 0:
            result.extend((cx + value * length, cy - width / 2) for value in values)
        elif face == 1:
            result.extend((cx + length / 2, cy + value * width) for value in values)
        elif face == 2:
            result.extend((cx + value * length, cy + width / 2) for value in values)
        else:
            result.extend((cx - length / 2, cy + value * width) for value in values)
    return np.asarray(result)


def test_full_column_recovers_center_and_dimensions() -> None:
    points = _rectangle_surface()
    fit = fit_column_instance(points, np.arange(len(points)) % 15)
    assert fit["status"] == "reliable"
    assert np.allclose(fit["center"], [2.0, 3.0], atol=0.04)
    assert np.allclose([fit["width_m"], fit["length_m"]], [0.6, 0.9], atol=0.05)


def test_two_face_l_shape_requires_template_for_completion() -> None:
    points = _rectangle_surface(faces=(0, 3))
    initial = fit_column_instance(points, np.arange(len(points)) % 12)
    assert initial["status"] == "uncertain"
    assert len(initial["observed_edge_indices"]) <= 2
    template = ColumnTemplate("CT-000", 0.6, 0.9, 0.01, 4)
    completed = fit_column_instance(points, np.arange(len(points)) % 12, template=template)
    assert completed["status"] == "template_completed"
    assert completed["template_id"] == "CT-000"
    assert set(range(4)) - set(completed["observed_edge_indices"])


def test_templates_keep_different_column_sizes_separate() -> None:
    fitted = []
    for width, length in [(0.60, 0.90)] * 3 + [(0.85, 1.20)] * 3:
        fitted.append(
            {
                "identifiable_without_template": True,
                "width_m": width,
                "length_m": length,
            }
        )
    templates = learn_column_templates(fitted, dimension_tolerance_m=0.12)
    assert len(templates) == 2
    assert sorted(round(item.width_m, 2) for item in templates) == [0.6, 0.85]


def test_circular_column_selects_circle_and_recovers_center() -> None:
    angles = np.linspace(0.0, 2 * np.pi, 72, endpoint=False)
    points = np.column_stack([4.2 + 0.35 * np.cos(angles), -1.7 + 0.35 * np.sin(angles)])
    fit = fit_best_column_instance(points, np.arange(len(points)) % 14)
    assert fit["status"] == "reliable"
    assert fit["cross_section_model"] == "circle"
    assert np.allclose(fit["center"], [4.2, -1.7], atol=0.03)
    assert abs(fit["diameter_m"] - 0.70) <= 0.04


def test_loose_column_roi_keeps_supported_faces_and_reports_outliers() -> None:
    surface = _rectangle_surface()
    clutter = np.asarray(
        [[1.45, 2.50], [2.55, 3.50]] * 4,
        dtype=float,
    )
    points = np.vstack([surface, clutter])
    fit = fit_column_instance(points, np.arange(len(points)) % 15)
    assert fit["status"] == "reliable"
    assert len(fit["observed_edge_indices"]) >= 3
    assert fit["surface_inlier_fraction"] >= 0.70
    assert fit["residual_p95_m"] > fit["robust_residual_p95_m"]
