"""Behavioural tests independent of the evaluation GT."""
from copy import deepcopy
import json
from pathlib import Path
import sys

import ezdxf
import numpy as np
from shapely.geometry import LineString

from parking_pipeline.joint_reconstruction_v3 import (
    DEFAULT_CONFIG, PointEvidence, make_scene, reconstruct, validate_scene,
    export_scene, digest, apply_relations,
)


def fixture(gap_support=True, opening=False, design_y=.18, other_face=False):
    x = np.arange(0., 4.001, .025)
    if not gap_support:
        x = x[(x <= 1.5) | (x >= 2.1)]
    points = np.array([[xx, 0., z] for xx in x for z in [.5, .7, 1., 1.2]])
    walls = []
    for name, lo, hi in [("A", 0., 1.5), ("B", 2.1, 4.)]:
        y = .20 if other_face and name == "B" else .015
        rows = np.flatnonzero((points[:, 0] >= lo) & (points[:, 0] <= hi))
        walls.append({"wall_id": name, "coordinates": [[lo, y], [hi, y]],
                      "source_voxel_rows": rows.tolist(), "observed_support_fraction": 1.})
    if other_face:
        points[points[:, 0] >= 2.1, 1] = .20
    design = {"wall_segments": [{"design_segment_id": "D-S", "design_wall_id": "D",
                                 "line": LineString([[0, design_y], [4, design_y]])}],
              "openings": [{"design_opening_id": "O", "line": LineString([[1.6, -.2], [1.6, .2]])}] if opening else []}
    cfg = deepcopy(DEFAULT_CONFIG)
    scene = make_scene(walls, [], design, cfg)
    ev = PointEvidence(points, config=cfg)
    return scene, ev


def run(scene, ev):
    return reconstruct(scene, ev, progress=lambda *a, **k: None)


def test_multheight_fragments_recover_gap_and_share_identity():
    s, ev = fixture()
    s = run(s, ev)
    assert len(s["relations"]) == 1
    assert s["objects"]["A"]["wall_face_id"] == s["objects"]["B"]["wall_face_id"]
    assert len([o for o in s["objects"].values() if o["kind"] == "INFERRED_WALL_FACE"]) == 1
    assert validate_scene(s)["valid"]


def test_open_without_points_not_bridged_even_with_continuous_cad():
    s, ev = fixture(gap_support=False)
    s = run(s, ev)
    assert not s["relations"]
    assert all(o["kind"] != "INFERRED_WALL_FACE" for o in s["objects"].values())


def test_design_opening_vetoes_even_supported_proposal():
    s, ev = fixture(opening=True)
    s = run(s, ev)
    assert not s["relations"]
    assert any(c["decision"] == "design_opening_conflict" for c in s["final_candidates"])


def test_biased_design_corrected_by_lidar_and_used_in_reassociation():
    s, ev = fixture(design_y=.30)
    s = run(s, ev)
    d = s["design_entities"]["D-S"]
    assert d["original_geometry"][0][1] == .30
    assert abs(d["validated_faces"][0]["coordinates"][0][1]) < .002
    assert abs(s["objects"]["A"]["current_geometry"][0][1]) < .002
    assert s["objects"]["A"]["design_correspondence"]["mean_distance_m"] < .002
    assert any(c["action"] == "reassociate" for c in s["design_changes"])


def test_opposite_wall_faces_do_not_merge_on_shared_design_identity():
    s, ev = fixture(other_face=True, design_y=.10)
    s = run(s, ev)
    assert not s["relations"]
    assert s["objects"]["A"]["wall_face_id"] != s["objects"]["B"]["wall_face_id"]
    assert len(s["design_entities"]["D-S"]["validated_faces"]) == 2


def test_connector_recomputed_with_stable_ids_and_export_hashes(tmp_path):
    s, ev = fixture()
    s = run(s, ev)
    rid = s["relations"][0]["predicted_relation_id"]
    candidate = next(c for c in s["final_candidates"] if c["selected"])
    # Simulate a subsequent supported endpoint update and commit the recomputed connector.
    s["objects"]["A"]["current_geometry"][-1][0] += .01
    candidate["coordinates"][0] = deepcopy(s["objects"]["A"]["current_geometry"][-1])
    apply_relations(s, [candidate], 99)
    assert s["relations"][0]["predicted_relation_id"] == rid
    assert validate_scene(s)["valid"]
    manifest = export_scene(s, tmp_path, "synthetic-run", {})
    topo = json.loads((tmp_path / "joint_final_topology.json").read_text())
    state = json.loads((tmp_path / "joint_scene_state.json").read_text())
    assert manifest["scene_state_sha256"] == topo["scene_state_sha256"] == state["scene_state_sha256"]
    payload = {k: v for k, v in state.items() if k not in ["scene_state_sha256", "scene_hash_definition"]}
    assert digest(payload) == state["scene_state_sha256"]
    doc = ezdxf.readfile(tmp_path / "joint_final_geometry.dxf")
    for relation in topo["relations"]:
        for handle in relation["dxf_host_handles"] + relation["dxf_geometry_handles"]:
            assert relation["predicted_relation_id"] in [t.value for t in doc.entitydb[handle].get_xdata("LIDAR2CAD_JOINT")]


def test_selection_is_deterministic():
    a, ea = fixture()
    b, eb = fixture()
    assert digest(run(a, ea)) == digest(run(b, eb))


def test_low_height_occlusion_recovered_using_other_heights():
    s, ev = fixture()
    points = ev.points.copy()
    # In the gap, low returns are occluded while two higher bins see the face.
    mask = (points[:,0] > 1.5) & (points[:,0] < 2.1) & (points[:,2] < .9)
    probabilities = np.tile([1.,0.,0.], (len(points),1))
    probabilities[mask] = [0.,0.,1.]
    ev = PointEvidence(points, probabilities, s["config"])
    s = run(s, ev)
    assert len(s["relations"]) == 1
    assert s["relations"][0]["evidence"]["multiheight_coverage"] > .9


def test_one_height_only_cannot_confirm_a_wall_gap():
    s, ev = fixture()
    probabilities = np.tile([1.,0.,0.], (len(ev.points),1))
    mask = (ev.points[:,0] > 1.5) & (ev.points[:,0] < 2.1) & (ev.points[:,2] > .5)
    probabilities[mask] = [0.,0.,1.]
    ev = PointEvidence(ev.points, probabilities, s["config"])
    assert not run(s, ev)["relations"]


def corner_fixture(supported=True, opening=False):
    x = np.arange(0, 2.001, .025)
    points = np.array([[t, 0., z] for t in x for z in [.5,.8,1.1,1.4]] +
                      [[2., t, z] for t in x for z in [.5,.8,1.1,1.4]])
    if not supported:
        points = points[(points[:,0] <= 1.7) | (points[:,1] >= .3)]
    walls = [{"wall_id":"A", "coordinates":[[0,0],[1.7,0]], "observed_support_fraction":1.,
              "source_voxel_rows":np.flatnonzero(points[:,0]<=1.7).tolist()},
             {"wall_id":"B", "coordinates":[[2,.3],[2,2]], "observed_support_fraction":1.,
              "source_voxel_rows":np.flatnonzero(points[:,1]>=.3).tolist()}]
    design = {"wall_segments":[], "openings":[{"design_opening_id":"O", "line":LineString([[1.9,-.2],[1.9,.2]])}] if opening else []}
    cfg = deepcopy(DEFAULT_CONFIG)
    return make_scene(walls, [], design, cfg), PointEvidence(points, config=cfg)


def test_supported_corner_connects_without_face_identity_union(tmp_path):
    s, ev = corner_fixture()
    s = run(s, ev)
    assert len(s["relations"]) == 1
    assert s["relations"][0]["relation_semantics"] == "distinct_face_junction"
    assert s["objects"]["A"]["wall_face_id"] != s["objects"]["B"]["wall_face_id"]
    assert len(s["relations"][0]["connection_geometry"]) == 3
    assert validate_scene(s)["valid"]
    assert export_scene(s, tmp_path, "corner", {})["checks"]["valid"]


def test_unsupported_corner_and_design_opening_remain_unconnected():
    for supported, opening in [(False, False), (True, True)]:
        s, ev = corner_fixture(supported, opening)
        assert not run(s, ev)["relations"]


def test_corrected_design_direction_is_consumed_by_later_refit():
    s, ev = fixture(design_y=.15)
    s["design_entities"]["D-S"]["original_geometry"] = [[0,.15],[4,.35]]
    s["config"]["max_iterations"] = 12
    one = deepcopy(s); one["config"]["design_feedback"] = False
    full, oneway = run(s, ev), run(one, ev)
    assert full["design_changes"]
    assert any(c["action"] == "face_refit" and c["iteration"] > 1 for c in full["geometry_changes"])
    assert full["objects"]["A"]["current_geometry"] != oneway["objects"]["A"]["current_geometry"]
