from __future__ import annotations

import numpy as np
from shapely.geometry import LineString

from parking_pipeline.v5_evidence import (
    _best_run_with_one_gap,
    build_exact_voxel_evidence,
    curve_observation_audit,
    height_windows,
    multiscale_fusion,
    window_occupancy,
)


def _column(x: float, z_values: np.ndarray) -> np.ndarray:
    return np.column_stack([np.full(len(z_values), x), np.zeros(len(z_values)), z_values])


def test_longest_run_keeps_valid_subrun_after_two_bin_gap() -> None:
    assert _best_run_with_one_gap(np.asarray([0, 1, 2, 5, 6, 7, 8])) == (5, 8, 4)


def test_five_centimetre_cells_do_not_borrow_vertical_support() -> None:
    tall = _column(0.01, np.arange(0.2, 2.31, 0.1))
    short = _column(0.11, np.arange(0.2, 0.71, 0.1))
    evidence = build_exact_voxel_evidence(
        np.vstack([tall, short]),
        floor_m=0.0,
        ceiling_m=2.5,
        min_vertical_span_m=1.2,
        min_height_bins=11,
        min_top_above_floor_m=1.2,
        padding_m=0.0,
    )
    assert len(evidence.structural_xy_cell) == 1
    assert np.isclose(evidence.structural_xy[0, 0], 0.025)


def test_height_windows_append_top_aligned_tail_without_changing_ids() -> None:
    thin = height_windows(0.0, 2.675, 0.5, 0.3, "thin")
    assert thin[0].window_id == "thin_0.000_0.500"
    assert thin[-1].window_id == "thin_2.175_2.675"
    assert np.isclose(thin[-1].z_max_m, 2.675)


def test_overlap_windows_do_not_create_observed_support() -> None:
    z = np.asarray([0.2, 0.3])
    evidence = build_exact_voxel_evidence(
        _column(0.01, z),
        floor_m=0.0,
        ceiling_m=2.5,
        min_vertical_span_m=1.2,
        min_height_bins=11,
        min_top_above_floor_m=1.2,
        padding_m=0.0,
    )
    thin = window_occupancy(evidence, height_windows(0.0, 2.5, 0.5, 0.3, "thin"))
    thick = window_occupancy(evidence, height_windows(0.0, 2.5, 1.0, 0.5, "thick"))
    observed, candidate, metrics = multiscale_fusion(evidence, thin, thick)
    assert not observed.any()
    assert candidate.any()
    assert metrics["confidence_definition"].startswith("unique_xyz_bins")


def test_curve_audit_does_not_fill_twenty_centimetre_gap() -> None:
    left_x = np.arange(0.0, 0.401, 0.05)
    right_x = np.arange(0.60, 1.001, 0.05)
    z = np.asarray([0.3, 0.4])
    points = np.vstack(
        [np.asarray([[x, 0.0, height] for x in left_x for height in z]),
         np.asarray([[x, 0.0, height] for x in right_x for height in z])]
    )
    evidence = build_exact_voxel_evidence(
        points,
        floor_m=0.0,
        ceiling_m=2.5,
        min_vertical_span_m=1.2,
        min_height_bins=11,
        min_top_above_floor_m=1.2,
        padding_m=0.05,
    )
    audit = curve_observation_audit(
        LineString([(0.0, 0.0), (1.0, 0.0)]), evidence, distance_m=0.06
    )
    supported = np.asarray(audit["supported"], dtype=bool)
    assert not supported[9:12].any()

