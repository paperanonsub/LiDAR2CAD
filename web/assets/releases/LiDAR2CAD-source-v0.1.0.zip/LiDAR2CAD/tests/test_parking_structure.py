import cv2
import numpy as np
from shapely.geometry import LineString

from parking_pipeline.structure import detect_column_rectangles, merge_wall_fragments


def _cfg() -> dict:
    return {
        "wall_source_min_length_m": 0.20,
        "wall_min_length_m": 0.50,
        "wall_merge_angle_deg": 3.0,
        "wall_merge_offset_m": 0.08,
        "wall_staggered_merge_angle_deg": 5.0,
        "wall_staggered_merge_offset_m": 0.25,
        "wall_parallel_overlap_guard_m": 0.30,
        "wall_group_gap_m": 1.20,
        "wall_observed_join_gap_m": 0.25,
        "wall_inferred_gap_m": 1.20,
        "wall_support_distance_m": 0.15,
        "wall_observed_min_support": 0.50,
        "wall_inferred_min_support": 0.20,
        "wall_junction_tolerance_m": 0.20,
        "column_min_cells": 4,
        "column_min_side_m": 0.15,
        "column_max_side_m": 1.0,
        "column_max_aspect": 2.5,
        "column_min_area_m2": 0.02,
        "column_max_area_m2": 1.0,
        "column_side_support_distance_m": 0.12,
        "column_side_min_support": 0.40,
        "column_min_mean_support": 0.30,
        "column_confirmed_side_count": 3,
        "column_wall_clearance_m": 0.10,
    }


def _mask_for_lines(lines: list[LineString], shape=(100, 140), grid=0.05) -> np.ndarray:
    mask = np.zeros(shape, dtype=np.uint8)
    for line in lines:
        pixels = np.rint(np.asarray(line.coords) / grid).astype(np.int32)
        cv2.polylines(mask, [pixels.reshape(-1, 1, 2)], False, 255, 1)
    return mask


def test_fragment_merge_straightens_and_marks_large_gap_inferred() -> None:
    lines = [
        LineString([(0.0, 1.0), (2.0, 1.01)]),
        LineString([(2.15, 1.0), (4.0, 1.0)]),
        LineString([(4.65, 1.01), (6.0, 1.0)]),
    ]
    mask = _mask_for_lines(lines)
    # Sparse points inside the 65 cm gap make it a supported inference rather
    # than an unobserved wall.
    cv2.line(mask, (80, 20), (93, 20), 255, 1)
    observed, inferred, _ = merge_wall_fragments(
        lines, mask, np.zeros(2), 0.05, _cfg()
    )
    assert len(observed) == 2
    assert len(inferred) == 1
    assert 0.50 < inferred[0]["line"].length < 0.80
    assert all(abs(np.diff(np.asarray(value["line"].coords), axis=0)[0, 1]) < 0.05 for value in observed)


def test_parallel_faces_fifteen_centimetres_apart_are_not_merged() -> None:
    lines = [
        LineString([(0.0, 1.0), (3.0, 1.0)]),
        LineString([(0.0, 1.15), (3.0, 1.15)]),
    ]
    mask = _mask_for_lines(lines)
    observed, inferred, metrics = merge_wall_fragments(
        lines, mask, np.zeros(2), 0.05, _cfg()
    )
    assert len(observed) == 2
    assert not inferred
    assert metrics["axis_group_count"] == 2


def test_non_overlapping_staggered_fragments_share_the_stronger_axis() -> None:
    lines = [
        LineString([(0.0, 1.0), (3.0, 1.0)]),
        LineString([(3.15, 1.18), (5.0, 1.18)]),
    ]
    mask = _mask_for_lines(lines)
    observed, _, metrics = merge_wall_fragments(
        lines, mask, np.zeros(2), 0.05, _cfg()
    )
    assert metrics["axis_group_count"] == 1
    assert len(observed) == 1
    coordinates = np.asarray(observed[0]["line"].coords)
    assert np.max(np.abs(coordinates[:, 1] - 1.0)) < 0.05


def test_closed_compact_vertical_component_becomes_column() -> None:
    mask = np.zeros((80, 80), dtype=np.uint8)
    cv2.rectangle(mask, (25, 25), (35, 37), 255, 1)
    columns, uncertain = detect_column_rectangles(
        mask, np.zeros(2), 0.05, [], _cfg()
    )
    assert len(columns) == 1
    assert not uncertain
    assert columns[0]["polygon"].is_valid
    assert columns[0]["supported_side_count"] >= 3
