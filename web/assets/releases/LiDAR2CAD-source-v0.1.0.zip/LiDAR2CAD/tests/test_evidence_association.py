from __future__ import annotations

import json
import numpy as np
import ezdxf
import yaml
from shapely.geometry import LineString

from parking_pipeline.evidence_association import (HeightFragment, ObjectEvidenceIndex,
    associate_height_fragments, annotate_dual_evidence, enrich_connection_evidence, longest_missing_run)
from parking_pipeline.v5_evidence import (HeightWindow, build_exact_voxel_evidence, save_exact_evidence)
from parking_pipeline.topology_v6 import select_continuity_connections
from parking_pipeline.structure_v4 import update_shared_nodes, write_architectural_dxf
from parking_pipeline.reconstruction_r309 import run_reconstruction
from parking_pipeline.structure_v4 import _plain_properties
from lidar2outline.io import write_point_cloud


def fragment(name, window, y, rows, low=.2, high=.6):
    return HeightFragment(name, window, low, high, LineString([(0, y), (1, y)]),
                          np.array([1., 0.]), np.asarray(rows))


def evidence(lines, heights=None):
    heights = heights if heights is not None else np.arange(.21, 1.52, .1)
    points = [[*line.interpolate(float(s)).coords[0], z] for line in lines
              for s in np.arange(0, line.length + .001, .05) for z in heights]
    return build_exact_voxel_evidence(np.asarray(points), floor_m=0., ceiling_m=2., padding_m=.1)


def wall(name, line, exact, mask=None):
    return dict(wall_id=name, association_object_ids=[name], line=line, geometry_kind='line',
                status='observed', source='test',
                source_voxel_rows=np.flatnonzero(mask).tolist() if mask is not None else list(range(len(exact.centroids))))


def candidate(line):
    return dict(connection_id='c', endpoint_keys=[['a', 1], ['b', 0]], kind='collinear',
                line=line, source='test', status='inferred_gap', score=.95,
                strict_support_fraction=1., relaxed_support_fraction=1.,
                orientation_score=1., attachment_support_score=1.)


def test_separated_heights_associate_without_shared_voxel_and_deduplicate():
    objects, report = associate_height_fragments([fragment('a', 'low', 0, [0, 1]),
        fragment('b', 'high', 0, [2, 3], 1., 1.4), fragment('c', 'overlap', 0, [1, 2])], {})
    assert len(objects) == 1
    assert objects[0]['source_voxel_rows'] == [0, 1, 2, 3]
    assert report['unique_source_voxel_count'] == 4


def test_parallel_walls_and_transitive_drift_do_not_merge():
    objects, report = associate_height_fragments([fragment('a', 'w1', 0, [0]),
        fragment('b', 'w2', .03, [1]), fragment('c', 'w3', .06, [2])], {})
    assert len(objects) == 2
    assert report['group_conflicts_rejected'] >= 1
    objects, _ = associate_height_fragments([fragment('a', 'w1', 0, [0]),
                                            fragment('b', 'w2', .08, [1])], {})
    assert len(objects) == 2


def test_group_recheck_uses_unique_sources_without_absorbing_parallel_wall():
    fragments = [
        fragment('a', 'w1', 0.00, [0, 1]),
        fragment('b', 'w2', 0.02, [2, 3]),
        fragment('c', 'w3', 0.04, [4, 5]),
        fragment('parallel', 'w4', 0.09, [6, 7]),
    ]
    source_xy = np.asarray([
        [0., 0.00], [1., 0.00],
        [0., 0.02], [1., 0.02],
        [0., 0.04], [1., 0.04],
        [0., 0.09], [1., 0.09],
    ])
    objects, report = associate_height_fragments(
        fragments,
        {
            'association_group_recheck_enabled': True,
            'association_group_recheck_p95_m': .025,
            'association_group_recheck_max_m': .03,
        },
        source_xy=source_xy,
    )
    assert len(objects) == 2
    assert sorted(len(value['fragment_ids']) for value in objects) == [1, 3]
    assert report['group_recheck_accepted_count'] == 1


def test_group_recheck_requires_source_coordinates():
    with np.testing.assert_raises_regex(ValueError, 'requires source_xy'):
        associate_height_fragments(
            [fragment('a', 'w1', 0.0, [0, 1])],
            {'association_group_recheck_enabled': True},
        )


def test_height_gap_limit_and_direction_limit_are_executable():
    upper = fragment('b', 'high', 0, [1], 2., 2.3)
    assert len(associate_height_fragments([fragment('a', 'low', 0, [0]), upper], {})[0]) == 2
    upper.z_min_m, upper.z_max_m = .4, .8
    upper.tangent = np.array([0., 1.])
    assert len(associate_height_fragments([fragment('a', 'low', 0, [0]), upper], {})[0]) == 2


def test_weak_observation_is_not_inference_and_high_window_never_fills_low():
    line = LineString([(0, 0), (1, 0)])
    exact = evidence([line], [.81, .91])
    record = wall('a', line, exact)
    annotated = annotate_dual_evidence([record], ObjectEvidenceIndex(exact, [record]),
        [HeightWindow('low', 'thin', .2, .7), HeightWindow('high', 'thin', .8, 1.3)])[0]
    assert all(i['state'] == 'observed' and i['evidence_strength'] == 'weak' for i in annotated['support_intervals'])
    assert all(i['state'] == 'unknown' for i in annotated['window_evidence']['low'])
    assert all(i['state'] == 'observed' for i in annotated['window_evidence']['high'])


def test_foreign_parallel_surface_cannot_pass_standard_or_observed_gate():
    a, b, foreign = (LineString([(0, 0), (.4, 0)]), LineString([(1, 0), (1.4, 0)]),
                     LineString([(.4, .05), (1, .05)]))
    exact = evidence([a, b, foreign])
    xy = exact.centroids[:, :2]
    walls = [wall('a', a, exact, (xy[:, 0] < .41) & (xy[:, 1] < .025)),
             wall('b', b, exact, (xy[:, 0] > .99) & (xy[:, 1] < .025)),
             wall('foreign', foreign, exact, xy[:, 1] > .025)]
    cfg = dict(object_consistent_gate=True)
    c = enrich_connection_evidence([candidate(LineString([(.4, 0), (1, 0)]))], walls, ObjectEvidenceIndex(exact, walls), cfg)[0]
    assert c['geometric_support_fraction'] > .85
    assert c['object_support_fraction'] < .2
    assert c['foreign_support_fraction'] > .7
    assert not c['object_evidence_eligible']
    for status in ['observed', 'inferred_gap']:
        c['status'] = status
        observed, inferred, _ = select_continuity_connections([c], cfg)
        assert not observed and not inferred


def test_multi_hypothesis_recovers_split_wall_as_inference_only():
    first = LineString([(0, 0), (.3, 0)])
    bridge = LineString([(.3, 0), (.7, 0)])
    second = LineString([(.7, 0), (1., 0)])
    exact = evidence([first, bridge, second])
    xy = exact.centroids[:, :2]
    walls = [
        wall('a', first, exact, xy[:, 0] < .3),
        wall('bridge', bridge, exact, (xy[:, 0] >= .3) & (xy[:, 0] <= .7)),
        wall('b', second, exact, xy[:, 0] > .7),
    ]
    hard_cfg = dict(object_consistent_gate=True, object_ownership_mode='hard')
    soft_cfg = dict(object_consistent_gate=True, object_ownership_mode='multi_hypothesis')
    source = candidate(LineString([(.3, 0), (.7, 0)]))
    index = ObjectEvidenceIndex(exact, walls)
    hard = enrich_connection_evidence([source], walls, index, hard_cfg)[0]
    soft = enrich_connection_evidence([source], walls, index, soft_cfg)[0]
    assert not hard['object_evidence_eligible']
    assert soft['compatible_hypothesis_object_ids'] == ['bridge']
    assert soft['compatible_support_fraction'] > .5
    assert soft['object_evidence_eligible'], {
        key: soft[key] for key in [
            'soft_support_fraction', 'object_support_fraction',
            'foreign_support_fraction', 'object_p95_m',
            'host_support_fraction', 'compatible_support_fraction',
        ]
    }
    assert soft['status'] == 'inferred_gap'
    observed, inferred, _ = select_continuity_connections([soft], soft_cfg)
    assert not observed and len(inferred) == 1


def test_multi_hypothesis_does_not_borrow_parallel_foreign_wall():
    first = LineString([(0, 0), (.4, 0)])
    second = LineString([(.6, 0), (1., 0)])
    parallel = LineString([(.4, .05), (.6, .05)])
    exact = evidence([first, second, parallel])
    xy = exact.centroids[:, :2]
    walls = [
        wall('a', first, exact, (xy[:, 0] < .4) & (xy[:, 1] < .025)),
        wall('parallel', parallel, exact, xy[:, 1] > .025),
        wall('b', second, exact, (xy[:, 0] > .6) & (xy[:, 1] < .025)),
    ]
    cfg = dict(object_consistent_gate=True, object_ownership_mode='multi_hypothesis')
    result = enrich_connection_evidence(
        [candidate(LineString([(.4, 0), (.6, 0)]))], walls,
        ObjectEvidenceIndex(exact, walls), cfg,
    )[0]
    assert not result['compatible_hypothesis_object_ids']
    assert result['foreign_support_fraction'] > .5
    assert not result['object_evidence_eligible']


def test_small_blind_gap_can_be_inferred_but_not_measured():
    a, b = LineString([(0, 0), (.4, 0)]), LineString([(.55, 0), (1., 0)])
    exact = evidence([a, b])
    walls = [wall('a', a, exact, exact.centroids[:, 0] < .5),
             wall('b', b, exact, exact.centroids[:, 0] > .5)]
    cfg = dict(object_consistent_gate=True)
    index = ObjectEvidenceIndex(exact, walls)
    c = enrich_connection_evidence([candidate(LineString([(.4, 0), (.55, 0)]))], walls, index, cfg)[0]
    assert c['continuation_eligible']
    observed, inferred, _ = select_continuity_connections([c], cfg)
    assert not observed and len(inferred) == 1
    final = annotate_dual_evidence(inferred, index, [])
    assert any(i['state'] == 'inferred' and i['evidence_strength'] == 'absent' for i in final[0]['support_intervals'])


def test_node_children_and_dxf_preserve_interval_strength(tmp_path):
    full = LineString([(0, 0), (1, 0)])
    exact = evidence([LineString([(0, 0), (.4, 0)])])
    host = wall('a', full, exact)
    children, _, _ = update_shared_nodes([host, dict(wall_id='t', line=LineString([(.5, 0), (.5, 1)]),
        status='inferred_gap', source='test', geometry_kind='line')], {'wall_junction_tolerance_m': .001})
    children = annotate_dual_evidence(children, ObjectEvidenceIndex(exact, [host]), [])
    assert any(w['status'] != 'observed' for w in children)
    output = tmp_path / 'test.dxf'
    write_architectural_dxf(output, [], children, [], [])
    entities = list(ezdxf.readfile(output).modelspace())
    assert any(e.dxf.layer == 'WALL_OBSERVED' for e in entities)
    assert any(e.dxf.layer == 'WALL_UNKNOWN' for e in entities)
    assert all(e.has_xdata('LIDAR2EVIDENCE') for e in entities)


def test_no_phantom_missing_run():
    assert longest_missing_run({'sample_arclength_m': [0., .05, .1], 'supported': [True]*3}, .1) == 0


def test_nested_provenance_survives_geojson_serialization():
    properties = _plain_properties({'provenance': {'kind': 'test', 'rows': np.array([1, 2])},
                                    'window_evidence': {'low': [{'distance': np.float64(.02)}]},
                                    'line': LineString([(0, 0), (1, 0)])}, {'line'})
    assert json.loads(json.dumps(properties))['provenance']['rows'] == [1, 2]
    assert properties['window_evidence']['low'][0]['distance'] == .02


def test_accepted_connections_cannot_cross_when_constraint_enabled():
    first = candidate(LineString([(0, 0), (1, 1)]))
    first.update(status='observed', strict_full_support_fraction=1.)
    second = dict(first, connection_id='d', endpoint_keys=[['d', 1], ['e', 0]],
                  line=LineString([(0, 1), (1, 0)]))
    accepted, inferred, _ = select_continuity_connections([first, second],
                                      {'topology_enforce_connection_crossings': True})
    assert len(accepted) + len(inferred) == 1


def test_raw_cloud_input_without_annotations_or_semantic_cache(tmp_path):
    exact = evidence([LineString([(0, 0), (2, 0)])])
    cloud = tmp_path / 'registered.pcd'
    # Avoid placing a re-voxelized synthetic fixture exactly on XY bin borders.
    points = exact.centroids.astype(float).copy()
    points[:, :2] += .013
    write_point_cloud(cloud, points)
    cfg = {'project': {'output_dir': str(tmp_path / 'out')}, 'parking_structure':
           {'input_cloud': str(cloud), 'floor_m': 0., 'ceiling_m': 2.,
            'automatic_columns': False, 'topology_directional_trace_enabled': False}}
    path = tmp_path / 'raw.yaml'
    path.write_text(yaml.safe_dump(cfg), encoding='utf-8')
    report = run_reconstruction(path)
    assert report['association']['object_count'] > 0
    assert (tmp_path / 'out/exact_voxels.npz').is_file()
    assert ezdxf.readfile(tmp_path / 'out/architectural_plan.dxf').modelspace()


def test_point_evidence_only_end_to_end_and_frozen_candidates(tmp_path):
    exact = evidence([LineString([(0, 0), (2, 0)])])
    cache = tmp_path / 'points.npz'
    save_exact_evidence(cache, exact)
    cfg = {'project': {'output_dir': str(tmp_path / 'v2')}, 'parking_structure':
           {'input_evidence_cache': str(cache), 'automatic_columns': False,
            'object_consistent_gate': False, 'topology_directional_trace_enabled': False}}
    path = tmp_path / 'v2.yaml'
    path.write_text(yaml.safe_dump(cfg), encoding='utf-8')
    first = run_reconstruction(path)
    assert first['association']['object_count'] > 0
    graph = json.loads((tmp_path / 'v2/building_object_graph.json').read_text(encoding='utf-8'))
    assert graph['walls'] and graph['walls'][0]['window_evidence']
    cfg['project']['output_dir'] = str(tmp_path / 'v3')
    cfg['parking_structure'].update(object_consistent_gate=True,
        frozen_candidate_file=str(tmp_path / 'v2/frozen_candidates.json'))
    path.write_text(yaml.safe_dump(cfg), encoding='utf-8')
    second = run_reconstruction(path)
    assert not second['validation']['independent_accuracy_evaluated']
    assert json.loads((tmp_path / 'v2/frozen_candidates.json').read_text()) == json.loads((tmp_path / 'v3/frozen_candidates.json').read_text())
