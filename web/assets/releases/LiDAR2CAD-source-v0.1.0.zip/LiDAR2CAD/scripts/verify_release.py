"""Verify release contents without claiming to reproduce reported benchmark scores."""
import ast
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    manifest = json.loads((ROOT / "SOURCE_MANIFEST.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        path = ROOT / item["path"]
        assert path.is_file(), item["path"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"], item["path"]
        assert not Path(item["path"]).is_absolute()
        if path.suffix == ".py":
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=item["path"])
    for name in ["LICENSE", "LICENSE-DATA.md", "THIRD_PARTY_NOTICES.md"]:
        assert (ROOT / name).is_file()
    results = ROOT / "data/reported_results"
    reported = json.loads((results / "author_results.json").read_text(encoding="utf-8"))
    assert reported["locally_rerun"] is False
    assert reported["independent_audit"] == "not_performed"
    for number, table in enumerate(reported["tables"], 1):
        with (results / f"table_{number:02d}.csv").open(encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.reader(handle))
        assert rows == [table["headers"], *table["rows"]], f"CSV differs: {number}"
    fixture = json.loads((ROOT / "data/synthetic_demo/input.json").read_text(encoding="utf-8"))
    assert fixture["is_synthetic"] is True
    inventory = json.loads((ROOT / "data/DATA_INVENTORY.json").read_text(encoding="utf-8"))
    assert all(item["public_archive_included"] is False for item in inventory["field_inputs"])
    print(json.dumps({"verified_files": len(manifest["files"]), "lossless_csv_tables": len(reported["tables"]),
                      "synthetic_fixture_labeled": True, "paper_benchmark_rerun": False, "status": "passed"}, indent=2))


if __name__ == "__main__":
    main()
