"""Run a synthetic joint-reconstruction fixture; this is not a field benchmark."""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np
from shapely.geometry import LineString
from parking_pipeline.joint_reconstruction_v3 import (
    DEFAULT_CONFIG, PointEvidence, make_scene, reconstruct, validate_scene, export_scene,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "data/synthetic_demo/input.json")
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/synthetic_demo")
    args = parser.parse_args()
    raw = json.loads(args.input.read_text(encoding="utf-8"))
    if raw.get("is_synthetic") is not True:
        raise ValueError("The demo expects an explicitly labeled synthetic input")
    points = np.asarray(raw["points"], dtype=float)
    design = {"wall_segments": [dict(item, line=LineString(item["coordinates"])) for item in raw["design_segments"]],
              "openings": [dict(item, line=LineString(item["coordinates"])) for item in raw["design_openings"]]}
    config = deepcopy(DEFAULT_CONFIG)
    config.update(raw.get("config_overrides", {}))
    scene = make_scene(raw["walls"], [], design, config)
    scene["coordinate_frame"] = "Synthetic local Cartesian frame; XY/Z in metres; not ICPARK"
    scene = reconstruct(scene, PointEvidence(points, config=config), progress=lambda *a, **k: None)
    validation = validate_scene(scene)
    if not validation["valid"]:
        raise RuntimeError(f"Invalid scene: {validation}")
    if len(scene["relations"]) != 1:
        raise RuntimeError("Expected one supported connection in the synthetic fixture")
    args.output.mkdir(parents=True, exist_ok=True)
    source_hash = hashlib.sha256(args.input.read_bytes()).hexdigest()
    export_scene(scene, args.output, "synthetic-smoke-demo", {"synthetic_input_sha256": source_hash})
    report = {"is_synthetic": True, "purpose": "API and export smoke test, not a paper benchmark", "point_count": len(points),
              "relation_count": len(scene["relations"]), "validation": validation, "input_sha256": source_hash}
    (args.output / "demo_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
