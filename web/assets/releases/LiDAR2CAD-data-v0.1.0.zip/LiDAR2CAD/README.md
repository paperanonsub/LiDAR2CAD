# LiDAR2CAD

Joint structural reconstruction from LiDAR observations and design CAD for
underground parking garages.

This is a curated source-and-data release, separate from the working research
directory. Code is licensed under MIT. Original released tabular data and
synthetic fixtures are licensed under CC BY 4.0; see LICENSE-DATA.md for scope.
No public repository address has been assigned yet. Preparing this folder does
not create a remote repository or publish it on the Internet.

## What is actually included?

| Component | Location | Scope |
| --- | --- | --- |
| Reconstruction code | parking_pipeline/, lidar2outline/ | Local implementation snapshot; not the missing off-machine snapshot |
| Minimal joint demo | scripts/run_joint_demo.py | Evidence-conditioned correction and DXF export |
| Reconstruction configuration | configs/R309_portable.yaml | Bring your own registered, gravity-aligned cloud |
| Regression tests | tests/ | Behavioral tests; not scene benchmark scores |
| Synthetic input | data/synthetic_demo/ | Explicitly synthetic geometry and source points |
| Reported numerical data | data/reported_results/ | Original JSON, lossless CSV exports, and manuscript tables |
| Availability inventory | data/DATA_INVENTORY.json | Describes unreleased field inputs and missing current-run artifacts |
| Traceability | SOURCE_MANIFEST.json | Original file paths, source hashes, and documented packaging changes |

The synthetic demo is never represented as a field experiment or benchmark.
The reported tables are author-confirmed off-machine measurements. Local unit
tests do not independently validate those measurements. Historical local
reference geometry is not substituted for the current manuscript's references.

## Install

Python 3.10 or newer is required. A clean virtual environment is recommended.
For the small joint demo and its regression tests:

    python -m pip install -e ".[dev]"
    python scripts/run_joint_demo.py
    python -m pytest tests/test_joint_reconstruction_v3.py tests/test_design_assisted_r309.py -q

The demo writes outputs/synthetic_demo/ with DXF, scene-state JSON, topology,
source hashes, candidate audit, and a machine-readable demo report. It exits
nonzero if the scene is invalid or the expected supported connection is absent.

For the point-cloud extraction and cross-height pipeline:

    python -m pip install -e ".[extraction,dev]"
    python -m parking_pipeline.reconstruction_r309 --config configs/R309_portable.yaml

Change the input path in the YAML before the second command; no field point
cloud is silently downloaded. Its output path is resolved by the existing
pipeline from the current working directory; run from this release directory.
The R309 entrypoint is point-cloud reconstruction, not the complete
design-assisted method by itself. The joint modules provide design coupling.

## Code map

- parking_pipeline/evidence_association.py: cross-height fragments and source ownership.
- parking_pipeline/v5_evidence.py: unique-voxel evidence and height windows.
- parking_pipeline/reconstruction_r309.py: point-cloud reconstruction orchestration.
- parking_pipeline/joint_reconstruction_v3.py: shared scene state, alternating updates, supported relations, and export.
- parking_pipeline/design_assisted_r309.py: design correspondences and candidate construction.
- parking_pipeline/design_assisted_reconstruction.py: alternative evidence-aware design-assisted pipeline.
- parking_pipeline/topology_v6.py: candidate generation and conflict-aware selection.

Modules are released for inspection and reuse. They are not certified to
reproduce the 86.44% / 92.31% manuscript results: matching off-machine code,
predictions, exact reference geometry, and full execution logs are unavailable
in the imported result record. See docs/REPRODUCIBILITY.md.

## Data and redistribution

The released data are the reported numerical tables and synthetic inputs.
Raw facility scans, engineering drawings, semantic checkpoints, third-party
model code, and historical reference geometry are NOT included in the public
archives. data/DATA_INVENTORY.json records local availability and exclusions
without copying large or rights-uncleared assets.

Do not claim that this initial release contains the complete ICPARK benchmark.
Do not apply this repository's license to excluded material. Supplementary
field-data release needs redistribution authorization and current-run matching.

## Verify

    python scripts/verify_release.py
    python -m pytest tests -q

The verification script checks the file manifest, syntax, relative paths in
public metadata, result provenance, CSV row counts, and required licenses. It
does not rerun the scene benchmark. Archive SHA-256 values are supplied in the
homepage download manifest and SHA256SUMS.txt.

## Publish

See docs/PUBLISHING.md for the repository and static-site handoff. No remote
push or release upload is performed by these build/test scripts. The original
manuscript and third-party software keep their own licensing status.
