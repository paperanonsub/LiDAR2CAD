# Third-party dependencies

No third-party source trees, pretrained weights, ROS bags, or vendor SDKs
are bundled in this release. Python dependencies are installed separately
and retain their respective upstream licenses.

Core runtime dependencies: NumPy, SciPy, Shapely, ezdxf, and Matplotlib.
Point-cloud extraction additionally uses Open3D, scikit-image, scikit-learn,
OpenCV, PyYAML, NetworkX, and pyproj. Consult the installed distributions'
license files when redistributing an environment or container.

The research workspace mentions Sonata / Point Transformer V3 features and
other baseline models. This release does not distribute those models or
their weights and does not relicense them under MIT or CC BY 4.0.

The original project modules are included without importing their external
third-party source directories. SOURCE_MANIFEST.json records file provenance.
No complete legal or intellectual-property audit is claimed.
