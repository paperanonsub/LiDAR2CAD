# Repository and static-site publication

This package is prepared locally. It has not been pushed to a public service.
The project workspace has no configured Git repository or supplied repository
URL, and no GitHub CLI was found during preparation. Do not invent a URL.

## Before the first public upload

- Choose the owner or organization and repository name.
- Confirm MIT for original code and CC BY 4.0 for the selected original data.
- Review the source manifest, data card, exclusions, and reproducibility note.
- Confirm whether publication should remain anonymous during peer review.
- Do not add raw scans, drawings, weights, caches, or credentials by wildcard.

## Publish this curated folder, not the working research directory

After creating the intended empty repository and signing in using your own
normal Git workflow, run these commands from this directory. Replace the
remote URI with the actual repository address supplied by its owner:

    git init -b main
    git add README.md LICENSE LICENSE-DATA.md THIRD_PARTY_NOTICES.md pyproject.toml .gitignore
    git add parking_pipeline lidar2outline tests scripts configs docs data SOURCE_MANIFEST.json
    git commit -m "Initial LiDAR2CAD source and reported-data release"

Then add the real remote and push. No remote is embedded in this document,
and none of the release tools runs a push or creates a public repository.

## Homepage downloads

The companion static homepage links to locally generated source and data
archives under assets/releases/. Deploying the homepage with that directory
publishes those archives. Large field inputs are not part of them. After
a repository URL is supplied, add a repository link in the resources section
and homepage header without replacing the direct downloads.
