# Data license and attribution

SPDX-License-Identifier: CC-BY-4.0

Copyright (c) 2026 LiDAR2CAD contributors.

The original tabular exports in data/reported_results/ and the synthetic
inputs in data/synthetic_demo/ are licensed under Creative Commons
Attribution 4.0 International:

https://creativecommons.org/licenses/by/4.0/

Full license terms: https://creativecommons.org/licenses/by/4.0/legalcode.en

Attribution: "LiDAR2CAD contributors, LiDAR2CAD initial code and reported-data
release, 2026." Retain the source/provenance metadata and indicate changes.
The license URI is provided as part of the license notice.

The following are not covered by this grant: raw facility scans, engineering
drawings, historical field reference geometry, semantic/model weights,
third-party code, the manuscript PDF, and its figures. These are excluded
from the code/data archives. Inclusion in the local research workspace does
not establish a right to redistribute or relicense them.

Code uses the separate MIT license in LICENSE. The licenses do not imply
independent verification of numerical results or grant rights the
contributors do not hold. The license choices apply only to the original
release materials selected in response to the request to open-source them.
