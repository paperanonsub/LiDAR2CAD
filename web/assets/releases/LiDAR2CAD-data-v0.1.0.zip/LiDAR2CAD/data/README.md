# Released data

There are two intentionally separate data categories:

1. reported_results/: author-confirmed off-machine numerical results, their
   original provenance JSON, lossless per-table CSV exports, and manuscript
   table source files. These are reported aggregates, not raw benchmark data.
2. synthetic_demo/: deterministic artificial walls, design segments, and
   sampled points for an executable example. Not collected at a real facility,
   not ground truth for the paper, and never used to support its scores.

DATA_INVENTORY.json lists relevant field inputs that exist locally but are
excluded from these archives, and explicitly marks the missing current-run
artifacts. Sizes are logical file sizes; some workspace inputs are hard links.

The released original data use CC BY 4.0 as scoped in ../LICENSE-DATA.md.
Field-data redistribution authorization and matching exact experimental
versions remain necessary before calling this a complete benchmark release.
